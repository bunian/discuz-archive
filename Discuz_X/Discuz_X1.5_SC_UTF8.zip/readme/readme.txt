+----------------------------------+
 Discuz! X 社区软件系统简介
+----------------------------------+
Crossday Discuz! Board（以下简称 Discuz!，中国国家版权局著作权登记号 2008SR11708
）是康盛创想(北京)科技有限公司（英文简称Comsenz）推出的一套通用的社区论坛软件系
统。作为国内最大的社区软件及服务提供商，Comsenz旗下的 Discuz! 产品，无论在功能、
稳定性、负载能力、安全保障等方面都居于国内外同类产品领先地位，是全球成熟度最高、
覆盖率最大的论坛软件系统之一。

+----------------------------------+
 Discuz! X 社区软件的下载
+----------------------------------+
您可以随时从我们的官方下载站下载到最新版本，以及各种补丁
http://download.comsenz.com/DiscuzX/

+----------------------------------+
 Discuz! X 社区软件的环境需求
+----------------------------------+
1. 可用的 www 服务器，如 Apache、Zeus、IIS 等
2. php 4.3.0 及以上
3. Zend Optimizer 2.5.7 及以上
4. MySQL 3.23 及以上，仅针对 MySQL 版

+----------------------------------+
 Discuz! X 社区软件的安装
+----------------------------------+
1. 上传 upload 目录中的文件到服务器
2. 设置目录属性（windows 服务器可忽略这一步）
	以下这些目录需要可读写权限
	./config
	./data 含子目录
3. 执行安装脚本 /install/
   请在浏览器中运行 install 程序，即访问 http://您的域名/论坛目录/install/
4. 参照页面提示，进行安装，直至安装完毕

+----------------------------------+
 Discuz! X 软件的技术支持
+----------------------------------+
当您在安装、升级、日常使用当中遇到疑难，请您到以下站点获取技术支持。

Discuz! 讨论区：          http://www.discuz.net
Discuz! 使用手册:         http://faq.comsenz.com/usersguide/discuz
Discuz! 风格下载：        http://www.comsenz.com/downloads/styles/discuz
Discuz! 插件下载：        http://www.comsenz.com/downloads/plugins/discuz
Discuz! 相关产品:         http://www.comsenz.com/downloads/install

Discuz! 商业授权购买：    http://www.comsenz.com/purchase/discuz
Discuz! 商业用户支持：    http://www.comsenz.com/customer/
