<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: portal_view.php 9843 2010-05-05 05:38:57Z wangjinbo $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$aid = empty($_GET['aid'])?0:intval($_GET['aid']);
if(empty($aid)) {
	showmessage("view_no_article_id");
}
$article = DB::fetch_first("SELECT * FROM ".DB::table('portal_article_title')." WHERE aid='$aid'");
if(empty($article)) {
	showmessage("view_article_no_exist");
}
if($article['url']) {
	dheader("location:{$article['url']}");
	exit();
}

$cat = category_remake($article['catid']);

$article['pic'] = pic_get($article['pic'], 'portal', $article['thumb'], $article['remote']);

$article_count = DB::fetch_first("SELECT * FROM ".DB::table('portal_article_count')." WHERE aid='$aid'");
if($article_count) $article = array_merge($article_count, $article);

$page = intval($_GET['page']);
if($page<1) $page = 1;
$start = $page-1;

$content = array();
$multi = '';

$query = DB::query("SELECT * FROM ".DB::table('portal_article_content')." WHERE aid='$aid' ORDER BY pageorder LIMIT $start,1");
$content = DB::fetch($query);

require_once libfile('function/blog');
$content['content'] = blog_bbcode($content['content']);

$multi = multi($article['contents'], 1, $page, "portal.php?mod=view&aid=$aid");

$article['related'] = array();
$query = DB::query("SELECT a.aid,a.title
	FROM ".DB::table('portal_article_related')." r
	LEFT JOIN ".DB::table('portal_article_title')." a ON a.aid=r.raid
	WHERE r.aid='$aid'");
while ($value = DB::fetch($query)) {
	$article['related'][] = $value;
}

$common_url = '';
$commentlist = $org = array();
if($article['id'] && $article['idtype']) {

	if($article['idtype'] == 'blogid') {
		$org = db::fetch_first("SELECT * FROM ".db::table('home_blog')." WHERE blogid='$article[id]'");

		$common_url = "home.php?mod=space&uid=$org[uid]&do=blog&id=$article[id]";
		$form_url = "home.php?mod=spacecp&ac=comment";

		$article['commentnum'] = getcount('home_comment', array('id'=>$article['id'], 'idtype'=>'blogid'));
		$query = DB::query("SELECT authorid AS uid, author AS username, dateline, message
			FROM ".DB::table('home_comment')." WHERE id='$article[id]' AND idtype='blogid' ORDER BY dateline DESC LIMIT 0,20");
		while ($value = DB::fetch($query)) {
			$commentlist[] = $value;
		}
	} else {
		$common_url = "forum.php?mod=viewthread&tid=$article[id]";
		$form_url = "forum.php?mod=post&action=reply&tid=$article[id]&replysubmit=yes&infloat=yes&handlekey=fastpost";

		require_once libfile('function/discuzcode');
		$posttable = getposttablebytid($article['id']);

		$article['commentnum'] = getcount($posttable, array('tid'=>$article['id'], 'first'=>'0'));

		$firstpost = DB::fetch_first("SELECT first, authorid AS uid, author AS username, dateline, message, smileyoff, bbcodeoff, htmlon, attachment, pid
			FROM ".DB::table($posttable)." WHERE tid='$article[id]' AND first='1'");
		if(!$org = $firstpost) {
			db::update('portal_article_title', array('id'=>0, 'idtype'=>''), array('aid'=>$aid));
			header("location: portal.php?mod=view&aid=$aid");
			exit();
		}

		$attachpids = -1;
		$attachtags = $aimgs = array();
		$firstpost['message'] = $content['content'];
		if($firstpost['attachment']) {
			if($_G['group']['allowgetattach']) {
				$attachpids .= ",$firstpost[pid]";
				if(preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $firstpost['message'], $matchaids)) {
					$attachtags[$firstpost['pid']] = $matchaids[1];
				}
			} else {
				$firstpost['message'] = preg_replace("/\[attach\](\d+)\[\/attach\]/i", '', $firstpost['message']);
			}
		}

		$post[$firstpost['pid']] = $firstpost;
		if($attachpids != '-1') {
			require_once libfile('function/attachment');
			parseattach($attachpids, $attachtags, $post);
		}

		$content['content'] = $post[$firstpost['pid']]['message'];
		$content['pid'] = $firstpost['pid'];
		unset($post);

		$query = DB::query("SELECT first, authorid AS uid, author AS username, dateline, message, smileyoff, bbcodeoff, htmlon, attachment, pid
			FROM ".DB::table($posttable)." WHERE tid='$article[id]' AND first='0' ORDER BY dateline DESC LIMIT 0,20");
		$attachpids = -1;
		$attachtags = array();
		$_G['group']['allowgetattach'] = 1;
		while ($value = DB::fetch($query)) {
			$value['message'] = discuzcode($value['message'], $value['smileyoff'], $value['bbcodeoff'], $value['htmlon']);
			$commentlist[$value['pid']] = $value;
			if($value['attachment']) {
				$attachpids .= ",$value[pid]";
				if(preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $value['message'], $matchaids)) {
					$attachtags[$value['pid']] = $matchaids[1];
				}
			}
		}

		if($attachpids != '-1') {
			require_once libfile('function/attachment');
			parseattach($attachpids, $attachtags, $commentlist);
		}
	}

} else {

	$common_url = "portal.php?mod=comment&aid=$aid";
	$form_url = "portal.php?mod=portalcp&ac=comment";

	$query = DB::query("SELECT * FROM ".DB::table('portal_comment')." WHERE aid='$aid' ORDER BY cid DESC LIMIT 0,20");
	while ($value = DB::fetch($query)) {
		$value['allowop'] = 1;
		$commentlist[] = $value;
	}
}

$hash = md5($article['uid']."\t".$article['dateline']);
$id = $article['aid'];
$idtype = 'aid';

loadcache('click');
$clicks = empty($_G['cache']['click']['aid'])?array():$_G['cache']['click']['aid'];
$maxclicknum = 0;
foreach ($clicks as $key => $value) {
	$value['clicknum'] = $article["click{$key}"];
	$value['classid'] = mt_rand(1, 4);
	if($value['clicknum'] > $maxclicknum) $maxclicknum = $value['clicknum'];
	$clicks[$key] = $value;
}

$clickuserlist = array();
$query = DB::query("SELECT * FROM ".DB::table('home_clickuser')."
	WHERE id='$id' AND idtype='$idtype'
	ORDER BY dateline DESC
	LIMIT 0,24");
while ($value = DB::fetch($query)) {
	$value['clickname'] = $clicks[$value['clickid']]['name'];
	$clickuserlist[] = $value;
}

if($article_count) {
	DB::query("UPDATE ".DB::table('portal_article_count')." SET catid='$article[catid]', viewnum=viewnum+1 WHERE aid='$aid'");
} else {
	DB::insert('portal_article_count', array(
		'aid'=>$aid,
		'catid'=>$article['catid'],
		'dateline'=>$article['dateline'],
		'viewnum'=>1));
}

$article['dateline'] = dgmdate($article['dateline']);

$navtitle = $article['title'].($page>1?" ( $page )":'').' - '.$cat['catname'].' -';
$metadescription = $article['summary'];

include_once template("diy:portal/view:{$article['catid']}");

?>