<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: config_global_default.php 11023 2010-05-20 02:23:09Z monkey $
 */

$_config = array();

// 數據庫服務器設置
$_config['db']['map'] = array();
$_config['db'][1]['dbhost']  		= 'localhost';		// 服務器地址
$_config['db'][1]['dbuser']  		= 'root';		// 用戶
$_config['db'][1]['dbpw'] 	 	= 'root';		// 密碼
$_config['db'][1]['dbcharset'] 		= 'utf8';		// 字符集
$_config['db'][1]['pconnect'] 		= 0;			// 是否持續連接
$_config['db'][1]['dbname']  		= 'ultrax';		// 數據庫
$_config['db'][1]['tablepre'] 		= 'pre_';		// 表名前綴

// 內存服務器優化設置（以下設置需要PHP擴展組件支持，其中 memcache 優先於其他設置，當 memcache 無法啟用時，會自動開啟另外的兩種優化模式）
//  -----------------  CONFIG MEMORY  ----------------- //
$_config['memory']['prefix'] = 'discuz_';
$_config['memory']['eaccelerator'] = 1;				// 啟動對 eaccelerator 的支持
$_config['memory']['xcache'] = 1;				// 啟動對 xcache 的支持
$_config['memory']['memcache']['server'] = '';			// memcache 服務器地址
$_config['memory']['memcache']['port'] = 11211;			// memcache 服務器端口
$_config['memory']['memcache']['pconnect'] = 1;			// memcache 是否長久連接
$_config['memory']['memcache']['timeout'] = 1;			// memcache 服務器連接超時

//  -----------------  CONFIG CACHE  ----------------- //
$_config['cache']['main']['type'] = '';

//  -----------------  CONFIG default CACHE  ----------------- //
$_config['cache']['main']['file']['path'] = 'data/ultraxcache';
$_config['cache']['type'] 			= 'sql';	// 緩存類型 file=文件緩存, sql=數據庫緩存

// 頁面輸出設置
$_config['output']['charset'] 			= 'utf-8';	// 頁面字符集
$_config['output']['forceheader']		= 1;		// 強制輸出頁面字符集，用於避免某些環境亂碼
$_config['output']['gzip'] 			= 0;		// 是否採用 Gzip 壓縮輸出
$_config['output']['tplrefresh'] 		= 1;		// 模板自動刷新開關 0=關閉, 1=打開
$_config['output']['language'] 			= 'zh_tw';	// 頁面語言 zh_cn/zh_tw
$_config['output']['staticurl'] 		= 'static/';	// 站點靜態文件路徑，「/」結尾

// COOKIE 設置
$_config['cookie']['cookiepre'] 		= 'uchome_'; 	// COOKIE前綴
$_config['cookie']['cookiedomain'] 		= ''; 		// COOKIE作用域
$_config['cookie']['cookiepath'] 		= '/'; 		// COOKIE作用路徑

// 默認程序以及域名綁定設置
$_config['app']['default']			= 'forum';
$_config['app']['domain']['forum']		= '';		// 論壇綁定域名
$_config['app']['domain']['group']		= '';		// 群組綁定域名
$_config['app']['domain']['home']		= '';		// 用戶中心綁定域名
$_config['app']['domain']['portal']		= '';		// 門戶綁定域名
$_config['app']['domain']['mobile']		= '';		// 手機模式綁定域名
$_config['app']['domain']['default']		= '';		// 除去上面的域名之外的地址綁定的域名

// 站點安全設置
$_config['security']['authkey']			= 'asdfasfas';	// 站點加密密鑰
$_config['security']['urlxssdefend']		= true;		// 自身 URL XSS 防禦
$_config['security']['attackevasive']		= 0;		// CC 攻擊防禦 1|2|4

$_config['admincp']['founder']			= '1';		// 站點創始人：擁有站點管理後台的最高權限，每個站點可以設置 1名或多名創始人
								// 可以使用uid，也可以使用用戶名；多個創始人之間請使用逗號",」分開;
$_config['admincp']['forcesecques']		= 0;		// 管理人員必須設置安全提問才能進入系統設置 0=否, 1=是[安全]
$_config['admincp']['checkip']			= 1;		// 後台管理操作是否驗證管理員的 IP, 1=是[安全], 0=否。僅在管理員無法登陸後台時設置 0。
$_config['admincp']['runquery']			= 1;		// 是否允許後台運行 SQL 語句 1=是 0=否[安全]
$_config['admincp']['dbimport']			= 1;		// 是否允許後台恢復論壇數據  1=是 0=否[安全]

// 家園二級域名設置
$_config['home']['allowdomain']			= 0;		// 個人空間是否啟用二級域名 1=是 0=否
$_config['home']['domainroot']			= '';		// 二級域名根域名，例如：discuz.net
$_config['home']['holddomain'] = 'www,space,home,forum,portal';	// 保留的二級域名，多個之間使用逗號",」分開

?>