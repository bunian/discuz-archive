<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admincp_doing.php 6946 2010-03-27 03:54:50Z chenchunshao $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$detail = $_G['gp_detail'];
$users = $_G['gp_users'];
$userip = $_G['gp_userip'];
$keywords = $_G['gp_keywords'];
$lengthlimit = $_G['gp_lengthlimit'];
$starttime = $_G['gp_starttime'];
$endtime = $_G['gp_endtime'];
$searchsubmit = $_G['gp_searchsubmit'];
$doids = $_G['gp_doids'];
$ppp = $_G['ppp'];

cpheader();

if(!submitcheck('doingsubmit')) {
	$starttime = !preg_match("/^(0|\d{4}\-\d{1,2}\-\d{1,2})$/", $starttime) ? dgmdate(TIMESTAMP - 86400 * 7, 'Y-n-j') : $starttime;
	$endtime = $_G['adminid'] == 3 || !preg_match("/^(0|\d{4}\-\d{1,2}\-\d{1,2})$/", $endtime) ? dgmdate(TIMESTAMP, 'Y-n-j') : $endtime;

	shownav('topic', 'nav_doing');
	showsubmenusteps('nav_doing', array(
		array('doing_search', !$searchsubmit),
		array('nav_doing', $searchsubmit)
	));
	showtips('doing_tips');
	echo <<<EOT
<script type="text/javascript" src="static/js/forum_calendar.js"></script>
<script type="text/JavaScript">
function page(number) {
	$('doingforum').page.value=number;
	$('doingforum').searchsubmit.click();
}
</script>
EOT;
	showtagheader('div', 'searchposts', !$searchsubmit);
	showformheader("doing", '', 'doingforum');
	showhiddenfields(array('page' => $page));
	showtableheader();
	showsetting('doing_search_detail', 'detail', $detail, 'radio');
	showsetting('doing_search_user', 'users', $users, 'text');
	showsetting('doing_search_ip', 'userip', $userip, 'text');
	showsetting('doing_search_keyword', 'keywords', $keywords, 'text');
	showsetting('doing_search_lengthlimit', 'lengthlimit', $lengthlimit, 'text');
	showsetting('doing_search_time', array('starttime', 'endtime'), array($starttime, $endtime), 'daterange');
	showsubmit('searchsubmit');
	showtablefooter();
	showformfooter();
	showtagfooter('div');

} else {

	$doids = authcode($doids, 'DECODE');
	$doidsadd = $doids ? explode(',', $doids) : $_G['gp_delete'];
	include_once libfile('function/delete');
	$deletecount = count(deletedoings($doidsadd));
	$cpmsg = cplang('doing_succeed', array('deletecount' => $deletecount));

?>
<script type="text/JavaScript">alert('<?=$cpmsg?>');parent.$('doingforum').searchsubmit.click();</script>
<?php

}

if(submitcheck('searchsubmit')) {

	$doids = $doingcount = '0';
	$sql = $error = '';

	$keywords = trim($keywords);
	$users = trim($users);

	if($users != '') {
		$uids = '-1';
		$query = DB::query("SELECT uid FROM ".DB::table('common_member')." WHERE username IN ('".str_replace(',', '\',\'', str_replace(' ', '', $users))."')");
		while($member = DB::fetch($query)) {
			$uids .= ",$member[uid]";
		}
		$sql .= " AND d.uid IN ($uids)";
	}
	if($useip != '') {
		$sql .= " AND d.ip LIKE '".str_replace('*', '%', $useip)."'";
	}
	if($keywords != '') {
		$sqlkeywords = '';
		$or = '';
		$keywords = explode(',', str_replace(' ', '', $keywords));

		for($i = 0; $i < count($keywords); $i++) {
			if(preg_match("/\{(\d+)\}/", $keywords[$i])) {
				$keywords[$i] = preg_replace("/\\\{(\d+)\\\}/", ".{0,\\1}", preg_quote($keywords[$i], '/'));
				$sqlkeywords .= " $or d.message REGEXP '".$keywords[$i]."'";
			} else {
				$sqlkeywords .= " $or d.message LIKE '%".$keywords[$i]."%'";
			}
			$or = 'OR';
		}
		$sql .= " AND ($sqlkeywords)";
	}

	if($lengthlimit != '') {
		$lengthlimit = intval($lengthlimit);
		$sql .= " AND LENGTH(d.message) < $lengthlimit";
	}

	if($starttime != '0') {
		$starttime = strtotime($starttime);
		$sql .= " AND d.dateline>'$starttime'";
	}

	if($_G['adminid'] == 1 && $endtime != dgmdate(TIMESTAMP, 'Y-n-j')) {
		if($endtime != '0') {
			$endtime = strtotime($endtime);
			$sql .= " AND d.dateline<'$endtime'";
		}
	} else {
		$endtime = TIMESTAMP;
	}
	if(($_G['adminid'] == 2 && $endtime - $starttime > 86400 * 16) || ($_G['adminid'] == 3 && $endtime - $starttime > 86400 * 8)) {
		$error = 'prune_mod_range_illegal';
	}

	if(!$error) {
		if($detail) {
			$pagetmp = $page;
			do{
				$query = DB::query("SELECT d.uid, d.doid, d.username, d.message, d.ip, d.dateline FROM ".DB::table('home_doing')." d WHERE 1 $sql ORDER BY d.dateline DESC LIMIT ".(($pagetmp - 1) * $ppp).",{$ppp} ");
				$pagetmp--;
			} while(!DB::num_rows($query) && $pagetmp);
			$doings = '';

			while($doing = DB::fetch($query)) {
				$doing['dateline'] = dgmdate($doing['dateline']);
				$doings .= showtablerow('', '', array(
					"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$doing[doid]\"  />",
					"<a href=\"home.php?mod=space&uid=$doing[uid]\" target=\"_blank\">$doing[username]</a>",
					$doing['message'],
					$doing['ip'],
					$doing['dateline']
				), TRUE);
			}
			$doingcount = DB::result_first("SELECT count(*) FROM ".DB::table('home_doing')." d WHERE 1 $sql");
			$multi = multi($doingcount, $ppp, $page, ADMINSCRIPT."?action=doing");
			$multi = preg_replace("/href=\"".ADMINSCRIPT."\?action=doing&amp;page=(\d+)\"/", "href=\"javascript:page(\\1)\"", $multi);
			$multi = str_replace("window.location='".ADMINSCRIPT."?action=doing&amp;page='+this.value", "page(this.value)", $multi);

		} else {
			$doingcount = 0;
			$query = DB::query("SELECT doid FROM ".DB::table('home_doing')." d WHERE 1 $sql");
			while($doing = DB::fetch($query)) {
				$doids .= ','.$doing['doid'];
				$doingcount++;
			}
			$multi = '';
		}

		if(!$doingcount) {
			$error = 'doing_post_nonexistence';
		}
	}

	showtagheader('div', 'postlist', $searchsubmit);
	showformheader('doing&frame=no', 'target="doingframe"');
	showhiddenfields(array('doids' => authcode($doids, 'ENCODE')));
	showtableheader(cplang('doing_result').' '.$doingcount.' <a href="###" onclick="$(\'searchposts\').style.display=\'\';$(\'postlist\').style.display=\'none\';" class="act lightlink normal">'.cplang('research').'</a>', 'fixpadding');

	if($error) {
		echo "<tr><td class=\"lineheight\" colspan=\"15\">$lang[$error]</td></tr>";
	} else {
		if($detail) {
			showsubtitle(array('', 'author', 'message', 'ip', 'time'));
			echo $doings;
		}
	}

	showsubmit('doingsubmit', 'delete', $detail ? 'del' : '', '', $multi);
	showtablefooter();
	showformfooter();
	echo '<iframe name="doingframe" style="display:none"></iframe>';
	showtagfooter('div');

}

?>