<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: discuz_version.php 13241 2010-07-23 03:16:48Z cnteacher $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@define('DISCUZ_VERSION', 'X1');
@define('DISCUZ_RELEASE', '20100723');

?>