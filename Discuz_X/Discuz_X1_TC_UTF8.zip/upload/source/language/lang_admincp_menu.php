<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_admincp_menu.php 9689 2010-05-04 08:33:00Z xupeng $
 */

$lang = array
(


	'header_index' => '首頁',
	'header_global' => '全局',
	'header_forum' => '論壇',
	'header_user' => '用戶',
	'header_topic' => '內容',
	'header_extended' => '擴展',
	'header_plugin' => '插件',
	'header_style' => '界面',
	'header_adv' => '廣告',
	'header_tools' => '工具',
	'header_uc' => 'UCenter',
	'header_welcome' => '您好',
	'header_logout' => '退出',
	'header_bbs' => '站點首頁',
	'header_portal' => '門戶',
	'header_group' => '群組',
	'header_founder' => '站長',
	'header_addons' => '擴展中心',


	'menu_home' => '管理中心首頁',
	'menu_home_clearhistorymenus' => '清空歷史操作',

	'menu_setting_basic' => '站點信息',
	'menu_setting_access' => '註冊與訪問',
	'menu_setting_customnav' => '導航欄',
	'menu_setting_styles' => '界面設置',
	'menu_setting_optimize' => '優化設置',
	'menu_setting_functions' => '站點功能',
	'menu_setting_user' => '用戶權限',
	'menu_setting_credits' => '積分設置',
	'menu_setting_mail' => '郵件設置',
	'menu_setting_sec' => '防灌水設置',
	'menu_setting_datetime' => '時間設置',
	'menu_setting_attachments' => '上傳設置',
	'menu_setting_uc' => 'UCenter 設置',
	'menu_setting_uchome' => 'UCHome 設置',
	'menu_setting_home' => '空間設置',
	'menu_setting_manyou' => 'Manyou 設置',
	'menu_setting_search' => '搜索設置',
	'menu_setting_district' => '地區設置',

	'menu_forums' => '版塊管理',
	'menu_forums_merge' => '版塊合併',
	'menu_forums_threadtypes' => '主題分類',
	'menu_forums_infotypes' => '分類信息',
	'menu_forums_infooption' => '分類信息選項',

	'menu_members_add' => '添加用戶',
	'menu_members_edit' => '用戶管理',
	'menu_members_newsletter' => '發送通知',
	'menu_members_edit_ban_user' => '禁止用戶',
	'menu_members_ipban' => '禁止 IP',
	'menu_members_credits' => '積分獎懲',
	'menu_members_profile' => '用戶欄目',
	'menu_members_verify' => '資料審核',
	'menu_members_stat' => '資料統計',
	'menu_moderate_modmembers' => '審核新用戶',
	'menu_profilefields' => '用戶欄目定制',
	'menu_admingroups' => '管理組',
	'menu_usergroups' => '用戶組',
	'menu_hotuser' => '明星會員',
	'menu_defaultuser' => '推薦好友',

	'menu_moderate_posts' => '審核帖子',
	'menu_maint_threads' => '主題管理',
	'menu_maint_prune' => '批量刪帖',
	'menu_maint_attaches' => '附件管理',
	'menu_posting_tags' => '標籤管理',
	'menu_posting_censors' => '詞語過濾',
	'menu_maint_report' => '用戶舉報',
	'menu_threads_forumstick' => '多版塊置頂',
	'menu_post_position_index' => '帖子優化',
	'menu_maint_doing' => '記錄管理',
	'menu_maint_blog' => '日誌管理',
	'menu_maint_feed' => '動態管理',
	'menu_maint_album' => '相冊管理',
	'menu_maint_pic' => '圖片管理',
	'menu_maint_comment' => '評論/留言管理',
	'menu_maint_share' => '分享管理',

	'menu_posting_attachtypes' => '附件類型尺寸',
	'menu_moderate_recyclebin' => '主題回收站',

	'menu_founder' => '站點信息',
	'menu_founder_perm' => '後台管理團隊',
	'menu_founder_groupperm' => '編輯團隊職務權限 - {group}',
	'menu_founder_permgrouplist' => '編輯權限 - {perm}',
	'menu_founder_memberperm' => '編輯團隊成員 - {username}',

	'menu_addons' => '擴展中心',
	'menu_plugins' => '插件',
	'menu_tasks' => '站點任務',
	'menu_magics' => '道具中心',
	'menu_medals' => '勳章中心',
	'menu_misc_help' => '站點幫助',
	'menu_google' => 'Google 搜索',
	'menu_ec' => '電子商務',

	'menu_styles' => '風格管理',
	'menu_styles_templates' => '模板管理',
	'menu_posting_smilies' => '表情管理',
	'menu_click' => '表態動作',
	'menu_thread_icon' => '主題圖標',
	'menu_thread_stamp' => '主題圖章',
	'menu_posting_editor' => '編輯器設置',
	'menu_misc_onlinelist' => '在線列表圖標',

	'menu_misc_link' => '友情鏈接',
	'memu_focus_topic' => '站長推薦',
	'menu_adv_custom' => '站點廣告',

	'menu_misc_announce' => '站點公告',
	'menu_tools_updatecaches' => '更新緩存',
	'menu_tools_postposition' => '高樓貼優化',
	'menu_tools_updatecounters' => '更新統計',
	'menu_tools_javascript' => '數據調用',
	'menu_tools_relatedtag' => ' 標籤聚合',
	'menu_tools_creditwizard' => '積分策略嚮導',
	'menu_tools_fileperms' => '文件權限檢查',
	'menu_tools_filecheck' => '文件校驗',
	'menu_forum_scheme' => '站點方案管理',
	'menu_db' => '數據庫',
	'menu_postsplit' => '帖子分表',
	'menu_threadsplit' => '主題分表',
	'menu_logs' => '運行記錄',
	'menu_custommenu_manage' => '常用操作管理',
	'menu_misc_cron' => '計劃任務',

	'menu_article' => '文章管理',
	'menu_portalcategory' => '文章分類',
	'menu_blogcategory' => '日誌分類',
	'menu_albumcategory' => '相冊分類',
	'menu_block' => '模塊管理',
	'menu_blockstyle' => '模塊樣式',
	'menu_topic' => '專題管理',

	'menu_group_setting' => '群組設置',
	'menu_group_type' => '群組分類',
	'menu_group_manage' => '群組管理',
	'menu_group_userperm' => '群主權限',
	'menu_group_level' => '群組等級',

	'admincp_title' => $_G['setting']['bbname'].' 管理中心',

);

?>