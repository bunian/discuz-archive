<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_friend.php 6757 2010-03-25 09:01:29Z cnteacher $
 */

$lang = array(
	'friend_group_default' => '其他',
	'friend_group_1' => '通過本站認識',
	'friend_group_2' => '通過活動認識',
	'friend_group_3' => '通過朋友認識',
	'friend_group_4' => '親人',
	'friend_group_5' => '同事',
	'friend_group_6' => '同學',
	'friend_group_7' => '不認識',
	'friend_group_more' => '自定義{num}'
);

?>