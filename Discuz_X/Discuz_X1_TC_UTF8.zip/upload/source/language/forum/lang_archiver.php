<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_archiver.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(

	'page' => '頁',
	'replies' => '篇回復',
	'anonymous' => '匿名',
	'full_version' => '查看完整版本',
	'forum_nonexistence' => '您沒有權限訪問這個論壇的存檔或該論壇不存在。',
	'thread_nonexistence' => '您沒有權限查看這個話題或該話題不存在。',
	'post_time' => '發表於',

);

?>