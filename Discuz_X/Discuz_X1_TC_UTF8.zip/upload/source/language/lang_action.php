<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_action.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(
	0 => '註冊/登錄',
	1 => '空間',
	2 => '論壇',
	3 => '群組',
	4 => '首頁',

	100 => '其他',
	127 => '插件',

);

?>