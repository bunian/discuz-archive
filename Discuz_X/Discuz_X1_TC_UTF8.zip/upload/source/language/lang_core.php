<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_core.php 10215 2010-05-07 08:58:25Z maruitao $
 */

$lang = array
(
	'nextpage' => '下一頁',
	'prevpage' => '上一頁',
	'date' => array(
		'before' => '前',
		'day' => '天',
		'yday' => '昨天',
		'byday' => '前天',
		'hour' => '小時',
		'half' => '半',
		'min' => '分鐘',
		'sec' => '秒',
		'now' => '現在',
	),
	'yes' => '是',
	'no' => '否',
	'weeks' => array(
		1 => '週一',
		2 => '週二',
		3 => '週三',
		4 => '週四',
		5 => '週五',
		6 => '週六',
		7 => '週日',
	),
	'dot' => '、',
	'archive' => '存檔',
	'portal' => '門戶',
	'end' => '末尾',

	'seccode_image_tips' => '輸入下圖中的字符<br />',
	'seccode_image_ani_tips' => '輸入下面動畫圖片中最大的字符<br />',
	'seccode_sound_tips' => '輸入你聽到的字符<br />',
	'secqaa_tips' => '輸入下面問題的答案<br />',
);

?>