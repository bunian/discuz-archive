<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_feed.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(
	'feed_name' => '空間 動態廣告',
	'feed_desc' => '展現方式: 日誌廣告顯示於動態的上方。',
);

?>