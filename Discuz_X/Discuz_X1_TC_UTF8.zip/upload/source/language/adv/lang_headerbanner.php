<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_headerbanner.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(
	'headerbanner_name' => '全局 頁頭通欄廣告',
	'headerbanner_desc' => '展現方式: 頁頭通欄廣告顯示於頁面上方，通常使用 468x60 圖片或 Flash 的形式。當前頁面有多個頁頭通欄廣告時，系統會隨機選取其中之一顯示。<br />價值分析: 由於能夠在頁面打開的第一時間將廣告內容展現於最醒目的位置，因此成為了網頁中價位最高、最適合進行商業宣傳或品牌推廣的廣告類型之一。',
	'headerbanner_fids' => '投放版塊',
	'headerbanner_fids_comment' => '設置廣告投放的論壇版塊，當廣告投放範圍中包含「論壇」時有效',
	'headerbanner_groups' => '投放群組分類',
	'headerbanner_groups_comment' => '設置廣告投放的群組分類，當廣告投放範圍中包含「群組」時有效',
);

?>