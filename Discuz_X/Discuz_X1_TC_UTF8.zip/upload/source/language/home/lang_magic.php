<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_magic.php 7803 2010-04-13 09:48:39Z monkey $
 */

$lang = array
(
	'target_tid' => '目標主題tid',
	'target_pid' => '目標帖子pid',
	'target_username' => '目標用戶名',
	'magics_type_1' => '帖子類',
	'magics_type_2' => '會員類',
	'magics_type_3' => '其他類',

	'CCK_color' => '顏色',
	'MOK_info' => '獲得的錢幣數目規則：大於1且小於購買價格150%的隨機數',
	'CODE_info' => '獲得Discuz!測試邀請碼一個',
	'MVK_target' => '要移動到的版面',
	'SOFA_message' => '一道閃電劃破湛藍的天空，隨著一聲巨響，沙發被我搶了！哈哈！',
);

?>