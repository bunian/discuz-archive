<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_portalcategory.php 6757 2010-03-25 09:01:29Z cnteacher $
 */

$lang = array
(
	'portalcategory_catid' => '父級欄目',
	'portalcategory_catid_comment' => '選擇父級欄目',
	'portalcategory_orderby' => '排序方式',
	'portalcategory_orderby_comment' => '設置以哪一字段或方式對分類進行排序',
	'portalcategory_orderby_displayorder' => '按默認順序排序',
	'portalcategory_orderby_articles' => '按文章數倒序',
);

?>