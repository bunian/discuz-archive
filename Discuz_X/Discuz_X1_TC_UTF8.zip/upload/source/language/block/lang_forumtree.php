<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_forumtree.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(
	'forumtree_name' => '版塊樹形列表',
	'forumtree_desc' => '樹形顯示版塊列表',
	'forumtree_fids' => '顯示的版塊',
	'forumtree_fids_comment' => '設置允許顯示的版塊，留空為顯示所有版塊',
);

?>