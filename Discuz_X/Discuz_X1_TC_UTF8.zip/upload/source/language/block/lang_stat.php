<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_blank.php 6757 2010-03-25 09:01:29Z cnteacher $
 */

$lang = array
(
	'stat_option' => '統計選項',
	'stat_option_posts' => '發貼總數',
	'stat_option_groups' => '群組總數',
	'stat_option_members' => '會員總數',
	'stat_option_groupmembers' => '群組成員數',
	'stat_option_groupnewposts' => '群組今日發帖',
	'stat_option_bbsnewposts' => '廣場今日發貼數',
	'stat_option_bbslastposts' => '廣場昨日發貼數',

	'stat_posts' => '帖子',
	'stat_groups' => '群組',
	'stat_members' => '會員',
	'stat_groupmembers' => '成員加入群組',
	'stat_groupnewposts' => '今日發帖',
	'stat_bbsnewposts' => '今日發帖',
	'stat_bbslastposts' => '昨日發帖',
);
?>