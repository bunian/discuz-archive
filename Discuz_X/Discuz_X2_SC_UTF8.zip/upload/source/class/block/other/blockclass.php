<?php

$blockclass = array(
	'name' => lang('blockclass', 'blockclass_other'),
);


?>