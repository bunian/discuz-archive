+----------------------------------+
 Discuz! X 社區軟件系統簡介
+----------------------------------+
Crossday Discuz! Board（以下簡稱 Discuz!，中國國家版權局著作權登記號 2008SR11708
）是康盛創想(北京)科技有限公司（英文簡稱Comsenz）推出的一套通用的社區論壇軟件系
統。作為國內最大的社區軟件及服務提供商，Comsenz旗下的 Discuz! 產品，無論在功能、
穩定性、負載能力、安全保障等方面都居於國內外同類產品領先地位，是全球成熟度最高、
覆蓋率最大的論壇軟件系統之一。

+----------------------------------+
 Discuz! X 社區軟件的下載
+----------------------------------+
您可以隨時從我們的官方下載站下載到最新版本，以及各種補丁
http://download.comsenz.com/DiscuzX/

+----------------------------------+
 Discuz! X 社區軟件的環境需求
+----------------------------------+
1. 可用的 www 服務器，如 Apache、Zeus、IIS 等
2. php 4.3.0 及以上
3. Zend Optimizer 2.5.7 及以上
4. MySQL 3.23 及以上，僅針對 MySQL 版

+----------------------------------+
 Discuz! X 社區軟件的安裝
+----------------------------------+
1. 上傳 upload 目錄中的文件到服務器
2. 設置目錄屬性（windows 服務器可忽略這一步）
	以下這些目錄需要可讀寫權限
	./config
	./data 含子目錄
3. 執行安裝腳本 /install/
   請在瀏覽器中運行 install 程序，即訪問 http://您的域名/論壇目錄/install/
4. 參照頁面提示，進行安裝，直至安裝完畢

+----------------------------------+
 Discuz! X 軟件的技術支持
+----------------------------------+
當您在安裝、升級、日常使用當中遇到疑難，請您到以下站點獲取技術支持。

Discuz! 討論區：          http://www.discuz.net
Discuz! 使用手冊:         http://faq.comsenz.com/usersguide/discuz
Discuz! 風格下載：        http://www.comsenz.com/downloads/styles/discuz
Discuz! 插件下載：        http://www.comsenz.com/downloads/plugins/discuz
Discuz! 相關產品:         http://www.comsenz.com/downloads/install

Discuz! 商業授權購買：    http://www.comsenz.com/purchase/discuz
Discuz! 商業用戶支持：    http://www.comsenz.com/customer/
