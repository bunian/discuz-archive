<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: discuz_version.php 26700 2011-12-20 07:14:45Z cnteacher $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@define('DISCUZ_VERSION', 'X1.5');
@define('DISCUZ_RELEASE', '20111221');

?>