<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: modcp_plugin.php 22550 2011-05-12 05:21:39Z monkey $
 */

if(!defined('IN_DISCUZ') || !defined('IN_MODCP')) {
	exit('Access Denied');
}

$modtpl = $_G['gp_id'];

include pluginmodule($_G['gp_id'], 'modcp_'.$op);

?>