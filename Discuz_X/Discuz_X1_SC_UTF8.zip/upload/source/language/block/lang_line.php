<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_line.php 6757 2010-03-25 09:01:29Z cnteacher $
 */

$lang = array
(
	'line_style' => '分割线样式',
	'line_style_line' => '实线',
	'line_style_dash' => '虚线',
);
?>