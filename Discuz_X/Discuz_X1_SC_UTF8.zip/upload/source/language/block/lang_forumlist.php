<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_forumlist.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(
	'forumlist_fups' => '上级版块',
	'forumlist_fups_comment' => '设置显示某些分类或版块下属的版块',
	'forumlist_titlelength' => '名称长度',
	'forumlist_titlelength_comment' => '设置版块名称显示的最大长度',
	'forumlist_summarylength' => '介绍长度',
	'forumlist_summarylength_comment' => '设置版块介绍显示的最大长度',
	'forumlist_orderby' => '版块排序方式',
	'forumlist_orderby_comment' => '设置以哪一字段或方式对版块进行排序',
	'forumlist_orderby_displayorder' => '按显示顺序顺序排序',
	'forumlist_orderby_threads' => '按主题数倒序排序',
	'forumlist_orderby_todayposts' => '按今日发贴数倒序排序',
	'forumlist_orderby_posts' => '按帖子数倒序排序',
);

?>