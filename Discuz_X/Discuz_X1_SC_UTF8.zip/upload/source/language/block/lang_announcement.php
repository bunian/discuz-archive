<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_blank.php 6757 2010-03-25 09:01:29Z cnteacher $
 */

$lang = array
(
	'announcement_type' => '公告类型',
	'announcement_type_text' => '文字公告',
	'announcement_type_link' => '网站链接',
	'announcement_titlelength' => '标题长度',
	'announcement_summarylength' => '内容长度',
	'announcement_startrow' => '起始位置',
);
?>