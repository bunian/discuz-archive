<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_portalcategory.php 6757 2010-03-25 09:01:29Z cnteacher $
 */

$lang = array
(
	'portalcategory_catid' => '父级栏目',
	'portalcategory_catid_comment' => '选择父级栏目',
	'portalcategory_orderby' => '排序方式',
	'portalcategory_orderby_comment' => '设置以哪一字段或方式对分类进行排序',
	'portalcategory_orderby_displayorder' => '按默认顺序排序',
	'portalcategory_orderby_articles' => '按文章数倒序',
);

?>