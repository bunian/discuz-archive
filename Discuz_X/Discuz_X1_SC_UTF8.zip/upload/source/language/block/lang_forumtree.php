<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_forumtree.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(
	'forumtree_name' => '版块树形列表',
	'forumtree_desc' => '树形显示版块列表',
	'forumtree_fids' => '显示的版块',
	'forumtree_fids_comment' => '设置允许显示的版块，留空为显示所有版块',
);

?>