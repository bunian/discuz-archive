<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_blank.php 6757 2010-03-25 09:01:29Z cnteacher $
 */

$lang = array
(
	'stat_option' => '统计选项',
	'stat_option_posts' => '发贴总数',
	'stat_option_groups' => '群组总数',
	'stat_option_members' => '会员总数',
	'stat_option_groupmembers' => '群组成员数',
	'stat_option_groupnewposts' => '群组今日发帖',
	'stat_option_bbsnewposts' => '广场今日发贴数',
	'stat_option_bbslastposts' => '广场昨日发贴数',

	'stat_posts' => '帖子',
	'stat_groups' => '群组',
	'stat_members' => '会员',
	'stat_groupmembers' => '成员加入群组',
	'stat_groupnewposts' => '今日发帖',
	'stat_bbsnewposts' => '今日发帖',
	'stat_bbslastposts' => '昨日发帖',
);
?>