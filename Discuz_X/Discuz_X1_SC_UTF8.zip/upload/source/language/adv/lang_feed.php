<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_feed.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(
	'feed_name' => '空间 动态广告',
	'feed_desc' => '展现方式: 日志广告显示于动态的上方。',
);

?>