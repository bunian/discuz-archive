<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_action.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

$lang = array
(
	0 => '注册/登录',
	1 => '空间',
	2 => '论坛',
	3 => '群组',
	4 => '首页',

	100 => '其他',
	127 => '插件',

);

?>