﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Discuz.Plugin
{
    public interface ITag
    {
    }
}
