﻿using System;
using System.Text;

namespace Discuz.Config
{
    /// <summary>
    /// Discuz!NT 配置信息类接口
    /// </summary>
    public interface IConfigInfo
    {
    }
}
