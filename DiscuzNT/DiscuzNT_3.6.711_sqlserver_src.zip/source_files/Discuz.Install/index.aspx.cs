using System;

namespace Discuz.Install
{
    public class index : System.Web.UI.Page
    {
        public string preproduct = "Discuz!NT 2.6.x";
        public string productname = "Discuz!NT 3.5.0";

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
