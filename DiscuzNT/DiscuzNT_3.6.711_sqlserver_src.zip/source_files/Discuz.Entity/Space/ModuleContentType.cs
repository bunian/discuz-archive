using System;

namespace Discuz.Entity
{
	/// <summary>
	/// ContentType ��ժҪ˵����
	/// </summary>
	public enum ModuleContentType
	{
		Html,
		HtmlInline,
		Url
	}
}
