using System;

namespace Discuz.Entity
{
	/// <summary>
	/// FeatureType ��ժҪ˵����
	/// </summary>
	public enum FeatureType
	{
		SetPrefs,
		Dynamic_Height,
		SetTitle,
		Tabs,
		Drag,
		Grid,
		MiniMessage,
		Analytics,
		Flash,
		None
	}
}
