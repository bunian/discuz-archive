using System;

namespace Discuz.Entity
{
	/// <summary>
	/// �ҵ�����ʵ��
	/// </summary>
	public class MyTopicInfo : ShowforumPageTopicInfo
	{
        //private string m_forumname = string.Empty;

        ///// <summary>
        ///// �������
        ///// </summary>
        //public string Forumname
        //{
        //    get { return m_forumname; }
        //    set { m_forumname = value; }
        //}

	}
}
