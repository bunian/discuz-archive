﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Discuz.Entity
{
    public enum OrderDirection: int
    {
        ASC,
        DESC
    }
}
