﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Discuz.Entity
{
    public enum FriendsEnum
    {
        RequestList,
        CreateFriendRequest,
        IgnoreRequest,
        DeleteFriendship,
        CreateFriendshipRequest,
        Default,
        PassRequest
    }
}
