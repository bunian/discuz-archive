using System;

namespace Discuz.Common
{
	/// <summary>
	/// DNT�Զ����쳣�ࡣ
	/// </summary>
	public class DNTException : Exception
	{
		public DNTException()
		{
			//
		}


		public DNTException(string msg) : base(msg)
		{
			//
		}
	}
}
