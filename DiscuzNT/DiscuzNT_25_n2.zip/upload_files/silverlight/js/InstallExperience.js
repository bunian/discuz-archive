﻿//Create our install experience html
var installExperienceHTML =  '<div style="position:auto; text-align:left; background-repeat:no-repeat; /*background-image:url(assets/faded_preinstall.png);*/">'; 
    installExperienceHTML += '<div style="">';
    installExperienceHTML += '<div id="menuDiv" class="hintinfo"></div><div id="InstallPromptDiv" style="width:206px;"> </div> </div> <div id="PostInstallGuidance"'; 
    installExperienceHTML += 'style="width:auto; font-weight:bold; font-size:18px; font-family:sans-serif; height:auto; padding-top:20px;text-align:left; color:#3366ff; ';
    installExperienceHTML += 'font-weight:normal; font-size:11pt">&nbsp;</div> </div>';

//calls installandcreatesilverlight method to instantiate silverlight once it is installed
/*
Silverlight.InstallAndCreateSilverlight('1.0', 
			document.getElementById('divPlayer_a74e5260-4189-4d66-babe-a818a4c813bf'), 
			installExperienceHTML,
			'InstallPromptDiv',
			createSLObjects);
*/
		
			
