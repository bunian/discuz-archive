﻿function shownavbar(albumid, curphotoid, b, jsonurl){
	var c="tools/ajax.aspx?t=album&albumid=" + albumid;
	var f=jsonurl;
	_sendRequest(f,function(d){var e={};try{e=eval("("+d+")")}catch(f){e={};
	
	_sendRequest(c,function(d){var e={};try{e=eval("("+d+")")}catch(f){e={}}var h=e?e:null;b(h, curphotoid);e=null;b=null},false,true);
	return;
	
	}var h=e?e:null;b(h, curphotoid);e=null;b=null},false,false)
}
function bindPhotoNav(obj, curphotoid)
{
	var items = obj.items;
	var length = items.length;
	var photoindex = 1;
	var photonav = $("photonav");
	if (items.length < 1)
	{
		photonav.innerHTML = "暂时无法显示导航条";
		return;
	}

	var html = "";
	html += "<table cellpadding='1'><tr>";
	for (var i in items)
	{
		var border = "";
		var size = 88;
		if (items[i].photoid == curphotoid)
		{
			photoindex = new Number(i) + 1;
			border = " class=\"activeimg\"";
			size = 76;
		}
		html += "<td><a href='showphoto.aspx?photoid=" + items[i].photoid + "'><div" + border + "><img title='" + items[i].title + "' alt='" + items[i].title + "' src='" + items[i].square + "' onerror=\"this.onerror=null;this.src='templates/{templatepath}/images/errorphoto.gif';\" width='" + size + "' height='" + size + "' border='0' /></div></a></td>";
	
	}
	html += "</tr></table>";
	photonav.innerHTML = html;

	_attachEvent(window, "load", function(){
		//scrolling
		if (photoindex > 5) {
			$('photonav').scrollLeft = (photoindex-5) * 90;
		}

		//disable prevImg
		if (photoindex == 1) {
			$("prevImg").style.display = 'none';
			if (1 == length) {
				$("nextImg").style.display = 'none';
				$("nextImgOnPhoto").href = 'showphoto.aspx?photoid=' + items[0].photoid;
			}
			else{
				$("nextImgOnPhoto").href = 'showphoto.aspx?photoid=' + items[photoindex].photoid;
				$("nextImg").href = 'showphoto.aspx?photoid=' + items[photoindex].photoid;
			}
		}

		//disable nextImg
		else if (photoindex == length) {
			$("nextImg").style.display = 'none';
			$("nextImgOnPhoto").href = 'showphoto.aspx?photoid=' + items[0].photoid;
			$("prevImg").href = 'showphoto.aspx?photoid=' + items[photoindex - 2].photoid;
		}
		else {
			$("prevImg").href = 'showphoto.aspx?photoid=' + items[photoindex - 2].photoid;
			$("nextImg").href = 'showphoto.aspx?photoid=' + items[photoindex].photoid;
			$("nextImgOnPhoto").href = 'showphoto.aspx?photoid=' + items[photoindex].photoid;
		}
		$("photoIndex").innerHTML = '<em>' + photoindex + '</em>/' + length;
	});

}

function resizePhoto(img)
{
	if (img.width > 685)
	{
		img.width = 685;
	}
}
