
---------------------------------------
  UCenter Home ./update 目录文件说明
---------------------------------------

  1. update.php：
     将UCenter Home升级到最新版本的升级程序。
  2. convert.php：
     X-Space转换到UCenter Home的转换程序。
  
---------------------------------------
  update.php 文件使用方法
---------------------------------------

  适用于 UCenter Home 升级安装。
  如果你之前安装过UCenter Home，请如下进行升级操作：
  
  1. 请先自行备份当前的数据库，避免升级失败，造成数据丢失而无法恢复。
  2. 将程序包 ./upload 目录中，除config.new.php文件、./install目录以外的其他所有文件，
     全部上传并覆盖当前程序。
  3. 将本目录中的 update.php 文件上传到服务器程序根目录，并在浏览器运行。
     根据升级程序的提示，进行数据库升级操作。
     
---------------------------------------     
  convert.php 文件使用方法
---------------------------------------

  适用于 从 X-Space 转换到 UCenter Home。
  如果您的站点之前使用了X-Space，将X-Space转换到UCenter Home操作：
  
  1. 下载并安装UCenter。
     http://download.comsenz.com/UCenter/
  2. 升级Discuz!论坛到最新的6.1.0版本
     http://download.comsenz.com/Discuz/
  3. 上传程序包 ./upload 目录中的所有文件到服务器，并进行全新安装(参考全新安装说明)。
  4. 将本目录中的 convert.php 文件上传到服务器程序根目录，并在浏览器运行。
     根据转换程序的提示，进行X-Space到UCenter Home的转换操作。
     