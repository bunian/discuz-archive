
---------------------------------------
  UCenter Home 介绍
---------------------------------------

  UCenter Home 是一套采用PHP+MYSQL构建的
  社会化网络软件（Social Network Software，简称SNS）。
  
  通过 UCenter Home，您可以轻松构建一个以好友关系为核心的交流网络，
  让站内用户可以用迷你博客一句话记录生活中的点点滴滴；
  方便快捷地发布日志、上传图片；
  更可以十分方便的与其好友们一起分享信息、讨论感兴趣的话题；
  轻松快捷的了解好友最新动态。

---------------------------------------
  UCenter Home 全新安装
---------------------------------------

  1. 首先，请确保您的站点已经安装 UCenter 程序。
     如果没有安装 UCenter，请先下载并进行安装。
     UCenter 下载地址：
     http://download.comsenz.com/UCenter/
     
  2. 通过ftp工具，将 ./upload 目录中的所有文件上传到服务器上。
  
  3. 将程序根目录下面的 config.new.php 重命名为 config.php 。
  
  4. 以"创始人"身份，登录 UCenter 后台，并进行如下操作：
     "应用管理" --> "添加新应用"
     选择安装方式: URL 安装
     应用程序安装地址: http://本程序访问URL/install/index.php
     
  5. 点击"安装"，请根据向导，填入必要的信息，开始 UCenter Home 安装。
     特别注意的是，要根据安装向导的提示，正确设置各个目录的读写属性。
  
  6. 安装完毕后，请务必将 install 目录删除。

---------------------------------------
  UCenter Home 升级安装
---------------------------------------

  如果你之前安装过UCenter Home，请如下进行升级操作：
  
  1. 请先自行备份当前的数据库，避免升级失败，造成数据丢失而无法恢复。
  2. 将程序包 ./upload 目录中，除config.new.php文件、./install目录以外的其他所有文件，
     全部上传并覆盖当前程序。
  3. 将程序包 ./update 目录中，update.php文件上传到服务器程序根目录，并在浏览器运行。
     根据升级程序的提示，进行数据库升级操作。
     
---------------------------------------     
  从 X-Space 转换到 UCenter Home
---------------------------------------

  如果您的站点之前使用了X-Space，将X-Space转换到UCenter Home操作：
  
  1. 下载并安装UCenter。
     http://download.comsenz.com/UCenter/
  2. 升级Discuz!论坛到最新的6.1.0版本
     http://download.comsenz.com/Discuz/
  3. 上传程序包 ./upload 目录中的所有文件到服务器，并进行全新安装(参考全新安装说明)。
  4. 将程序包 ./update 目录中的 convert.php文件上传到服务器程序根目录，并在浏览器运行。
     根据转换程序的提示，进行X-Space到UCenter Home的转换操作。

---------------------------------------
  UCenter Home 更多设置帮助
---------------------------------------

  请在线访问 UCenter Home 官方帮助栏目，获得更多使用文档。
  http://u.discuz.net/help/
  

祝您使用愉快


(C) UCenter Home 2001-2008 Comsenz Inc
http://u.discuz.net