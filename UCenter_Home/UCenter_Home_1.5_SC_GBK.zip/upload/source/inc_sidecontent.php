<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: inc_sidecontent.php 8635 2008-09-01 09:39:22Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}


?>