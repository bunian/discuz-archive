<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: Feed.php 9732 2008-11-14 01:51:43Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

class Feed extends MyBase {

	function publishTemplatizedAction($uId, $appId, $titleTemplate, $titleData, $bodyTemplate, $bodyData, $bodyGeneral = '', $image1 = '', $image1Link = '', $image2 = '', $image2Link = '', $image3 = '', $image3Link = '', $image4 = '', $image4Link = '', $targetIds = '', $privacy = '', $hashTemplate = '', $hashData = '') {
		global $_SGLOBAL;

		$friend = ($privacy == 'public') ? 0 : ($privacy == 'friends' ? 1 : 2);
		
		$images = array($image1, $image2, $image3, $image4);
		$image_links = array($image1Link, $image2Link, $image3Link, $image4Link);
		include_once(S_ROOT.'./source/function_cp.php');
		$result = feed_add($appId, $titleTemplate, $titleData, $bodyTemplate, $bodyData, $bodyGeneral, $images, $image_links, $targetIds, $friend, 0, 1);
		
		return new APIResponse($result);
	}
}

?>
