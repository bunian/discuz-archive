<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: update.php 6894 2008-03-30 03:52:28Z liguode $
*/

if(!@include('./common.php')) {
	exit('�бN����󲾨�{�Ǯڥؿ��A�B��!');
}

error_reporting(0);

//�sSQL
$sqlfile = S_ROOT.'./install/install.sql';
if(!file_exists($sqlfile)) {
	show_msg('�̷s��SQL���s�b,�нT�{ install/install.sql �w�W��');
}

$lockfile = './data/update.lock';
if(file_exists($lockfile)) {
	show_msg('ĵ�i!�z�w�g�ɯŹLUCenter Home�ƾڮw���c<br>
		���F�O�Ҽƾڦw���A�ХߧY��ʧR�� update.php ���<br>
		�p�G�z�Q�A���ɯ�UCenter Home�A�ЧR�� data/update.lock ���A�A���B��w�ˤ��');
}

//����B�z
if(submitcheck('delsubmit')) {
	//�R����
	if(!empty($_POST['deltables'])) {
		foreach ($_POST['deltables'] as $tname => $value) {
			$_SGLOBAL['db']->query("DROP TABLE ".tname($tname));
		}
	}
	//�R���r�q
	if(!empty($_POST['delcols'])) {
		foreach ($_POST['delcols'] as $tname => $cols) {
			foreach ($cols as $col => $indexs) {
				if($col == 'PRIMARY') {
					$_SGLOBAL['db']->query("ALTER TABLE ".tname($tname)." DROP PRIMARY KEY", 'SILENT');//�̽����~
				} elseif($col == 'KEY') {
					foreach ($indexs as $index => $value) {
						$_SGLOBAL['db']->query("ALTER TABLE ".tname($tname)." DROP INDEX `$index`", 'SILENT');//�̽����~
					}
				} else {
					$_SGLOBAL['db']->query("ALTER TABLE ".tname($tname)." DROP `$col`");
				}
			}
		}
	}
	
	show_msg('�R�����M�r�q�ާ@�����F', '?step=2');
}

//�B�z�}�l
if(empty($_GET['step'])) {
	//�}�l
	$_GET['step'] = 0;
	
	show_msg('<a href="?step=1">�ɯŶ}�l</a><br>���ɯŵ{�Ƿ|�ѷӳ̷s��SQL��,��A���ƾڮw�i��ɯ�<br>�нT�O�A�w�g�W�ǳ̷s����� install/install.sql');
	
} elseif ($_GET['step'] == 1) {

	//�s��SQL
	$sql = sreadfile($sqlfile);
	preg_match_all("/CREATE\s+TABLE\s+uchome\_(.+?)\s+\((.+?)\)\s+(TYPE|ENGINE)\=/is", $sql, $matches);
	$newtables = empty($matches[1])?array():$matches[1];
	$newsqls = empty($matches[0])?array():$matches[0];
	if(empty($newtables) || empty($newsqls)) {
		show_msg('�̷s��SQL�����T,�нT�{���T�W�� install/install.sql');
	}

	//�ɯŪ�
	$i = empty($_GET['i'])?0:intval($_GET['i']);
	if($i>=count($newtables)) {
		//�B�z����
		showmessage('�i�J�U�@�B�ާ@', '?step=2', 0);
	}
	//���e�B�z��
	$newtable = $newtables[$i];
	$newcols = getcolumn($newsqls[$i]);

	//������eSQL
	if(!$query = $_SGLOBAL['db']->query("SHOW CREATE TABLE ".tname($newtable), 'SILENT')) {
		//�K�[��
		preg_match("/(CREATE TABLE .+?)\s+[TYPE|ENGINE]+\=/is", $newsqls[$i], $maths);
		if(strpos($newtable, 'session')) {
			$type = mysql_get_server_info() > '4.1' ? " ENGINE=MEMORY".(empty($_SC['dbcharset'])?'':" DEFAULT CHARSET=$_SC[dbcharset]" ): " TYPE=HEAP";
		} else {
			$type = mysql_get_server_info() > '4.1' ? " ENGINE=MYISAM".(empty($_SC['dbcharset'])?'':" DEFAULT CHARSET=$_SC[dbcharset]" ): " TYPE=MYISAM";
		}
		$usql = $maths[1].$type;
		$usql = str_replace("CREATE TABLE uchome_", 'CREATE TABLE '.$_SC['tablepre'], $usql);
		if(!$_SGLOBAL['db']->query($usql, 'SILENT')) {
			show_msg('�K�[�� '.tname($newtable).' �X��,�Ф�u����H�USQL�y�y��,�A���s�B�楻�ɯŵ{��:<br><br>'.shtmlspecialchars($usql));
		} else {
			$msg = '�K�[�� '.tname($newtable).' ����';
		}
	} else {
		$value = $_SGLOBAL['db']->fetch_array($query);
		$oldcols = getcolumn($value['Create Table']);
		
		//����ɯ�SQL��
		$updates = array();
		foreach ($newcols as $key => $value) {
			if($key == 'PRIMARY') {
				if($value != $oldcols[$key]) {
					$updates[] = "DROP PRIMARY KEY";
					$updates[] = "ADD PRIMARY KEY $value";
				}
			} elseif ($key == 'KEY') {
				foreach ($value as $subkey => $subvalue) {
					if(!empty($oldcols['KEY'][$subkey])) {
						if($subvalue != $oldcols['KEY'][$subkey]) {
							$updates[] = "DROP INDEX `$subkey`";
							$updates[] = "ADD INDEX `$subkey` $subvalue";
						}
					} else {
						$updates[] = "ADD INDEX `$subkey` $subvalue";
					}
				}
			} else {
				if(!empty($oldcols[$key])) {
					if(str_replace('mediumtext', 'text', $value) != str_replace('mediumtext', 'text', $oldcols[$key])) {
						$updates[] = "CHANGE `$key` `$key` $value";
					}
				} else {
					$updates[] = "ADD `$key` $value";
				}
			}
		}
		
		//�ɯųB�z
		if(!empty($updates)) {
			$usql = "ALTER TABLE ".tname($newtable)." ".implode(', ', $updates);
			if(!$_SGLOBAL['db']->query($usql, 'SILENT')) {
				show_msg('�ɯŪ� '.tname($newtable).' �X��,�Ф�u����H�U�ɯŻy�y��,�A���s�B�楻�ɯŵ{��:<br><br><b>�ɯ�SQL�y�y</b>:<div style=\"position:absolute;font-size:11px;font-family:verdana,arial;background:#EBEBEB;padding:0.5em;\">'.shtmlspecialchars($usql)."</div><br><b>Error</b>: ".$_SGLOBAL['db']->error()."<br><b>Errno.</b>: ".$_SGLOBAL['db']->errno());
			} else {
				$msg = '�ɯŪ� '.tname($newtable).' ����';
			}
		} else {
			$msg = '�ˬd�� '.tname($newtable).' �����A���ݤɯ�';
		}
	}

	//�B�z�U�@��
	$next = '?step=1&i='.($_GET['i']+1);
	show_msg($msg, $next);

} elseif ($_GET['step'] == 2) {
	
	//�ˬd�ݭn�R�����r�q
	
	//�Ѫ����X
	$oldtables = array();
	$query = $_SGLOBAL['db']->query("SHOW TABLES LIKE '$_SC[tablepre]%'");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$values = array_values($value);
		if(!strexists($values[0], 'cache')) {
			$oldtables[] = $values[0];//�����B�w�s
		}
	}

	//�s�����X
	$sql = sreadfile($sqlfile);
	preg_match_all("/CREATE\s+TABLE\s+uchome\_(.+?)\s+\((.+?)\)\s+(TYPE|ENGINE)\=/is", $sql, $matches);
	$newtables = empty($matches[1])?array():$matches[1];
	$newsqls = empty($matches[0])?array():$matches[0];
	
	//�ݭn�R������
	$deltables = array();
	$delcolumns = array();
	
	//�Ѫ����A�s���S��
	foreach ($oldtables as $tname) {
		$tname = substr($tname, strlen($_SC['tablepre']));
		if(in_array($tname, $newtables)) {
			//����r�q�O�_�h�l
			$query = $_SGLOBAL['db']->query("SHOW CREATE TABLE ".tname($tname));
			$cvalue = $_SGLOBAL['db']->fetch_array($query);
			$oldcolumns = getcolumn($cvalue['Create Table']);
			
			//�s��
			$i = array_search($tname, $newtables);
			$newcolumns = getcolumn($newsqls[$i]);
			
			//�Ѫ����A�s���S�����r�q
			foreach ($oldcolumns as $colname => $colstruct) {
				if($colname == 'PRIMARY') {
					//����r
					if(empty($newcolumns[$colname])) {
						$delcolumns[$tname][] = 'PRIMARY';
					}
				} elseif($colname == 'KEY') {
					//����
					foreach ($colstruct as $key_index => $key_value) {
						if(empty($newcolumns[$colname][$key_index])) {
							$delcolumns[$tname]['KEY'][$key_index] = $key_value;
						}
					}
				} else {
					//���q�r�q
					if(empty($newcolumns[$colname])) {
						$delcolumns[$tname][] = $colname;
					}
				}
			}
		} else {
			$deltables[] = $tname;
		}
	}

	//���
	show_header();
	echo '<form method="post" action="update.php?step=2">';
	
	//�R����
	$deltablehtml = '';
	if($deltables) {
		$deltablehtml .= '<table>';
		foreach ($deltables as $tablename) {
			$deltablehtml .= "<tr><td><input type=\"checkbox\" name=\"deltables[$tablename]\" value=\"1\"></td><td>{$_SC['tablepre']}$tablename</td></tr>";
		}
		$deltablehtml .= '</table>';
		echo "<p>�H�U �ƾڪ� �P�зǼƾڮw�ۤ�O�h�l��:<br>�z�i�H�ھڻݭn�ۦ�M�w�O�_�R��</p>$deltablehtml";
	}

	//�R���r�q
	$delcolumnhtml = '';
	if($delcolumns) {
		$delcolumnhtml .= '<table>';
		foreach ($delcolumns as $tablename => $cols) {
			foreach ($cols as $col) {
				if (is_array($col)) {
					foreach ($col as $index => $indexvalue) {
						$delcolumnhtml .= "<tr><td><input type=\"checkbox\" name=\"delcols[$tablename][KEY][$index]\" value=\"1\"></td><td>{$_SC['tablepre']}$tablename</td><td>���� $index $indexvalue</td></tr>";
					}
				} elseif($col == 'PRIMARY') {
					$delcolumnhtml .= "<tr><td><input type=\"checkbox\" name=\"delcols[$tablename][PRIMARY]\" value=\"1\"></td><td>{$_SC['tablepre']}$tablename</td><td>�D�� PRIMARY</td></tr>";
				} else {
					$delcolumnhtml .= "<tr><td><input type=\"checkbox\" name=\"delcols[$tablename][$col]\" value=\"1\"></td><td>{$_SC['tablepre']}$tablename</td><td>�r�q $col</td></tr>";
				}
			}
		}
		$delcolumnhtml .= '</table>';
		
		echo "<p>�H�U �r�q �P�зǼƾڮw�ۤ�O�h�l��:<br>�z�i�H�ھڻݭn�ۦ�M�w�O�_�R��</p>$delcolumnhtml";
	}
	
	if(empty($deltables) && empty($delcolumns)) {
		echo "<p>�P�зǼƾڮw�ۤ�A�S���ݭn�R�����ƾڪ��M�r�q</p><a href=\"?step=3\">���I���i�J�U�@�B</a></p>";
	} else {
		echo "<p><input type=\"submit\" name=\"delsubmit\" value=\"����R��\"></p><p>�z�]�i�H�����h�l�����M�r�q<br><a href=\"?step=3\">�����i�J�U�@�B</a></p>";
	}
	echo '</form>';
	
	show_footer();
	exit();

} elseif ($_GET['step'] == 3) {
	
	//�ƾڳB�z
	
	//�glog
	if(@$fp = fopen($lockfile, 'w')) {
		fwrite($fp, 'UCenter Home');
		fclose($fp);
	}

	show_msg('�ɯŧ����A���F�z���ƾڦw���A�קK���ƤɯšA�еn��FTP�R�������!');
}


//���h�ǰt,����r�q/����/����r�H��
function getcolumn($creatsql) {

	preg_match("/\((.+)\)/is", $creatsql, $matchs);
	
	$cols = explode("\n", $matchs[1]);
	$newcols = array();
	foreach ($cols as $value) {
		$value = trim($value);
		if(empty($value)) continue;
		$value = remakesql($value);//�S�Ϧr�Ŵ���
		if(substr($value, -1) == ',') $value = substr($value, 0, -1);//�h�������r��

		$vs = explode(' ', $value);
		$cname = $vs[0];

		if(strtoupper($cname) == 'KEY') {
			$subvalue = trim(substr($value, 3));
			$subvs = explode(' ', $subvalue);
			$subcname = $subvs[0];
			$newcols['KEY'][$subcname] = trim(substr($value, (5+strlen($subcname))));
		} elseif(strtoupper($cname) == 'INDEX') {
			$subvalue = trim(substr($value, 5));
			$subvs = explode(' ', $subvalue);
			$subcname = $subvs[0];
			$newcols['KEY'][$subcname] = trim(substr($value, (7+strlen($subcname))));
		} elseif(strtoupper($cname) == 'PRIMARY') {
			$newcols['PRIMARY'] = trim(substr($value, 11));
		} else {
			$newcols[$cname] = trim(substr($value, strlen($cname)));
		}
	}
	return $newcols;
}

//��zsql��
function remakesql($value) {
	$value = trim(preg_replace("/\s+/", ' ', $value));//�Ů�зǤ�
	$value = str_replace(array('`',', ', ' ,', '( ' ,' )'), array('', ',', ',','(',')'), $value);//�h���L�βŸ�
	$value = preg_replace('/(text NOT NULL) default \'\'/i',"\\1", $value);//�h���L�βŸ�
	return $value;
}

//���
function show_msg($message, $url_forward='') {
	global $_SGLOBAL;

	obclean();
	
	if($url_forward) {
		$_SGLOBAL['extrahead'] = '<meta http-equiv="refresh" content="1; url='.$url_forward.'">';
		$message = "<a href=\"$url_forward\">$message(���त...)</a>";
	} else {
		$_SGLOBAL['extrahead'] = '';
	}
	
	show_header();
	print<<<END
	<table>
	<tr><td>$message</td></tr>
	</table>
END;
	show_footer();
	exit();
}


//�����Y��
function show_header() {
	global $_SGLOBAL, $_SC;

	$nowarr = array($_GET['step'] => ' class="current"');
	
	if(empty($_SGLOBAL['extrahead'])) $_SGLOBAL['extrahead'] = '';
	
	print<<<END
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml"> 
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=$_SC[charset]" />
	$_SGLOBAL[extrahead]
	<title> UCenter Home �ƾڮw�ɯŵ{�� </title>
	<style type="text/css">
	* {font-size:12px; font-family: Verdana, Arial, Helvetica, sans-serif; line-height: 1.5em; word-break: break-all; }
	body { text-align:center; margin: 0; padding: 0; background: #F5FBFF; }
	.bodydiv { margin: 40px auto 0; width:720px; text-align:left; border: solid #86B9D6; border-width: 5px 1px 1px; background: #FFF; }
	h1 { font-size: 18px; margin: 1px 0 0; line-height: 50px; height: 50px; background: #E8F7FC; color: #5086A5; padding-left: 10px; }
	#menu {width: 100%; margin: 10px auto; text-align: center; }
	#menu td { height: 30px; line-height: 30px; color: #999; border-bottom: 3px solid #EEE; }
	.current { font-weight: bold; color: #090 !important; border-bottom-color: #F90 !important; }
	.showtable { width:100%; border: solid; border-color:#86B9D6 #B2C9D3 #B2C9D3; border-width: 3px 1px 1px; margin: 10px auto; background: #F5FCFF; }
	.showtable td { padding: 3px; }
	.showtable strong { color: #5086A5; }
	.datatable { width: 100%; margin: 10px auto 25px; }
	.datatable td { padding: 5px 0; border-bottom: 1px solid #EEE; }
	input { border: 1px solid #B2C9D3; padding: 5px; background: #F5FCFF; }
	.button { margin: 10px auto 20px; width: 100%; }
	.button td { text-align: center; }
	.button input, .button button { border: solid; border-color:#F90; border-width: 1px 1px 3px; padding: 5px 10px; color: #090; background: #FFFAF0; cursor: pointer; }
	#footer { font-size: 10px; line-height: 40px; background: #E8F7FC; text-align: center; height: 38px; overflow: hidden; color: #5086A5; margin-top: 20px; }
	</style>
	<script src="source/script_ajax.js" type="text/javascript" language="javascript"></script>
	<script src="source/script_common.js" type="text/javascript" language="javascript"></script>
	</head>
	<body>
	<div class="bodydiv">
	<h1>UCenter Home�ƾڮw�ɯŤu��</h1>
	<div style="width:90%;margin:0 auto;">
	<table id="menu">
	<tr>
	<td{$nowarr[0]}>�ɯŶ}�l</td>
	<td{$nowarr[1]}>�ƾڮw���c�K�[/�ɯ�</td>
	<td{$nowarr[2]}>�ƾڮw���c�R��</td>
	<td{$nowarr[3]}>�ɯŧ���</td>
	</tr>
	</table>
	<br>
END;
}

//��������
function show_footer() {
	print<<<END
	</div>
	<div id="footer">&copy; Comsenz Inc. 2001-2007 UCenter Home.discuz.net</div>
	</div>
	<br>
	</body>
	</html>
END;
}

?>