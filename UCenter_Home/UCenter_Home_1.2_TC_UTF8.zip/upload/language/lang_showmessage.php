<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: lang_showmessage.php 7352 2008-05-13 01:41:40Z zhengqingpeng $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

$_SGLOBAL['msglang'] = array(

	//common
	'do_success' => '進行的操作完成了',
	'no_privilege' => '您沒有權限進行此操作',

	//mt.php
	'designated_election_it_does_not_exist' => '指定的選吧不存在',

	//do.php
	'enter_the_space' => '進入個人空間頁面',
	'enter_the_network' => '進入隨便看看頁面',

	//network.php
	'points_deducted_yes_or_no' => '本次操作將扣減您 \\1 個積分，確認繼續？<p><a href="\\2" class="submit">繼續操作</a> &nbsp; <a href="network.php?ac=\\3" class="submit">取消操作</a></p>',

	//source/cp_album.php
	'photos_do_not_support_the_default_settings' => '默認相冊不支持本設置',
	'album_name_errors' => '您沒有正確設置相冊名',
	
	//source/space_app.php
	'correct_choice_for_application_show' => '請選擇正確的應用進行查看',

	//source/do_login.php
	'users_were_not_empty_please_re_login' => '對不起，用戶名不能為空，請重新登錄',
	'login_failure_please_re_login' => '對不起,登錄失敗,請重新登錄',

	//source/cp_blog.php
	'no_authority_to_add_log' => '您目前沒有權限添加日誌',
	'no_authority_operation_of_the_log' => '您沒有權限操作該日誌',
	'that_should_at_least_write_things' => '至少應該寫一點東西',
	'failed_to_delete_operation' => '刪除失敗，請檢查操作',
	'trace_no_self' => '自己不能給自己留腳印',
	'trace_have' => '您已經留過腳印了',
	'trace_success' => '您成功留下自己的腳印了',

	//source/cp_class.php
	'did_not_specify_the_type_of_operation' => '沒有正確指定要操作的分類',
	'enter_the_correct_class_name' => '請正確輸入分類名',

	'note_wall_reply_success' => '已經回復到 \\1 的留言板',

	//source/cp_comment.php

	'operating_too_fast' => "兩次發佈操作太快了，請等 \\1 秒鐘再試",
	'content_is_too_short' => '輸入的內容不能少於4個字符',
	'comments_do_not_exist' => '指定的評論不存在',
	'do_not_accept_comments' => '該日誌不接受評論',
	'sharing_does_not_exist' => '評論的分享不存在',
	'non_normal_operation' => '非正常操作',

	//source/cp_common.php
	'security_exit' => '你已經安全退出了\\1',

	//source/cp_doing.php
	'should_write_that' => '至少應該寫一點東西',

	//source/cp_import.php
	'blog_import_no_result' => '"無法獲取原數據，請確認已正確輸入的站點URL和帳號信息，服務器返回:<br /><textarea name=\"tmp[]\" style=\"width:98%;\" rows=\"4\">\\1</textarea>"',
	'blog_import_no_data' => '獲取數據失敗，請參考服務器返回:<br />\\1',
	'support_function_has_not_yet_opened fsockopen' => '站點尚未開啟fsockopen函數支持，還不能使用本功能',
	'integral_inadequate' => "您現在的積分 \\1 不足以完成本次操作。本操作將需要積分: \\2",
	'url_is_not_correct' => '輸入的網站URL不正確',
	'choose_at_least_one_log' => '請至少選擇一個要導入的日誌',

	//source/cp_friend.php
	'friends_add' => '您和 \\1 成為好友了',
	'you_have_friends' => '你們已經是好友了',
	'enough_of_the_number_of_friends' => '您當前的好友數目達到系統限制，請先刪除部分好友',
	'request_has_been_sent' => '好友請求已經發送，請等待對方驗證中',
	'waiting_for_the_other_test' => '正在等待對方驗證中',
	'you_are_friends' => "你們是好友了",
	'please_correct_choice_groups_friend' => '請正確選擇分組好友',
	'specified_user_is_not_your_friend' => '指定的用戶還不是您的好友',

	//source/cp_mtag.php
	'mtag_max_inputnum' => '無法加入，您在欄目 "\\1" 中的選吧數目已達到 \\2 個限制數目',
	'you_are_already_a_member' => '您已經是該選吧的成員了',
	'join_success' => '加入成功，您現在是該選吧的成員了',
	'the_discussion_topic_does_not_exist' => '對不起，參與討論的話題不存在',
	'content_is_not_less_than_four_characters' => '對不起，內容不能少於4個字符',
	'you_are_not_a_member_of' => '您不是該選吧的成員',

	//source/cp_pm.php
	'this_message_could_not_be_deleted' => '指定的短消息不能被刪除',
	'correctly_designated_recipient' => '指定的收件人還沒有在本空間激活，不能發送短消息',
	'unable_to_send_air_news' => '不能發送空消息',
	'message_can_not_send' => '短消息無法進行發送',
	'not_to_their_own_greeted' => '不能向自己打招呼',
	'has_been_hailed_overlooked' => '招呼已經忽略了',

	//source/cp_profile.php
	'update_on_successful_individuals' => '個人資料更新成功了',

	//source/cp_share.php
	'blog_does_not_exist' => '指定的日誌不存在',
	'logs_can_not_share' => '指定的日誌因隱私設置不能夠被分享',
	'album_does_not_exist' => '指定的相冊不存在',
	'album_can_not_share' => '指定的相冊因隱私設置不能夠被分享',
	'image_does_not_exist' => '指定的圖片不存在',
	'image_can_not_share' => '指定的圖片因隱私設置不能夠被分享',
	'topics_does_not_exist' => '指定的話題不存在',
	'mtag_does_not_exist' => '指定的選吧不存在',
	'tag_does_not_exist' => '指定的標籤不存在',
	'url_incorrect_format' => '分享的網址格式不正確',
	'not_correctly_designated_to_share_information' => '沒有正確指定要分享的信息',
	'description_share_input' => '請輸入分享的描述',

	//source/cp_space.php
	'domain_length_error' => '設置的二級域名長度不能小於\\1個字符',
	'credits_exchange_invalid' => '兌換的積分方案有錯，不能進行兌換，請返回修改。',
	'credits_transaction_amount_invalid' => '您要轉賬或兌換的積分數量輸入有誤，請返回修改。',
	'credits_password_invalid' => '您沒有輸入密碼或密碼錯誤，不能進行積分操作，請返回。',
	'credits_balance_insufficient' => '對不起，您的積分餘額不足，兌換失敗，請返回。',
	'extcredits_dataerror' => '兌換失敗，請與管理員聯繫。',
	'domain_be_retained' => '您設定的域名被系統保留，請選擇其他域名',
	'not_enabled_this_feature' => '系統還沒有開啟本功能',
	'space_size_inappropriate' => '請正確指定要兌換的上傳空間大小',
	'space_does_not_exist' => '指定的空間不存在',
	'integral_convertible_unopened' => '系統目前沒有開啟積分兌換功能',
	'two_domain_have_been_occupied' => '設置的二級域名已經有人使用了',
	'only_two_names_from_english_composition_and_figures' => '設置的二級域名需要由英文字母開頭且只由英文和數字構成',
	'two_domain_length_not_more_than_30_characters' => '設置的二級域名長度不能超過30個字符',
	'old_password_invalid' => '您沒有輸入舊密碼或舊密碼錯誤，請返回重新填寫。',
	'no_change' => '沒有做任何修改',
	'protection_of_users' => '受保護的用戶，沒有權限修改',

	//source/cp_theme.php
	'theme_does_not_exist' => '指定的風格不存在',

	//source/cp_upload.php
	'upload_images_completed' => '上傳圖片完成了',

	//source/cp_thread.php
	'to_login' => '請先登錄再進行本操作',
	'title_not_too_little' => '標題不能少於4個字符',
	'posting_does_not_exist' => '指定的話題不存在',
	'settings_of_your_mtag' => '有了選吧才能發話題，你需要先選吧一下你的選吧。<br>選吧，就是自己選擇的志同道合的交流圈。<br>在吧內，不僅可以結識與你有相同選擇的朋友，更可以一起交流話題。<br><br><a href="cp.php?ac=mtag" class="submit">設置我的選吧</a>',
	'first_select_a_mtag' => '你至少應該選擇一個選吧才能發話題。<br><br><a href="cp.php?ac=mtag" class="submit">設置我的選吧</a>',
	'no_mtag_allow_thread' => '當前你參與的選吧加入人數不足，還不能進行發話題操作。<br><br><a href="cp.php?ac=mtag" class="submit">設置我的選吧</a>',
	'mtag_close' => '選擇的選吧已經被鎖定，不能進行本操作',

	//source/space_album.php
	'to_view_the_photo_does_not_exist' => '出問題了，您要查看的相冊不存在',

	//source/space_blog.php
	'view_to_info_did_not_exist' => '出問題了，您要查看的信息不存在或者已經被刪除',

	//source/space_pic.php
	'view_images_do_not_exist' => '您要查看的圖片不存在',

	//source/mt_thread.php
	'topic_does_not_exist' => '指定的話題不存在',

	//source/do_inputpwd.php
	'news_does_not_exist' => '指定的信息不存在',
	'proved_to_be_successful' => '驗證成功，現在進入查看頁面',
	'password_is_not_passed' => '輸入的密碼驗證不通過,請返回重新確認',



	//source/do_login.php
	'login_success' => '登錄成功了，現在引導您進入登錄前頁面 \\1',
	'not_open_registration' => '非常抱歉，本站目前暫時不開放註冊',
	'not_open_registration_invite' => '非常抱歉，本站目前暫時不允許用戶直接註冊，需要有好友邀請鏈接才能註冊',
	
	//source/do_lostpasswd.php
	'getpasswd_account_notmatch' => '用戶名，Email 地址不匹配，請返回修改。',
	'getpasswd_send_succeed' => '取回密碼的方法已經通過 Email 發送到您的信箱中，<br />請在 3 天之內修改您的密碼。',
	'user_does_not_exist' => '該用戶不存',
	'getpasswd_illegal' => '您所用的 ID 不存在或已經過期，無法取回密碼。',
	'profile_passwd_illegal' => '密碼空或包含非法字符，請返回重新填寫。',
	'getpasswd_succeed' => '您的密碼已重新設置，請使用新密碼登錄。',
	'getpasswd_account_invalid' => '對不起，創始人不能使用取回密碼功能，請返回。',

	//source/do_register.php
	'registered' => '註冊成功了，進入個人空間',
	'system_error' => '系統錯誤，未找到UCenter Client文件',
	'password_inconsistency' => '兩次輸入的密碼不一致',
	'profile_passwd_illegal' => '密碼空或包含非法字符，請重新填寫。',
	'user_name_is_not_legitimate' => '用戶名不合法',
	'include_not_registered_words' => '用戶名包含不允許註冊的詞語',
	'user_name_already_exists' => '用戶名已經存在',
	'email_format_is_wrong' => 'Email 格式有誤',
	'email_not_registered' => 'Email 不允許註冊',
	'email_has_been_registered' => 'Email 已經被註冊',
	'register_error' => '註冊失敗',

	//tag.php
	'tag_does_not_exist' => '指定的標籤不存在',

	//cp_poke.php
	'poke_success' => '已經發送，\\1下次訪問時會收到通知',
	'mtag_minnum_erro' => '本選吧成員數不足 \\1 個，還不能進行本操作',
	'mtag_no_manage' => '你不是本選吧成員，不能進行本操作<br />你可以進行如下設置:<br /><a href="\\1">設置你的選吧</a>，並在 " \\2 " 選項中填寫(或選擇) " \\3 "',

	//source/function_common.php
	'information_contains_the_shielding_text' => '對不起，發佈的信息中包含站點屏蔽的文字',
	'site_temporarily_closed' => '站點暫時關閉',
	'ip_is_not_allowed_to_visit' => '不能訪問，您當前的IP不在站點允許訪問的範圍內。',
	'no_data_pages' => '指定的頁面已經沒有數據了',
	'length_is_not_within_the_scope_of' => '分頁數不在允許的範圍內',

	//source/function_block.php
	'page_number_is_beyond' => '頁數是否超出範圍',
	//source/function_cp.php
	'incorrect_code' => '輸入的驗證碼不正確，請重新確認',

	//source/network_album.php
	'search_short_interval' => '兩次搜索間隔太短，請稍後再進行搜索',
	'set_the_correct_search_content' => '對不起，請設置正確的查找內容',

	//source/space_share.php
	'share_does_not_exist' => '要查看的分享不存在',

	//source/space_tag.php
	'tag_locked' => '標籤已經被鎖定',

	//admin/admincp_block.php
	'enter_the_next_step' => '進入下一步操作',
	'invite_error' => '無法獲取好友邀請碼，請確認您是否有足夠的積分來進行本操作',
	'invite_code_error' => '對不起，您訪問的邀請鏈接不正確，請確認。',
	'invite_code_fuid' => '對不起，您訪問的邀請鏈接已經被他人使用了。',
	
	//source/do_invite.php
	'should_not_invite_your_own' => '對不起，您不能通過訪問自己的邀請鏈接來邀請自己。',
	'close_invite' => '對不起，系統已經關閉了好友邀請功能',
	
	'field_required' => '個人資料中的必填項目「\\1」 不能為空，請確認',
	'firend_self_error' => '對不起，您不能加自己為好友'

);

?>