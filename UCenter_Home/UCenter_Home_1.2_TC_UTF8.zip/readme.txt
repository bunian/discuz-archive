
---------------------------------------
  UCenter Home 介紹
---------------------------------------

  UCenter Home 是一套採用PHP+MYSQL構建的
  社會化網絡軟件（Social Network Software，簡稱SNS）。
  
  通過 UCenter Home，您可以輕鬆構建一個以好友關係為核心的交流網絡，
  讓站內用戶可以用迷你博客一句話記錄生活中的點點滴滴；
  方便快捷地發佈日誌、上傳圖片；
  更可以十分方便的與其好友們一起分享信息、討論感興趣的話題；
  輕鬆快捷的瞭解好友最新動態。

---------------------------------------
  UCenter Home 全新安裝
---------------------------------------

  1. 首先，請確保您的站點已經安裝 UCenter 程序。
     如果沒有安裝 UCenter，請先下載並進行安裝。
     UCenter 下載地址：
     http://download.comsenz.com/UCenter/
     
  2. 通過ftp工具，將 ./upload 目錄中的所有文件上傳到服務器上。
  
  3. 將程序根目錄下面的 config.new.php 重命名為 config.php 。
  
  4. 以"創始人"身份，登錄 UCenter 後台，並進行如下操作：
     "應用管理" --> "添加新應用"
     選擇安裝方式: URL 安裝
     應用程序安裝地址: http://本程序訪問URL/install/index.php
     
  5. 點擊"安裝"，請根據嚮導，填入必要的信息，開始 UCenter Home 安裝。
     特別注意的是，要根據安裝嚮導的提示，正確設置各個目錄的讀寫屬性。
  
  6. 安裝完畢後，請務必將 install 目錄刪除。

---------------------------------------
  UCenter Home 升級安裝
---------------------------------------

  如果你之前安裝過UCenter Home，請如下進行升級操作：
  
  1. 請先自行備份當前的數據庫，避免升級失敗，造成數據丟失而無法恢復。
  2. 將程序包 ./upload 目錄中，除config.new.php文件、./install目錄以外的其他所有文件，
     全部上傳並覆蓋當前程序。
  3. 將程序包 ./update 目錄中，update.php文件上傳到服務器程序根目錄，並在瀏覽器運行。
     根據升級程序的提示，進行數據庫升級操作。
     
---------------------------------------     
  從 X-Space 轉換到 UCenter Home
---------------------------------------

  如果您的站點之前使用了X-Space，將X-Space轉換到UCenter Home操作：
  
  1. 下載並安裝UCenter。
     http://download.comsenz.com/UCenter/
  2. 升級Discuz!論壇到最新的6.1.0版本
     http://download.comsenz.com/Discuz/
  3. 上傳程序包 ./upload 目錄中的所有文件到服務器，並進行全新安裝(參考全新安裝說明)。
  4. 將程序包 ./update 目錄中的 convert.php文件上傳到服務器程序根目錄，並在瀏覽器運行。
     根據轉換程序的提示，進行X-Space到UCenter Home的轉換操作。

---------------------------------------
  UCenter Home 更多設置幫助
---------------------------------------

  請在線訪問 UCenter Home 官方幫助欄目，獲得更多使用文檔。
  http://u.discuz.net/help/
  

祝您使用愉快


(C) UCenter Home 2001-2008 Comsenz Inc
http://u.discuz.net