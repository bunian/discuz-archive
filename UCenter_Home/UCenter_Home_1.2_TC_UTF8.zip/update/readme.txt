
---------------------------------------
  UCenter Home ./update 目錄文件說明
---------------------------------------

  1. update.php：
     將UCenter Home升級到最新版本的升級程序。
  2. convert.php：
     X-Space轉換到UCenter Home的轉換程序。
  
---------------------------------------
  update.php 文件使用方法
---------------------------------------

  適用於 UCenter Home 升級安裝。
  如果你之前安裝過UCenter Home，請如下進行升級操作：
  
  1. 請先自行備份當前的數據庫，避免升級失敗，造成數據丟失而無法恢復。
  2. 將程序包 ./upload 目錄中，除config.new.php文件、./install目錄以外的其他所有文件，
     全部上傳並覆蓋當前程序。
  3. 將本目錄中的 update.php 文件上傳到服務器程序根目錄，並在瀏覽器運行。
     根據升級程序的提示，進行數據庫升級操作。
     
---------------------------------------     
  convert.php 文件使用方法
---------------------------------------

  適用於 從 X-Space 轉換到 UCenter Home。
  如果您的站點之前使用了X-Space，將X-Space轉換到UCenter Home操作：
  
  1. 下載並安裝UCenter。
     http://download.comsenz.com/UCenter/
  2. 升級Discuz!論壇到最新的6.1.0版本
     http://download.comsenz.com/Discuz/
  3. 上傳程序包 ./upload 目錄中的所有文件到服務器，並進行全新安裝(參考全新安裝說明)。
  4. 將本目錄中的 convert.php 文件上傳到服務器程序根目錄，並在瀏覽器運行。
     根據轉換程序的提示，進行X-Space到UCenter Home的轉換操作。
     