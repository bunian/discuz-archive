
---------------------------------------
  目錄文件說明
---------------------------------------

  1. update.php：
     將UCenter Home升級到最新版本的升級程序。
  2. convert.php：
     X-Space轉換到UCenter Home的轉換程序。
  3. client_bbs.php
     將UCenter Home整合到Discuz! 6.0/5.x/4.x/3.x/2.x的文件。
  
---------------------------------------
  update.php 文件使用方法
---------------------------------------

  適用於 UCenter Home 升級安裝。
  如果你之前安裝過UCenter Home，請如下進行升級操作：
  
  1. 請先自行備份當前的數據庫，避免升級失敗，造成數據丟失而無法恢復。
  2. 將程序包 ./upload 目錄中，除config.new.php文件、./install目錄以外的其他所有文件，
     全部上傳並覆蓋當前程序。
  3. 將本目錄中的 update.php 文件上傳到服務器程序根目錄，並在瀏覽器運行。
     根據升級程序的提示，進行數據庫升級操作。
     
---------------------------------------     
  convert.php 文件使用方法
---------------------------------------

  適用於 從 X-Space 轉換到 UCenter Home。
  如果您的站點之前使用了X-Space，將X-Space轉換到UCenter Home操作：
  
  1. 下載並安裝UCenter。
     http://download.comsenz.com/UCenter/
  2. 升級Discuz!論壇到最新的6.1.0版本
     http://download.comsenz.com/Discuz/
  3. 上傳程序包 ./upload 目錄中的所有文件到服務器，並進行全新安裝(參考全新安裝說明)。
  4. 將本目錄中的 convert.php 文件上傳到服務器程序根目錄，並在瀏覽器運行。
     根據轉換程序的提示，進行X-Space到UCenter Home的轉換操作。

---------------------------------------     
  client_bbs.php 文件使用方法
---------------------------------------

  適用於當前安裝Discuz! 6.0/5.x/4.x/3.x/2.x的用戶，整合使用UCenter Home。

  1. 下載並安裝最新版本的UCenter。
     http://download.comsenz.com/UCenter/1.5.0/
  2. 上傳程序包 ./upload 目錄中的所有文件到服務器，並進行UCenter Home的全新安裝
     (參考UCenter Home全新安裝說明)。
  3. 修改UCenter Home的根目錄下的 ./config.php 文件：
  
	修改方法，在文件最後添加當前你使用的Discuz!的數據庫連接參數：

	//Discuz6.0/5.x/4.x/3.x 配置參數
	$_SC['bbs_dbhost']  		= ''; //Mysql服務器地址
	$_SC['bbs_dbuser']  		= ''; //用戶
	$_SC['bbs_dbpw'] 	 	= ''; //密碼
	$_SC['bbs_dbcharset'] 		= ''; //字符集
	$_SC['bbs_pconnect'] 		= 0; //是否持續連接
	$_SC['bbs_dbname']  		= 'discuz'; //數據庫
	$_SC['bbs_tablepre'] 		= 'cdb_'; //表名前綴
	$_SC['bbs_cookiepre'] 		= 'cdb_'; //COOKIE前綴
	$_SC['bbs_cookiedomain'] 	= ''; //COOKIE作用域
	$_SC['bbs_cookiepath'] 		= '/'; //COOKIE作用路徑

  4. 將本目錄中的  client_bbs.php 文件上傳到 ./uc_client 目錄下。
  5. 修改 ./uc_client 目錄下的 client.php 文件：
	
	修改方法，找到：

	global $uc_controls;

	在這一行下面添加：

	global $_SC;
	if($_SC['bbs_dbname'] && in_array($model, array('friend','user','pm'))) {
		include_once UC_ROOT.'./client_bbs.php';
		$func_name = "bbs_{$model}_{$action}";
		if(function_exists($func_name)) {
			return call_user_func_array("bbs_{$model}_{$action}", $args);
		}
	}
