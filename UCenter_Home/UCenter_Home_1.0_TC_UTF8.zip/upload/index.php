<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: index.php 6729 2008-03-24 09:23:51Z liguode $
*/

include_once('./common.php');

if(is_numeric($_SERVER['QUERY_STRING'])) {
	showmessage('enter_the_space', "space.php?uid=$_SERVER[QUERY_STRING]", 0);
}

//��������
if(!isset($_GET['do']) && $_SCONFIG['allowdomain']) {
	$hostarr = explode('.', $_SERVER['HTTP_HOST']);
	if(count($hostarr) > 2 && $hostarr[0] != 'www' && !isholddomain($hostarr[0])) {
		showmessage('enter_the_space', 'space.php?domain='.$hostarr[0], 0);
	}
}

if($_SGLOBAL['supe_uid']) {
	//��ת
	showmessage('enter_the_space', 'space.php?do=home', 0);
} else {
	if(empty($_SCONFIG['networkpublic'])) {
		include template('index');
	} else {
		showmessage('enter_the_network', 'network.php', 0);
	}
}

?>