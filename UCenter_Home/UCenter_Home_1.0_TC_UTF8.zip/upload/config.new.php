<?php
/*
	[Ucenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: config.php 6798 2008-03-27 01:04:03Z liguode $
*/

$_SC = array();

//Ucenter Home 配置參數
$_SC['dbhost']  		= 'localhost'; //服務器地址
$_SC['dbuser']  		= 'root'; //用戶
$_SC['dbpw'] 	 		= 'root'; //密碼
$_SC['dbcharset'] 		= 'utf8'; //字符集
$_SC['pconnect'] 		= 0; //是否持續連接
$_SC['dbname']  		= 'uchome'; //數據庫
$_SC['tablepre'] 		= 'uchome_'; //表名前綴
$_SC['charset'] 		= 'utf-8'; //頁面字符集
$_SC['gzipcompress'] 	= 0; //啟用gzip
$_SC['founder'] 		= '1'; //創始人 UID, 可以支持多個創始人，之間使用 「,」 分隔
$_SC['template']		= 'default'; //選擇模板目錄
$_SC['cookiepre'] 		= 'uchome_'; //COOKIE前綴
$_SC['cookiedomain'] 	= ''; //COOKIE作用域
$_SC['cookiepath'] 		= '/'; //COOKIE作用路徑
$_SC['attachdir']		= './attachment/'; //附件本地保存位置(服務器路徑, 屬性 777, 必須為 web 可訪問到的目錄, 相對目錄務必以 "./" 開頭, 末尾加 "/")
$_SC['attachurl']		= 'attachment/'; //附件本地URL地址(可為當前 URL 下的相對地址或 http:// 開頭的絕對地址, 末尾加 "/")
$_SC['tplrefresh']		= 10; //判斷模板是否更新的效率等級，數值越大，效率越高; 設置為0則永久不判斷

//UCenter 配置參數
define('UC_CONNECT', 'mysql'); // 連接 UCenter 的方式: mysql/NULL, 默認為空時為 fscoketopen(), mysql 是直接連接的數據庫, 為了效率, 建議採用 mysql
//數據庫相關 (mysql 連接時, 並且沒有設置 UC_DBLINK 時, 需要配置以下變量)
define('UC_DBHOST', 'localhost'); // UCenter 數據庫主機
define('UC_DBUSER', 'root'); // UCenter 數據庫用戶名
define('UC_DBPW', 'root'); // UCenter 數據庫密碼
define('UC_DBNAME', 'ucenter'); // UCenter 數據庫名稱
define('UC_DBCHARSET', 'utf8'); // UCenter 數據庫字符集
define('UC_DBTABLEPRE', 'uc_'); // UCenter 數據庫表前綴
define('UC_DBCONNECT', '0'); // UCenter 數據庫持久連接 0=關閉, 1=打開
//通信相關
define('UC_KEY', '1234567890'); // 與 UCenter 的通信密鑰, 要與 UCenter 保持一致
define('UC_API', 'http://localhost/uc_server'); // UCenter 的 URL 地址, 在調用頭像時依賴此常量
define('UC_CHARSET', 'utf-8'); // UCenter 的字符集
define('UC_IP', ''); // UCenter 的 IP, 當 UC_CONNECT 為非 mysql 方式時, 並且當前應用服務器解析域名有問題時, 請設置此值
define('UC_APPID', '1'); // 當前應用的 ID

?>