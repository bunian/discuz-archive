<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: lang_source.php 7111 2008-04-18 02:22:19Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

$_SGLOBAL['sourcelang'] = array(

	'by' => '通過',
	'album' => '相冊',
	'mtag' => '選吧',
	'share' => '分享',
	'delete' => '刪除',
	'add' => '添加',
	'person' => '人',
	'colon' => '：',
	'tab_space' => ' ',
	'comment' => '評論',
	
	'friend_group_default' => '默認分組',
	'friend_group' => '好友分組',
	
	'feed_comment_space' => '{actor} 在 {touser} 的留言板留了言',
	'feed_comment_image' => '{actor} 評論了 {touser} 的圖片',
	'feed_comment_blog' => '{actor} 評論了 {touser} 的日誌 {blog}',
	'feed_comment_share' => '{actor} 評論了 {touser} 的{share}',
	'feed_invite' => '{actor} 發起邀請，跟 {username} 成為了好友',
	
	'note_wall' => '在留言板上給你<a href="\\1" target="_blank">留言</a>',
	'note_wall_reply' => '回復了你的<a href="\\1" target="_blank">留言</a>',
	'note_wall_reply_success' => '已經回復到 \\1 的留言板',
	'note_pic_comment' => '評論了你的<a href="\\1" target="_blank">圖片</a>',
	'note_pic_comment_reply' => '回復了你的<a href="\\1" target="_blank">圖片評論</a>',
	'note_blog_comment' => '評論了你的日誌 <a href="\\1" target="_blank">\\2</a>',
	'note_blog_comment_reply' => '回復了你的<a href="\\1" target="_blank">日誌評論</a>',
	'note_share_comment' => '評論了你的 <a href="\\1" target="_blank">分享</a>',
	'note_share_comment_reply' => '回復了你的<a href="\\1" target="_blank">分享評論</a>',
	'note_share_space' => '分享了你的空間',
	'note_share_blog' => '分享了你的日誌 <a href="\\1" target="_blank">\\2</a>',
	'note_share_album' => '分享了你的相冊 <a href="\\1" target="_blank">\\2</a>',
	'note_share_pic' => '分享了你的相冊 \\2 中的<a href="\\1" target="_blank">圖片</a>',
	'note_share_thread' => '分享了你的話題 <a href="\\1" target="_blank">\\2</a>',
	
	'note_doing_reply' => '針對你的<a href="\\1" target="_blank">迷你博客</a>進行了<a href="\\2" target="_blank">評論</a>',
	
	'feed_friend_title' => '{actor} 跟 {touser} 成為了好友',
	'note_friend_add' => '跟你成為了好友',
	'note_invite' => '接受了您的好友邀請',
	
	'friend_invite_subject' => '\\1在\\2邀請你為好友',
	'friend_invite_message' => '\\1 在 \\2 站點邀請你為好友。<br />請複製下面的鏈接到瀏覽器窗口查看，成為 \\1 的好友：<br />\\3do.php?ac=invite&code=\\4<br /><br />\\2 是屬於你自己的空間。<br />在這裡，你可以一句話記錄生活中的點點滴滴，方便快捷地發佈信息和圖片，與志同道合的朋友們一起交流與分享。<br />(這是站內自動發送的系統消息，你不需要回復)<br />\\3<br />',
	
	'feed_mtag_join' => '{actor} 加入了選吧 {mtag} ({field})',
	
	'share_space' => '分享了一個用戶',
	'share_blog' => '分享了一篇日誌',
	'share_album' => '分享了一個相冊',
	'share_image' => '分享了一張圖片',
	'share_thread' => '分享了一個話題',
	'share_mtag' => '分享了一個選吧',
	'share_mtag_membernum' => '現有 {membernum} 名成員',
	'share_tag' => '分享了一個標籤',
	'share_tag_blognum' => '現有 {blognum} 篇日誌',
	'share_link' => '分享了一個網址',
	
	'feed_thread' => '<b>{actor} 發起了新話題</b>',
	'feed_thread_reply' => '{actor} 回復了 {touser} 的話題 {thread}',
	'note_thread_reply' => '回復了你的話題',
	'note_post_reply' => '在話題 <a href=\"\\1\" target="_blank">\\2</a> 中回復了你的<a href=\"\\3\" target="_blank">回帖</a>',
	
	'feed_blog' => '<b>{actor} 發表了新日誌</b>',
	
	'not_allow_upload' => '您現在沒有權限上傳圖片',
	'the_default_style' => '默認風格',
	'the_diy_style' => '自定義風格',
	'lack_of_access_to_upload_file_size' => '無法獲取上傳文件大小',
	'only_allows_upload_file_types' => '只允許上傳jpg、gif、png的圖片',
	'unable_to_create_upload_directory_server' => '服務器無法創建上傳目錄',
	'inadequate_capacity_space' => '空間容量不足，不能上傳新附件',
	'mobile_picture_temporary_failure' => '無法轉移臨時圖片到服務器指定目錄',
	'create_a_new_album' => '創建了新相冊',
	'upload_a_new_picture' => '上傳了新圖片',
	'the_total_picture' => '共 \\1 張圖片',
	'network_space_user' => '用戶',
	'casual_look' => '隨便看看',
	'get_passwd_subject' => '取回密碼郵件',
	'get_passwd_message' => '您只需在提交請求後的三天之內，通過點擊下面的鏈接重置您的密碼：<br />\\1<br />(如果上面不是鏈接形式，請將地址手工粘貼到瀏覽器地址欄再訪問)<br />上面的頁面打開後，輸入新的密碼後提交，之後您即可使用新的密碼登錄了。',
	
	'wall_pm_subject' => '您好，我給您留言了',
	'wall_pm_message' => '我在您的留言板給你留言了，[url=\\1]點擊這裡去留言板看看吧[/url]'
);

?>