<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: lang_main.php 6565 2008-03-14 09:26:09Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

$_SGLOBAL['mainlang'] = array(

	'before' => '前',
	'hour' => '小時',
	'minute' => '分鐘',
	'second' => '秒',
	'now' => '現在',
	'dot' => '、',
	
	'default_albumname' => '默認相冊',
	
	'man' => '男',
	'woman' => '女',
	'year' => '年',
	'month' => '月',
	'day' => '日',
	'unmarried' => '未婚',
	'married' => '已婚',
	
	'wall' => '留言',
	'pic_comment' => '圖片評論',
	'blog_comment' => '日誌評論',
	'share_comment' => '分享評論',
	'share_notice' => '分享通知',
	'doing_comment' => '迷你博客回復',
	'friend_notice' => '好友通知',
	'thread_comment' => '話題回復',
	
	'credit' => '積分',
	'credit_unit' => '個'
);

?>