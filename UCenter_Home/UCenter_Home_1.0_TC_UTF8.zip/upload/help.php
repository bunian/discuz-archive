<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: help.php 6703 2008-03-24 02:37:52Z liguode $
*/

include_once('./common.php');

if(empty($_GET['ac'])) $_GET['ac'] = 'register';

$actives = array($_GET['ac'] => ' style="font-weight:bold;"');

include template('help');

?>