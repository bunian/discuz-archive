<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: admincp_network.php 10761 2008-12-18 06:55:26Z liguode $
*/

if(!defined('IN_UCHOME') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!checkperm('managenetwork')) {
	cpmessage('no_authority_management_operation');
}

//ȡ�õ�������
$thevalue = array();
$network = data_get('network');
$network = empty($network)?array():unserialize(sstripslashes($network));
$module = trim($_GET['module'])?trim($_GET['module']):'';

if(submitcheck('thevaluesubmit')) {
	$key = key($_POST['network']);
	$networkcache = array();
	$wherearr = $sql = array();
	if(empty($_POST['network'][$key]['usedefault'])) {
		$_POST['network'][$key]['start'] = intval($_POST['network'][$key]['start']);
		$_POST['network'][$key]['limit'] = intval($_POST['network'][$key]['limit']) ? intval($_POST['network'][$key]['limit']) : 1;
		$groupids = isset($_POST['network'][$key]['groupid']) ? getdotstring($_POST['network'][$key]['groupid'], 'int') : '';
		switch($key) {
			case 'space':
				$uids = getdotstring($_POST['network'][$key]['uid'], 'int');
				if($uids) $wherearr[] = 'uid IN ('.$uids.')';
				if($groupids) $wherearr[] = 'groupid IN ('.$groupids.')';
				if($_POST['network'][$key]['updatetime']) {
					 $wherearr[] = getscopequery('updatetime', $_POST['network'][$key]['updatetime'], 1);
				}
				if($_POST['network'][$key]['dateline']) {
					 $wherearr[] = getscopequery('dateline', $_POST['network'][$key]['dateline'], 1);
				}
				//ʵ����֤
				if($_POST['network'][$key]['namestatus'] == 1) {
					$wherearr[] = "namestatus='1'";
				} elseif ($_POST['network'][$key]['namestatus'] == -1) {
					$wherearr[] = "namestatus='0'";
				}
				if($_POST['network'][$key]['avatar'] == 1) {
					$wherearr[] = "avatar='1'";
				} elseif ($_POST['network'][$key]['avatar'] == -1) {
					$wherearr[] = "avatar='0'";
				}
				
				$scopequery = getscopequery('viewnum', $_POST['network'][$key]['viewnum']);
				if($scopequery) $wherearr[] = $scopequery;
				$scopequery = getscopequery('friendnum', $_POST['network'][$key]['friendnum']);
				if($scopequery) $wherearr[] = $scopequery;
				$scopequery = getscopequery('credit', $_POST['network'][$key]['credit']);
				if($scopequery) $wherearr[] = $scopequery;
				if($wherearr) $sql['where'] = 'WHERE '.implode(' AND ', $wherearr);
				if($_POST['network'][$key]['order']) {
					$sql['order'] = 'ORDER BY '.$_POST['network'][$key]['order'].' '.$_POST['network'][$key]['sc'];
				}
				$sql['limit'] = getlimit($_POST['network'][$key]['start'], $_POST['network'][$key]['limit']);
				break;
			case 'doing':
				$uids = getdotstring($_POST['network'][$key]['uid'], 'int');
				if($uids) $wherearr[] = 'd.uid IN ('.$uids.')';
				if($_POST['network'][$key]['dateline']) {
					 $wherearr[] = getscopequery('dateline', $_POST['network'][$key]['dateline'], 1, 'd');
				}
				if($groupids) {
					$sql['from'] = ', '.tname('space').' s ';
					$wherearr[] = "s.groupid IN($groupids)";
					$wherearr[] = "d.uid = s.uid";
				}
				if($wherearr) $sql['where'] = 'WHERE '.implode(' AND ', $wherearr);
				if($_POST['network'][$key]['order']) {
					$sql['order'] = 'ORDER BY d.'.$_POST['network'][$key]['order'].' '.$_POST['network'][$key]['sc'];
				}
				$sql['limit'] = getlimit($_POST['network'][$key]['start'], $_POST['network'][$key]['limit']);
				break;
			case 'blog':
				$wherearr[] = "b.friend='0'";
				if($_POST['network'][$key]['dateline']) {
					 $wherearr[] = getscopequery('dateline', $_POST['network'][$key]['dateline'], 1, 'b');
				}
				
				$uids = getdotstring($_POST['network'][$key]['uid'], 'int');
				if($uids) $wherearr[] = 'b.uid IN ('.$uids.')';
				$scopequery = getscopequery('viewnum', $_POST['network'][$key]['viewnum'], 0, 'b');
				if($scopequery) $wherearr[] = $scopequery;
				
				$scopequery = getscopequery('replynum', $_POST['network'][$key]['replynum'], 0, 'b');
				if($scopequery) $wherearr[] = $scopequery;
				
				$scopequery = getscopequery('tracenum', $_POST['network'][$key]['tracenum'], 0, 'b');
				if($scopequery) $wherearr[] = $scopequery;
				
				if($groupids) {
					$network['blogfrom'] = tname('space').' s ,';
					$wherearr[] = "s.groupid IN($groupids)";
					$wherearr[] = "b.uid = s.uid";
				} else {
					$network['blogfrom'] = '';
				}
				
				if($wherearr) $sql['where'] = implode(' AND ', $wherearr);
				if($_POST['network'][$key]['order']) {
					$sql['order'] = 'ORDER BY b.'.$_POST['network'][$key]['order'].' '.$_POST['network'][$key]['sc'];
				}
				$sql['limit'] = getlimit($_POST['network'][$key]['start'], $_POST['network'][$key]['limit']);
				break;
			case 'album':
				$wherearr[] = "a.friend='0'";
				
				$albumids = getdotstring($_POST['network'][$key]['albumid'], 'int');
				if($albumids) $wherearr[] = 'a.albumid IN ('.$albumids.')';
				
				$uids = getdotstring($_POST['network'][$key]['uid'], 'int');
				if($uids) $wherearr[] = 'a.uid IN ('.$uids.')';
				
				if($_POST['network'][$key]['updatetime']) {
					 $wherearr[] = getscopequery('updatetime', $_POST['network'][$key]['updatetime'], 1, 'a');
				}
				if($_POST['network'][$key]['dateline']) {
					 $wherearr[] = getscopequery('dateline', $_POST['network'][$key]['dateline'], 1, 'a');
				}
				$scopequery = getscopequery('picnum', $_POST['network'][$key]['picnum'], 0, 'a');
				if($scopequery) $wherearr[] = $scopequery;
				
				if($groupids) {
					$sql['from'] = ', '.tname('space').' s ';
					$wherearr[] = "s.groupid IN($groupids)";
					$wherearr[] = "a.uid = s.uid";
				}
				
				if($wherearr) $sql['where'] = ' WHERE '.implode(' AND ', $wherearr);
				if($_POST['network'][$key]['order']) {
					$sql['order'] = 'ORDER BY a.'.$_POST['network'][$key]['order'].' '.$_POST['network'][$key]['sc'];
				}
				$sql['limit'] = getlimit($_POST['network'][$key]['start'], $_POST['network'][$key]['limit']);
				break;
			case 'share':
				$uids = getdotstring($_POST['network'][$key]['uid'], 'int');
				if($uids) $wherearr[] = 'sh.uid IN ('.$uids.')';
				if($_POST['network'][$key]['dateline']) {
					 $wherearr[] = getscopequery('dateline', $_POST['network'][$key]['dateline'], 1, 'sh');
				}
				
				if($groupids) {
					$sql['from'] = ', '.tname('space').' s ';
					$wherearr[] = "s.groupid IN($groupids)";
					$wherearr[] = "sh.uid = s.uid";
				}
				
				if($wherearr) $sql['where'] = 'WHERE '.implode(' AND ', $wherearr);
				if($_POST['network'][$key]['order']) {
					$sql['order'] = 'ORDER BY sh.'.$_POST['network'][$key]['order'].' '.$_POST['network'][$key]['sc'];
				}
				$sql['limit'] = getlimit($_POST['network'][$key]['start'], $_POST['network'][$key]['limit']);
				break;
			case 'mtag':
				$tagids = getdotstring($_POST['network'][$key]['tagid'], 'int');
				if($tagids) $wherearr[] = 'tagid IN ('.$tagids.')';
				
				$fieldids = getdotstring($_POST['network'][$key]['fieldid'], 'int');
				if($fieldids) $wherearr[] = 'fieldid IN ('.$fieldids.')';
				$scopequery = getscopequery('membernum', $_POST['network'][$key]['membernum']);
				if($scopequery) $wherearr[] = $scopequery;
				if($wherearr) $sql['where'] = 'WHERE '.implode(' AND ', $wherearr);
				if($_POST['network'][$key]['order']) {
					$sql['order'] = 'ORDER BY '.$_POST['network'][$key]['order'].' '.$_POST['network'][$key]['sc'];
				}
				$sql['limit'] = getlimit($_POST['network'][$key]['start'], $_POST['network'][$key]['limit']);
				break;
			case 'slide':
				
				$sql['from'] = ', '.tname('album').' a ';
				
				if($groupids) {
					$sql['from'] .= ', '.tname('space').' s ';
					$wherearr[] = "s.groupid IN($groupids)";
					$wherearr[] = "p.uid = s.uid";
				}
				
				$wherearr[] = "a.friend='0' AND a.albumid=p.albumid";
					
				$picids = getdotstring($_POST['network'][$key]['picid'], 'int');
				if($picids) $wherearr[] = 'p.picid IN ('.$picids.')';
				
				$albumids = getdotstring($_POST['network'][$key]['albumid'], 'int');
				if($albumids) $wherearr[] = 'p.albumid IN ('.$albumids.')';
				
				$uids = getdotstring($_POST['network'][$key]['uid'], 'int');
				if($uids) $wherearr[] = 'p.uid IN ('.$uids.')';

				if($wherearr) $sql['where'] = 'WHERE '.implode(' AND ', $wherearr);
				
				$sql['order'] = 'ORDER BY p.dateline DESC';
				$sql['limit'] = getlimit($_POST['network'][$key]['start'], $_POST['network'][$key]['limit']);
				break;
		}
		
		$sqlstring = implode(' ', $sql);
		$_POST['network'][$key]['sql'] = $sqlstring;
		$network[$key] = $_POST['network'][$key];
	} else {
		$network[$key] = array();
		$network[$key]['usedefault'] = 1;
	}
	foreach(array('space', 'doing', 'blog', 'album', 'share', 'mtag', 'slide', 'blogfrom') as $val) {
		$sql = '';
		$sql = $val != 'blogfrom' ? trim($network[$val]['sql']) : $network[$val];
		$networkcache[$val] = empty($sql) ? '' : $sql;
	}

	include_once(S_ROOT.'./source/function_cache.php');
	cache_write('network_setting', "network", $networkcache);
	data_set('network', $network);
	
	@unlink(S_ROOT.'./data/data_network.php');
	
	cpmessage('do_success', 'admincp.php?ac=network');
	
} elseif(submitcheck('settingsubmit')) {
	
	$setarr = array();
	foreach ($_POST['config'] as $var => $value) {
		$value = trim($value);
		if(!isset($_SCONFIG[$var]) || $_SCONFIG[$var] != $value) {
			$setarr[] = "('$var', '$value')";
		}
	}
	if($setarr) {
		$_SGLOBAL['db']->query("REPLACE INTO ".tname('config')." (var, datavalue) VALUES ".implode(',', $setarr));
		//���»���
		include_once(S_ROOT.'./source/function_cache.php');
		config_cache();
	}
	cpmessage('do_success', 'admincp.php?ac=network');
}

$configs = array();
$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('config')." WHERE var IN ('networkpage', 'networkupdate')");
while ($value = $_SGLOBAL['db']->fetch_array($query)) {
	$value['datavalue'] = shtmlspecialchars($value['datavalue']);
	$configs[$value['var']] = $value['datavalue'];
}

if($module == 'mtag') {
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('profield')." ORDER BY displayorder");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$list[] = $value;
	}
}

if(empty($network[$module])) {
	$network[$module]['usedefault'] = 1;
}

if($network[$module]['groupid'] && is_string($network[$module]['groupid'])) {
	$network[$module]['groupid'] = explode(',', $network[$module]['groupid']);
}

//����ѡ���
function getselectstr($var, $optionarray, $value='', $other='') {

	$selectstr = '<select id="'.$var.'" name="'.$var.'"'.$other.'>';
	foreach ($optionarray as $optionkey => $optionvalue) {
		$selectstr .= '<option value="'.$optionkey.'">'.$optionvalue.'</option>';
	}
	$selectstr = str_replace('value="'.$value.'"', 'value="'.$value.'" selected', $selectstr);
	$selectstr .= '</select>';
	return $selectstr;
}

function getscopequery($var, $tarr, $isdate=0, $pre='') {
	global $_SGLOBAL;

	$wheresql = '';
	if(!empty($pre)) $pre = $pre.'.';
	if($tarr) {
		if($isdate) {
			$tarr = intval($tarr);
			if($tarr) $wheresql = $pre.$var.'>=($_SGLOBAL[timestamp]-'.$tarr.')';
		} else {
			$tarr[0] = intval($tarr[0]);
			$tarr[1] = intval($tarr[1]);
			if($tarr[0] && $tarr[1] && $tarr[1] > $tarr[0]) {
				$wheresql = '('.$pre.$var.'>='.$tarr[0].' AND '.$pre.$var.'<='.$tarr[1].')';
			} else if($tarr[0] && empty($tarr[1])) {
				$wheresql = $pre.$var.'>='.$tarr[0];
			} else if(empty($tarr[0]) && $tarr[1]) {
				$wheresql = $pre.$var.'<='.$tarr[1];
			}
		}
	}
	return $wheresql;
}
//���$string���Ǳ������򷵻ؼ��ϡ������ַ���
function getdotstring ($string, $vartype, $allownull=false, $varscope=array(), $sqlmode=1, $unique=true) {

	if(is_array($string)) {
		$stringarr = $string;
	} else {
		if(substr($string, 0, 1) == '$') {
			return $string;
		}
		$string = str_replace('��', ',', $string);
		$string = str_replace(' ', ',', $string);
		$stringarr = explode(',', $string);
	}

	$newarr = array();
	foreach ($stringarr as $value) {
		$value = trim($value);
		if($vartype == 'int') {
			$value = intval($value);
		}
		if(!empty($varscope)) {
			if(in_array($value, $varscope)) {
				$newarr[] = $value;
			}
		} else {
			if($allownull) {
				$newarr[] = $value;
			} else {
				if(!empty($value)) $newarr[] = $value;
			}
		}
	}

	if($unique) $newarr = sarray_unique($newarr);
	if($vartype == 'int') {
		$string = implode(',', $newarr);
	} else {
		if($sqlmode) {
			$string = '\''.implode('\',\'', $newarr).'\'';
		} else {
			$string = implode(',', $newarr);
		}
	}
	return $string;
}
//����������ͬ��ֵȥ��,ͬʱ������ļ���Ҳ���Ե�
function sarray_unique($array) {
	$newarray = array();
	if(!empty($array) && is_array($array)) {
		$array = array_unique($array);
		foreach ($array as $value) {
			$newarray[] = $value;
		}
	}
	return $newarray;
}
function getlimit($start, $limit) {
	$start = $start? $start : 0;;
	$limit = $limit ? $limit : 1;
	return 'LIMIT '.$start.','.$limit;
}
	

?>