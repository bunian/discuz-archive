<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: convert.php 10835 2008-12-26 10:01:40Z zhengqingpeng $
*/

error_reporting(7);

if(!@include('./common.php')) {
	exit('�бN����󲾨�{�Ǯڥؿ��A�B��!');
}

$formhash = formhash();

//�C���B�z�Ӽ�
$perpage = 10;

$start = empty($_GET['start'])?0:intval($_GET['start']);
$turl = 'convert.php';
$set = array();
$tpre = '';

@include(S_ROOT.'./data/data_convert.php');
if($set) {
	$tpre = '`'.$set['dbname'].'`.'.$set['tablepre'];
}

$lockfile = './data/convert.lock';
if(file_exists($lockfile)) {
	show_msg('ĵ�i!�z�w�g�ഫ�L�ƾ�<br>
		���F�O�Ҽƾڦw���A�ХߧY��ʧR�� convert.php ���<br>
		�p�G�z�Q���s�ഫ�ƾڡA�ЧR�� data/convert.lock ���A�A���B�楻���');
}

if(submitcheck('setsubmit')) {
	include_once(S_ROOT.'./source/function_cache.php');
	
	cache_write('convert', "set", $_POST['set']);
	
	show_msg('�ƾڮw�O�s����', $turl.'?step=300');
	
} elseif(submitcheck('opensubmit')) {
	$uid = getcount('member', array('username'=>$_POST['username']), 'uid');
	if(!$uid) {
		show_msg('���w���Τ�W���s�b�A���ԷV��g�޲z���Τ�W', 'convert.php?step=18');
	}
	
	//�glog
	if(@$fp = fopen($lockfile, 'w')) {
		fwrite($fp, 'UCenter Home');
		fclose($fp);
	}
	updatetable('space', array('groupid'=>1), array('uid'=>$uid));
	show_msg('�]�m�޲z�����\\�A�ƾ��ഫ��������!<br>
		<font color=blue>�ХߧY�R�����ഫ���!</font><br>
		<a href="space.php">�n�����s�� UCenter Home �a</a><br>
		�n����A���˧A�i��@�U�ާ@�G<br>
		�i�J �޲z���x => �έp��s �����A��U���έp�ƾڶi��@�U���s�έp�C');
}

//�B�z�}�l
if(empty($_GET['step'])) {
	//�}�l
	$_GET['step'] = 0;
	
	show_msg("<span style=\"font-size:14px;\">���{�Ƿ|�NX-Space 3.x/4.x�t�C�ഫ�� UCenter Home�C</span><br><br>
		<strong>�ƾ��ഫ�����A�аȥ��\\Ū</strong><br>
		�ѩ�UCenter Home�PSupeSite/X-Space�\\�઺���P�A���ഫ�{�ǡA�u�|�i��H�U�ƾګH�����ഫ�A��L�ƾڤ����ഫ�A�л{�u�A�ѡG<br><br>
		<table width=\"100%\" class=\"datatable\">
		<tr style=\"font-weight:bold;\"><td width=\"100\">X-Space</td><td width=\"100\">UCenter Home</td><td>�Ƶ�</td></tr>
		<tr><td>�Τ�Ŷ��ƾ�</td><td>�Τ�Ŷ��ƾ�</td><td>�]�A�Ŷ��d�ݼơB�Ыخɶ��B�n���B����ϥΤj�p�B�~������</td></tr>
		<tr><td>��x</td><td>��x</td></td><td>�䤤�A��x�����۩w�q�r�q�����ഫ</td></tr>
		<tr><td>�Ϥ��D�D</td><td>��x</td><td>�Ϥ��D�D�����Ϥ��B���е��c���o�g��x�����e�C�P�ɡA�Ϥ������ഫ��Τ᪺�q�{�ۥU�̭�</td></tr>
		<tr><td>���</td><td>��x</td><td>��󪺤��СB�U���a�}���c���o�g��x�����e</td></tr>
		<tr><td>�ӫ~</td><td>��x</td><td>�ӫ~����B�ƶq�B���е��c���o�g��x�����e</td></tr>
		<tr><td>���W</td><td>��x</td><td>���W�����񾹡B���W���е��c���o�g��x�����e</td></tr>
		<tr><td>����</td><td>��x</td><td>���Ҫ��챵�B���Ҫ����е����q�o�g��x�����e</td></tr>
		<tr><td>�n��</td><td>�n��</td><td>�n���ഫ�ᬰ�ӽЦn�ͪ��A�A�ݭn�����@�U</td></tr>
		<tr><td>�d��</td><td>�d��</td><td>�䤤�A�������ܬ����}��</td></tr>
		<tr><td>��x����</td><td>��x����</td></td><td>&nbsp;</td></tr>
		<tr><td>����</td><td>����</td></td><td>&nbsp;</td></tr>
		</table>
		<br>
		<strong>�����ഫ���ƾ�</strong>�G<br>
		SupeSite/X-Space�����s�i�B���i�B�t�Τ����B�W�D�B�ҫ��B�Ҷ��B���áB�ͱ��챵�B�벼�B��T�B�Ķ����B�M�D�B�Τ᭷��B�}�L���ƾڤ��|���ഫ�C
		<br><br>
		
		�ھڱz�����I�W�ҡA�ഫ�ƾڥi��ݭn�Ƥ����A�ƦܴX�p�ɪ��ɶ�<br>�b�������A������X-Space���I�A�T��X�ݡA�í@�ߵ���!<br><br>
		<a href=\"$turl?step=100\">�ڤw�g�{�u�\\Ū�H�W�W�h�A�}�l�ƾ��ഫ�ާ@</a>");

} elseif ($_GET['step'] == 1) {
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}userspaces LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;
		if($value['islock']) continue;
		$value = saddslashes($value);
	
		//���ѨM:�B�~���Ŷ�
		$setarr = array(
			'uid' => $value['uid'],
			'username' => $value['username'],
			'credit' => $value['credit'],//�n��
			'domain' => $value['domain'],
			'viewnum' => $value['viewnum'],
			'dateline' => $value['dateline'],
			'updatetime' => $value['lastpost'],
			'attachsize' => $value['spacesize']
		);
		inserttable('space', $setarr, 0, true);
		
		$setarr = array(
			'uid' => $value['uid'],
			'resideprovince' => $value['province'],
			'residecity' => $value['city']
		);
		inserttable('spacefield', $setarr, 0, true);
	}
	
	show_next('�Τ�Ŷ��ƾ�');

} elseif ($_GET['step'] == 2) {
	
	//��x
	$next = false;
	$perpage = 5;
	$query = $_SGLOBAL['db']->query("SELECT i.*, ii.* FROM {$tpre}spaceitems i LEFT JOIN {$tpre}spaceblogs ii ON ii.itemid=i.itemid WHERE i.type='blog' AND i.folder<3 LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;

		//����B�z
		if($value['haveattach']) {
			$subquery = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}attachments WHERE itemid='$value[itemid]'");
			while ($subvalue = $_SGLOBAL['db']->fetch_array($subquery)) {
				if(strexists($value['message'], $value['filepath']) || strexists($value['message'], $value['thumbpath'])) {
					continue;
				}
				if($subvalue['isimage']) {
					//�Ϥ�
					$value['message'] .= "<div><img src=\"{$_SC[attachurl]}$subvalue[filepath]\"></div>";
				} else {
					$value['message'] .= "<div>���: <a href=\"{$_SC[attachurl]}$subvalue[filepath]\">$subvalue[filename]</a></div>";
				}
			}
		}
		if($value['mood']) {
			$value['message'] = '<div><strong>�߱�</strong>: '.$value['mood'].'</div>'.$value['message'];
		}
		if($value['weather']) {
			$value['message'] = '<div><strong>�Ѯ�</strong>: '.$value['weather'].'</div>'.$value['message'];
		}
		
		include_once(S_ROOT.'./source/function_cp.php');
		include_once(S_ROOT.'./source/function_blog.php');
		$value = saddslashes($value);
		
		$setarr = array(
			'blogid' => $value['itemid'],
			'uid' => $value['uid'],
			'username' => $value['username'],
			'subject' => $value['subject'],
			'classid' => $value['itemtypeid'],
			'viewnum' => $value['viewnum'],
			'replynum' => $value['replynum'],
			'dateline' => $value['dateline'],
			'noreply' => empty($value['allowreply'])?1:0,
			'friend' => $value['folder']>1?1:0
		);
		inserttable('blog', $setarr, 0, true);
		
		$setarr = array(
			'blogid' => $value['itemid'],
			'message' => message_replace($value['message']),
			'postip' => $value['postip']
		);
		inserttable('blogfield', $setarr, 0, true);
	}

	show_next('��x�ƾ�');
	
} elseif ($_GET['step'] == 3) {
	
	//�Ϥ�
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}attachments LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;
		if(!$value['isimage']) {
			continue;
		}
		
		$value = saddslashes($value);
		$setarr = array(
			'picid' => $value['aid'],
			'uid' => $value['uid'],
			'dateline' => $value['dateline'],
			'filename' => $value['filename'],
			'title' => $value['subject'],
			'type' => $value['attachtype'],
			'size' => $value['size'],
			'filepath' => $value['filepath'],
			'thumb' => 0
		);
		inserttable('pic', $setarr, 0, true);
	}

	show_next('�Ϥ��ƾ�');
	
} elseif ($_GET['step'] == 4) {
	
	$next = false;
	$updateid = array();
	$query = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}friends LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;
		$value = saddslashes($value);
		$updateid[] = $value['frienduid'];
		$setarr = array(
			'uid' => $value['uid'],
			'fuid' => $value['frienduid']
		);
		inserttable('friend', $setarr, 0, true);
	}
	if($updateid) {
		$_SGLOBAL['db']->query("UPDATE ".tname('friend')." f, ".tname('space')." s SET f.fusername = s.username where f.fuid IN ('".implode("','", $updateid)."') AND f.fuid=s.uid");
	}
	
	show_next('�n��');

} elseif ($_GET['step'] == 5) {
	
	$cid_start = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT cid FROM {$tpre}spacecomments ORDER BY cid DESC LIMIT 1"), 0)+100;
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}guestbooks LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;
		$value = saddslashes($value);
		$setarr = array(
			'cid' => ($cid_start + $value['gid']),
			'uid' => $value['uid'],
			'id' => $value['uid'],
			'idtype' => 'uid',
			'author' => $value['author'],
			'authorid' => $value['authorid'],
			'ip' => $value['ip'],
			'message' => $value['message'],
			'dateline' => $value['dateline']
		);
		inserttable('comment', $setarr, 0, true);
	}
	
	show_next('�d��');

} elseif ($_GET['step'] == 6) {
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}itemtypes LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;
		$value = saddslashes($value);
		
		$setarr = array(
			'classid' => $value['typeid'],
			'classname' => $value['typename'],
			'uid' => $value['uid'],
			'dateline' => $_SGLOBAL['timestamp']
		);
		inserttable('class', $setarr, 0, true);
	}
	
	show_next('�ӤH����');

} elseif ($_GET['step'] == 7) {
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}spacecomments WHERE type != 'news' LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;
		$value = saddslashes($value);
		if(empty($value['message'])) {
			continue;
		}
		$setarr = array(
			'cid' => $value['cid'],
			'id' => $value['itemid'],
			'idtype' => 'blogid',
			'uid' => $value['uid'],
			'authorid' => $value['authorid'],
			'author' => $value['author'],
			'ip' => $value['ip'],
			'dateline' => $value['dateline'],
			'message' => $value['message']
		);
		inserttable('comment', $setarr, 0, true);
	}
	
	show_next('����');

} elseif ($_GET['step'] == 8) {
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT i.*, ii.* FROM {$tpre}spaceitems i LEFT JOIN {$tpre}spacefiles ii ON ii.itemid=i.itemid WHERE i.type='file' AND i.folder<3 LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;

		if($value['filesize']) {
			$value['message'] .= '<div><strong>�j�p</strong>: '.$value['filesize'].' '.$value['filesizeunit'].'</div>';
		}
		if($value['version']) {
			$value['message'] .= '<div><strong>����</strong>: '.$value['version'].'</div>';
		}
		if($value['producer']) {
			$value['message'] .= '<div><strong>�X�~</strong>: '.$value['producer'].'</div>';
		}
		if($value['downfrom']) {
			$value['message'] .= '<div><strong>�ӷ�</strong>: '.$value['downfrom'].'</div>';
		}
		if($value['language']) {
			$value['message'] .= '<div><strong>�y��</strong>: '.$value['language'].'</div>';
		}
		if($value['permission']) {
			$value['message'] .= '<div><strong>���v</strong>: '.$value['permission'].'</div>';
		}
	
		//����p��B�z?
		$i = 0;
		if($value['haveattach']) {
			$subquery = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}attachments WHERE itemid='$value[itemid]'");
			while ($subvalue = $_SGLOBAL['db']->fetch_array($subquery)) {
				if(strexists($value['message'], $value['filepath']) || strexists($value['message'], $value['thumbpath'])) {
					continue;
				}
				if($subvalue['isimage']) {
					//�Ϥ�
					$value['message'] .= "<div><img src=\"{$_SC[attachurl]}$subvalue[filepath]\"></div>";
				} else {
					$i++;
					$value['message'] .= "<div><strong>���a�U��[$i]</strong>: <a href=\"{$_SC[attachurl]}$subvalue[filepath]\">$subvalue[filename]</a> (�U����A�бN��󭫩R�W�� $subvalue[filename] ��i���`�ϥ�)</div>";
				}
			}
		}
		
		$i = 0;
		if($value['remoteurl']) {
			$remoteurl = unserialize($value['remoteurl']);
			foreach ($remoteurl as $rs) {
				$i++;
				$value['message'] .= '<div><strong>���{�U��['.$i.']</strong>: <a href="'.$rs['remoteurl'].'" target="_blank">'.$rs['remoteurlname'].'</a></div>';
			}
		}

		$value = saddslashes($value);
		$setarr = array(
			'blogid' => $value['itemid'],
			'uid' => $value['uid'],
			'username' => $value['username'],
			'subject' => $value['subject'],
			'classid' => $value['itemtypeid'],
			'viewnum' => $value['viewnum'],
			'replynum' => $value['replynum'],
			'dateline' => $value['dateline'],
			'noreply' => empty($value['allowreply'])?1:0,
			'friend' => $value['folder']>1?1:0
		);
		inserttable('blog', $setarr, 0, true);
		
		$setarr = array(
			'blogid' => $value['itemid'],
			'message' => message_replace($value['message']),
			'postip' => $value['postip']
		);
		inserttable('blogfield', $setarr, 0, true);
	}
	
	show_next('���ƾ�');

} elseif ($_GET['step'] == 9) {
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT i.*, ii.* FROM {$tpre}spaceitems i LEFT JOIN {$tpre}spacegoods ii ON ii.itemid=i.itemid WHERE i.type='goods' AND i.folder<3 LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;

		//����p��B�z?
		if($value['haveattach']) {
			$subquery = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}attachments WHERE itemid='$value[itemid]'");
			while ($subvalue = $_SGLOBAL['db']->fetch_array($subquery)) {
				if(strexists($value['message'], $value['filepath']) || strexists($value['message'], $value['thumbpath'])) {
					continue;
				}
				if($subvalue['isimage']) {
					//�Ϥ�
					$value['message'] .= "<div><img src=\"{$_SC[attachurl]}$subvalue[filepath]\"></div>";
				} else {
					$value['message'] .= "<div><strong>���</strong>: <a href=\"{$_SC[attachurl]}$subvalue[filepath]\">$subvalue[filename]</a></div>";
				}
			}
		}
		if($value['price']) {
			$value['message'] .= '<div><strong>����</strong>: '.$value['price'].'</div>';
		}
		if($value['province']) {
			$value['message'] .= '<div><strong>�a��</strong>: '.$value['province'].' '.$value['city'].'</div>';
		}

		$value = saddslashes($value);
		$setarr = array(
			'blogid' => $value['itemid'],
			'uid' => $value['uid'],
			'username' => $value['username'],
			'subject' => $value['subject'],
			'classid' => $value['itemtypeid'],
			'viewnum' => $value['viewnum'],
			'replynum' => $value['replynum'],
			'dateline' => $value['dateline'],
			'noreply' => empty($value['allowreply'])?1:0,
			'friend' => $value['folder']>1?1:0
		);
		inserttable('blog', $setarr, 0, true);
		
		$setarr = array(
			'blogid' => $value['itemid'],
			'message' => message_replace($value['message']),
			'postip' => $value['postip']
		);
		inserttable('blogfield', $setarr, 0, true);
	}
	
	show_next('�ӫ~�ƾ�');
	
} elseif ($_GET['step'] == 10) {
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT i.*, ii.* FROM {$tpre}spaceitems i LEFT JOIN {$tpre}spacelinks ii ON ii.itemid=i.itemid WHERE i.type='link' AND i.folder<3 LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;

		//����p��B�z?
		if($value['haveattach']) {
			$subquery = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}attachments WHERE itemid='$value[itemid]'");
			while ($subvalue = $_SGLOBAL['db']->fetch_array($subquery)) {
				if(strexists($value['message'], $value['filepath']) || strexists($value['message'], $value['thumbpath'])) {
					continue;
				}
				if($subvalue['isimage']) {
					//�Ϥ�
					$value['message'] .= "<div><img src=\"{$_SC[attachurl]}$subvalue[filepath]\"></div>";
				} else {
					$value['message'] .= "<div><strong>���</strong>: <a href=\"{$_SC[attachurl]}$subvalue[filepath]\">$subvalue[filename]</a></div>";
				}
			}
		}
		
		$value['message'] .= '<div><strong>�챵</strong>: <a href="'.$value['url'].'" target="_blank">�I���X��</a></div>';
		
		$value = saddslashes($value);
		$setarr = array(
			'blogid' => $value['itemid'],
			'uid' => $value['uid'],
			'username' => $value['username'],
			'subject' => $value['subject'],
			'classid' => $value['itemtypeid'],
			'viewnum' => $value['viewnum'],
			'replynum' => $value['replynum'],
			'dateline' => $value['dateline'],
			'noreply' => empty($value['allowreply'])?1:0,
			'friend' => $value['folder']>1?1:0
		);
		inserttable('blog', $setarr, 0, true);
		
		$setarr = array(
			'blogid' => $value['itemid'],
			'message' => message_replace($value['message']),
			'postip' => $value['postip']
		);
		inserttable('blogfield', $setarr, 0, true);
	}
	
	show_next('���Ҽƾ�');

} elseif ($_GET['step'] == 11) {
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT i.*, ii.* FROM {$tpre}spaceitems i LEFT JOIN {$tpre}spacevideos ii ON ii.itemid=i.itemid WHERE i.type='video' AND i.folder<3 LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;

		//����p��B�z?
		if($value['haveattach']) {
			$subquery = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}attachments WHERE itemid='$value[itemid]'");
			while ($subvalue = $_SGLOBAL['db']->fetch_array($subquery)) {
				if(strexists($value['message'], $value['filepath']) || strexists($value['message'], $value['thumbpath'])) {
					continue;
				}
				if($subvalue['isimage']) {
					//�Ϥ�
					$value['message'] .= "<div><img src=\"{$_SC[attachurl]}$subvalue[filepath]\"></div>";
				} else {
					$value['message'] .= "<div><strong>���</strong>: <a href=\"{$_SC[attachurl]}$subvalue[filepath]\">$subvalue[filename]</a></div>";
				}
			}
		}
		
		if($value['videosize']) {
			$value['videosize'] = formatsize($value['videosize']);
			$value['message'] .= "<div><strong>�v���j�p</strong>: $value[videosize]</div>";
		}
		
		if($value['file']) {
			$flvurl = getsiteurl().rawurlencode($value['file']);
			$value['message'] .= '<div>
				<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" id="photo" align="middle" height="315" width="420">
				<param name="movie" value="image/flv.swf?flvurl='.$flvurl.'">
				<param name="quality" value="high">
				<param name="allowFullScreen" value="true">
				<embed src="image/flv.swf?flvurl='.$flvurl.'" quality="high" name="photo" type="application/x-shockwave-flash" allowfullscreen="true" pluginspage="http://www.macromedia.com/go/getflashplayer" align="middle" height="315" width="420">
				</object>
				<br>'.$value['videoname'].'</a></div>';
		}

		if($value['remoteurl']) {
			$remoteurl = unserialize($value['remoteurl']);
			if($value['subtype'] == 'media') {
				foreach ($remoteurl as $rs) {
					$value['message'] .= '<div>
						<object id="PlayerEx2" classid="clsid:6BF52A52-394A-11d3-B153-00C04F79FAA6" width="420" height="315">
						<param name="AutoStart" value="0">
						<param name="URL" value="'.$rs['remoteurl'].'">
						<embed autostart="false" src="'.$rs['remoteurl'].'" type="video/x-ms-wmv" width="420" height="315" controls="ImageWindow" console="cons"></embed>
						</object>
						<br>'.$rs['remoteurlname'].'</div>';
				}
			} elseif($value['subtype'] == 'real') {
				foreach ($remoteurl as $rs) {
					$value['message'] .= '<div>
						<object id="RVOCX" classid="CLSID:CFCDAA03-8BE4-11CF-B84B-0020AFBBCCFA" width="420" height="315">
						<param name="AUTOSTART" value="0">
						<param name="SRC" value="'.$rs['remoteurl'].'">
						<param name="CONTROLS" value="ControlPanel">
						<param name="CONSOLE" value="cons">
						<embed autostart="false" src="'.$rs['remoteurl'].'" type="audio/x-pn-realaudio-plugin" width="420" height="315" controls="ControlPanel" console="cons"></embed>
						</object>
						<br>'.$rs['remoteurlname'].'</div>';
				}
			} elseif($value['subtype'] == 'flash') {
				foreach ($remoteurl as $rs) {
					if(fileext($rs['remoteurl']) == 'flv') {
						$rs['remoteurl'] = 'image/flv.swf?flvurl='.$rs['remoteurl'];
					}
					$value['message'] .= '<div>
						<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" id="photo" align="middle" height="315" width="420">
						<param name="movie" value="'.$rs['remoteurl'].'">
						<param name="quality" value="high">
						<param name="allowFullScreen" value="true">
						<embed src="'.$rs['remoteurl'].'" quality="high" name="photo" type="application/x-shockwave-flash" allowfullscreen="true" pluginspage="http://www.macromedia.com/go/getflashplayer" align="middle" height="315" width="420">
						</object>
						<br>'.$rs['remoteurlname'].'</div>';
				}
			} else {
				foreach ($remoteurl as $rs) {
					$value['message'] .= '<div><a href="'.$rs['remoteurl'].'">'.$rs['remoteurlname'].'</a></div>';
				}
			}
		}
		
		$value = saddslashes($value);
		$setarr = array(
			'blogid' => $value['itemid'],
			'uid' => $value['uid'],
			'username' => $value['username'],
			'subject' => $value['subject'],
			'classid' => $value['itemtypeid'],
			'viewnum' => $value['viewnum'],
			'replynum' => $value['replynum'],
			'dateline' => $value['dateline'],
			'noreply' => empty($value['allowreply'])?1:0,
			'friend' => $value['folder']>1?1:0
		);
		inserttable('blog', $setarr, 0, true);
		
		$setarr = array(
			'blogid' => $value['itemid'],
			'message' => message_replace($value['message']),
			'postip' => $value['postip']
		);
		inserttable('blogfield', $setarr, 0, true);
	}
	
	show_next('���W�ƾ�');
	
} elseif ($_GET['step'] == 12) {
	
	$next = false;
	$query = $_SGLOBAL['db']->query("SELECT i.*, ii.* FROM {$tpre}spaceitems i LEFT JOIN {$tpre}spaceimages ii ON ii.itemid=i.itemid WHERE i.type='image' AND i.folder<3 LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$next = true;

		//����p��B�z?
		if($value['haveattach']) {
			$subquery = $_SGLOBAL['db']->query("SELECT * FROM {$tpre}attachments WHERE itemid='$value[itemid]'");
			while ($subvalue = $_SGLOBAL['db']->fetch_array($subquery)) {
				if(strexists($value['message'], $value['filepath']) || strexists($value['message'], $value['thumbpath'])) {
					continue;
				}
				if($subvalue['isimage']) {
					//�Ϥ�
					$value['message'] .= "<div><img src=\"{$_SC[attachurl]}$subvalue[filepath]\"></div>";
				} else {
					$value['message'] .= "<div><strong>���</strong>: <a href=\"{$_SC[attachurl]}$subvalue[filepath]\">$subvalue[filename]</a></div>";
				}
			}
		}
		
		$value = saddslashes($value);
		$setarr = array(
			'blogid' => $value['itemid'],
			'uid' => $value['uid'],
			'username' => $value['username'],
			'subject' => $value['subject'],
			'classid' => $value['itemtypeid'],
			'viewnum' => $value['viewnum'],
			'replynum' => $value['replynum'],
			'dateline' => $value['dateline'],
			'noreply' => empty($value['allowreply'])?1:0,
			'friend' => $value['folder']>1?1:0
		);
		inserttable('blog', $setarr, 0, true);
		
		$setarr = array(
			'blogid' => $value['itemid'],
			'message' => message_replace($value['message']),
			'postip' => $value['postip']
		);
		inserttable('blogfield', $setarr, 0, true);
	}
	
	show_next('�Ϥ��D�D�ƾ�');
	
} elseif ($_GET['step'] == 13) {
	$msg = <<<EOF
	<form method="post" action="convert.php">
	<table>
	<tr><td colspan="2">�ƾ��ഫ����!<br><br>
	�̫�A�п�J�A���Τ�W�A�t�αN�z�]��UCenter Home���޲z��!
	</td></tr>
	<tr><td>�z���Τ�W</td><td><input type="text" name="username" value="" size="30"></td></tr>
	<tr><td></td><td><input type="submit" name="opensubmit" value="�]���޲z��"></td></tr>
	</table>
	<input type="hidden" name="formhash" value="$formhash">
	</form>
EOF;
	show_msg($msg);
	
} elseif ($_GET['step'] == 100) {
	
	show_msg("<strong>�����A�z�ݭn�N�׾¤ɯŨ�Discuz! 6.1 (�o�@�B�D�`���n�A�ӥB���ݶi�檺)�C<br>���U�ӡA�U���åB���s�w�� UCenter Home �{��</strong><br><font color=blue>ĵ�i�G�p�G�z��UCenter Home���O���s�w�ˡA���ഫ�{�Ƿ|�л\\�z�{�����Ҧ��ƾڡC�а��n�ƾڳƥ��I</font><br><br>
		<a href=\"$turl?step=110\">�w�g�ɯŤF�׾¡A�å��s�w�ˤFUCenter Home�A�i�J�U�@�B</a>");
	
} elseif ($_GET['step'] == 110) {
	
	show_msg("<strong>�T�O���e UCenter Home �ϥΪ�MySQL�b���A������v���s���ާ@���e�� X-Space ���ƾڮw�C</strong><br><br>
		<a href=\"$turl?step=120\">�w�g�]�mMySQL�v���A�i�J�U�@�B</a>");
	
} elseif ($_GET['step'] == 120) {
	
	show_msg("<strong>�бN��SupeSite/X-Space�s����󪺥ؿ��]�@�묰 ./attachments �ؿ��^�����Ҧ���󧨩M���A�ƻs����e�� UCenter Home �{�Ǥ��� ./attachment �ؿ��U���C</strong><br><br>
		<a href=\"$turl?step=130\">�w�g�ƻs�n������A�i�J�U�@�B</a>");
	
} elseif ($_GET['step'] == 130) {
	
	show_msg("<strong>�бN��SupeSite/X-Space�s��v�����ؿ��]�@�묰 ./video �ؿ��^�����Ҧ���󧨩M���A�ƻs�� ���e�� UCenter Home �{�Ǥ��� ./video �ؿ��U���]�Х��Ыظ� video ��󧨡^�C</strong><br><br>
		<a href=\"$turl?step=200\">�w�g�ƻs�n���W���A�i�J�U�@�B</a>");
	
} elseif ($_GET['step'] == 200) {

	$msg = <<<EOF
	<strong>�]�m�w����X-Space���H���G</strong><br><br>
	<form method="post" action="convert.php">
	<table>
	<tr><td>�Ҧb�ƾڮw�W�G</td><td><input type="text" name="set[dbname]" value="supesite"></td></tr>
	<tr><td>���W�e��G</td><td><input type="text" name="set[tablepre]" value="supe_"></td></tr>
	<tr><td>���e������ؿ��W�G</td><td><input type="text" name="set[attach]" value="attachments"> (<strong>�ǽT��g</strong>�A�@�묰 attachments)</td></tr>
	<tr><td>���e������X��URL�G</td><td><input type="text" name="set[purl]" value="http://localhost/xspace/attachments/" size="40"> (<strong>�ǽT��g�A�����[�u/�v</strong>)</td></tr>
	<tr><td colspan="2">�зǽT��g���eX-Space������ؿ��W�M����X��url�a�}�C<br>���ഫ�{�Ƿ|�ھڳo����ܶq�A�N���e�����Ϥ��a�}�i���q�����A<br>�H�קK�X�{�Ϥ��L�k�X�ݪ����D�C
	</td></tr>
	<tr><td></td><td><input type="submit" name="setsubmit" value="����O�s"></td></tr>
	</table>
	<input type="hidden" name="formhash" value="$formhash">
	</form>
EOF;
	show_msg($msg);

} elseif ($_GET['step'] == 300) {
	
	if(!$query = $_SGLOBAL['db']->query("SELECT uid FROM {$tpre}userspaces LIMIT 1", 'SILENT')) {
		show_msg("���ॿ�T�s�� X-Space ���ƾڮw�A���ˬdX-Space�]�m�A�åB�T�OUCenter Home��MySQL�b���i�H���v���ާ@X-Space���ƾڮw�C");
	} else {
		show_msg("�˴� X-Space ���ƾڮw�A�s�����\\�C<br><br><a href=\"$turl?step=1\">�I�������}�l�i�J�ƾڤɯŹL�{</a>");
	}
} 

//����
function show_next($batch) {
	global $turl, $next, $start, $perpage;
	
	$nowtime = gmdate('H:i:\<\b\>s\<\/\b\>', time()+8*3600);
	if($next) {
		$start = $start + $perpage;
		show_msg("�� $_GET[step] �B / �@ 13 �B<br>OK,�����B�z����! ($start)<br><br><a href=\"$turl?step=$_GET[step]&start=$start\">�i�J�U�@�� <strong>$batch</strong> �B�z, �Э@�ߵ��� ...</a><br><br>Now Time: $nowtime ", "$turl?step=$_GET[step]&start=$start");
	} else {
		show_msg("�� $_GET[step] �B / �@ 13 �B<br><strong>$batch</strong> �����B�z����! <br><br><a href=\"$turl?step=".($_GET['step']+1)."\">�i�J�U�@�B�B�z</a><br><br>Now Time: $nowtime", "$turl?step=".($_GET['step']+1));
	}
}

//���
function show_msg($message, $url_forward='') {
	global $_SGLOBAL;

	obclean();
	
	$_SGLOBAL['extrahead'] = $url_forward ? '<meta http-equiv="refresh" content="0; url='.$url_forward.'">' : '';
	show_header();
	print<<<END
	<table>
	<tr><td>$message</td></tr>
	</table>
END;
	show_footer();
	exit();
}

//�ƻs���
function scopy($source, $obj) {
	if(!@copy($source, $obj)) {
		$content = '';
		if(@$fp = fopen($source, 'rb')) {
			$content = fread($fp, filesize($source));
			fclose($fp);
		}
		if($content && @$fp = fopen($obj, 'wb')) {
			fwrite($fp, $content);
			fclose($fp);
		}
	}
}

//�����Y��
function show_header() {
	global $_SGLOBAL, $_SC;

	$nowarr[$_GET['step']] = ' class="current"';
	
	if(empty($_SGLOBAL['extrahead'])) $_SGLOBAL['extrahead'] = '';
	
	print<<<END
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml"> 
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=$_SC[charset]" />
	$_SGLOBAL[extrahead]
	<title> X-Space => UCenter Home �ഫ�{�� </title>
	<style type="text/css">
	* {font-size:12px; font-family: Verdana, Arial, Helvetica, sans-serif; line-height: 1.5em; word-break: break-all; }
	body { text-align:center; margin: 0; padding: 0; background: #F5FBFF; }
	.bodydiv { margin: 40px auto 0; width:720px; text-align:left; border: solid #86B9D6; border-width: 5px 1px 1px; background: #FFF; }
	h1 { font-size: 18px; margin: 1px 0 0; line-height: 50px; height: 50px; background: #E8F7FC; color: #5086A5; padding-left: 10px; }
	#menu {width: 100%; margin: 10px auto; text-align: center; }
	#menu td { height: 30px; line-height: 30px; color: #999; border-bottom: 3px solid #EEE; }
	.current { font-weight: bold; color: #090 !important; border-bottom-color: #F90 !important; }
	.showtable { width:100%; border: solid; border-color:#86B9D6 #B2C9D3 #B2C9D3; border-width: 3px 1px 1px; margin: 10px auto; background: #F5FCFF; }
	.showtable td { padding: 3px; }
	.showtable strong { color: #5086A5; }
	.datatable { width: 100%; margin: 10px auto 25px; }
	.datatable td { padding: 5px 0; border-bottom: 1px solid #EEE; }
	input { border: 1px solid #B2C9D3; padding: 5px; background: #F5FCFF; }
	.button { margin: 10px auto 20px; width: 100%; }
	.button td { text-align: center; }
	.button input, .button button { border: solid; border-color:#F90; border-width: 1px 1px 3px; padding: 5px 10px; color: #090; background: #FFFAF0; cursor: pointer; }
	#footer { font-size: 10px; line-height: 40px; background: #E8F7FC; text-align: center; height: 38px; overflow: hidden; color: #5086A5; margin-top: 20px; }
	</style>
	<script src="source/script_ajax.js" type="text/javascript" language="javascript"></script>
	<script src="source/script_common.js" type="text/javascript" language="javascript"></script>
	</head>
	<body>
	<div class="bodydiv">
	<h1>X-Space => UCenter Home �ഫ�{��</h1>
	<div style="width:90%;margin:0 auto;">
	<table id="menu">
	<tr>
	<td{$nowarr[0]}>�ഫ�}�l</td>
	<td{$nowarr[1]}>�ƾ��ഫ</td>
	<td>�ɯŧ���</td>
	</tr>
	</table>
	<br>
END;
}

//��������
function show_footer() {
	print<<<END
	</div>
	<div id="footer">&copy; Comsenz Inc. 2001-2008 u.discuz.net</div>
	</div>
	<br>
	</body>
	</html>
END;
}

//���e����
function message_replace($message) {
	global $_SC, $set;
	
	$searchs = array(
		'"'.$set['attach'].'/',
		'"/'.$set['attach'].'/',
		'href='.$set['attach'].'/',
		'href=/'.$set['attach'].'/',
		$set['purl']
	);
	$replaces = array(
		'"'.$_SC['attachurl'],
		'"'.$_SC['attachurl'],
		'href='.$_SC['attachurl'],
		'href='.$_SC['attachurl'],
		$_SC['attachurl']
	);
	$message = str_replace($searchs, $replaces, $message);
	
	return $message;
}

?>