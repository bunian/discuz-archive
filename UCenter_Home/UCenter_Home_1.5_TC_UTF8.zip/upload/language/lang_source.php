<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: lang_source.php 9580 2008-11-10 03:21:36Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

$_SGLOBAL['sourcelang'] = array (

	'hour' => '小時',
	'before' => '前',
	'minute' => '分鐘',
	'second' => '秒',
	'now' => '現在',
	'dot' => '、',
	'mtag' => '群組',
	'friend_group_default' => '其他',
	'friend_group_1' => '通過本站認識',
	'friend_group_2' => '通過活動認識',
	'friend_group_3' => '通過朋友認識',
	'friend_group_4' => '親人',
	'friend_group_5' => '同事',
	'friend_group_6' => '同學',
	'friend_group_7' => '不認識',
	'friend_group' => '自定義',
	'default_albumname' => '默認相冊',
	'wall' => '留言',
	'pic_comment' => '圖片評論',
	'blog_comment' => '日誌評論',
	'blog_trace' => '日誌踩一腳',
	'share_comment' => '分享評論',
	'share_notice' => '分享',
	'doing_comment' => '記錄回復',
	'friend_notice' => '好友',
	'thread_comment' => '話題回復',
	'credit' => '積分',
	'credit_unit' => '個',
	'man' => '男',
	'woman' => '女',
	'year' => '年',
	'month' => '月',
	'day' => '日',
	'unmarried' => '單身',
	'married' => '非單身'
);

?>