<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: lang_cp.php 10978 2009-01-14 02:39:06Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

$_SGLOBAL['cplang'] = array(

	'by' => '通過',
	'tab_space' => ' ',
	'note_blog_trace' => '踩了一腳你的日誌 <a href="\\1" target="_blank">\\2</a>',
	'feed_trace' => '{actor} 踩了一腳 {username} 的日誌 {blog}',
	'feed_comment_space' => '{actor} 在 {touser} 的留言板留了言',
	'feed_comment_image' => '{actor} 評論了 {touser} 的圖片',
	'feed_comment_blog' => '{actor} 評論了 {touser} 的日誌 {blog}',
	'feed_comment_share' => '{actor} 對 {touser} 分享的 {share} 發表了評論',
	'share' => '分享',
	'share_action' => '分享了',
	'note_wall' => '在留言板上給你<a href="\\1" target="_blank">留言</a>',
	'note_wall_reply' => '回復了你的<a href="\\1" target="_blank">留言</a>',
	'note_pic_comment' => '評論了你的<a href="\\1" target="_blank">圖片</a>',
	'note_pic_comment_reply' => '回復了你的<a href="\\1" target="_blank">圖片評論</a>',
	'note_blog_comment' => '評論了你的日誌 <a href="\\1" target="_blank">\\2</a>',
	'note_blog_comment_reply' => '回復了你的<a href="\\1" target="_blank">日誌評論</a>',
	'note_share_comment' => '評論了你的 <a href="\\1" target="_blank">分享</a>',
	'note_share_comment_reply' => '回復了你的<a href="\\1" target="_blank">分享評論</a>',
	'wall_pm_subject' => '您好，我給您留言了',
	'wall_pm_message' => '我在您的留言板給你留言了，[url=\\1]點擊這裡去留言板看看吧[/url]',
	'note_showcredit' => '贈送給您 \\1 個競價積分，幫助提升在<a href="network.php?ac=space&view=show" target="_blank">競價排行榜</a>中的名次',
	'feed_showcredit' => '{actor} 贈送給 {fusername} 競價積分 {credit} 個，幫助好友提升在<a href="network.php?ac=space&view=show" target="_blank">競價排行榜</a>中的名次',
	'feed_showcredit_self' => '{actor} 增加競價積分 {credit} 個，提升自己在<a href="network.php?ac=space&view=show" target="_blank">競價排行榜</a>中的名次',
	'feed_doing_title' => '{actor}：{message}',
	'note_doing_reply' => '在<a href="\\1" target="_blank">記錄</a>中對你進行了回復',
	'feed_friend_title' => '{actor} 和 {touser} 成為了好友',
	'note_friend_add' => '和你成為了好友',
	
	
	
	'friend_subject' => '<a href="\\2" target="_blank">\\1 請求加你為好友</a>',
	'comment_friend' =>'<a href="\\2" target="_blank">\\1 給你留言了</a>',
	'photo_comment' => '<a href="\\2" target="_blank">\\1 評論了你的照片</a>',
	'blog_comment' => '<a href="\\2" target="_blank">\\1 評論了你的日誌</a>',
	'share_comment' => '<a href="\\2" target="_blank">\\1 評論了你的分享</a>',
	'friend_pm' => '<a href="\\2" target="_blank">\\1 給你發私信了</a>',
	'poke_subject' => '<a href="\\2" target="_blank">\\1 向你打招呼</a>',
	'mtag_reply' => '<a href="\\2" target="_blank">\\1 回復了你的話題</a>',

	'friend_pm_reply' => '\\1 回復了你的私信',
	'comment_friend_reply' => '\\1 回復了你的留言',
	'blog_comment_reply' => '\\1 回復了你的日誌評論',
	'photo_comment_reply' => '\\1 回復了你的照片評論',
	'share_comment_reply' => '\\1 回復了你的分享評論',
	
	'invite_subject' => '\\1邀請您加入\\2，並成為TA的好友',
	'invite_massage' => '<table border="0">
		<tr>
		<td valign="top">\\1</td>
		<td valign="top">
		<h3>Hi，我是\\2，在\\3上建立了個人主頁，邀請您也加入並成為我的好友</h3><br>
		請加入到我的好友中，你就可以通過我的個人主頁瞭解我的近況，分享我的照片，隨時與我保持聯繫<br>
		<br>
		邀請附言：<br>
		\\4
		<br><br>
		<strong>請你點擊以下鏈接，接受好友邀請：</strong><br>
		<a href="\\5">\\5</a><br>
		<br>
		<strong>如果你擁有\\3上面的賬號，請點擊以下鏈接查看我的個人主頁：</strong><br>
		<a href="\\6">\\6</a><br>
		</td></tr></table>',
	
	'app_invite_subject' => '\\1邀請您加入\\2，一起來玩\\3',
	'app_invite_massage' => '<table border="0">
		<tr>
		<td valign="top">\\1</td>
		<td valign="top">
		<h3>Hi，我是\\2，在\\3上玩 \\7，邀請您也加入一起玩</h3><br>
		<br>
		邀請附言：<br>
		\\4
		<br><br>
		<strong>請你點擊以下鏈接，接受好友邀請一起玩\\7：</strong><br>
		<a href="\\5">\\5</a><br>
		<br>
		<strong>如果你擁有\\3上面的賬號，請點擊以下鏈接查看我的個人主頁：</strong><br>
		<a href="\\6">\\6</a><br>
		</td></tr></table>',
	
	'feed_mtag_add' => '{actor} 創建了新群組 {mtags}',
	'note_members_grade_-9' => '將你從群組 <a href="space.php?do=mtag&tagid=\\1" target="_blank">\\2</a> 請出',
	'note_members_grade_-2' => '將你在群組 <a href="space.php?do=mtag&tagid=\\1" target="_blank">\\2</a> 的成員身份修改為 待審核',
	'note_members_grade_-1' => '將你在群組 <a href="space.php?do=mtag&tagid=\\1" target="_blank">\\2</a> 中禁言',
	'note_members_grade_0' => '將你在群組 <a href="space.php?do=mtag&tagid=\\1" target="_blank">\\2</a> 的成員身份修改為 普通成員',
	'note_members_grade_1' => '將你設為了群組 <a href="space.php?do=mtag&tagid=\\1" target="_blank">\\2</a> 的明星成員',
	'note_members_grade_8' => '將你設為了群組 <a href="space.php?do=mtag&tagid=\\1" target="_blank">\\2</a> 的副群主',
	'note_members_grade_9' => '將你設為了群組 <a href="space.php?do=mtag&tagid=\\1" target="_blank">\\2</a> 的群主',
	'feed_mtag_join' => '{actor} 加入了群組 {mtag} ({field})',
	'mtag_joinperm_2' => '需邀請才可加入',
	'feed_mtag_join_invite' => '{actor} 接受 {fromusername} 的邀請，加入了群組 {mtag} ({field})',
	'person' => '人',
	'delete' => '刪除',
	
	'active_email_subject' => '您的郵箱激活郵件',
	'active_email_msg' => '請複製下面的激活鏈接到瀏覽器進行訪問，以便激活你的郵箱。<br>郵箱激活鏈接:<br><a href="\\1" target="_blank">\\1</a>',
	'share_space' => '分享了一個用戶',
	'note_share_space' => '分享了你的空間',
	'share_blog' => '分享了一篇日誌',
	'note_share_blog' => '分享了你的日誌 <a href="\\1" target="_blank">\\2</a>',
	'share_album' => '分享了一個相冊',
	'note_share_album' => '分享了你的相冊 <a href="\\1" target="_blank">\\2</a>',
	'default_albumname' => '默認相冊',
	'share_image' => '分享了一張圖片',
	'album' => '相冊',
	'note_share_pic' => '分享了你的相冊 \\2 中的<a href="\\1" target="_blank">圖片</a>',
	'share_thread' => '分享了一個話題',
	'mtag' => '群組',
	'note_share_thread' => '分享了你的話題 <a href="\\1" target="_blank">\\2</a>',
	'share_mtag' => '分享了一個群組',
	'share_mtag_membernum' => '現有 {membernum} 名成員',
	'share_tag' => '分享了一個標籤',
	'share_tag_blognum' => '現有 {blognum} 篇日誌',
	'share_link' => '分享了一個網址',
	'share_video' => '分享了一個視頻',
	'share_music' => '分享了一個音樂',
	'share_flash' => '分享了一個 Flash',
	'feed_task' => '{actor} 參與了有獎活動 {task}',
	'feed_task_credit' => '{actor} 參與了有獎活動 {task}，領取了 {credit} 個獎勵積分',
	'the_default_style' => '默認風格',
	'the_diy_style' => '自定義風格',
	'feed_thread' => '{actor} 發起了新話題',
	
	'feed_thread_reply' => '{actor} 回復了 {touser} 的話題 {thread}',
	'note_thread_reply' => '回復了你的話題',
	'note_post_reply' => '在話題 <a href=\\"\\1\\" target="_blank">\\2</a> 中回復了你的<a href=\\"\\3\\" target="_blank">回帖</a>',
	'thread_edit_trail' => '<ins class="modify">[本話題由 \\1 於 \\2 編輯]</ins>',
	'create_a_new_album' => '創建了新相冊',
	'not_allow_upload' => '您現在沒有權限上傳圖片',
	'get_passwd_subject' => '取回密碼郵件',
	'get_passwd_message' => '您只需在提交請求後的三天之內，通過點擊下面的鏈接重置您的密碼：<br />\\1<br />(如果上面不是鏈接形式，請將地址手工粘貼到瀏覽器地址欄再訪問)<br />上面的頁面打開後，輸入新的密碼後提交，之後您即可使用新的密碼登錄了。',
	'file_is_too_big' => '文件過大',
	'feed_blog_password' => '{actor} 發表了新加密日誌 {subject}',
	'feed_blog' => '{actor} 發表了新日誌',
	'lack_of_access_to_upload_file_size' => '無法獲取上傳文件大小',
	'only_allows_upload_file_types' => '只允許上傳jpg、gif、png標準格式的圖片',
	'unable_to_create_upload_directory_server' => '服務器無法創建上傳目錄',
	'inadequate_capacity_space' => '空間容量不足，不能上傳新附件',
	'mobile_picture_temporary_failure' => '無法轉移臨時圖片到服務器指定目錄',
	'ftp_upload_file_size' => '遠程上傳圖片失敗',
	'comment' => '評論',
	'upload_a_new_picture' => '上傳了新圖片',
	'the_total_picture' => '共 \\1 張圖片',
	'feed_invite' => '{actor} 發起邀請，和 {username} 成為了好友',
	'note_invite' => '接受了您的好友邀請',
	'space_open_subject' => '快來打理一下您的個人主頁吧',
	'space_open_message' => 'hi，我今天去拜訪了一下您的個人主頁，發現您自己還沒有打理過呢。趕快來看看吧。地址是：\\1space.php',
	'feed_space_open' => '{actor} 開通了自己的個人主頁',
	'feed_profile_update' => '{actor} 更新了自己的個人資料',
	'apply_mtag_manager' => '想申請成為 <a href="\\1" target="_blank">\\2</a> 的群主，理由如下:\\3。<a href="\\1" target="_blank">(點擊這裡進入管理)</a>',
	'feed_add_attachsize' => '{actor} 用 {credit} 個積分兌換了 {size} 附件空間，可以上傳更多的圖片啦(<a href="cp.php?ac=credit&op=addsize">我也來兌換</a>)'
	
);

?>