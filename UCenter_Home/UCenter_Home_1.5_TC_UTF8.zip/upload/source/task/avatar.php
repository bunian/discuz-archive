<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: avatar.php 10586 2008-12-10 06:53:47Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

//判斷用戶是否設置了頭像
$avatar_exists = trim(ckavatar($space['uid']));
if(strlen($avatar_exists) < 1) {
	showmessage('這個功能要求您的UCenter的Server端的 avatar.php 程序需要進行升級。<br>如果您是本站管理員，請通過下面的地址下載 avatar.php 文件的壓縮包，並覆蓋您的UCenter根目錄中的同名文件即可。<br><a href="http://u.discuz.net/download/avatar.zip">http://u.discuz.net/download/avatar.zip</a>');
}
	
if($avatar_exists) {

	//活動完成
	$task['done'] = 1;
	
	//更新用戶頭像標識位
	updatetable('space', array('avatar'=>1), array('uid'=>$space['uid']));
	
	//找熱門異性有頭像的用戶
	$wherearr = array();
	$wherearr[] = "s.uid=sf.uid";
	$wherearr[] = "s.avatar='1'";
	if($space['sex'] == 2) {
		$title = '帥哥';
		$wherearr[] = "sf.sex='1'";
	} else {
		$title = '美女';
		$wherearr[] = "sf.sex='2'";
	}
	$nouids = $space['friend']?$space['friend'].",$space[uid]":$space['uid'];
	$wherearr[] = "s.uid NOT IN ($nouids)";
	
	$query = $_SGLOBAL['db']->query("SELECT s.uid,s.username,s.name,s.namestatus
		FROM ".tname('space')." s, ".tname('spacefield')." sf
		WHERE ".implode(' AND ', $wherearr)."
		ORDER BY s.friendnum DESC LIMIT 0,10");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		realname_set($value['uid'], $value['username'], $value['name'], $value['namestatus']);
		$spaces[] = $value;
	}
	
	realname_get();
	
	if($spaces) {
		$task['result'] = '<p>找到'.$title.'朋友，推薦給您：</p>';
		$task['result'] .= '<ul class="avatar_list">';
		foreach ($spaces as $key => $value) {
			$task['result'] .= '<li>
			<div class="avatar48"><a href="space.php?uid='.$value['uid'].'" target="_blank"><img src="'.avatar($value['uid'], 'small').'" class="avatar"></a></div>
			<p><a href="space.php?uid='.$value['uid'].'" target="_blank" target="_blank">'.$_SN[$value['uid']].'</a></p>
			<p class=\"time\"><a href="cp.php?ac=friend&op=add&uid='.$value['uid'].'" id="a_reside_friend_'.$key.'" onclick="ajaxmenu(event, this.id, 99999, \'\', -1)">加為好友</a></p>
			</li>';
		}
		$task['result'] .= '</ul>';
	}

} else {

	//活動完成嚮導
	$task['guide'] = '請按照以下的說明來參與本活動：
		<ul>
		<li>1. <a href="cp.php?ac=avatar" target="_blank">新窗口打開個人頭像設置頁面</a>；</li>
		<li>2. 在新打開的設置頁面中，請選擇您的照片進行上傳編輯。</li>
		</ul>';

}

?>