<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: email.php 9984 2008-11-21 08:57:24Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

if($space['emailcheck']) {

	$task['done'] = 1;//活動完成

} else {

	//活動完成嚮導
	$task['guide'] = '
		<strong>請按照以下的說明來參與本活動：</strong>
		<ul>
		<li><a href="cp.php?ac=password" target="_blank">新窗口打開賬號設置頁面</a>；</li>
		<li>在新打開的設置頁面中，將自己的郵箱真實填寫，並點擊「驗證郵箱」按鈕；</li>
		<li>幾分鐘後，系統會給你發送一封郵件，收到郵件後，請按照郵件的說明，訪問郵件中的驗證鏈接就可以了。</li>
		</ul>';

}

?>