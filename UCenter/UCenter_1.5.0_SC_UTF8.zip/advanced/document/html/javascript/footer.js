document.write('</div><div class="footer">');
document.write('版权所有 &copy; 2001 - 2009 <a href="http://www.comsenz.com/" target="_blank">康盛创想(北京)科技有限公司 Comsenz Inc</a>');
document.write('</div></div>');