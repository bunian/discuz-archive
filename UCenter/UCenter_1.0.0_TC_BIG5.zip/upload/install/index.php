<?php

error_reporting(7);

set_magic_quotes_runtime(0);

define('UC_ROOT', substr(__FILE__, 0, -9));
define('UC_CHARSET', 'big5');
define('UC_DBCHARSET', 'big5');

define('UC_CONFIG', UC_ROOT.'../data/config.inc.php');

require UC_ROOT.'./global.func.php';
require UC_ROOT.'./install.lang.php';
require UC_ROOT.'./db.class.php';

define('UC_NAME', 'UCenter');
define('UC_VERSION', '1.0.0');

$step = getgpc('step');

if(file_exists(UC_ROOT.'./../data/install.lock')) {
	uc_install_msg('uc_installed');
}

if(!ini_get('short_open_tag')) {
	uc_install_msg('short_open_tag_invalid');
}

//note ����POST����
$ucdbhost = getgpc('ucdbhost', 'P');
$ucdbname = getgpc('ucdbname', 'P');
$ucdbuser = getgpc('ucdbuser', 'P');
$ucdbpw = getgpc('ucdbpw', 'P');
$uctablepre = getgpc('uctablepre', 'P');
$ucdbcharset = getgpc('ucdbcharset', 'P');
$ucfounderpw = getgpc('ucfounderpw', 'P');

$hidden = var_to_hidden('ucdbhost', $ucdbhost);
$hidden .= var_to_hidden('ucdbname', $ucdbname);
$hidden .= var_to_hidden('ucdbuser', $ucdbuser);
$hidden .= var_to_hidden('ucdbpw', $ucdbpw);
$hidden .= var_to_hidden('uctablepre', $uctablepre);
$hidden .= var_to_hidden('ucdbcharset', $ucdbcharset);
$hidden .= var_to_hidden('ucfounderpw', $ucfounderpw);

$ucdbcharset = !empty($ucdbcharset) ? $ucdbcharset : UC_DBCHARSET;

//note ȫ�°�װ UCenter���ж��ļ�Ȩ��
if($step == 'license' || empty($step)) {

	uc_install_header();
	echo '</div><div class="main" style="margin-top:-123px;"><div class="licenseblock">';
	echo $lang['license'];
	echo '</div><div class="btnbox marginbot"><form action="index.php?step=ucdir" method="post">';
	echo $hidden;
	echo '<input type="checkbox" onclick="document.getElementById(\'agree\').disabled=!this.checked;"/>'.$lang['i_agree'].'<br /> <input id="agree" disabled="disabled" type="submit" value="'.$lang['new_step'].'">';
	echo '</form></div>';
	uc_install_footer();

} elseif($step == 'ucdir') {

	$pass = TRUE;

	$ucdbcharset = isset($_GET['ucdbcharset']) ? $_GET['ucdbcharset'] : 'gbk';
	$dirs = array('../data/config.inc.php', '../data', '../data/cache', '../data/view', '../data/avatar', '../data/logs', '../data/backup', '../data/tmp');

	uc_install_header();

	$result = array();
	if(function_exists('mysql_connect')) {
		$result['mysql'] = '<td class="w pdleft1">'.$lang['supportted'].'</td>';
	} else {
		$result['mysql'] = '<td class="nw pdleft1">'.$lang['unsupportted'].'</td>';
		$pass = FALSE;
	}
	if(PHP_VERSION > '4.3.0') {
		$result['phpversion'] = '<td class="w pdleft1">'.PHP_VERSION.'</td>';
	} else {
		$result['phpversion'] = '<td class="nw pdleft1">'.PHP_VERSION.'</td>';
		$pass = FALSE;
	}

	if(@ini_get(file_uploads)) {
		$max_size = @ini_get(upload_max_filesize);
		$result['upload'] = '<td class="w pdleft1">'.$lang['max_size'].$max_size.'</td>';
	} else {
		$result['upload'] = '<td class="nw pdleft1">'.$lang['unsupportted'].'</td>';
		$pass = FALSE;
	}

	if(function_exists('diskfreespace')) {
		$curr_disk_space = intval(diskfreespace('.') / (1024 * 1024)).'M';
		if($curr_disk_space > 10) {
			$result['diskfree'] = '<td class="w pdleft1">'.$curr_disk_space.'</td>';
		} else {
			$result['diskfree'] = '<td class="nw pdleft1">'.$curr_disk_space.'</td>';
			$pass = FALSE;
		}
	} else {
		$result['diskfree'] = '<td class="w pdleft1">'.$lang['diskfreespace_unsupportted'].'</td>';
	}
?>

		<div class="setup step1">
			<h2><?=$lang['step1_title']?></h2>
			<p><?=$lang['step1_desc']?></p>
		</div>
		<div class="stepstat">
			<ul>
				<li class="current">1</li>
				<li class="unactivated">2</li>
				<li class="unactivated">3</li>
				<li class="unactivated last">4</li>
			</ul>
			<div class="stepstatbg stepstat1"></div>
		</div>
	</div>

	<div class="main">
		<h2 class="title"><?php echo $lang['env_check'];?></h2>
		<table class="tb" style="margin:20px 0 20px 55px;">
			<tr>
				<th><?php echo $lang['project'];?></th>
				<th class="padleft"><?php echo $lang['ucenter_required'];?></th>
				<th class="padleft"><?php echo $lang['ucenter_best'];?></th>
				<th class="padleft"><?php echo $lang['curr_server'];?></th>
			</tr>
			<tr>
				<td><?php echo $lang['os'];?></td>
				<td class="padleft"><?php echo $lang['unlimit'];?></td>
				<td class="padleft">UNIX/Linux/FreeBSD</td>
				<td class="padleft"><?php echo PHP_OS;?></td>
			</tr>
			<tr>
				<td>PHP <?php echo $lang['version'];?></td>
				<td class="padleft">4.3.0+</td>
				<td class="padleft">5.0.0+</td>
				<?php echo $result['phpversion'];?>
			</tr>
			<tr>
				<td><?php echo $lang['attach_upload'];?></td>
				<td class="padleft"><?php echo $lang['allow'];?></td>
				<td class="padleft"><?php echo $lang['allow'];?></td>
				<?php echo $result['upload'];?>
			</tr>
			<tr>
				<td>MySQL <?php echo $lang['supportted'];?></td>
				<td class="padleft">MySQL4.0+</td>
				<td class="padleft">MySQL5.0+</td>
				<?php echo $result['mysql'];?>
			</tr>
			<tr>
				<td><?php echo $lang['disk_free'];?></td>
				<td class="padleft">10M+</td>
				<td class="padleft"><?php echo $lang['unlimit'];?></td>
				<?php echo $result['diskfree'];?>
			</tr>
		</table>
		<h2 class="title"><?php echo $lang['priv_check'];?></h2>
		<table class="tb" style="margin:20px 0 20px 55px;width:90%;">
			<tr>
				<th><?=$lang['step1_file']?></th>
				<th class="padleft"><?=$lang['step1_need_status']?></th>
				<th class="padleft"><?=$lang['step1_status']?></th>
			</tr>
<?

	if(!file_exists(UC_ROOT.'../data/config.inc.php')) {
		$fp = @fopen(UC_ROOT.'../data/config.inc.php', 'w');
		@fclose($fp);
	}

        foreach($dirs as $dir) {
		$iswritable = is_writable(UC_ROOT.'/'.$dir);
		$pass == TRUE && !$iswritable && $pass = FALSE;
		echo '<tr><td>'.$dir.'</td><td class="w pdleft1">'.$lang['writeable'].'</td><td'.($iswritable ? ' class="w pdleft1">'.$lang['writeable'] : ' class="nw pdleft1">'.$lang['unwriteable']).'</td></tr>';
	}
?>
		</table>
		<h2 class="title"><?php echo $lang['func_depend'];?></h2>
		<table class="tb" style="margin:20px 0 20px 55px;width:90%;">
			<tr>
				<th><?php echo $lang['func_name'];?></th>
				<th class="padleft"><?php echo $lang['check_result'];?></th>
				<th class="padleft"><?php echo $lang['suggestion'];?></th>
			</tr>
<?php
	$functions = array('mysql_connect'=>FALSE, 'fsockopen'=>FALSE, 'gethostbyname'=>FALSE, 'file_get_contents'=>FALSE, 'xml_parser_create'=>FALSE);
	$advices = array(
		'mysql_connect' => $lang['advice_mysql'],
		'fsockopen' => $lang['advice_fopen'],
		//'gethostbyname' => '������ DNS �������������⣬����ϵ�ռ��̣�ȷ�� DNS ����û������',
		'file_get_contents' => $lang['advice_file_get_contents'],
		'xml_parser_create' => $lang['advice_xml'],
	);
	foreach($functions as $name=>$status) {
		/*if($name == 'fsockopen') {
			//$status = @fsockopen('www.discuz.net', 80, $errno, $errstr, 15) || @fsockopen('www.discuz.com', 80, $errno, $errstr, 15) || @fsockopen('www.comsenz.com', 80, $errno, $errstr, 15);
		} else {
			$status = function_exists($name);
		}*/
		$status = function_exists($name);
		if(!$status) {
			$pass = FALSE;
		}
		echo '<tr><td>'.$name.'()</td>'.($status ? '<td class="w pdleft1">'.$lang['supportted'].'</td>' : '<td class="nw pdleft1">'.$lang['unsupportted'].'</td>').($status ? '<td class="padleft">'.$lang['none'].'</td>' : '<td><font color="red">'.$advices[$name].'</font></td>').'</tr>';
	}
?>
		</table>


<?php

	echo '<form action="index.php?step=ucdb" method="post">';
	echo $hidden;
	if($pass) {
		$nextstep = ' <input type="button" onclick="history.back();" value="'.$lang['old_step'].'"><input type="submit" value="'.$lang['new_step'].'">';
	} else {
		$nextstep = ' <input type="button" disabled="disabled" value="'.$lang['step1_unwriteable'].'">';
	}
	echo '<div class="btnbox marginbot"> '.$nextstep.'</div>';
	echo '</form>';

	uc_install_footer();

} elseif($step == 'ucdb') {

	uc_install_header();

	$msg = getgpc('msg', 'P');
	@include UC_CONFIG;

?>
		<div class="setup step2">
			<h2><?=$lang['step2_title']?></h2>
			<p><?=$lang['step2_desc']?></p>
		</div>
		<div class="stepstat">
			<ul>
				<li>1</li>
				<li class="current">2</li>
				<li class="unactivated">3</li>
				<li class="unactivated last">4</li>
			</ul>
			<div class="stepstatbg stepstat2"></div>
		</div>
	</div>
	<div class="main">
		<form method="post" action="index.php?step=ucadmin">
<?

	if($msg) {

?>
		<div class="desc">
			<ul>
				<?=$msg?>
			</ul>
		</div>
<?

	}

?>
		<table class="tb2">
			<tr>
				<th><span class="red"><?=$lang['step2_dbhost']?>:</span></th>
				<td><input name="ucdbhost" type="text" class="txt" value="<?php echo $ucdbhost ? $ucdbhost : (defined('UC_DBHOST') ? UC_DBHOST : 'localhost');?>" /></td>
			</tr>
			<tr>
				<th><?=$lang['step2_dbname']?></th>
				<td><input name="ucdbname" type="text" class="txt" value="<?php echo $ucdbname ? $ucdbname : (defined('UC_DBNAME') ? UC_DBNAME : 'test');?>" /></td>
			</tr>
			<tr>
				<th><?=$lang['step2_dbuser']?>:</th>
				<td><input name="ucdbuser" type="text" class="txt" value="<?php echo $ucdbuser ? $ucdbuser : (defined('UC_DBUSER') ? UC_DBUSER : 'root');?>" /></td>
			</tr>
			<tr>
				<th><?=$lang['step2_dbpw']?>:</th>
				<td><input name="ucdbpw" type="password" class="txt" value="<?php echo $ucdbpw ? $ucdbpw : (defined('UC_DBPW') ? UC_DBPW : '');?>" /></td>
			</tr>
			<tr>
				<th><span class="red"><?=$lang['step2_tablepre']?>:</span></th>
				<td><input name="uctablepre" type="text" class="txt" value="<?php echo $uctablepre ? $uctablepre : (defined('UC_DBTABLEPRE') ? UC_DBTABLEPRE : 'uc_');?>" /></td>
			</tr>
		</table>
		<input type="hidden" name="ucfounderpw" value="<?php echo $ucfounderpw;?>">
		<div class="btnbox marginbot"><input type="button" value="<?=$lang['old_step']?>" onclick="history.back();" /><input type="submit" name="submit" value="<?=$lang['new_step']?>" /></div>
		</form>
<?

	/*echo '<form action="index.php?step=ucdb" method="post">';
	echo $hidden;
	if($pass) {
		$nextstep = ' <input type="button" onclick="history.back();" value="'.$lang['old_step'].'"><input type="submit" value="'.$lang['new_step'].'">';
	} else {
		$nextstep = ' <input type="button" disabled="disabled" value="'.$lang['step1_unwriteable'].'">';
	}
	echo '<div class="btnbox marginbot"> '.$nextstep.'</div>';
	echo '</form>';*/

	uc_install_footer();

} elseif($step == 'ucadmin') {

	//note ��� mysql �ʺ�����
	$msg = '';
	if(!@mysql_connect($ucdbhost, $ucdbuser, $ucdbpw)) {
		$errormsg = 'database_errno_'.mysql_errno();
		$msg .= '<li>'.($lang[$errormsg] ? $lang[$errormsg] : mysql_error()) .'</li>';
		$quit = TRUE;
	} else {

		$curr_mysql_version = mysql_get_server_info();

		if(!$ucdbname) {
			$msg .= $lang['step3_error_dbname_empty'];
		}
		if($curr_mysql_version > '4.1') {
			mysql_query("CREATE DATABASE IF NOT EXISTS `$ucdbname` DEFAULT CHARACTER SET $ucdbcharset");
		} else {
			mysql_query("CREATE DATABASE IF NOT EXISTS `$ucdbname`");
		}
		if(mysql_errno()) {
			$errormsg = isset($lang['database_errno_'.mysql_errno()]) ? $lang['database_errno_'.mysql_errno()] :  mysql_error();
			$msg .= "<li>".$errormsg.'</li>';
			$quit = TRUE;
		} else {
			mysql_select_db($ucdbname);
			if($curr_mysql_version < '3.23') {
				$msg .= '<li>'.$lang['mysql_version_323'].'</li>';
				$quit = TRUE;
			}
			$sqlarray = array(
				'createtable' => 'CREATE TABLE uc_test (test TINYINT (3) UNSIGNED)',
				'insert' => 'INSERT INTO uc_test (test) VALUES (1)',
				'select' => 'SELECT * FROM uc_test',
				'update' => 'UPDATE uc_test SET test=\'2\' WHERE test=\'1\'',
				'delete' => 'DELETE FROM uc_test WHERE test=\'2\'',
				'droptable' => 'DROP TABLE uc_test'
			);

			foreach($sqlarray as $key => $sql) {
				mysql_select_db($ucdbname);
				mysql_query($sql);
				if(mysql_errno()) {
					$errnolang = 'dbpriv_'.$key;
					$msg .= '<li>'.$lang[$errnolang].'</li>';
					$quit = TRUE;
				}
			}

			$result = mysql_query("SELECT COUNT(*) FROM ".$uctablepre."applications");
			if($result) {
				$msg .= '<li><span class="red">'.$lang['db_not_null'].'</span></li>';
				$alert = " onSubmit=\"return confirm('$lang[db_drop_table_confirm]');\"";
			}
		}
	}

	if($quit && empty($_POST['msg'])) {
		$hidden .= var_to_hidden('msg', htmlspecialchars($msg));
		echo '<form action="index.php?step=ucdb" method="post" id="ucdbform">';
		echo $hidden;
		echo '</form>';
		echo '<script type="text/javascript">document.getElementById(\'ucdbform\').submit();</script>';
		exit;
	}

	uc_install_header();

?>
		<div class="setup step3">
			<h2><?=$lang['step3_title']?></h2>
			<p><?=$lang['step3_desc']?></p>
		</div>
		<div class="stepstat">
			<ul>
				<li>1</li>
				<li>2</li>
				<li class="current">3</li>
				<li class="unactivated last">4</li>
			</ul>
			<div class="stepstatbg stepstat3"></div>
		</div>
	</div>
	<div class="main">
		<div class="desc">
			<ul>
				<?=$lang['step3_comment']?>
				<?php echo getgpc('msg', 'P');?>
			</ul>
		</div>
		<form method="post" action="index.php?step=ucinstall&ucdbcharset=<?=$ucdbcharset?>"<?=$alert?>>
		<?=$hidden?>
		<table class="tb2">
			<tr>
				<th><?=$lang['step3_founder']?>:</th>
				<td><input type="text" class="txt" disabled="disabled" readonly="readonly" value="UCenter Administrator" /></td>
			</tr>
			<tr>
				<th><?=$lang['step3_password']?>:</th>
				<td><input name="ucfounderpw" type="password" class="txt" value="<?=$ucfounderpw?>" /></td>
			</tr>
			<tr>
				<th><?=$lang['step3_repeatpw']?>:</th>
				<td><input name="ucfounderpw2" type="password" class="txt" value="<?=$ucfounderpw?>" /></td>
			</tr>
		</table>
		<div class="btnbox marginbot"><input type="button" value="<?=$lang['old_step']?>" onclick="history.back();" /><input type="submit" name="submit" value="<?=$lang['new_step']?>" /></div>
		</form>
<?

	uc_install_footer();

} elseif($step == 'ucinstall') {

	$ucfounderpw = getgpc('ucfounderpw', 'P');
	$ucfounderpw2 = getgpc('ucfounderpw2', 'P');

	if($ucfounderpw != $ucfounderpw2) {
		uc_install_msg('step4_error_password_invalid');
	}

	if(!is_writable(UC_CONFIG)) {
		uc_install_msg($lang['step4_error_config_unwriteable1'].UC_CONFIG.$lang['step4_error_config_unwriteable2']);
	}

	$ucapi = strtolower(substr($_SERVER['SERVER_PROTOCOL'], 0, strpos($_SERVER['SERVER_PROTOCOL'], '/'))).'://'.$_SERVER['HTTP_HOST'].substr(substr($_SERVER['PHP_SELF'], 0, strrpos($_SERVER['PHP_SELF'], '/')), 0, -11);

	//note �������ñ�
	$db = new db();
	$db->connect($ucdbhost, $ucdbuser, $ucdbpw, $ucdbname, $ucdbcharset, 0);

	$sql = file_get_contents(UC_ROOT.'./uc.sql');
	$sql = str_replace("\r\n", "\n", $sql);
	uc_install_header();

?>
		<div class="setup step4">
			<h2><?=$lang['step4_title']?></h2>
			<p><?=$lang['step4_desc']?></p>
		</div>
		<div class="stepstat">
			<ul>
				<li>1</li>
				<li>2</li>
				<li>3</li>
				<li class="current last">4</li>
			</ul>
			<div class="stepstatbg stepstat4"></div>
		</div>
	</div>
<script type="text/javascript">
function showmessage(message) {
	document.getElementById('notice').value += message + "\r\n";
}
function initinput() {
	/*parent.document.getElementById('ucapi').value='<?=$ucapi?>';
	parent.document.getElementById('ucfounder').value='<?=$ucfounder?>';
	parent.document.getElementById('ucfounderpw').value='<?=$ucfounderpw?>';
	parent.document.getElementById('installuclink').style.display='none';*/
	window.location='<?php echo 'index.php?step=login';?>';
}
</script>
	<div class="main">
		<div class="btnbox"><textarea name="notice" style="width: 80%;"  readonly="readonly" id="notice"></textarea></div>
		<div class="btnbox marginbot">
		<input type="button" name="submit" value=" <?=$lang['install_in_processed']?> " disabled style="height: 25" id="laststep" onclick="initinput()">
		</div>
		<?php runquery($sql);?>
<?

	$ucsalt = substr(uniqid(rand()), 0, 6);
	$ucfounderpw= md5(md5($ucfounderpw).$ucsalt);
	$regdate = time();

	//note д�� UCenter �����ļ� uc/data/config.inc.php
	$configfile = UC_CONFIG;
	$ucauthkey = generate_key();
	$ucsiteid = generate_key();
	$ucmykey = generate_key();
	$config = "<?php \r\ndefine('UC_DBHOST', '$ucdbhost');\r\n";
	$config .= "define('UC_DBUSER', '$ucdbuser');\r\n";
	$config .= "define('UC_DBPW', '$ucdbpw');\r\n";
	$config .= "define('UC_DBNAME', '$ucdbname');\r\n";
	$config .= "define('UC_DBCHARSET', '$ucdbcharset');\r\n";
	$config .= "define('UC_DBTABLEPRE', '$uctablepre');\r\n";
	$config .= "define('UC_COOKIEPATH', '/');\r\n";
	$config .= "define('UC_COOKIEDOMAIN', '');\r\n";
	$config .= "define('UC_DBCONNECT', 0);\r\n";
	$config .= "define('UC_CHARSET', '".UC_CHARSET."');\r\n";
	$config .= "define('UC_FOUNDERPW', '$ucfounderpw');\r\n";
	$config .= "define('UC_FOUNDERSALT', '$ucsalt');\r\n";
	$config .= "define('UC_KEY', '$ucauthkey');\r\n";
	$config .= "define('UC_SITEID', '$ucsiteid');\r\n";
	$config .= "define('UC_MYKEY', '$ucmykey');\r\n";
	$config .= "define('UC_DEBUG', false);\r\n";
	$config .= "define('UC_PPP', 20);\r\n";
	$fp = fopen(UC_CONFIG, 'w');
	fwrite($fp, $config);
	fclose($fp);
	echo '<script type="text/javascript">document.getElementById("laststep").disabled=false;document.getElementById("laststep").value = \''.$lang['install_succeed'].'\';</script>'."\r\n";
	uc_install_footer();

} elseif($step == 'login') {

	include UC_CONFIG;
	$md5password =  UC_FOUNDERPW;
	setcookie('uc_founderauth', authcode("|$md5password|".md5($_SERVER['HTTP_USER_AGENT'])."|1", 'ENCODE', UC_KEY), time() + 3600, '/');
	header("Location:../admin.php?m=frame&a=index&mainurl=".urlencode('admin.php?m=app&a=add'));
	touch(UC_ROOT.'./../data/install.lock');
	exit;

}

?>
