<?php

define('UC_VERNAME', '中文版');

$lang = array(

	'message_title' => '提示信息',
	'error_message' => '錯誤信息',
	'message_return' => '返回',
	'return' => '返回',
	'install_wizard' => '安裝嚮導',
	'config_nonexistence' => '配置文件不存在',
	'short_open_tag_invalid' => '對不起，請將 php.ini 中的 short_open_tag 設置為 On，否則無法繼續安裝。',
	'redirect' => '瀏覽器會自動跳轉頁面，無需人工干預。<br>除非當您的瀏覽器沒有自動跳轉時，請點擊這裡',

	'database_errno_2003' => '無法連接數據庫，請檢查數據庫是否啟動，數據庫服務器地址是否正確',
	'database_errno_1044' => '無法創建新的數據庫，請檢查數據庫名稱填寫是否正確',
	'database_errno_1045' => '無法連接數據庫，請檢查數據庫用戶名或者密碼是否正確',
	'database_errno_1064' => 'SQL 語法錯誤',

	'dbpriv_createtable' => '沒有CREATE TABLE權限，無法繼續安裝',
	'dbpriv_insert' => '沒有INSERT權限，無法繼續安裝',
	'dbpriv_select' => '沒有SELECT權限，無法繼續安裝',
	'dbpriv_update' => '沒有UPDATE權限，無法繼續安裝',
	'dbpriv_delete' => '沒有DELETE權限，無法繼續安裝',
	'dbpriv_droptable' => '沒有DROP TABLE權限，無法安裝',

	'db_not_null' => '數據庫中已經安裝過 UCenter, 繼續安裝會清空原有數據。',
	'db_drop_table_confirm' => '繼續安裝會清空全部原有數據，您確定要繼續嗎?',

	'writeable' => '可寫',
	'unwriteable' => '不可寫',
	'old_step' => '上一步',
	'new_step' => '下一步',

	'database_errno_2003' => '無法連接數據庫，請檢查數據庫是否啟動，數據庫服務器地址是否正確',
	'database_errno_1044' => '無法創建新的數據庫，請檢查數據庫名稱填寫是否正確',
	'database_errno_1045' => '無法連接數據庫，請檢查數據庫用戶名或者密碼是否正確',

	'step1_title' => '開始安裝',
	'step1_desc' => 'UCenter 文件目錄權限檢查',
	'step1_file' => '目錄文件',
	'step1_need_status' => '所需狀態',
	'step1_status' => '當前狀態',
	'step1_unwriteable' => '請將以上目錄權限全部設置為 777，然後進行下一步安裝。',

	'step2_title' => '填寫相關配置',
	'step2_desc' => 'UCenter 數據庫配置',
	'step2_dbhost' => '數據庫服務器',
	'step2_dbuser' => '數據庫用戶名',
	'step2_dbpw' => '數據庫密碼',
	'step2_dbname' => '數據庫名',
	'step2_tablepre' => '表名前綴',

	'step3_error_dbname_empty' => '數據庫名為空',
	'step3_title' => '填寫相關配置',
	'step3_founder' => '創始人用戶名',
	'step3_desc' => '設置 UCenter 創始人密碼',
	'step3_comment' => '<li>創始人用戶名為系統內置，不可修改。</li><li>請牢記 UCenter 創始人密碼，憑該密碼登陸 UCenter。</li>',
	'step3_username' => '管理員帳號',
	'step3_password' => '創始人密碼',
	'step3_repeatpw' => '重複創始人密碼',

	'step4_error_password_invalid' => '兩次輸入密碼不一致，請返回。',
	'step4_error_config_unwriteable1' => 'UCenter 的配置文件 ',
	'step4_error_config_unwriteable2' => ' 不可寫，請返回設置為可寫狀態。',
	'step4_title' => '最後一步',
	'step4_desc' => '創建更新 UCenter 數據庫',

	'install_in_processed' => '正在安裝...',
	'install_succeed' => '安裝用戶中心成功，點擊進入下一步',
	'license' => '<div class="license"><h1>中文版授權協議 適用於中文用戶</h1>

<p>版權所有 (c) 2001-2008，康盛創想（北京）科技有限公司保留所有權利。</p>

<p>感謝您選擇 UCenter 產品。希望我們的努力能為您提供一個高效快速和強大的站點解決方案。</p>

<p>康盛創想（北京）科技有限公司為 UCenter 產品的開發商，依法獨立擁有 UCenter 產品著作權。康盛創想（北京）科技有限公司網址為 http://www.comsenz.com，UCenter 官方網站網址為 http://www.discuz.com，UCenter 官方討論區網址為 http://www.discuz.net。</p>

<p>UCenter 著作權已在中華人民共和國國家版權局註冊，著作權受到法律和國際公約保護。使用者：無論個人或組織、盈利與否、用途如何（包括以學習和研究為目的），均需仔細閱讀本協議，在理解、同意、並遵守本協議的全部條款後，方可開始使用 UCenter 軟件。</p>

<p>本授權協議適用且僅適用於 UCenter 1.x 版本，康盛創想（北京）科技有限公司擁有對本授權協議的最終解釋權。</p>

<h3>I. 協議許可的權利</h3>
<ol>
<li>您可以在完全遵守本最終用戶授權協議的基礎上，將本軟件應用於非商業用途，而不必支付軟件版權授權費用。</li>
<li>您可以在協議規定的約束和限制範圍內修改 UCenter 源代碼(如果被提供的話)或界面風格以適應您的網站要求。</li>
<li>您擁有使用本軟件構建的網站中全部會員資料、文章及相關信息的所有權，並獨立承擔與文章內容的相關法律義務。</li>
<li>獲得商業授權之後，您可以將本軟件應用於商業用途，同時依據所購買的授權類型中確定的技術支持期限、技術支持方式和技術支持內容，自購買時刻起，在技術支持期限內擁有通過指定的方式獲得指定範圍內的技術支持服務。商業授權用戶享有反映和提出意見的權力，相關意見將被作為首要考慮，但沒有一定被採納的承諾或保證。</li>
</ol>

<h3>II. 協議規定的約束和限制</h3>
<ol>
<li>未獲商業授權之前，不得將本軟件用於商業用途（包括但不限於企業網站、經營性網站、以營利為目或實現盈利的網站）。購買商業授權請登陸http://www.discuz.com參考相關說明，也可以致電8610-51657885瞭解詳情。</li>
<li>不得對本軟件或與之關聯的商業授權進行出租、出售、抵押或發放子許可證。</li>
<li>無論如何，即無論用途如何、是否經過修改或美化、修改程度如何，只要使用 UCenter 的整體或任何部分，未經書面許可，頁面頁腳處的 UCenter 名稱和康盛創想（北京）科技有限公司下屬網站（http://www.comsenz.com、http://www.discuz.com 或 http://www.discuz.net） 的鏈接都必須保留，而不能清除或修改。</li>
<li>禁止在 UCenter 的整體或任何部分基礎上以發展任何派生版本、修改版本或第三方版本用於重新分發。</li>
<li>如果您未能遵守本協議的條款，您的授權將被終止，所被許可的權利將被收回，並承擔相應法律責任。</li>
</ol>

<h3>III. 有限擔保和免責聲明</h3>
<ol>
<li>本軟件及所附帶的文件是作為不提供任何明確的或隱含的賠償或擔保的形式提供的。</li>
<li>用戶出於自願而使用本軟件，您必須瞭解使用本軟件的風險，在尚未購買產品技術服務之前，我們不承諾提供任何形式的技術支持、使用擔保，也不承擔任何因使用本軟件而產生問題的相關責任。</li>
<li>康盛創想（北京）科技有限公司不對使用本軟件構建的網站中的文章或信息承擔責任。</li>
</ol>

<p>有關 UCenter 最終用戶授權協議、商業授權與技術服務的詳細內容，均由 UCenter 官方網站獨家提供。康盛創想（北京）科技有限公司擁有在不事先通知的情況下，修改授權協議和服務價目表的權力，修改後的協議或價目表對自改變之日起的新授權用戶生效。</p>

<p>電子文本形式的授權協議如同雙方書面簽署的協議一樣，具有完全的和等同的法律效力。您一旦開始安裝 UCenter，即被視為完全理解並接受本協議的各項條款，在享有上述條款授予的權力的同時，受到相關的約束和限制。協議許可範圍以外的行為，將直接違反本授權協議並構成侵權，我們有權隨時終止授權，責令停止損害，並保留追究相關責任的權力。</p></div>',

	'uc_installed' => '您已經安裝過 UCenter，如果需要重新安裝，請刪除 data/install.lock 文件',
	'i_agree' => '我已仔細閱讀，並同意上述條款中的所有內容',
	'supportted' => '支持',
	'unsupportted' => '不支持',
	'max_size' => '支持/最大尺寸',
	'project' => '項目',
	'ucenter_required' => 'UCenter 所需配置',
	'ucenter_best' => 'UCenter 最佳',
	'curr_server' => '當前服務器',
	'env_check' => '環境檢查',
	'os' => '操作系統',
	'unlimit' => '不限制',
	'version' => '版本',
	'attach_upload' => '附件上傳',
	'allow' => '允許',
	'disk_free' => '磁盤空間',
	'priv_check' => '目錄、文件權限檢查',
	'func_depend' => '函數依賴性檢查',
	'func_name' => '函數名稱',
	'check_result' => '檢查結果',
	'suggestion' => '建議',
	'advice_mysql' => '請檢查 mysql 模塊是否正確加載',
	'advice_fopen' => '該函數需要 php.ini 中 allow_url_fopen 選項開啟。請聯繫空間商，確定開啟了此項功能',
	'advice_file_get_contents' => '該函數需要 php.ini 中 allow_url_fopen 選項開啟。請聯繫空間商，確定開啟了此項功能',
	'advice_xml' => '該函數需要 PHP 支持 XML。請聯繫空間商，確定開啟了此項功能',
	'none' => '無',
	'diskfreespace_unsupportted' => '無法檢測剩餘空間',
);