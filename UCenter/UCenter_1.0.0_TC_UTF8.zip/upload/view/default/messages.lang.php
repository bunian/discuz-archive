<?php

$lang = array(
	'please_login' => '請重新登錄',
	'receiver_no_exists' => '收件人不存在，請重新填寫',
	'pm_save_succeed' => '短消息已保存到草稿箱',
	'pm_send_succeed' => '$sent 條短消息成功發送',
	'pm_send_announce_succeed' => '公共消息成功發送',
	'pm_send_ignore' => '短消息發送失敗',
	'pm_delete_succeed' => '短消息成功刪除',
	'pm_delete_invalid' => '短消息無法刪除',
	'pm_unread' => '當前短消息標記為未讀狀態',
	'blackls_updated' => '忽略列表已更新',

	'db_export_filename_invalid' => '您沒有輸入備份文件名或文件名中使用了敏感的擴展名，請返回修改。',
	'db_export_file_invalid' => '數據文件無法保存到服務器，請檢查目錄屬性。',
	'db_export_multivol_redirect' => '分卷備份: 數據文件 #$volume 成功創建，程序將自動繼續。',
	'db_export_multivol_succeed' => '恭喜您，全部 $volume 個備份文件成功創建，備份完成。<a href="admin.php?m=db&a=ls">點這裡查看數據備份記錄</a>。<br />$filelist',
	'db_import_multivol_succeed' => '分卷數據成功導入數據庫。<a href="admin.php?m=db&a=ls">點這裡返回數據備份記錄</a>。',
	'db_import_file_illegal' => '數據文件不存在: 可能服務器不允許上傳文件或尺寸超過限制。',
	'db_import_multivol_prompt' => '分卷數據 #$volume 成功導入數據庫，程序將自動導入本次備份的其他分卷。',

	'app_add_url_invalid' => '接口 URL 地址不合法',
	'app_add_ip_invalid' => 'IP 地址不合法',

	'syncappcredits_updated' => '成功同步應用的積分設置',

	'note_succeed' => '通知成功',
	'note_false' => '通知失敗',
	'no_permission_for_this_module' => '沒有權限管理改模塊',
	'admin_user_exists' => '該用戶名已經存在，請返回嘗試使用其他用戶名。',
	
	'user_edit_noperm' => '您沒權限編輯此用戶',
);