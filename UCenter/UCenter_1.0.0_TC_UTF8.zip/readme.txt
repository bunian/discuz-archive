
UCenter 1.0 安裝說明


1. 將 upload 文件夾下所有的文件上傳

2. 如果您的主機為 *nix 操作系統，請設置如下文件夾權限為 777
	./data
	./data/avatar
	./data/backup
	./data/cache
	./data/logs
	./data/tmp
	./data/view
	./data/config.inc.php

3. 通過瀏覽器訪問 http://您的域名/install/， 根據提示填寫 mysql 配置信息、管理員賬號信息

4. 通過 FTP 刪除 install 目錄

5. 完成安裝