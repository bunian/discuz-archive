//=========================================
// Ucenter 工具包文件说明
//=========================================

md5files.php		生成文件校验的文件
upgrade1.php		UCenter 1.0 测试版到 UCenter 1.0 正式版的升级
checkappid.php      	补充 notelist 缺少的字段
pmconvert.php		UCenter 1.5 短消息数据格式转换程序