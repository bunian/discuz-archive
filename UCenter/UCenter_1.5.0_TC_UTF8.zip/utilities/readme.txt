//=========================================
// Ucenter 工具包文件說明
//=========================================

md5files.php		生成文件校驗的文件
upgrade1.php		UCenter 1.0 測試版到 UCenter 1.0 正式版的升級
checkappid.php      	補充 notelist 缺少的字段
pmconvert.php		UCenter 1.5 短消息數據格式轉換程序