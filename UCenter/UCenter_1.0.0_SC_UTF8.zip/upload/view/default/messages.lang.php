<?php

$lang = array(
	'please_login' => '请重新登录',
	'receiver_no_exists' => '收件人不存在，请重新填写',
	'pm_save_succeed' => '短消息已保存到草稿箱',
	'pm_send_succeed' => '$sent 条短消息成功发送',
	'pm_send_announce_succeed' => '公共消息成功发送',
	'pm_send_ignore' => '短消息发送失败',
	'pm_delete_succeed' => '短消息成功删除',
	'pm_delete_invalid' => '短消息无法删除',
	'pm_unread' => '当前短消息标记为未读状态',
	'blackls_updated' => '忽略列表已更新',

	'db_export_filename_invalid' => '您没有输入备份文件名或文件名中使用了敏感的扩展名，请返回修改。',
	'db_export_file_invalid' => '数据文件无法保存到服务器，请检查目录属性。',
	'db_export_multivol_redirect' => '分卷备份: 数据文件 #$volume 成功创建，程序将自动继续。',
	'db_export_multivol_succeed' => '恭喜您，全部 $volume 个备份文件成功创建，备份完成。<a href="admin.php?m=db&a=ls">点这里查看数据备份记录</a>。<br />$filelist',
	'db_import_multivol_succeed' => '分卷数据成功导入数据库。<a href="admin.php?m=db&a=ls">点这里返回数据备份记录</a>。',
	'db_import_file_illegal' => '数据文件不存在: 可能服务器不允许上传文件或尺寸超过限制。',
	'db_import_multivol_prompt' => '分卷数据 #$volume 成功导入数据库，程序将自动导入本次备份的其他分卷。',

	'app_add_url_invalid' => '接口 URL 地址不合法',
	'app_add_ip_invalid' => 'IP 地址不合法',

	'syncappcredits_updated' => '成功同步应用的积分设置',

	'note_succeed' => '通知成功',
	'note_false' => '通知失败',
	'no_permission_for_this_module' => '没有权限管理改模块',
	'admin_user_exists' => '该用户名已经存在，请返回尝试使用其他用户名。',
	
	'user_edit_noperm' => '您没权限编辑此用户',
);