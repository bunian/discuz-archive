
UCenter 1.0 安装说明


1. 将 upload 文件夹下所有的文件上传

2. 如果您的主机为 *nix 操作系统，请设置如下文件夹权限为 777
	./data
	./data/avatar
	./data/backup
	./data/cache
	./data/logs
	./data/tmp
	./data/view
	./data/config.inc.php

3. 通过浏览器访问 http://您的域名/install/， 根据提示填写 mysql 配置信息、管理员账号信息

4. 通过 FTP 删除 install 目录

5. 完成安装