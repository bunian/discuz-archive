<?php

$lang = array(
	'user_search' => '搜索用戶',
	'user_name' => '用戶名',
	'user_regdate' => '註冊日期',
	'user_regip' => '註冊IP',
	'user_before' => '之前',
	'user_after' => '之後',
	'user_search' => '搜 索',
	'user_add' => '添加用戶',
	'user_password' => '密碼',
	'user_addsubmit' => '添 加',
	'delete' => '刪除',
	'email' => 'Email',
	'user_list' => '用戶列表',
);