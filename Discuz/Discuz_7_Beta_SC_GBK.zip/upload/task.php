<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: task.php 13890 2008-07-08 02:21:38Z liuqiang $
*/

define('NOROBOT', TRUE);
require_once './include/common.inc.php';

$discuz_action = 180;
$id = intval($id);

if(empty($action)) {

	$multipage = '';
	$page = max(1, intval($page));
	$start_limit = ($page - 1) * $tpp;

	$item = isset($item) && in_array($item, array('new', 'doing', 'done', 'failed')) ? $item : '';
	$tasklist = $mytasks = $endtasks = $magics = $magicids = $medals = $medalids = $groups = $groupids = array();
	$sqladd = $applyids = $doingids = $doneids = $failedids = $comma = $comma1 = $comma2 = $comma3 = '';

	$query = $db->query("SELECT taskid, status, csc, dateline FROM {$tablepre}mytasks WHERE uid='$discuz_uid'");
	while($mytask = $db->fetch_array($query)) {
		if($mytask['status'] == '1') {
			$doneids .= $comma1.$mytask['taskid'];
			$comma1 = ',';
		} elseif($mytask['status'] == '0') {
			$doingids .= $comma2.$mytask['taskid'];
			$comma2 = ',';
		} elseif($mytask['status'] == '-1') {
			$failedids .= $comma3.$mytask['taskid'];
			$comma3 = ',';
		}
		$applyids .= $comma.$mytask['taskid'];
		$comma = ',';
		$mytask['time'] = $mytask['dateline'] ? dgmdate("$dateformat $timeformat", $mytask['dateline'] + $timeoffset * 3600) : '';
		$mytasks[$mytask['taskid']] = $mytask;
	}

	if($item == 'new' && $applyids) {
		$sqladd = "taskid NOT IN ($applyids) AND";
	} elseif($item == 'doing' && $doingids) {
		$sqladd = "taskid IN ($doingids) AND";
	} elseif($item == 'done' && $doneids) {
		$sqladd = "taskid IN ($doneids) AND";
	} elseif($item == 'failed' && $failedids) {
		$sqladd = "taskid IN ($failedids) AND";
	}

	if(!$item || $item == 'new' || $sqladd) {
		$num = $db->result_first("SELECT COUNT(*) FROM {$tablepre}tasks WHERE $sqladd available='2'");
		$multipage = multi($num, $tpp, $page, 'task.php'.($item ? "?item=$item" : ''));

		$query = $db->query("SELECT * FROM {$tablepre}tasks WHERE $sqladd available='2' ORDER BY displayorder, taskid DESC LIMIT $start_limit, $tpp");
		while($task = $db->fetch_array($query)) {
			if($task['reward'] == 'magic') {
				$magicids[] = $task['prize'];
			} elseif($task['reward'] == 'medal') {
				$medalids[] = $task['prize'];
			} elseif($task['reward'] == 'group') {
				$groupids[] = $task['prize'];
			}
			if($task['endtime'] && $task['endtime'] <= $timestamp) {
				$endtasks[] = $task['taskid'];
			}
			$task['description'] = cutstr(strip_tags($task['description']), 120);
			$task['icon'] = $task['icon'] ? $task['icon'] : 'task.gif';
			$task['icon'] = strtolower(substr($task['icon'], 0, 7)) == 'http://' ? $task['icon'] : "images/tasks/$task[icon]";
			$tasklist[] = $task;
		}
	}

	if($magicids) {
		$query = $db->query("SELECT magicid, name FROM {$tablepre}magics WHERE magicid IN (".implodeids($magicids).")");
		while($magic = $db->fetch_array($query)) {
			$magics[$magic['magicid']] = $magic['name'];
		}
	}

	if($medalids) {
		$query = $db->query("SELECT medalid, name FROM {$tablepre}medals WHERE medalid IN (".implodeids($medalids).")");
		while($medal = $db->fetch_array($query)) {
			$medals[$medal['medalid']] = $medal['name'];
		}
	}

	if($groupids) {
		$query = $db->query("SELECT groupid, grouptitle FROM {$tablepre}usergroups WHERE groupid IN (".implodeids($groupids).")");
		while($group = $db->fetch_array($query)) {
			$groups[$group['groupid']] = $group['grouptitle'];
		}
	}

	if($item == 'doing' && ($newtask xor $doingids)) {
		$newtask = $doingids ? 1 : 0;
		$db->query("UPDATE {$tablepre}members SET prompt=".bindec($newtask.intval($newpm))." WHERE uid='$discuz_uid'", 'UNBUFFERED');
	}

	if($endtasks) {
		$db->query("UPDATE {$tablepre}tasks SET available='1' WHERE taskid IN (".implodeids($endtasks).")", 'UNBUFFERED');
	}

} elseif($action == 'view' && $id) {

	$task = $db->fetch_first("SELECT t.*, mt.status, mt.csc, mt.dateline FROM {$tablepre}tasks t LEFT JOIN {$tablepre}mytasks mt ON mt.uid='$discuz_uid' AND mt.taskid=t.taskid WHERE t.taskid='$id' AND t.available='2'");

	if($task['reward'] == 'magic') {
		$magicname = $db->result_first("SELECT name FROM {$tablepre}magics WHERE magicid='$task[prize]'");
	} elseif($task['reward'] == 'medal') {
		$medalname = $db->result_first("SELECT name FROM {$tablepre}medals WHERE medalid='$task[prize]'");
	} elseif($task['reward'] == 'group') {
		$grouptitle = $db->result_first("SELECT grouptitle FROM {$tablepre}usergroups WHERE groupid='$task[prize]'");
	}
	$task['icon'] = $task['icon'] ? $task['icon'] : 'task.gif';
	$task['icon'] = strtolower(substr($task['icon'], 0, 7)) == 'http://' ? $task['icon'] : "images/tasks/$task[icon]";
	$task['endtime'] = $task['endtime'] ? dgmdate("$dateformat $timeformat", $task['endtime'] + $timeoffset * 3600) : '';

	$taskvars = array();
	$query = $db->query("SELECT sort, name, description, variable, value FROM {$tablepre}taskvars WHERE taskid='$id'");
	while($taskvar = $db->fetch_array($query)) {
		if(!$taskvar['variable'] || $taskvar['value']) {
			if(!$taskvar['variable']) {
				$taskvar['value'] = $taskvar['description'];
			} elseif($taskvar['variable'] == 'forumid') {
				require_once DISCUZ_ROOT.'./forumdata/cache/cache_forums.php';
			}
			if($taskvar['sort'] == 'apply') {
				$taskvars['apply'][] = $taskvar;
			} elseif($taskvar['sort'] == 'complete') {
				$taskvars['complete'][] = $taskvar;
			}
		}
	}

	$grouprequired = $comma = '';
	$task['applyperm'] = $task['applyperm'] == 'all' ? '' : $task['applyperm'];
	if(!in_array($task['applyperm'], array('', 'member', 'admin'))) {
		$query = $db->query("SELECT grouptitle FROM {$tablepre}usergroups WHERE groupid IN (".str_replace("\t", ',', $task['applyperm']).")");
		while($group = $db->fetch_array($query)) {
			$grouprequired .= $comma.$group[grouptitle];
			$comma = ', ';
		}
	}

	if($task['relatedtaskid']) {
		$taskrequired = $db->result_first("SELECT name FROM {$tablepre}tasks WHERE taskid='$task[relatedtaskid]'");
	}

} elseif($action == 'apply' && $id) {

	if(!$discuz_uid) {
		showmessage('not_loggedin', NULL, 'NOPERM');
	}

	if(!$task = $db->fetch_first("SELECT * FROM {$tablepre}tasks WHERE taskid='$id' AND available='2'")) {
		showmessage('task_nonexistence', NULL, 'HALTED');
	} elseif(($task['starttime'] && $task['starttime'] > $timestamp) || ($task['endtime'] && $task['endtime'] <= $timestamp)) {
		showmessage('task_offline', NULL, 'HALTED');
	} elseif($task['tasklimits'] && $task['achievers'] >= $task['tasklimits']) {
		showmessage('task_full', NULL, 'HALTED');
	}

	if($task['relatedtaskid'] && !$db->result_first("SELECT COUNT(*) FROM {$tablepre}mytasks WHERE uid='$discuz_uid' AND taskid='$task[relatedtaskid]' AND status='1'")) {
		showmessage('task_relatedtask', 'task.php?action=view&id='.$task['relatedtaskid']);
	} elseif($task['applyperm'] && $task['applyperm'] != 'all' && !(($task['applyperm'] == 'member' && $adminid == '0') || ($task['applyperm'] == 'admin' && $adminid > '0') || forumperm($task['applyperm']))) {
		showmessage('task_grouplimit', 'task.php?item=new');
	} else {

		if(!$task['period'] && $db->result_first("SELECT COUNT(*) FROM {$tablepre}mytasks WHERE uid='$discuz_uid' AND taskid='$id'")) {
			showmessage('task_duplicate', 'task.php?item=new');
		} elseif($task['period'] && $db->result_first("SELECT COUNT(*) FROM {$tablepre}mytasks WHERE uid='$discuz_uid' AND taskid='$id' AND dateline>=$timestamp-$task[period]*3600")) {
			showmessage('task_nextperiod', 'task.php?item=new');
		}
	}

	require_once DISCUZ_ROOT.'./include/tasks/'.$task['scriptname'].'.inc.php';
	task_condition();
	task_preprocess();

	$db->query("REPLACE INTO {$tablepre}mytasks (uid, username, taskid, dateline)
		VALUES ('$discuz_uid', '$discuz_user', '$id', '$timestamp')");
	$db->query("UPDATE {$tablepre}tasks SET applicants=applicants+1 WHERE taskid='$id'", 'UNBUFFERED');
	$db->query("UPDATE {$tablepre}members SET prompt=".bindec('1'.intval($newpm))." WHERE uid='$discuz_uid'", 'UNBUFFERED');

	showmessage('task_applied', "task.php?action=view&id=$id");

} elseif($action == 'draw' && $id) {

	if(!$discuz_uid) {
		showmessage('not_loggedin', NULL, 'NOPERM');
	}

	if(!$task = $db->fetch_first("SELECT t.*, mt.dateline AS applytime, mt.status FROM {$tablepre}tasks t, {$tablepre}mytasks mt WHERE mt.uid='$discuz_uid' AND mt.taskid=t.taskid AND t.taskid='$id' AND t.available='2'")) {
		showmessage('task_nonexistence', NULL, 'HALTED');
	} elseif($task['status'] != 0) {
		showmessage('undefined_action', NULL, 'HALTED');
	} elseif($task['tasklimits'] && $task['achievers'] >= $task['tasklimits']) {
		showmessage('task_up_to_limit', 'task.php');
	}

	require_once DISCUZ_ROOT.'./include/tasks/'.$task['scriptname'].'.inc.php';
	$result = task_csc($task);
	if($result === TRUE) {

		if($task['reward']) {
			require_once DISCUZ_ROOT.'./include/task.func.php';
			$rewards = task_reward($task);
			if($task['reward'] == 'magic') {
				$magicname = $db->result_first("SELECT name FROM {$tablepre}magics WHERE magicid='$task[prize]'");
			} elseif($task['reward'] == 'medal') {
				$medalname = $db->result_first("SELECT name FROM {$tablepre}medals WHERE medalid='$task[prize]'");
			} elseif($task['reward'] == 'group') {
				$grouptitle = $db->result_first("SELECT grouptitle FROM {$tablepre}usergroups WHERE groupid='$task[prize]'");
			}
			sendpm($discuz_uid, 'task_reward_subject', 'task_reward_'.$task['reward'].'_message', 0);
		}

		task_sufprocess();

		$db->query("UPDATE {$tablepre}mytasks SET status='1', csc='100', dateline='$timestamp' WHERE uid='$discuz_uid' AND taskid='$id'");
		$db->query("UPDATE {$tablepre}tasks SET achievers=achievers+1 WHERE taskid='$id'", 'UNBUFFERED');

		if(!$db->result_first("SELECT COUNT(*) FROM {$tablepre}mytasks WHERE uid='$discuz_uid' AND status='0'")) {
			$db->query("UPDATE {$tablepre}members SET prompt=".bindec('0'.intval($newpm))." WHERE uid='$discuz_uid'", 'UNBUFFERED');
		}

		showmessage('task_completed', 'task.php?item=done');

	} elseif($result === FALSE) {

		$db->query("UPDATE {$tablepre}mytasks SET status='-1' WHERE uid='$discuz_uid' AND taskid='$id'", 'UNBUFFERED');
		showmessage('task_failed', 'task.php?item=failed');

	} else {

		if($result) {
			$db->query("UPDATE {$tablepre}mytasks SET csc='$result' WHERE uid='$discuz_uid' AND taskid='$id'", 'UNBUFFERED');
		}
		showmessage($result ? 'task_doing' : 'task_waiting', "task.php?action=view&id=$id");

	}

} elseif(in_array($action, array('giveup', 'delete')) && $id && !empty($formhash)) {

	if($formhash != FORMHASH) {
		showmessage('undefined_action', NULL, 'HALTED');
	} else {
		if($action == 'giveup') {
			if(!$db->result_first("SELECT COUNT(*) FROM {$tablepre}mytasks WHERE uid='$discuz_uid' AND status='0'")) {
				$db->query("UPDATE {$tablepre}members SET prompt=".bindec('0'.intval($newpm))." WHERE uid='$discuz_uid'", 'UNBUFFERED');
			}
		} else {
			$period = $db->result_first("SELECT period FROM {$tablepre}tasks WHERE taskid='$id'");
			if($period === FALSE) {
				showmessage('task_nonexistence');
			} elseif(!$period) {
				showmessage('undefined_action');
			}
		}
		$db->query("DELETE FROM {$tablepre}mytasks WHERE uid='$discuz_uid' AND taskid='$id'", 'UNBUFFERED');
		$db->query("UPDATE {$tablepre}tasks SET applicants=applicants-1 WHERE taskid='$id'", 'UNBUFFERED');
		showmessage($action == 'giveup' ? 'task_giveup' : 'task_deled', "task.php?item=view&id=$id");
	}

} elseif($action == 'parter' && $id) {

	$query = $db->query("SELECT * FROM {$tablepre}mytasks WHERE taskid='$id' ORDER BY dateline DESC LIMIT 0, 8");
	while($parter = $db->fetch_array($query)) {
		$parter['avatar'] = discuz_uc_avatar($parter['uid'], 'small');
		$parterlist[] = $parter;
	}

	include template('task_parter');
	dexit();

} else {

	showmessage('undefined_action', NULL, 'HALTED');

}

include template('task');

?>