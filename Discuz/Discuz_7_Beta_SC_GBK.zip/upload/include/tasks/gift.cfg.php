<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: gift.cfg.php 9806 2007-08-15 06:04:37Z liuqiang $
*/

	$task_name = $tasklang['gift_name'];

	$task_description = $tasklang['gift_desc'];

	$task_icon = 'gift.gif';

	$task_period = '';

	$task_conditions = array(
		array('sort' => '', 'name' => '', 'description' => '', 'variable' => '', 'value' => '', 'type' => '', 'extra' => ''),
	);

	$task_version = '1.0';

	$task_copyright = $tasklang['gift_copyright'];

?>