<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: member.inc.php 9806 2007-08-15 06:04:37Z liuqiang $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function task_condition() {
}

function task_preprocess() {
	global $db, $tablepre, $task, $discuz_uid, $timestamp;
	
	if($db->result_first("SELECT COUNT(*) FROM {$tablepre}taskvars WHERE taskid='$task[taskid]' AND variable='act' AND value='buddy'")) {
		include_once DISCUZ_ROOT.'./uc_client/client.php';
		$db->query("REPLACE INTO {$tablepre}spacecaches (uid, variable, value, expiration) VALUES ('$discuz_uid', 'buddy', '".(uc_friend_totalnum($discuz_uid, 1) + uc_friend_totalnum($discuz_uid, 3))."', '$timestamp')");
	}
}

function task_csc($task = array()) {
	global $db, $tablepre, $discuz_uid, $timestamp;

	$taskvars = array('num' => 0);
	$num = 0;
	$query = $db->query("SELECT variable, value FROM {$tablepre}taskvars WHERE taskid='$task[taskid]'");
	while($taskvar = $db->fetch_array($query)) {
		if($taskvar['value']) {
			$taskvars[$taskvar['variable']] = $taskvar['value'];
		}
	}

	if($taskvars['act'] == 'buddy') {
		include_once DISCUZ_ROOT.'./uc_client/client.php';
		$num = uc_friend_totalnum($discuz_uid, 1) + uc_friend_totalnum($discuz_uid, 3) - $db->result_first("SELECT value FROM {$tablepre}spacecaches WHERE uid='$discuz_uid' AND variable='buddy'");
	} elseif(in_array($taskvars['act'], array('favorite', 'magic'))) {
		$sqladd = $timelimit = '';
		$table = $taskvars['act'].'s';
		if($table == 'favorites') {
			$sqladd .= " AND tid>'0'";
		} elseif($taskvars['time'] || $task['period']) {
			$timelimit = max($taskvars['time'], $task['period']);
			$sqladd .= " AND dateline BETWEEN $task[applytime] AND $task[applytime]+3600*$timelimit";
		}
		$num = $db->result_first("SELECT COUNT(*) FROM $tablepre$table WHERE uid='$discuz_uid' $sqladd");
	}

	if($num && $num >= $taskvars['num']) {
		if($taskvars['act'] == 'buddy') {
			$db->query("DELETE FROM {$tablepre}spacecaches WHERE uid='$discuz_uid' AND variable='buddy'");
		}
		return TRUE;
	} elseif($timelimit && $timestamp >= $task['applytime'] + 3600 * $timelimit && (!$num || $num < $taskvars['num'])) {
		return FALSE;
	} else {
		return $num && $taskvars['num'] ? sprintf("%01.2f", $num / $taskvars['num'] * 100) : 0;
	}

}

function task_sufprocess() {
}

?>