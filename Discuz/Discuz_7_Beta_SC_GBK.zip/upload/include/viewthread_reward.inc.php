<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: viewthread_reward.inc.php 15998 2008-10-22 05:37:37Z monkey $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$rewardprice = abs($thread['price']);
$bestpost = array();
if($thread['price'] < 0 && $page == 1) {
	foreach($postlist as $key => $post) {
		if(!$post['first']) {
			$bestpost = $post;
			unset($postlist[$key]);
			break;
		}
	}
}

?>