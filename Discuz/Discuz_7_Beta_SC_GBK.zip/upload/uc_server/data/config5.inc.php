<?php 
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'ucenter');
define('UC_DBCHARSET', 'gbk');
define('UC_DBTABLEPRE', 'uc_');
define('UC_DBCONNECT', 0);
define('UC_CHARSET', 'gbk');
define('UC_FOUNDERPW', '1d4cc1d805df125fef55a755486d0ef3');
define('UC_FOUNDERSALT', '194254');
define('UC_KEY', '76bE6g1b8LcC6zdH0L1Neg0b5k082dfNaDaWd9cP2BaP483o819v5a229k4D469V');
define('UC_SITEID', '7xby6m108Ic26Ddk0B18ez0f5A0X27fDaAaPdwcY21a9403o8H9R502N9g4d4e9M');
define('UC_MYKEY', '7hbh611t8PcZ69dq0J1weA0z540v22fRa1agdWcS2tag4J3v8D9e552u994u4o9m');
define('UC_DEBUG', false);
define('UC_PPP', 20);
