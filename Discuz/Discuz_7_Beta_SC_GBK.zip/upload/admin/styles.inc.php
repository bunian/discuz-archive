<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: styles.inc.php 16334 2008-10-31 07:54:45Z monkey $
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
}

$operation = empty($operation) ? 'admin' : $operation;

if($operation == 'export' && $id) {

	$stylearray = $db->fetch_first("SELECT s.name, s.templateid, t.name AS tplname, t.directory, t.copyright FROM {$tablepre}styles s LEFT JOIN {$tablepre}templates t ON t.templateid=s.templateid WHERE styleid='$id'");
	if(!$stylearray) {
		cpheader();
		cpmsg('styles_export_invalid', '', 'error');
	}

	$stylearray['version'] = strip_tags($version);
	$time = gmdate("$dateformat $timeformat", $timestamp + $timeoffset * 3600);

	$query = $db->query("SELECT * FROM {$tablepre}stylevars WHERE styleid='$id'");
	while($style = $db->fetch_array($query)) {
		$stylearray['style'][$style['variable']] = $style['substitute'];
	}

	$style_export = "# Discuz! Style Dump\n".
			"# Version: Discuz! $version\n".
			"# Time: $time\n".
			"# From: $bbname ($boardurl)\n".
			"#\n".
			"# This file was BASE64 encoded\n".
			"#\n".
			"# Discuz! Community: http://www.Discuz.net\n".
			"# Please visit our website for latest news about Discuz!\n".
			"# --------------------------------------------------------\n\n\n".
			wordwrap(base64_encode(serialize($stylearray)), 50, "\n", 1);

	ob_end_clean();
	dheader('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
	dheader('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	dheader('Cache-Control: no-cache, must-revalidate');
	dheader('Pragma: no-cache');
	dheader('Content-Encoding: none');
	dheader('Content-Length: '.strlen($style_export));
	dheader('Content-Disposition: attachment; filename=discuz_style_'.$stylearray['name'].'.txt');
	dheader('Content-Type: '.(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') ? 'application/octetstream' : 'application/octet-stream'));

	echo $style_export;
	dexit();

}

cpheader();

$predefinedvars = array('available' => array(), 'boardimg' => array(), 'imgdir' => array(), 'styleimgdir' => array(), 'stypeid' => array(),
	'headerbgcolor' => array(0, $lang['styles_edit_type_bg']),
	'bgcolor' => array(0),
	'sidebgcolor' => array(0),

	'headerborder' => array(1, $lang['styles_edit_type_header']),
	'headerbordercolor' => array(0),
	'headertext' => array(0),
	'footertext' => array(0),

	'font' => array(1, $lang['styles_edit_type_font']),
	'fontsize' => array(1),
	'smfont' => array(1),
	'smfontsize' => array(1),
	'tabletext' => array(0),
	'midtext' => array(0),
	'lighttext' => array(0),

	'link' => array(0, $lang['styles_edit_type_url']),
	'highlightlink' => array(0),

	'wrapwidth' => array(1, $lang['styles_edit_type_wrap']),
	'wrapbg' => array(0),
	'wrapborder' => array(1),
	'wrapbordercolor' => array(0),

	'msgfontsize' => array(1, $lang['styles_edit_type_post']),
	'msgbigsize' => array(1),
	'contentwidth' => array(1),
	'contentseparate' => array(0),

	'menuborder' => array(0, $lang['styles_edit_type_menu']),
	'menubgcolor' => array(0),
	'menutext' => array(0),
	'menuhover' => array(0),
	'menuhovertext' => array(0),

	'inputborder' => array(0, $lang['styles_edit_type_input']),
	'inputborderdarkcolor' => array(0),
	'inputbg' => array(0),

	'dropmenuborder' => array(0, $lang['styles_edit_type_dropmenu']),
	'dropmenubgcolor' => array(0),

	'floatbgcolor' => array(0, $lang['styles_edit_type_float']),
	'floatmaskbgcolor' => array(0),

	'commonborder' => array(0, $lang['styles_edit_type_other']),
	'commonbg' => array(0),
	'specialborder' => array(0),
	'specialbg' => array(0),
	'interleavecolor' => array(0),
	'noticetext' => array(0),
);

if($operation == 'admin') {

	$query = $db->query("SELECT s.styleid, s.available, s.name, t.name AS tplname, t.directory, t.copyright FROM {$tablepre}styles s LEFT JOIN {$tablepre}templates t ON t.templateid=s.templateid ORDER BY s.styleid");
	$sarray = array();
	while($row = $db->fetch_array($query)) {
		$sarray[$row['styleid']] = $row;
	}

	$defaultid = $db->result_first("SELECT value FROM {$tablepre}settings WHERE variable='styleid'");

	if(!submitcheck('stylesubmit')) {

		$stylelist = '';
		$i = 0;
		foreach($sarray as $id => $style) {
			$style['name'] = dhtmlspecialchars($style['name']);
			$isdefault = $id == $defaultid ? 'checked' : '';
			$available = $style['available'] ? 'checked' : NULL;
			$preview = file_exists($style['directory'].'/preview.jpg') ? $style['directory'].'/preview.jpg' : './images/admincp/stylepreview.jpg';
			$stylelist .= ($i == 0 ? '<tr>' : '').
				'<td width="33%"><table cellspacing="0" cellpadding="0" style="margin-left: 10px; width: 200px;"><tr><td style="width: 120px; text-align: center; border-top: none;">'.
				"<p style=\"margin-bottom: 2px;\">StyleID: $id</p>
				<a href=\"{$boardurl}$indexname?styleid=$id\" target=\"_blank\"><img src=\"$preview\" /></a>
				<p style=\"margin: 2px 0\"><input type=\"text\" class=\"txt\" name=\"namenew[$id]\" value=\"$style[name]\" size=\"30\" style=\"margin-right:0\"></p>
				<p class=\"lightfont\">($style[tplname])</p></td><td style=\"padding-top: 17px; width: 80px; border-top: none; vertical-align: top;\">
				<p style=\"margin: 2px 0\">$lang[available] <input class=\"checkbox\" type=\"checkbox\" name=\"availablenew[$id]\" value=\"1\" $available></p>
				<p style=\"margin: 2px 0\">$lang[default] <input type=\"radio\" class=\"radio\" name=\"defaultnew\" value=\"$id\" $isdefault></p>
				<p style=\"margin: 2px 0\">$lang[delete] ".($isdefault ? '<input class="checkbox" type="checkbox" disabled="disabled" />' : '<input class="checkbox" type="checkbox" name="delete[]" value="'.$id.'" />')."</p>
				<p style=\"margin: 8px 0 2px\"><a href=\"$BASESCRIPT?action=styles&operation=edit&id=$id\">$lang[edit]</a></p>
				<p style=\"margin: 2px 0\"><a href=\"$BASESCRIPT?action=styles&operation=export&id=$id\">$lang[export]</a></p>
				<p style=\"margin: 2px 0\"><a href=\"$BASESCRIPT?action=styles&operation=copy&id=$id\">$lang[copy]</a></p>
				</td></tr></table></td>\n".($i == 3 ? '</tr>' : '');
			$i++;
			if($i == 3) {
				$i = 0;
			}
		}
		if($i > 0) {
			$stylelist .= str_repeat('<td></td>', 3 - $i);
		}

		shownav('style', 'styles_admin');
		showsubmenu('styles_admin', array(
			array('admin', 'styles', '1'),
			array('import', 'styles&operation=import', '0')
		));
		showtips('styles_admin_tips');
		showformheader('styles');
		showhiddenfields(array('updatecsscache' => 0));
		showtableheader('', 'tdhover');
		echo $stylelist;
		showtablefooter();
		showtableheader();
		echo '<tr><td>'.$lang['add_new'].'</td><td><input type="text" class="txt" name="newname" size="18"></td><td colspan="5">&nbsp;</td></tr>';
		showsubmit('stylesubmit', 'submit', 'del', '<input onclick="this.form.updatecsscache.value=1" type="submit" class="btn" name="stylesubmit" value="'.lang('styles_csscache_update').'">');
		showtablefooter();
		showformfooter();

	} else {

		if($updatecsscache) {
			updatecache('styles');
			cpmsg('csscache_update', $BASESCRIPT.'?action=styles', 'succeed');
		} else {

			if(is_numeric($defaultnew) && $defaultid != $defaultnew && isset($sarray[$defaultnew])) {
				$defaultid = $defaultnew;
				$db->query("UPDATE {$tablepre}settings SET value='$defaultid' WHERE variable='styleid'");
			}

			$availablenew[$defaultid] = 1;

			foreach($sarray as $id => $old) {
				$namenew[$id] = trim($namenew[$id]);
				$availablenew[$id] = $availablenew[$id] ? 1 : 0;
				if($namenew[$id] != $old['name'] || $availablenew[$id] != $old['available']) {
					$db->query("UPDATE {$tablepre}styles SET name='$namenew[$id]', available='$availablenew[$id]' WHERE styleid='$id'");
				}
			}

			if(!empty($delete) && is_array($delete)) {
				$did = array();
				foreach($delete as $id) {
					$id = intval($id);
					if($id == $defaultid) {
						cpmsg('styles_delete_invalid', '', 'error');
					} elseif($id != 1){
						$did[] = intval($id);
					}
				}
				if($did && ($ids = implodeids($did))) {
					$db->query("DELETE FROM {$tablepre}styles WHERE styleid IN ($ids)");
					$db->query("DELETE FROM {$tablepre}stylevars WHERE styleid IN ($ids)");
					$db->query("UPDATE {$tablepre}members SET styleid='0' WHERE styleid IN ($ids)");
					$db->query("UPDATE {$tablepre}forums SET styleid='0' WHERE styleid IN ($ids)");
					$db->query("UPDATE {$tablepre}sessions SET styleid='$defaultid' WHERE styleid IN ($ids)");
				}
			}

			if($newname) {
				$db->query("INSERT INTO {$tablepre}styles (name, templateid) VALUES ('$newname', '1')");
				$styleidnew = $db->insert_id();
				foreach(array_keys($predefinedvars) as $variable) {
					$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable)
						VALUES ('$styleidnew', '$variable')");
				}
			}

			updatecache('settings');
			updatecache('styles');
			cpmsg('styles_edit_succeed', $BASESCRIPT.'?action=styles', 'succeed');
		}

	}

} elseif($operation == 'import') {

	if(!submitcheck('importsubmit')) {

		shownav('style', 'styles_admin');
		showsubmenu('styles_admin', array(
			array('admin', 'styles', '0'),
			array('import', 'styles&operation=import', '1')
		));
		showformheader('styles&operation=import', 'enctype');
		showtableheader('styles_import');
		showtablerow('', '', '<input type="file" name="importfile" size="40" class="uploadbtn marginbot" />');
		showtablerow('', '', '<input class="checkbox" type="checkbox" name="ignoreversion" id="ignoreversion" value="1" /><label for="ignoreversion"> '.lang('styles_import_ignore_version').'</label>');
		showsubmit('importsubmit');
		showtablefooter();
		showformfooter();

	} else {

		$styledata = preg_replace("/(#.*\s+)*/", '', @implode('', file($_FILES['importfile']['tmp_name'])));
		@unlink($_FILES['importfile']['tmp_name']);
		$stylearray = daddslashes(unserialize(base64_decode($styledata)), 1);

		if(!is_array($stylearray)) {
			cpmsg('styles_import_data_invalid', '', 'error');
		} elseif(empty($ignoreversion) && strip_tags($stylearray['version']) != strip_tags($version)) {
			cpmsg('styles_import_version_invalid', '', 'error');
		}

		$renamed = 0;
		if($stylearray['templateid'] != 1) {
			$templatedir = DISCUZ_ROOT.'./'.$stylearray['directory'];
			if(!is_dir($templatedir)) {
				if(!@mkdir($templatedir, 0777)) {
					$basedir = dirname($stylearray['directory']);
					cpmsg('styles_import_directory_invalid', '', 'error');
				}
			}

			if($db->result_first("SELECT COUNT(*) FROM {$tablepre}templates WHERE name='$stylearray[tplname]'")) {
				$stylearray['tplname'] .= '_'.random(4);
				$renamed = 1;
			}
			$db->query("INSERT INTO {$tablepre}templates (name, directory, copyright)
				VALUES ('$stylearray[tplname]', '$stylearray[directory]', '$stylearray[copyright]')");
			$templateid = $db->insert_id();
		} else {
			$templateid = 1;
		}

		if($db->result_first("SELECT COUNT(*) FROM {$tablepre}styles WHERE name='$stylearray[name]'")) {
			$stylearray['name'] .= '_'.random(4);
			$renamed = 1;
		}
		$db->query("INSERT INTO {$tablepre}styles (name, templateid)
			VALUES ('$stylearray[name]', '$templateid')");
		$styleidnew = $db->insert_id();

		foreach($stylearray['style'] as $variable => $substitute) {
			$substitute = @htmlspecialchars($substitute);
			$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute)
				VALUES ('$styleidnew', '$variable', '$substitute')");
		}

		updatecache('styles');
		updatecache('settings');
		cpmsg($renamed ? 'styles_import_succeed_renamed' : 'styles_import_succeed', $BASESCRIPT.'?action=styles', 'succeed');
	}

} elseif($operation == 'copy') {

	$style = $db->fetch_first("SELECT * FROM {$tablepre}styles WHERE styleid='$id'");
	$style['name'] .= '_'.random(4);
	$db->query("INSERT INTO {$tablepre}styles (name, available, templateid)
			VALUES ('$style[name]', '$style[available]', '$style[templateid]')");
	$styleidnew = $db->insert_id();

	$query = $db->query("SELECT * FROM {$tablepre}stylevars WHERE styleid='$id'");
	while($stylevar = $db->fetch_array($query)) {
		$stylevar['substitute'] = addslashes($stylevar['substitute']);
		$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute)
				VALUES ('$styleidnew', '$stylevar[variable]', '$stylevar[substitute]')");
	}

	updatecache('styles');
	updatecache('settings');
	cpmsg('styles_copy_succeed', $BASESCRIPT.'?action=styles', 'succeed');

} elseif($operation == 'edit') {

	if(!submitcheck('editsubmit')) {

		if(empty($id)) {
			$stylelist = "<select name=\"id\" style=\"width: 150px\">\n";
			$query = $db->query("SELECT styleid, name FROM {$tablepre}styles");
			while($style = $db->fetch_array($query)) {
				$stylelist .= "<option value=\"$style[styleid]\">$style[name]</option>\n";
			}
			$stylelist .= '</select>';
			cpmsg('styles_nonexistence', $BASESCRIPT.'?action=styles&operation=edit'.(!empty($highlight) ? "&highlight=$highlight" : ''), 'form', $stylelist);
		}

		$style = $db->fetch_first("SELECT name, templateid FROM {$tablepre}styles WHERE styleid='$id'");
		if(!$style) {
			cpmsg('undefined_action', '', 'error');
		}

		$stylecustom = '';
		$stylestuff = $existvars = array();
		$query = $db->query("SELECT * FROM {$tablepre}stylevars WHERE styleid='$id'");
		while($stylevar = $db->fetch_array($query)) {
			if(array_key_exists($stylevar['variable'], $predefinedvars)) {
				$stylestuff[$stylevar['variable']] = array('id' => $stylevar['stylevarid'], 'subst' => $stylevar['substitute']);
				$existvars[] = $stylevar['variable'];
			} else {
				$stylecustom .= showtablerow('', array('class="td25"', 'class="td24 bold"', 'class="td26"'), array(
					"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$stylevar[stylevarid]\">",
					'{'.strtoupper($stylevar['variable']).'}',
					"<textarea name=\"stylevar[$stylevar[stylevarid]]\" style=\"height: 45px\" cols=\"50\" rows=\"2\">$stylevar[substitute]</textarea>",
				), TRUE);
			}
		}
		if($diffvars = array_diff(array_keys($predefinedvars), $existvars)) {
			foreach($diffvars as $variable) {
				$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute)
					VALUES ('$id', '$variable', '')");
				$stylestuff[$variable] = array('id' => $db->insert_id(), 'subst' => '');
			}
		}

		$tplselect = array();
		$query = $db->query("SELECT templateid, name FROM {$tablepre}templates");
		while($template = $db->fetch_array($query)) {
			$tplselect[] = array($template['templateid'], $template['name']);
		}

		$smileytypes = array();
		$query = $db->query("SELECT typeid, name FROM {$tablepre}imagetypes WHERE available='1'");
		while($type = $db->fetch_array($query)) {
			$smileytypes[] = array($type['typeid'], $type['name']);
		}

		shownav('style', 'styles_edit');
		showsubmenu('styles_admin', array(
			array('admin', 'styles', '0'),
			array('import', 'styles&operation=import', '0')
		));
		echo '
		<script type="text/JavaScript">
		function imgpre_onload(obj) {
			if(!obj.complete) {
				setTimeout(function() {imgpre_resize(obj)}, 100);
			}
			imgpre_resize(obj);
		}
		function imgpre_resize(obj) {
			if(obj.width > 350) {
				obj.style.width = \'350px\';
			}
		}
		function imgpre_update(id, obj) {
			url = obj.value;
			if(url) {
				re = /^http:\/\//i;
				var matches = re.exec(url);
				if(matches == null) {
					url = ($(\'styleimgdir\').value ? $(\'styleimgdir\').value : ($(\'imgdir\').value ? $(\'imgdir\').value : \'images/default\')) + \'/\' + url;
				}
				$(\'bgpre_\' + id).style.backgroundImage = \'url(\' + url + \')\';
			} else {
				$(\'bgpre_\' + id).style.backgroundImage = \'url(images/common/none.gif)\';
			}
		}
		function imgpre_switch(id) {
			if($(\'bgpre_\' + id).innerHTML == \'\') {
				url = $(\'bgpre_\' + id).style.backgroundImage.substring(4, $(\'bgpre_\' + id).style.backgroundImage.length - 1);
				$(\'bgpre_\' + id).innerHTML = \'<img onload="imgpre_onload(this)" src="\' + url + \'" />\';
				$(\'bgpre_\' + id).backgroundImage = $(\'bgpre_\' + id).style.backgroundImage;
				$(\'bgpre_\' + id).style.backgroundImage = \'\';
			} else {
				$(\'bgpre_\' + id).style.backgroundImage = $(\'bgpre_\' + id).backgroundImage;
				$(\'bgpre_\' + id).innerHTML = \'\';
			}
		}
		</script>
		';

		showformheader("styles&operation=edit&id=$id");
		showtableheader($lang['styles_edit'].' - '.$style['name'], 'nobottom');
		showsetting('styles_edit_name', 'namenew', $style['name'], 'text');
		showsetting('styles_edit_tpl', array('templateidnew', $tplselect), $style['templateid'], 'select');
		showsetting('styles_edit_smileytype', array("stylevar[{$stylestuff[stypeid][id]}]", $smileytypes), $stylestuff['stypeid']['subst'], 'select');
		showsetting('styles_edit_imgdir', '', '', '<input type="text" class="txt" name="stylevar['.$stylestuff['imgdir']['id'].']" id="imgdir" value="'.$stylestuff['imgdir']['subst'].'" />');
		showsetting('styles_edit_styleimgdir', '', '', '<input type="text" class="txt" name="stylevar['.$stylestuff['styleimgdir']['id'].']" id="styleimgdir" value="'.$stylestuff['styleimgdir']['subst'].'" />');
		showsetting('styles_edit_logo', "stylevar[{$stylestuff[boardimg][id]}]", $stylestuff['boardimg']['subst'], 'text');

		foreach($predefinedvars as $predefinedvar => $v) {
			if($v !== array()) {
				if(!empty($v[1])) {
					showtitle($v[1]);
				}
				$type = $v[0] == 1 ? 'text' : 'color';
				$extra = '';
				$comment = ($type == 'text' ? $lang['styles_edit_'.$predefinedvar.'_comment'] : $lang['styles_edit_hexcolor']).$lang['styles_edit_'.$predefinedvar.'_comment'];
				if(substr($predefinedvar, -7, 7) == 'bgcolor') {
					$stylestuff[$predefinedvar]['subst'] = explode(' ', $stylestuff[$predefinedvar]['subst']);
					$bgimg = $stylestuff[$predefinedvar]['subst'][1];
					$bgextra = implode(' ', array_slice($stylestuff[$predefinedvar]['subst'], 2));
					$stylestuff[$predefinedvar]['subst'] = $stylestuff[$predefinedvar]['subst'][0];
					$bgimgpre = $bgimg ? (preg_match('/^http:\/\//i', $bgimg) ? $bgimg : ($stylestuff['styleimgdir']['subst'] ? $stylestuff['styleimgdir']['subst'] : ($stylestuff['imgdir']['subst'] ? $stylestuff['imgdir']['subst'] : 'images/default')).'/'.$bgimg) : 'images/common/none.gif';
					$comment .= '<div id="bgpre_'.$stylestuff[$predefinedvar]['id'].'" onclick="imgpre_switch('.$stylestuff[$predefinedvar]['id'].')" style="background-image:url('.$bgimgpre.');cursor:pointer;float:right;width:350px;height:40px;overflow:hidden;border: 1px solid #ccc"></div>'.$lang['styles_edit_'.$predefinedvar.'_comment'].$lang['styles_edit_bg'];
					$extra = '<br /><input name="stylevarbgimg['.$stylestuff[$predefinedvar]['id'].']" value="'.$bgimg.'" onchange="imgpre_update('.$stylestuff[$predefinedvar]['id'].', this)" type="text" class="txt" style="margin:5px 0;" />'.
						'<br /><input name="stylevarbgextra['.$stylestuff[$predefinedvar]['id'].']" value="'.$bgextra.'" type="text" class="txt" />';
					$varcomment = ' {'.strtoupper($predefinedvar).'},{'.strtoupper(substr($predefinedvar, 0, -7)).'BGCODE}:';
				} else {
					$varcomment = ' {'.strtoupper($predefinedvar).'}:';
				}
				showsetting(lang('styles_edit_'.$predefinedvar).$varcomment, 'stylevar['.$stylestuff[$predefinedvar]['id'].']', $stylestuff[$predefinedvar]['subst'], $type, '', 0, $comment, $extra);
			}
		}
		showtablefooter();

		showtableheader('styles_edit_customvariable', 'notop');
		showsubtitle(array('', 'styles_edit_variable', 'styles_edit_subst'));
		echo $stylecustom;
		showtablerow('', array('class="td25"', 'class="td24 bold"', 'class="td26"'), array(
			lang('add_new'),
			'<input type="text" class="txt" name="newcvar">',
			'<textarea name="newcsubst" class="tarea" style="height: 45px" cols="50" rows="2"></textarea>'

		));
		showsubmit('editsubmit', 'submit', 'del');
		showtablefooter();
		showformfooter();

	} else {

		if($newcvar && $newcsubst) {
			if($db->result_first("SELECT COUNT(*) FROM {$tablepre}stylevars WHERE variable='$newcvar' AND styleid='$id'")) {
				cpmsg('styles_edit_variable_duplicate', '', 'error');
			} elseif(!preg_match("/[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*/", $newcvar)) {
				cpmsg('styles_edit_variable_illegal', '', 'error');
			}
			$newcvar = strtolower($newcvar);
			$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute)
				VALUES ('$id', '$newcvar', '$newcsubst')");
		}

		$db->query("UPDATE {$tablepre}styles SET name='$namenew', templateid='$templateidnew' WHERE styleid='$id'");
		foreach($stylevar as $varid => $substitute) {
			if(!empty($stylevarbgimg[$varid])) {
				$substitute .= ' '.$stylevarbgimg[$varid];
				if(!empty($stylevarbgextra[$varid])) {
					$substitute .= ' '.$stylevarbgextra[$varid];
				}
			}
			$substitute = @htmlspecialchars($substitute);
			$db->query("UPDATE {$tablepre}stylevars SET substitute='$substitute' WHERE stylevarid='$varid' AND styleid='$id'");
		}

		if($ids = implodeids($delete)) {
			$db->query("DELETE FROM {$tablepre}stylevars WHERE stylevarid IN ($ids) AND styleid='$id'");
		}

		updatecache('styles');
		cpmsg('styles_edit_succeed', $BASESCRIPT.'?action=styles'.($newcvar && $newcsubst ? '&operation=edit&id='.$id : ''), 'succeed');

	}

}

?>