var promptmsg = {
	'post_newthread' : '點這裡發表新話題',
	'post_reply' : '點這裡回復該話題',
	'post_subject' : '在這裡輸入帖子標題',
	'post_message' : '在這裡輸入帖子內容',
	'post_submit' : '點這裡發表帖子',
	'sendpm' : '點這裡給TA發送一條短消息',
	'sendpm_message' : '在這裡輸入短消息內容',
	'sendpm_submit' : '點這裡發送短消息',
	'addbuddy' : '點這裡把TA加為好友',
	'search_kw' : '點這裡輸入關鍵詞',
	'search_submit' : '點這裡開始搜索',
	'uploadavatar' : '點這裡進入頭像設置頁面',
	'modifyprofile_birthday' : '點這裡選擇生日',
	'modifyprofile_qq' : '點這裡輸入您常用的 QQ 號',
	'modifyprofile_submit' : '點這裡確認修改'
};