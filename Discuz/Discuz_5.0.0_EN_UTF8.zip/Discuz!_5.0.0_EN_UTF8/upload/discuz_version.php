<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('DISCUZ_VERSION', '5.0.0');
define('DISCUZ_RELEASE', '20080805');

?>