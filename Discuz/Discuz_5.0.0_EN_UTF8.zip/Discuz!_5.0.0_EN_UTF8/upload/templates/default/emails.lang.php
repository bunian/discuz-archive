<?php

$language = array (
  'get_passwd_subject' => '[Discuz!] Password Retrieving Request',
  'get_passwd_message' => '
$member[username]��
Send By $bbname:

You, or someone posing as you, has requested to reset password in
our forum.

----------------------------------------------------------------------
Attention��
----------------------------------------------------------------------

If this is not a valid request made by you, please disregard this 
email immediately.

If it this is a valid request, please follow the steps to reset your 
password.	


----------------------------------------------------------------------
Password Reset Steps
----------------------------------------------------------------------


1. To reset your password, please click on the link below in 3 days.

{$boardurl}member.php?action=getpasswd&uid=$member[uid]&id=$idstring

(You may need to cut and paste the link into your web browser.)

2. You will need to enter and confirm your new password.

3. You can login with your new password, you can change your password
in User CP. at anytime.

Request By IP : $onlineip


Best Regards

$bbname Administration Group.
$boardurl',
  'email_verify_subject' => '[Discuz!] Email Address Verfication',
  'email_verify_message' => '
$discuz_user ��
Send By $bbname :

You have received this email because this email address
was used during registration for our forums.
If you did not register at our forums, please disregard this
email. You do not need to unsubscribe or take any further action.

----------------------------------------------------------------------
Activation Instructions
----------------------------------------------------------------------

Thank you for registering.
We require that you "validate" your registration to ensure that
the email address you entered was correct. This protects against
unwanted spam and malicious abuse.

To activate your account, simply click on the following link:

{$boardurl}member.php?action=activate&uid=$discuz_uid&id=$idstring

(You may need to cut and paste the link into your web browser.)

Thank you for registering and enjoy your stay!

Regards,

$bbname Administration Group.
$boardurl',
  'email_notify_subject' => '[Discuz!] [$thread[subject]] Reply Notification',
  'email_notify_message' => '
$discuz_user ��
Send By $bbname :

You have received this email because the thread you subscribed have 
new replies in 24 hours.If you did not access our forums, please 
disregard this email. You do not need to unsubscribe or take any 
further action.

----------------------------------------------------------------------
Subject Information
----------------------------------------------------------------------
URL:  {$boardurl}viewthread.php?tid=$thread[tid]
Subject: $thread[subject]
Author: $thread[author]
Views: $thread[views]
Replies: $thread[replies]

Recently replied by $thread[lastposter] at $thread[lastpost].

It\'s possible that there\'s more replies in this thread, but we will 
not send more than one notice every 24 hours. If there\'s more replies
you will be noticed next time.


Regards,

$bbname Administration Group.
$boardurl',
  'add_member_subject' => '[Discuz!] You have been approved.',
  'add_member_message' => '
$newusername ��
Send By $bbname :

I am $discuz_user ��one of $bbname Administration Group��You have 
received this email because you have been approved to access our forum.

----------------------------------------------------------------------
Important��
----------------------------------------------------------------------

If you don\'t want to be a memeber of our forum, please disregard this 
email.

----------------------------------------------------------------------
Account Information
----------------------------------------------------------------------

Forum Name��$bbname
Url��$boardurl

User Name��$newusername
Password��$newpassword

Please use the information about to login into our fourm.



Regards,

$bbname Administration Group.
$boardurl',
  'birthday_subject' => '[Discuz!] Happy Birthday',
  'birthday_message' => '
$member[username]��
Send By $bbname :

You have received this email because this email address was used during
registration for our forums. According to the information provied by 
you, today is your birthday.

Happy Birthday!

If you did not register at our forums or it i\'snt today, please 
disregard this email. You do not need to unsubscribe or take any further
action.


Regards,

$bbname Administration Group.
$boardurl',
  'email_to_friend_subject' => 'Recommend to you: $thread[subject]',
  'email_to_friend_message' => '
$sendtoname,
Sent By $discuz_userss @ $bbname :

You have received this email because $discuz_userss use 
"Recommend to Friend" feature to send you following contents to your 
email address.
If you are not interest in, please disregard this email. You do not need
to unsubscribe or take any further action.

----------------------------------------------------------------------
Origion Email Begin
----------------------------------------------------------------------

$message

----------------------------------------------------------------------
Origion Email End
----------------------------------------------------------------------

Please notice that this is not offical email,we will not be responsible
for this kind of emails.

Welcome to $bbname
$boardurl',
  'moderate_member_subject' => '[Discuz!] Audit Result',
  'moderate_member_message' => '
$member[username] ��
Sent By $bbname :

You have received this email because this email address was used during
registration for our forums. And the Administrator choose to approve
members by hand.This email was sent to notice you about the result.

----------------------------------------------------------------------
Account Information & Audit Result
----------------------------------------------------------------------

Username      : $member[username]
Register Date : $member[regdate]
Submit Date   : $member[submitdate]
Submit Times  : $member[submittimes]
Reason        : $member[message]

Audit Result  : $member[operation]
Audit Date    : $member[moddate]
Audit By      : $discuz_userss
Remark        : $member[remark]

----------------------------------------------------------------------
Result Instructions
----------------------------------------------------------------------

Approved : You have been approved to access our forum.

Denied   : The Information provided by you is incomplete, or it doesn\'t
           match our requirements.You can change the information and 
           submit again, according to administrator\'s remark.

Deleted  : The Information doesn\'t match our requiments, or there\'s 
           too many registrations. You account was deleted in our 
           Database, you can\'t login or submit again, forgive me.


Regards,

$bbname Administration Group.
$boardurl',
);

?>
