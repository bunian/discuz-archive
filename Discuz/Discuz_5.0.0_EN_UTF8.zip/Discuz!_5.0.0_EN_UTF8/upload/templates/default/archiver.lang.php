<?php

// Message Pack for Discuz! Archiver Version 1.0.0
// Created by Crossday

$lang = array 
(

  'page' => 'Page',
  'replies' => 'Replies',
  'anonymous' => 'Anonymous',
  'full_version' => 'Full Version',
  'forum_nonexistence' => 'You have no permission to access the forum or the fourm doesn\'t exist.',
  'thread_nonexistence' => 'You have no permission to access the thread or the thread doesn\'t exist.',
);

?>
