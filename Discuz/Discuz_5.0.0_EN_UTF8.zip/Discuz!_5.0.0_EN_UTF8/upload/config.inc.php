<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: config.inc.php,v $
	$Revision: 1.14.2.1 $
	$Date: 2006/07/17 07:50:17 $
*/

// [EN]	Set below parameters according to your account information provided by your hosting

	$dbhost = 'localhost';			// database server

	$dbuser = 'dbuser';			// database username

	$dbpw = 'dbpasswd';			// database password

	$dbname = 'dbname';			// database name

	$adminemail = 'admin@your.com';		// admin email

	$dbreport = 0;				// send db error report? 1=yes


// [EN] If you have problems logging in Discuz!, then modify the following parameters, else please leave default

	$cookiedomain = ''; 			// cookie domain

	$cookiepath = '/';			// cookie path


// [EN] Special parameters, DO NOT modify these unless you are an expert in Discuz!

	$headercharset = 0;			// force outputing charset header

	$errorreport = 1;			// reporting php error, 0=only report to admins(safer), 1=report to all

	$forcesecques = 0;			// require security question for administrators' control panel, 0=off, 1=on

	$onlinehold = 900;			// time span of online recording

	$pconnect = 0;				// persistent database connection, 0=off, 1=on

	$forumfounders = '';			// super administrator's UID

// [EN] !ATTENTION! Do NOT modify following after your board was settle down

	$tablepre = 'cdb_';   			
						// table prefix, modify this when you are installingmore than 1 Discuz! in the same database.

	$attachdir = './attachments';		
						// attachments saving dir. (chmod to 777, visual web dir only, ending without slash

	$attachurl = 'attachments';		// attachements url


// [EN] !ATTENTION! Preservation or debugging for developing

	$database = 'mysql';			// 'mysql' for MySQL version and 'pgsql' for PostgreSQL version

	$charset = 'utf-8';			// default character set, 'gbk', 'big5', 'utf-8' are available

	$dbcharset = '';			// default database character set, 'gbk', 'big5', 'utf8', 'latin1' and blank are available

	$attackevasive = 0;			// protect against attacks via common request, 0=off, 1=cookie refresh limitation, 2=deny proxy request, 3=both

	$tplrefresh = 1;			// auto check validation of templates, 0=off, 1=on

// ============================================================================