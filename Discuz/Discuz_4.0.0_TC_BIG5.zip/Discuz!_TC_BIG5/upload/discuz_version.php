<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('DISCUZ_VERSION', '4.0.0');
define('DISCUZ_RELEASE', '20060102');

?>