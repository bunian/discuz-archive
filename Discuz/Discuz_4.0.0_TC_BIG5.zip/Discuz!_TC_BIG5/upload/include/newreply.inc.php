<?php

/*
	[DISCUZ!] include/newreply.inc.php - post replying for post module
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005-4-12 7:58
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$discuz_action = 12;

if(!$discuz_uid && !((!$forum['replyperm'] && $allowreply) || ($forum['replyperm'] && forumperm($forum['replyperm'])))) {
	showmessage('group_nopermission', NULL, 'NOPERM');
} elseif(empty($forum['allowreply'])) {
	if(!$forum['replyperm'] && !$allowreply) {
		showmessage('group_nopermission', NULL, 'NOPERM');
	} elseif($forum['replyperm'] && !forumperm($forum['replyperm'])) {
		showmessage('post_forum_newreply_nopermission', NULL, 'HALTED');
	}
}

if(empty($thread)) {
	showmessage('thread_nonexistence');
} elseif($thread['price'] > 0) {
	if(!$discuz_uid) {
		showmessage('group_nopermission', NULL, 'NOPERM');
	} elseif(!$forum['ismoderator'] && $thread['authorid'] != $discuz_uid) {
		$query = $db->query("SELECT tid FROM {$tablepre}paymentlog WHERE tid='$tid' AND uid='$discuz_uid'");
		if(!$db->num_rows($query)) {
			showmessage('undefined_action', NULL, 'HALTED');
		}
	}
}

checklowerlimit($replycredits);

if(!submitcheck('replysubmit', 0, $seccodecheck)) {

	if(isset($repquote)) {

		include_once language('misc');

		$query = $db->query("SELECT tid, fid, author, message, useip, dateline FROM {$tablepre}posts WHERE pid='$repquote' AND invisible='0'");
		$thaquote = $db->fetch_array($query);
		if($thaquote['tid'] != $tid) {
			showmessage('undefined_action', NULL, 'HALTED');
		}
		$quotefid = $thaquote['fid'];
		$message = $thaquote['message'];

		$time = gmdate("$dateformat $timeformat", $thaquote['dateline'] + ($timeoffset * 3600));
		$message = preg_replace("/\[hide=?\d*\](.+?)\[\/hide\]/is", "[b]$language[post_hidden][/b]", $message);
		$message = preg_replace("/(\[quote])(.*)(\[\/quote])/siU", "", $message);
		$message = preg_replace($language['post_edit_regexp'], '', $message);
		$message = cutstr(dhtmlspecialchars($message), 200);

		$thaquote['useip'] = substr($thaquote['useip'], 0, strrpos($thaquote['useip'], '.')).'.x';
		$thaquote['author'] = $thaquote['author'] ? "[i]$thaquote[author][/i]" : "[i]Guest[/i] from $thaquote[useip]";

		eval("\$language['post_reply_quote'] = \"$language[post_reply_quote]\";");
		$message = "[quote]$language[post_reply_quote]\n$message [/quote]\n";

	}

	if($thread['replies'] <= $ppp) {
		$postlist = array();
		$query = $db->query("SELECT * FROM {$tablepre}posts WHERE tid='$tid' AND invisible='0' ORDER BY dateline DESC");
		while($post = $db->fetch_array($query)) {
			$post['thisbg'] = $thisbg = isset($thisbg) && $thisbg == 'altbg1' ? 'altbg2' : 'altbg1';
			$post['dateline'] = gmdate("$dateformat $timeformat", $post['dateline'] + $timeoffset * 3600);;
			$post['message'] = preg_replace("/\[hide=?\d*\](.+?)\[\/hide\]/is", "[b]$language[post_hidden][/b]", $post['message']);
			$post['message'] = discuzcode($post['message'], $post['smileyoff'], $post['bbcodeoff'], $post['htmlon'], $forum['allowsmilies'], $forum['allowbbcode'], $forum['allowimgcode'], $forum['allowhtml'], $forum['jammer']);

			$postlist[] = $post;
		}
	}

	include template('post_newreply');

} else {

	require_once DISCUZ_ROOT.'./include/forum.func.php';

	if($subject == '' && $message == '') {
		showmessage('post_sm_isnull');
	}

	if($thread['closed'] && !$forum['ismoderator']) {
		showmessage('post_thread_closed');
	}

	if($post_autoclose = checkautoclose()) {
		showmessage($post_autoclose);
	}

	if($post_invalid = checkpost()) {
		showmessage($post_invalid);
	}

	if(checkflood()) {
		showmessage('post_flood_ctrl');
	}

	if(!empty($_FILES['attach'])) {
		checklowerlimit($creditspolicy['postattach']);
	}

	$attachment = ($allowpostattach && $attachments = attach_upload()) ? 1 : 0;

	$lastnotifytime = $timestamp - 86400;
	$emails = $comma = '';
	$query = $db->query("SELECT email FROM {$tablepre}subscriptions WHERE uid<>'$discuz_uid' AND tid='$tid' AND lastnotify<'$lastnotifytime'");
	while($subs = $db->fetch_array($query)) {
		$emails .= $comma.$subs['email'];
		$comma = ', ';
	}
	if($emails) {
		sendmail($emails, 'email_notify_subject', 'email_notify_message');
		$db->query("UPDATE {$tablepre}subscriptions SET lastnotify=$timestamp WHERE tid='$tid' AND lastnotify<'$lastnotifytime'", 'UNBUFFERED');
	}
	if(!empty($emailnotify) && $discuz_uid) {
		$db->query("INSERT INTO {$tablepre}subscriptions (uid, email, tid)
				VALUES ('$discuz_uid', '$email', '$tid')", 'SILENT');
	}

	$bbcodeoff = checkbbcodes($message, !empty($bbcodeoff));
	$smileyoff = checksmilies($message, !empty($smileyoff));
	$parseurloff = !empty($parseurloff);
	$htmlon = $allowhtml && !empty($htmlon) ? 1 : 0;

	$pinvisible = $modnewreplies ? 2 : 0;
	$db->query("INSERT INTO {$tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, usesig, htmlon, bbcodeoff, smileyoff, parseurloff, attachment)
			VALUES ('$fid', '$tid', '0', '$discuz_user', '$discuz_uid', '$subject', '$timestamp', '$message', '$onlineip', '$pinvisible', '$usesig', '$htmlon', '$bbcodeoff', '$smileyoff', '$parseurloff', '$attachment')");
	$pid = $db->insert_id();

	if($attachment) {
		foreach($attachments as $attach) {
			$db->query("INSERT INTO {$tablepre}attachments (tid, pid, dateline, readperm, filename, description, filetype, filesize, attachment, downloads)
				VALUES ('$tid', '$pid', '$timestamp', '$attach[perm]', '$attach[name]', '$attach[description]', '$attach[type]', '$attach[size]', '$attach[attachment]', '0')");
		}
		updatecredits($discuz_uid, $creditspolicy['postattach'], count($attachments));
	}

	if($modnewreplies) {
		!$allowuseblog || empty($isblog) ? showmessage('post_reply_mod_succeed', "forumdisplay.php?fid=$fid") :
			showmessage('post_reply_mod_blog_succeed', "blog.php?tid=$tid&starttime=$starttime&endtime=$endtime&page=$page");
	} else {
		$db->query("UPDATE {$tablepre}threads SET lastposter='$discuz_user', lastpost='$timestamp', replies=replies+1 ".($attachment ? ', attachment=\'1\'' : '')." WHERE tid='$tid' AND fid='$fid'", 'UNBUFFERED');

		updatepostcredits('+', $discuz_uid, $replycredits);

		$lastpost = "$thread[tid]\t".addslashes($thread['subject'])."\t$timestamp\t$discuz_user";
		$db->query("UPDATE {$tablepre}forums SET lastpost='$lastpost', posts=posts+1, todayposts=".todayposts()." WHERE fid='$fid'", 'UNBUFFERED');
		if($forum['type'] == 'sub') {
			$db->query("UPDATE {$tablepre}forums SET lastpost='$lastpost' WHERE fid='$forum[fup]'", 'UNBUFFERED');
		}

		!$allowuseblog || empty($isblog) ? showmessage('post_reply_succeed', "viewthread.php?tid=$tid&pid=$pid&page=".(@ceil(($thread['replies'] + 2) / $ppp))."&extra=$extra#pid$pid") :
			showmessage('post_reply_blog_succeed', "blog.php?tid=$tid&starttime=$starttime&endtime=$endtime&page=".(@ceil(($thread['replies'] + 1) / $ppp))."#bottom");
	}

}

?>