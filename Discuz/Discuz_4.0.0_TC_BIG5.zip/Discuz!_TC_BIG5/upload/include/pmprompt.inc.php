<?php

/*
	[DISCUZ!] include/pmprompt.inc.php - pm prompting
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005/10/11 10:49
*/

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

if($ignorepm == 'yes') {

	$db->query("UPDATE {$tablepre}pms SET new='2' WHERE msgtoid='$discuz_uid' AND folder='inbox' AND new='1'");
	$db->query("UPDATE {$tablepre}members SET newpm='0' WHERE uid='$discuz_uid'");

} else {

	if($maxpmnum == 0) {

		$query = $db->query("DELETE FROM {$tablepre}pms WHERE msgtoid='$discuz_uid' AND folder='inbox'", 'UNBUFFERED');
		$db->query("UPDATE {$tablepre}members SET newpm='0' WHERE uid='$discuz_uid'");

	} else {

		$newpmexists = 0;
		$pmlist = array();

		$query = $db->query("SELECT pmid, msgfrom, msgfromid, subject, message FROM {$tablepre}pms WHERE msgtoid='$discuz_uid' AND folder='inbox' AND new='1'");
		$newpmnum = $db->num_rows($query);
		if($newpmnum) {
			$newpmexists = 1;
			if($newpmnum <= 10) {
				$pmdetail = '';
				while($pm = $db->fetch_array($query)) {
					$pm['subject'] = cutstr($pm['subject'], 20);
					$pm['message'] = dhtmlspecialchars(cutstr($pm['message'], 70));
					$pmlist[] = $pm;
				}
			}
			$ignorelink = $PHP_SELF.'?ignorepm=yes';
			foreach($_GET as $key => $val) {
				$ignorelink .= '&'.dhtmlspecialchars($key).'='.@rawurlencode($val);
			}
		} else {
			$db->query("UPDATE {$tablepre}members SET newpm='0' WHERE uid='$discuz_uid'");
		}

	}

}

?>