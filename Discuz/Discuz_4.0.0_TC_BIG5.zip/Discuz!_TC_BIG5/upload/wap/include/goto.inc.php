<?php

/*
	[DISCUZ!] wap/include/goto.inc.php - wap forwarding
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005-2-28 10:15
*/

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

$discuz_action = 194;

echo "<p>$lang[goto]:</p>\n".
	"<p><input title=\"url\" name=\"url\" type=\"text\" value=\"http://\" /></p>\n".
	"<p><anchor title=\"$lang[submit]\">$lang[submit]<go href=\"index.php?action=goto&amp;url=$(url:escape)\" /></anchor></p>\n";

?>