<?php

/*
	[DISCUZ!] wap/include/global.func.php - global functions of wap version
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005-2-28 10:15
*/

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

function wapheader($title) {
	global $action, $_SERVER;
	header("Content-type: text/vnd.wap.wml; charset=utf-8");
	/*
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	*/
	echo "<?xml version=\"1.0\"?>\n".
		"<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n".
		"<wml>\n".
		"<head>\n".
		"<meta http-equiv=\"cache-control\" content=\"max-age=180,private\" />\n".
		"</head>\n".
		"<card id=\"discuz_wml\" title=\"$title\">\n";
		// newcontext=\"true\"
}

function wapfooter() {
	global $discuz_uid, $discuz_user, $lang;
	echo "<p align=\"center\"><br /><a href=\"index.php\">$lang[home]</a><br />\n".
		($discuz_uid ? "<a href=\"index.php?action=login&amp;logout=yes\">$discuz_user:$lang[logout]</a>" : "<a href=\"index.php?action=login\">$lang[login]</a>")."<br /><br />\n".
		"<small>Powered by Discuz!</small></p>\n".
		//"<do type=\"prev\" label=\"$lang[return]\"><exit /></do>\n".
		"</card>\n".
		"</wml>";

	updatesession();
	wmloutput();
}

function wapmsg($message, $forward = array()) {
	extract($GLOBALS, EXTR_SKIP);
	if(isset($lang[$message])) {
		eval("\$message = \"".$lang[$message]."\";");
	}
	echo "<p align=\"center\">$message".
		($forward ? "<br /><a href=\"$forward[link]\">".(isset($lang[$forward['title']]) ? $lang[$forward['title']] : $forward['title'])."</a>" : '').
		"</p>\n";

	wapfooter();
	exit();
}

function wapcutstr($string, &$length) {
	$strcut = '';
	if(strlen($string) > $length) {
		for($i = 0; $i < $length - 3; $i++) {
			$strcut .= ord($string[$i]) > 127 ? $string[$i].$string[++$i] : $string[$i];
		}
		$length = $i;
		return $strcut.' ..';
	} else {
		return $string;
	}
}


function wmloutput() {
	global $sid, $charset, $wapcharset;
	$content = preg_replace("/\<a(\s*[^\>]+\s*)href\=([\"|\']?)([^\"\'\s]+)/ies", "transsid('\\3','<a\\1href=\\2',1)", ob_get_contents());
	ob_end_clean();

	if($charset != 'utf-8') {
		if($wapcharset == 1) {
			$chs = new Chinese($charset, 'UTF8');
			echo $chs->Convert($content);
		} else {
			$chs = new Chinese($charset, 'UNICODE');
			echo str_replace('&#x;', '??', $chs->Convert($content));
		}
	} else {
		echo $content;
	}
}



?>