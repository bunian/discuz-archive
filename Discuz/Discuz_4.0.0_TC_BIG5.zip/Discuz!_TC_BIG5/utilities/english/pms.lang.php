<?php

// P.M. Pack for Discuz! Version 1.0
// Translated by Crossday

// ATTENTION: Please add slashes(\) before (') and (")

$language = array
(

	'reason_moderate_subject' => '[Discuz!] Your thread has been moderated',
	'reason_moderate_message' => 'This is the automatic message sent by Discuz! system.

[b]The following thread you posted has been {$modaction} by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url].[/b]

[b]Subject:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]Posted on:[/b] {$thread[dateline]}
[b]Forum:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]Reason:[/b] {$reason}

If you have any dissidence, please let me know.',

	'reason_delete_post_subject' => '[Discuz!] Your reply has been moderated',
	'reason_delete_post_message' => 'This is the automatic message sent by Discuz! system.

[b]The following reply you posted has been deleted by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url].[/b]
[quote]{$post[message]}[/quote]

[b]Posted on:[/b] {$post[dateline]}
[b]Forum:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]Reason:[/b] {$reason}

If you have any dissidence, please let me know.',

	'reason_move_subject' => '[Discuz!] Your thread has been moderated',
	'reason_move_message' => 'This is the automatic message sent by Discuz! system.

[b]The following thread you posted has been moved by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url].[/b]

[b]Subject:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]Posted on:[/b] {$thread[dateline]}
[b]Source Forum:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]
[b]Target Forum:[/b] [url={$boardurl}forumdisplay.php?fid={$toforum[fid]}]{$toforum[name]}[/url]
[b]Reason:[/b] {$reason}

If you have any dissidence, please let me know.',

	'rate_reason_subject' => '[Discuz!] Your message has been rated',
	'rate_reason_message' => 'This is the automatic message sent by Discuz! system.

[b]The following message you posted has been rated by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url].[/b]
[quote]{$post[message]}[/quote]

[b]Posted on:[/b] {$post[dateline]}
[b]Forum:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]
[b]Thread:[/b] [url={$boardurl}viewthread.php?tid={$tid}&page={$page}#pid{$pid}]{$thread[subject]}[/url]

[b]Score:[/b] {$ratescore}
[b]Reason:[/b] {$reason}',

	'transfer_subject' => '[Discuz!] You have got credits',
	'transfer_message' => 'This is the automatic message sent by Discuz! system.

[b]This email confirms that some one has sent you credits.[/b]

[b]From:[/b] [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url]
[b]Credits:[/b] {$extcredits[$creditsexchange][title]} {$amount} {$extcredits[$creditsexchange][unit]}
[b]Time:[/b] {$transfertime}

[b]Note:[/b] {$transfermessage}

You can [url={$boardurl}memcp.php?action=credits&operation=creditslog]click here[/url] to view the details of the transaction log.',

	'reportpost_subject'	=> '[Discuz!] Report post to you from {$discuz_user} ...',
	'reportpost_message'	=> '[i]{$discuz_user}[/i] has reported the following post to you, please visit:
[url]{$posturl}[/url]

His/Her reasons are: {$reason}',

	'addfunds_subject' => '[Discuz!] You have added funds successfully',
	'addfunds_message' => 'This is the automatic message sent by Discuz! system.

[b]Your request of adding funds to your credits account has been done.[/b]

[b]Order ID::[/b] {$order[orderid]}
[b]Submit Time:[/b] {$submitdate}
[b]Confirm Time:[/b] {$confirmdate}

[b]Payout:[/b] RMB {$order[price]} yuan
[b]Income:[/b] {$extcredits[$creditstrans][title]} {$order[amount]} {$extcredits[$creditstrans][unit]}

You can [url={$boardurl}memcp.php?action=credits&operation=creditslog]click here[/url] to view the details of the transaction log.',

);

?>