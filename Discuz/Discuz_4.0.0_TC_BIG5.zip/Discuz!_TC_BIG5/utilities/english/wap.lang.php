<?php

// Message Pack for Discuz! WAP Version 1.0.0
// Created by Crossday

$lang = array
(

	'username' => 'Username/UID',
	'password' => 'Password',
	'submit' => 'Submit',
	'page' => 'Page No.',
	'reply' => 'Reply',
	'delete' => 'Delete',
	'forum' => 'Forum',
	'thread' => 'Thread',
	'type' => 'Type',
	'subject' => 'Subject',
	'message' => 'Message',
	'next_page' => 'Next Page',
	'next_thread' => 'Next Thread',
	'end' => 'End',
	'unread' => 'UNREAD',
	'sub_forums' => ' Sub Forums',

	'not_loggedin' => 'You are not logged in',
	'wap_disabled' => 'WAP was disabled',
	'board_closed' => 'The board has been closed temporarily',
	'undefined_action' => 'Undefined Action',

	'home' => 'Home',
	'home_online' => 'Online ',
	'home_members' => 'members',
	'home_newpm' => 'new P.M.s',
	'home_forums' => '= Categories =',
	'home_tools' =>  '= Tools =',

	'login' => 'Login',
	'login_succeed' => '{$discuz_user} has logged in successfully',
	'login_strike' => 'Your failed login quota has been used up, please wait 15 minutes before trying again',
	'login_invalid' => 'Invalid username or password, you may have 5 attempts at most. If you don\'t have an account, please visit {$boardurl}register.php to register and try again',
	'logout' => 'Log Out',
	'logout_succeed' => 'You have logged out successfully',

	'forum_thread_sticky' => 'STICKY&gt;',
	'forum_thread_digest' => 'DIGEST&gt;',
	'forum_nopermission' => 'You don\'t have permission to access this forum',
	'forum_nonexistence' => 'Specified forum doesn\'t exist',

	'thread_nopermission' => 'You don\'t have permission to access this thread',
	'thread_nonexistence' => 'Specified thread doesn\'t exist',

	'post_reply' => 'Post Reply',
	'post_new' => 'Post New Thread',
	'post_sm_isnull' => 'You havn\'t enter the subject or message',
	'post_subject_toolang' => 'Subject is more than 80 bytes',
	'post_message_toolang' => 'Message is more than $minpostsize bytes',
	'post_message_tooshort' => 'Message is less than $maxpostsize bytes',
	'post_type_isnull' => 'you havn\'t choose a type for the thread',
	'post_flood_ctrl' => 'You could only post one message every $floodctrl seconds',
	'post_mod_succeed' => 'Your post has been submited to moderation successfully',
	'post_mod_forward' => 'Back to the forum',
	'post_thread_closed' => 'The thread has been closed',
	'post_thread_closed_by_dateline' => 'The thread posted before $forum[autoclose] days<br />has been closed automatically',
	'post_thread_closed_by_lastpost' => 'The thread latelely replied before $forum[autoclose] days<br />has been closed automatically',
	'post_newbie_span' => 'You could not post until $newbiespan hours after registration',
	'post_hide_nopermission' => 'You don\'t have permission to posting with [hide] code',
	'post_newthread_nopermission' => 'You don\'t have permission to post in this forum',
	'post_newthread_succeed' => 'The thread has been posted successfully',
	'post_newthread_forward' => 'Go to the thread',
	'post_newreply_nopermission' => 'You don\'t have permission to post reply in this forum',
	'post_newreply_succeed' => 'The reply has been posted successfully',
	'post_newreply_forward' => 'Go to the post',

	'pm' => 'P.M.',
	'pm_home' => 'P.M. Home',
	'pm_unread' => 'Unread Messages',
	'pm_all' => 'All Messages',
	'pm_send' => 'Send Message',
	'pm_to' => 'To',
	'pm_flood_ctrl' => 'You could only send one message every $floodctrl seconds',

	'pm_sm_isnull' => 'You havn\'t enter the subject or message',
	'pm_nonexistence' => 'Specified P.M. doesn\'t exist',
	'pm_send_nonexistence' => 'Invalid recipient username',
	'pm_send_ignore' => 'Message was rejected by recipient',
	'pm_send_succeed' => 'The message has been processed',
	'pm_delete_succeed' => 'The message has been deleted',

	'stats' => 'Statistics',
	'stats_threads' => 'Threads',
	'stats_posts' => 'Posts',
	'stats_members' => 'Members',

	'myphone' => 'My Mobile',
	'goto' => 'WAP Forwarding',


);

?>