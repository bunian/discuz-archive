<?php

$dlang = array
(
	'nextpage' => '下一页',
	'date' => '前,天,昨天,前天,小时,半,分钟,秒,刚才'
);

?>