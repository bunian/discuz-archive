<?php

/*
	[DISCUZ!] utilities/restore.php - Discuz! database importing utilities
	This is NOT a freeware, use is subject to license terms

	Version: 2.0.1
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/9/10 10:05
*/


error_reporting(7);
@set_time_limit(1000);
ob_implicit_flush();

define('IN_DISCUZ', TRUE);

require './config.inc.php';
require './include/db_'.$database.'.class.php';

$db = new dbstuff;
$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
$db->select_db($dbname);

if(!get_cfg_var('register_globals')) {
	@extract($HTTP_GET_VARS);
}

$sqldump = '';

echo "<HTML><HEAD></HEAD><BODY STYLE=\"font-family: Tahoma, Verdana, 細明體; font-size: 11px\"><b>數據庫恢復實用工具 RESTORE for Discuz!</b><br><br>".
	"本程序用於恢復用 Discuz! 備份的數據文件,當 Discuz! 出現問題無法運行和恢複數據,<br>".
	"而 phpMyAdmin 又不能恢復大文件時,可嘗試使用此工具.<br><br>".
	"版權所有(C) 康盛創想(北京)科技有限公司, 2002, 2003, 2004<br><br>".
	"注意:<br><br>".
	"<b>本程序需放於 Discuz! 目錄中才能使用<br><br>".
	"只能恢復存放在服務器(遠程或本地)上的數據文件,如果您的數據不在服務器上,請用 FTP 上傳<br><br>".
	"數據文件必須為 Discuz! 導出格式,並設置相應屬性使 PHP 能夠讀取<br><br>".
	"請盡量選擇服務器空閒時段操作,以避免超時.如程序長久(超過 10 分鐘)不反應,請刷新</b><br><br>";

if($file) {
	if(strtolower(substr($file, 0, 7)) == "http://") {
		echo "從遠程數據庫恢複數據 - 讀取遠程數據:<br><br>";
		echo "從遠程服務器讀取文件 ... ";

		$sqldump = @fread($fp, 99999999);
		@fclose($fp);
		if($sqldump) {
			echo "成功<br><br>";
		} elseif(!$multivol) {
			exit("失敗<br><br><b>無法恢複數據</b>");
		}
	} else {
		echo "從本地恢複數據 - 檢查數據文件:<br><br>";
		if(file_exists($file)) {
			echo "數據文件 $file 存在檢查 ... 成功<br><br>";
		} elseif(!$multivol) {
			exit("數據文件 $file 存在檢查 ... 失敗<br><br><br><b>無法恢複數據</b>");
		}

		if(is_readable($file)) {
			echo "數據文件 $file 可讀檢查 ... 成功<br><br>";
			@$fp = fopen($file, "r");
			@flock($fp, 3);
			$sqldump = @fread($fp, filesize($file));
			@fclose($fp);
			echo "從本地讀取數據 ... 成功<br><br>";
		} elseif(!$multivol) {
			exit("數據文件 $file 可讀檢查 ... 失敗<br><br><br><b>無法恢複數據</b>");
		}
	}

	if($multivol && !$sqldump) {
		exit("分卷備份範圍檢查 ... 成功<br><br><b>恭喜您,數據已經全部成功恢復!安全起見,請務必刪除本程序.</b>");
	}

	echo "數據文件 $file 格式檢查 ... ";
	@list(,,,$method, $volume) = explode(',', base64_decode(preg_replace("/^# Identify:\s*(\w+).*/s", "\\1", preg_replace("/^(.+)/", "\\1", substr($sqldump, 0, 256)))));
	if($method == 'multivol' && is_numeric($volume)) {
		echo "成功<br><br>";
	} else {
		exit("失敗<br><br><b>數據非 Discuz! 分卷備份格式,無法恢復</b>");
	}

	if($onlysave == "yes") {
		echo "將數據文件保存到本地服務器 ... ";
		$filename = "./forumdata".strrchr($file, "/");
		@$filehandle = fopen($filename, "w");
		@flock($filehandle, 3);
		if(@fwrite($filehandle, $sqldump)) {
			@fclose($filehandle);
			echo "成功<br><br>";
		} else {
			@fclose($filehandle);
			die("失敗<br><br><b>無法保存數據</b>");
		}
		echo "成功<br><br><b>恭喜您,數據已經成功保存到本地服務器 <a href=\"".strstr($filename, "/")."\">$filename</a>.安全起見,請務必刪除本程序.</b>";
	} else {
		$sqlquery = splitsql($sqldump);
		echo "拆分操作語句 ... 成功<br><br>";
		unset($sqldump);

		echo "正在恢複數據,請等待 ... <br><br>";
		foreach($sqlquery as $sql) {
			if(trim($sql)) {
				$db->query($sql);
				//echo "$sql<br>";
			}
		}

		$nextfile = str_replace("-$volume.sql", '-'.($volume + 1).'.sql', $file);

		echo "數據文件 <b>$volume#</b> 恢復成功,現在將自動導入其他分卷備份數據.<br><b>請勿關閉瀏覽器或中斷本程序運行</b>";
		redirect("restore.php?file=$nextfile&multivol=yes");
	}
} else {
	echo "參數:<br><br>".
		"<b>file=forumdata/dz_xxx.sql</b> (本地恢復: forumdata/dz_xxx.sql 是本地服務器上數據文件的路徑和名字)<br>".
		"<b>file=http://your.com/discuz/forumdata/dz_xxx.sql</b> (遠程恢復: http://... 是遠程數據文件的路徑和名字)<br><br>".
		"<b>onlysave=yes</b> (只將數據文件轉存到本地服務器,而不恢復到數據庫)<br><br>".
		"用法舉例:<br><br>".
		"<b><a href=\"restore.php?file=forumdata/discuz.sql\">restore.php?file=forumdata/discuz.sql</a></b> (恢復 forumdata 目錄下的 discuz.sql 數據文件)<br>".
		"<b><a href=\"restore.php?file=http://your.com/discuz/forumdata/dz_xxx.sql\">restore.php?file=http://your.com/discuz/forumdata/discuz_xxx.sql</a></b> (恢復 your.com 上的相應數據文件)<br>".
		"<b><a href=\"restore.php?file=http://your.com/discuz/forumdata/dz_xxx.sql&onlysave=yes\">restore.php?file=http://your.com/discuz/forumdata/dz_xxx.sql&onlysave=yes</a></b> (轉存 your.com 上的相應數據文件到本地服務器)<br>".
		"</BODY></HTML>";
}

function splitsql($sql){
	$ret = array();
	$num = 0;
	$queriesarray = explode(";\n", trim($sql));
	unset($sql);
	foreach($queriesarray as $query) {
		$queries = explode("\n", trim($query));
		foreach($queries as $query) {
			$ret[$num] .= $query[0] == "#" ? NULL : $query;
		}
		$num++;
	}
	return($ret);
}

function redirect($url) {
	echo "<script>";
	echo "function redirect() {window.location.replace('$url');}\n";
	echo "setTimeout('redirect();', 2000);\n";
	echo "</script>";
	echo "<br><br><a href=\"$url\">如果您的瀏覽器沒有自動跳轉，請點擊這裡</a>";
}

?>
