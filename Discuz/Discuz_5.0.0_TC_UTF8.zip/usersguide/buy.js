document.write("<li><a href=\"buy_standard.htm\" target=\"_self\">Discuz! 標準型服務</a>");
document.write("<li><a href=\"buy_vip.htm\" target=\"_self\">Discuz! VIP型服務</a>");
document.write("<li><a href=\"buy_enterprise.htm\" target=\"_self\">Discuz! 企業型服務</a>");
document.write("<li><a href=\"buy_assure.htm\" target=\"_self\">有限擔保與免責</a>");