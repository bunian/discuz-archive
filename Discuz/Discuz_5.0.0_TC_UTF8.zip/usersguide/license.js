document.write("<li><a href=\"license.htm\" target=\"_self\">最終用戶授權協議 中文版</a>");
document.write("<li><a href=\"license_english.htm\" target=\"_self\">最終用戶授權協議 英文版</a>");