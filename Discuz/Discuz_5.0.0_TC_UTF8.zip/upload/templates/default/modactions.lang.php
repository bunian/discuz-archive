<?php

// Moderation Pack for Discuz! Version 1.0.0
// Created by Crossday

$modactioncode = array
(

	'EDT' => '編輯',

	'DEL' => '刪除',
	'DLP' => '刪除回復',
	'PRN' => '批量刪帖',
	'UDL' => '反刪除',

	'DIG' => '加入精華',
	'UDG' => '解除精華',
	'EDI' => '限時精華',
	'UED' => '解除限時精華',

	'CLS' => '關閉',
	'OPN' => '打開',
	'ECL' => '限時關閉',
	'UEC' => '解除限時關閉',
	'EOP' => '限時打開',
	'UEO' => '解除限時打開',

	'STK' => '置頂',
	'UST' => '解除置頂',
	'EST' => '限時置頂',
	'UES' => '解除限時置頂',

	'SPL' => '分割',
	'MRG' => '合併',

	'HLT' => '設置高亮',
	'UHL' => '解除高亮',
	'EHL' => '限時高亮',
	'UEH' => '解除限時高亮',

	'BMP' => '提升',

	'MOV' => '移動',
	'CPY' => '複製',
	'TYP' => '分類',

	'RFD' => '強制退款',

	'MOD' => '審核通過',

	'ABL' => '加入文集',
	'RBL' => '移除文集',

	'PTS' => '推送主題',
	'RFS' => '解除推送',
	'RMR' => '取消懸賞'

);

?>