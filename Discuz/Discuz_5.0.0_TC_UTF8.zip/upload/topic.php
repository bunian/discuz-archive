<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: topic.php,v $
	$Revision: 1.7.8.1 $
	$Date: 2007/02/05 15:01:33 $
*/

require_once './include/common.inc.php';

if(empty($keyword)) {
	showmessage('undefined_action');
}

$tpp = intval($tpp);
$page = max(1, intval($page));
$start = ($page - 1) * $tpp;

$site = site();
$length = intval($length);
$stype = empty($stype) ? 0 : 'title';
$relate = in_array($relate, array('score', 'pdate', 'rdate')) ? $relate : 'score';

$keyword = dhtmlspecialchars(stripslashes($keyword));
$topic = $topic ? dhtmlspecialchars(stripslashes($topic)) : $keyword;

include template('topic');

?>