﻿document.write("<br><br><br><br></td></tr><tr><td colspan=\"3\" style=\"padding: 1\">");
document.write("<table cellspacing=\"0\" cellpadding=\"4\" width=\"100%\"><tr bgcolor=\"#F8F8F8\">");
document.write("<td align=\"center\" class=\"smalltxt\"><font color=\"#888888\">Discuz! Board 4.1.0 用戶使用說明書 &nbsp;");
document.write("版權所有 &copy;2001-2006 <a href=\"http://www.comsenz.com\" style=\"color: #888888; text-decoration: none\">");
document.write("北京康盛世紀科技有限公司</a>.</font></td></tr><tr style=\"font-size: 0px; line-height: 0px; spacing: 0px; padding: 0px; background-color: #698CC3\">");
document.write("<td>&nbsp;</td></tr></table></td></tr></table><br><br>");



