﻿<?php

// Moderation Pack for Discuz! Version 1.0.0
// Created by Crossday

$modactioncode = array
(

	'EDT' => 'edited',

	'DEL' => 'deleted',
	'DLP' => 'reply-deleted',
	'PRN' => 'pruned',
	'UDL' => 'undeleted',

	'DIG' => 'added to digest',
	'UDG' => 'removed from digest',
	'EDI' => 'time-limit digest',
	'UED' => 'removeed from time-limit digest',

	'CLS' => 'closed',
	'OPN' => 'opened',
	'ECL' => 'time-limit closing',
	'UEC' => 'removed from time-limit closing',
	'EOP' => 'time-limit opening',
	'UEO' => 'removed from time-limit opening',

	'STK' => 'sticked',
	'UST' => 'un-sticked',
	'EST' => 'time-limit sticky',
	'UES' => 'removed from time-limit sticky',

	'SPL' => 'splited',
	'MRG' => 'merged',

	'HLT' => 'highlighted',
	'UHL' => 'un-highlighted',
	'EHL' => 'time-limit highlight',
	'UEH' => 'removed from time-limit highlight',

	'BMP' => 'bumped',

	'MOV' => 'moved',
	'TYP' => 're-typed',

	'RFD' => 'refunded',

	'MOD' => 'moderated',

	'ABL' => 'added to blog',
	'RBL' => 'removed from blog'

);

?>