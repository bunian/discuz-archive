﻿<?php

// Misc Language Pack for Discuz! Version 1.0.0
// Translated by Crossday

$language = array
(
	'anonymous' => '匿名',

	'post_hidden' => '**** 本內容被作者隱藏 *****',
	'post_hide_credits' => '以下內容積分高於 $creditsrequire 才可瀏覽',
	'post_hide_credits_hidden' => '**** 本內容積分高於 $creditsrequire 才可瀏覽 ****',
	'post_hide_reply' => '以下內容跟帖回復才能看到',
	'post_hide_reply_hidden' => '**** 本內容跟帖回復才可瀏覽 *****',
	'post_banned' => '*** 作者被禁止或刪除 內容自動屏蔽 ***',
	'post_reply_quote' => '原帖由 $thaquote[author] 於 $time 發表',
	'post_edit' => '\n\n[[i] 本帖最後由 $editor 於 $edittime 編輯 [/i]]',
	'post_edit_regexp' => '/\n{2}\[\[i\] 本帖最後由 .*? 於 .*? 編輯 \[\/i\]\]$/s',

	'post_trade_yuan' => '元',
	'post_trade_seller' => '賣家',
	'post_trade_name' => '商品名稱',
	'post_trade_price' => '商品價格',
	'post_trade_quality' => '商品成色',
	'post_trade_locus' => '商品所在地',
	'post_trade_transport' => '物流方式',
	'post_trade_transport_seller' => '賣家承擔郵費',
	'post_trade_transport_buyer' => '買家承擔郵費',
	'post_trade_transport_mail' => '平郵',
	'post_trade_transport_express' => '快遞',
	'post_trade_transport_virtual' => '虛擬物品或無需郵遞',
	'post_trade_description' => '商品描述',

	'attach' => '附件',
	'attach_credits_policy' => '查看積分策略說明',
	'attach_img' => '圖片附件',
	'attach_readperm' => '閱讀權限',
	'attach_img_zoom' => '點擊在新窗口查看全圖\\nCTRL+鼠標滾輪放大或縮小',
	'attach_download_count' => '該附件被下載次數'
	
);

?>