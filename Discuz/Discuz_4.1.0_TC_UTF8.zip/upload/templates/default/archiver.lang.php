﻿<?php

// Message Pack for Discuz! Archiver Version 1.0.0
// Created by Crossday

$lang = array
(

	'page' => '頁',
	'replies' => '篇回復',
	'anonymous' => '匿名',
	'full_version' => '查看完整版本',
	'forum_nonexistence' => '您沒有權限訪問這個論壇的存檔或該論壇不存在。',
	'thread_nonexistence' => '您沒有權限察看這個話題或該話題不存在。',

);

?>