<?php

// Misc Language Pack for Discuz! Version 1.0.0
// Translated by Crossday

$language = array
(
	'anonymous' => 'Anonymous',

	'post_hidden' => '*** The message has been hidden by the author ***',
	'post_hide_credits' => 'Below message is for members whose credits are greater than $creditsrequire',
	'post_hide_credits_hidden' => '*** Hidden to credits lower than $creditsrequire ***',
	'post_hide_reply' => 'Below message is for replyers of this thread',
	'post_hide_reply_hidden' => '*** Hidden to non-reply visitors ***',
	'post_banned' => '*** The author has been banned or deleted ***',
	'post_reply_quote' => 'Originally posted by $thaquote[author] at $time',
	'post_edit' => '\n\n[[i] Last edited by  $editor at $edittime [/i]]',
	'post_edit_regexp' => '/\n{2}\[\[i\] Last edited by .*? at .*? \[\/i\]\]$/s',

	'post_trade_yuan' => 'Yuan',
	'post_trade_seller' => 'Seller',
	'post_trade_name' => 'Item Name',
	'post_trade_price' => 'Item Price',
	'post_trade_quality' => 'Item Quality',
	'post_trade_locus' => 'Item Location',
	'post_trade_transport' => 'Transport',
	'post_trade_transport_seller' => 'Seller will afford the postage.',
	'post_trade_transport_buyer' => 'Buyer will afford the postage.',
	'post_trade_transport_mail' => 'Mail',
	'post_trade_transport_express' => 'Express',
	'post_trade_transport_virtual' => 'Virtual item or no delivery required',
	'post_trade_description' => 'Item Description',

	'attach' => 'Attachment',
	'attach_credits_policy' => 'View credits policy',
	'attach_img' => 'Image Attachment',
	'attach_readperm' => 'Reading Access',
	'attach_img_zoom' => 'Click here to open new windows\\nCTRL+Mouse wheel to zoom in/out',
	'attach_download_count' => 'Download count'
);

?>