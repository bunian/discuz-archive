<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('DISCUZ_VERSION', '7.1');
define('DISCUZ_RELEASE', '20101020');

?>