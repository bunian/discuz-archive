<?php
//-----------------------------------------------------------------------------
//    Discuz! Board 1.0 Standard - Discuz! ������̳ (PHP & MySQL) 1.0 ��׼��
//-----------------------------------------------------------------------------
//    Copyright(C) Dai Zhikang, Crossday Studio, 2002. All rights reserved
//
//    Crossday ������ www.crossday.com    *Discuz! ����֧�� www.Discuz.net
//-----------------------------------------------------------------------------
//  ����ϸ�Ķ� Discuz! ��ȨЭ��,�鿴��ʹ�� Discuz! ���κβ�����ζ����ȫͬ��
//  Э���е�ȫ������,�����֮��֧�ֹ���������ҵ,�Ͻ�һ��Υ��Э�����Ȩ��Ϊ.
//-----------------------------------------------------------------------------
// Discuz! רע���ṩ��Чǿ�����̳�������,��������ҵ��;,�����빺��ʹ����Ȩ!
//-----------------------------------------------------------------------------


error_reporting(7);
set_magic_quotes_runtime(0);
define("IN_CDB", TRUE);

$action = ($HTTP_POST_VARS["action"]) ? $HTTP_POST_VARS["action"] : $HTTP_GET_VARS["action"];
$PHP_SELF = $HTTP_SERVER_VARS["PHP_SELF"];

if (function_exists("set_time_limit") == 1 && @ini_get("safe_mode") == 0) {
	@set_time_limit(1000);
}

@require "./config.php";
require "./functions.php";

header("Content-Type: text/html; charset=$charset");
$version = "1.01";

function loginit($log) {
	$fp = @fopen("./datatemp/illegallog.php");
	@fwrite($fp, "<?PHP exit(\"Access Denied\"); ?>\n");
	@fclose($fp);
}

function process($name) {
	global $tablepre;
	echo"�������ݱ� ".$tablepre.$name." ";
}

function insert($name) {
	global $tablepre;
	echo"���������� ".$tablepre.$name." ";
}

function result($result = 1, $output = 1) {
	if($result) {
		$text = "... <font color=\"#0000EE\">�ɹ�</font><br>";
		if(!$output) {
			return $text;
		}
		echo $text;
	} else {
		$text = "... <font color=\"#FF0000\">ʧ��</font><br>";
		if(!$output) {
			return $text;
		}
		echo $text;
	}
}

function dir_writeable($dir) {
	if(!is_dir($dir)) {
		@mkdir($dir, 0777);
	}
	if(is_dir($dir)) {
		if($fp = @fopen("$dir/test.test", "w")) {
			@fclose($fp);
			@unlink("$dir/test.test");
			$writeable = 1;
		} else {
			$writeable = 0;
		}
	}
	return $writeable;
}

?>
<html>
<head>
<title>Discuz! Installation Wizard</title>
<style>
A:visited	{COLOR: #3A4273; TEXT-DECORATION: none}
A:link		{COLOR: #3A4273; TEXT-DECORATION: none}
A:hover		{COLOR: #3A4273; TEXT-DECORATION: underline}
p		{TEXT-INDENT : 15px}
body,table,td	{COLOR: #3A4273; FONT-FAMILY: Tahoma, Verdana, Arial; FONT-SIZE: 11px; LINE-HEIGHT: 20px; scrollbar-base-color: #E3E3EA; scrollbar-arrow-color: #5C5C8D}
input		{COLOR: #085878; FONT-FAMILY: Tahoma, Verdana, Arial; FONT-SIZE: 12px; background-color: #3A4273; color: #FFFFFF; scrollbar-base-color: #E3E3EA; scrollbar-arrow-color: #5C5C8D}
.install	{FONT-FAMILY: Arial, Verdana; FONT-SIZE: 20px; FONT-WEIGHT: bold; COLOR: #000000}
</style>
</head>

<body bgcolor="#3A4273" text="#000000">
<table width="95%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center">
  <tr>
    <td>
      <table width="98%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td class="install" height="30" valign="bottom"><font color="#FF0000">&gt;&gt;</font> 
            Discuz! Installation Wizard</td>
        </tr>
        <tr>
          <td> 
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td align="center"> 
            <b>��ӭ���� Crossday Discuz! Board ��װ�򵼣���װǰ����ϸ�Ķ� licence ����ÿ��ϸ�ڣ�����ȷ��������ȫ���� Discuz! ����ȨЭ��֮����ܿ�ʼ��װ��readme ���ṩ���й�������װ��˵��������ͬ����ϸ�Ķ����Ա�֤��װ���̵�˳�����С�</b>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
<?

if(!$action) {

?>
        <tr> 
          <td><b>��ǰ״̬��</b><font color="#0000EE">Discuz! �û�����Э��</font></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ���������ϸ�Ķ����������Э��</font></b></td>
        </tr>
        <tr>
          <td><br>
            <table width="90%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr>
                <td bgcolor="#E3E3EA">
                  <table width="99%" cellspacing="1" border="0" align="center">
                    <tr>
                      <td>
��Ȩ���� (c) 2002, Crossday Studio<br>
��������Ȩ��.<br><br>

��л��ѡ�� Discuz! ��̳��Ʒ��ϣ�����ǵ�Ŭ����Ϊ���ṩһ����Ч���ٺ�ǿ��� web ��̳
���������<br><br>

Discuz! Ӣ��ȫ��Ϊ Crossday Discuz! Board������ȫ��Ϊ Discuz! ��̳��<br>
Crossday Studio Ϊʵ������ (http://www.11cn.org) ���� Discuz! ��Ŀ�����Ĺ����ҡ�<br><br>

Discuz! �� Crossday Studio ��������������֧����̳�ٷ���վΪ http://www.Discuz.net��
Crossday Studio �ٷ���վΪ http://www.crossday.com��<br><br>

����ȨЭ�������ҽ������� Discuz! 1.01 �汾��Crossday Studio ӵ�ж��κΰ汾 Discuz!
��ȨЭ�����ȫ�����ս��ͺ��޸�Ȩ��<br><br>

�ڿ�ʼ��װ Discuz! ֮ǰ���������ϸ�Ķ�����Ȩ�ĵ�������ȷ��������ȨЭ���ȫ������
�󣬼��ɼ��� Discuz! ��̳�İ�װ��������һ����ʼ��װ Discuz!��������Ϊ��ȫͬ�Ȿ��
ȨЭ���ȫ�����ݣ�����������⣬���ǽ�����Э���ϵ�����׷����<br><br>

���ڸ����û���������Ŀǰ�汾�� Discuz! Ϊ�����������������ѻ�ñ����򣬲���װ��
�Լ��������ϣ���Ϊ������վ��һ���֣�������֧�����á�������Ҳ����ŵ�Ը����û��ṩ��
����ʽ�ļ���֧�֡�<br><br>

������ҵ�û���������û��� Discuz! ������ҵ���ϣ�Discuz! Ϊ��ҵ������������֧����ҵ
��Ȩ���ã�������ǵ���ʽ��Ȩ�󣬲���ʹ�� Discuz!������һ������ҵ��йص� Discuz!
Ӧ�ã���Ӧ���ڿͻ�������̳����ҵ��Ʒ��̳����ҵ��˾���۰�ȵȶ��ǷǷ��ģ��ؽ��õ���
����׷��������� Discuz! ��Ȩ����ָ����Χ�ڵļ���֧�ַ����й���ҵ��Ȩ�ļ۸񡢸���
��ʽ������֧����Ϣ��Discuz! ����֧����̳�ṩΩһ�Ĺٷ���Ŀ���ͽ��͡�<br><br>

������Σ���������;��Ρ��Ƿ񾭹��޸Ļ�������ֻҪ��ʹ�� Discuz! ���κ�����򲿷֣�
ҳ�Ŵ��� Discuz! ���ƺ� Crossday Studio (http://www.Discuz.net) �����Ӷ����뱣����
����������޸ġ�<br><br>

�����Բ鿴 Discuz! ��ȫ��Դ���룬Ҳ���Ը����Լ�����Ҫ��������޸ģ���ֻҪ Discuz!
������κβ��ֱ����������޸ĺ��ϵͳ�У������޸ĳ̶���Σ������뱣��ҳ�Ŵ��� Discuz!
���ƺ� Crossday Studio �����ӵ�ַ�����޸ĺ�Ĵ��룬��û�л������ (Crossday Studio��
http://www.crossday.com) ����ʽ���ɵ�����£��Ͻ������������ۡ�<br><br>

�����ҽ����ڸ����û���Discuz! �ǿ���Դ����������������ӭ����ԭ����������ȫ����Ȩ
��Ϣ��˵������ǰ���£������ͷ��������򣬵�Υ�����������δ֧����Ȩ���û�δ��������
ʽ���ɶ��� Discuz! ������ҵĿ��ʹ�úʹ������Ǳ���ֹ�ġ�ͬʱ��ӭ�� Discuz! ����Ȥ��
��ʵ�����������˶� Discuz! �Ŀ����ṩ֧�֡�<br><br>

��װ Discuz! ��������ȫͬ�Ȿ��Ȩ�ĵ��Ļ���֮�ϣ���˶������ľ��ף�Υ������ȨЭ��
��һ�����е�ȫ�����Ρ�
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="config">
              <input type="submit" name="submit" value="����ȫͬ��" style="height: 25">&nbsp;
              <input type="button" name="exit" value="�Ҳ���ͬ��" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

} elseif($action == "config") {

	$exist_error = FALSE;
	$write_error = FALSE;
	if(file_exists("./config.php")) {
		$fileexists = result(1, 0);
	} else {
		$fileexists = result(0, 0);
		$exist_error = TRUE;
	}
	if(is_writeable("./config.php")) {
		$filewriteable = result(1, 0);
	} else {
		$filewriteable = result(0, 0);
		$write_error = TRUE;
	}
	if($exist_error) {
		$config_info = "���� config.php ������, �޷�������װ, ���� FTP �����ļ��ϴ�������.";
	} elseif(!$write_error) {
		$config_info = "����������д�������ݿ��˺���Ϣ, ͨ��������벻Ҫ�޸ĺ�ɫѡ������.";
	} elseif($write_error) {
		$config_info = "��װ���޷�д�������ļ�, ��˶�������Ϣ, �����޸�, ��ͨ�� FTP ���ĺõ� config.php �ϴ�.";
	}

?>
        <tr> 
          <td><b>��ǰ״̬��</b><font color="#0000EE">���� config.php</font></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ��������ļ�״̬</font></b></td>
        </tr>
        <tr>
          <td>config.php ���ڼ�� <?=$fileexists?></td>
        </tr>
        <tr>
          <td>config.php ��д��� <?=$filewriteable?></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ���/�༭��ǰ����</font></b></td>
        </tr>
        <tr>
          <td align="center"><br><?=$config_info?></td>
        </tr>
<?

	if(!$exist_error) {

		if(!$write_error) {

			$dbhost = "localhost";
			$dbuser = "dbuser";
			$dbpw = "dbpw";
			$dbname = "dbname";
			$adminemail = "admin@domain.com";
			$tablepre = "cdb_";

			@include "./config.php";

?>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <table width="500" cellspacing="1" bgcolor="#000000" border="0" align="center">
                <tr bgcolor="#3A4273">
                  <td align="center" width="20%" style="color: #FFFFFF">����ѡ��</td>
                  <td align="center" width="35%" style="color: #FFFFFF">��ǰֵ</td>
                  <td align="center" width="45%" style="color: #FFFFFF">ע��</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;���ݿ������:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbhost" value="<?=$dbhost?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;���ݿ��������ַ, һ��Ϊ localhost</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;���ݿ��û���:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbuser" value="<?=$dbuser?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;���ݿ��˺��û���</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;���ݿ�����:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="password" name="dbpw" value="<?=$dbpw?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;���ݿ��˺�����</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;���ݿ���:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbname" value="<?=$dbname?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;���ݿ�����</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;ϵͳ Email:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="adminemail" value="<?=$adminemail?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;���ڷ��ͳ�����󱨸�</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA" style="color: #FF0000">&nbsp;����ǰ׺:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="tablepre" value="<?=$tablepre?>" size="30" onClick="javascript: alert('��װ����ʾ:\n\n��������Ҫ��ͬһ���ݿⰲװ��� CDB\n��̳,����,ǿ�ҽ�������Ҫ�޸ı���ǰ׺.');"></td>
                  <td bgcolor="#E3E3EA">&nbsp;ͬһ���ݿⰲװ����̳ʱʹ��</td>
                </tr>
              </table>
              <br>
              <input type="hidden" name="action" value="environment">
              <input type="hidden" name="saveconfig" value="1">
              <input type="submit" name="submit" value="����������Ϣ" style="height: 25">
              <input type="button" name="exit" value="�˳���װ��" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

		} else {

			@include "./config.php";

?>
        <tr>
          <td>
            <br>
            <table width="60%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr bgcolor="#3A4273">
                <td align="center" style="color: #FFFFFF">����</td>
                <td align="center" style="color: #FFFFFF">��ǰֵ</td>
                <td align="center" style="color: #FFFFFF">ע��</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$dbhost</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbhost?></td>
                <td bgcolor="#E3E3EA" align="center">���ݿ������, һ��Ϊ localhost</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$dbuser</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbuser?></td>
                <td bgcolor="#E3E3EA" align="center">���ݿ��˺�(�û���)</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$dbpw</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbpw?></td>
                <td bgcolor="#E3E3EA" align="center">���ݿ�����</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$dbname</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbname?></td>
                <td bgcolor="#E3E3EA" align="center">���ݿ�����</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$adminemail</td>
                <td bgcolor="#EEEEF6" align="center"><?=$adminemail?></td>
                <td bgcolor="#E3E3EA" align="center">ϵͳ Email</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$tablepre</td>
                <td bgcolor="#EEEEF6" align="center"><?=$tablepre?></td>
                <td bgcolor="#E3E3EA" align="center">���ݱ���ǰ׺</td>
              </tr>
            </table>
            <br>
          </td>
        </tr>
        <tr>
          <td align="center">
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="environment">
              <input type="submit" name="submit" value="����������ȷ" style="height: 25">
              <input type="button" name="exit" value="ˢ���޸Ľ��" style="height: 25" onclick="javascript: window.location=('<?=$PHP_SELF?>?action=config');">
            </form>
          </td>
        </tr>
<?

		}

	} else {

?>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="config">
              <input type="submit" name="submit" value="���¼������" style="height: 25">
              <input type="button" name="exit" value="�˳���װ��" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

	}

} elseif($action == "environment") {

	if($HTTP_POST_VARS["saveconfig"] && is_writeable("./config.php")) {

		$dbhost = $HTTP_POST_VARS["dbhost"];
		$dbuser = $HTTP_POST_VARS["dbuser"];
		$dbpw = $HTTP_POST_VARS["dbpw"];
		$dbname = $HTTP_POST_VARS["dbname"];
		$adminemail = $HTTP_POST_VARS["adminemail"];
		$tablepre = $HTTP_POST_VARS["tablepre"];

		$fp = fopen("./config.php", "r");
		$configfile = fread($fp, filesize("./config.php"));
		fclose($fp);

		$configfile = preg_replace("/[$]dbhost\s*\=\s*\".*?\"/is", "\$dbhost = \"$dbhost\"", $configfile);
		$configfile = preg_replace("/[$]dbuser\s*\=\s*\".*?\"/is", "\$dbuser = \"$dbuser\"", $configfile);
		$configfile = preg_replace("/[$]dbpw\s*\=\s*\".*?\"/is", "\$dbpw = \"$dbpw\"", $configfile);
		$configfile = preg_replace("/[$]dbname\s*\=\s*\".*?\"/is", "\$dbname = \"$dbname\"", $configfile);
		$configfile = preg_replace("/[$]adminemail\s*\=\s*\".*?\"/is", "\$adminemail = \"$adminemail\"", $configfile);
		$configfile = preg_replace("/[$]tablepre\s*\=\s*\".*?\"/is", "\$tablepre = \"$tablepre\"", $configfile);

		$fp = fopen("./config.php", "w");
		fwrite($fp, trim($configfile));
		fclose($fp);

	}

	include "./config.php";
	include "./lib/$database.php";
	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);

	$msg = "";
	$quit = FALSE;

	$curr_os = PHP_OS;

	$curr_php_version = PHP_VERSION;
	if($curr_php_version < "4.0.0") {
		$msg .= "<font color=\"#FF0000\">���� PHP �汾С�� 4.0.0, �޷�ʹ�� Discuz!.</font>\t";
		$quit = TRUE;
	} elseif($curr_php_version < "4.0.6") {
		$msg .= "<font color=\"#FF0000\">���� PHP �汾С�� 4.0.6, �޷�ʹ��ͷ��ߴ���� gzip ѹ������.</font>\t";
	}

	if(@ini_get(file_uploads)) {
		$max_size = @ini_get(upload_max_filesize);
		$curr_upload_status = "����/��� $max_size";
		$msg .= "�������ϴ��ߴ��� $max_size ���µĸ����ļ�.\t";
	} else {
		$curr_upload_status = "�������ϴ�����";
		$msg .= "<font color=\"#FF0000\">���ڷ���������, ���޷�ʹ�ø�������.</font>\t";
	}

	$query = $db->query("SELECT VERSION()");
	$curr_mysql_version = $db->result($query, 0);
	if($curr_mysql_version < "3.23") {
		$msg .= "<font color=\"#FF0000\">���� MySQL �汾���� 3.23, Discuz! ��һЩ���ܿ����޷�����ʹ��.</font>\t";
	}

	$curr_disk_space = intval(diskfreespace(".") / (1024 * 1024))."M";

	if(dir_writeable($attachdir)) {
		$curr_attach_writeable = "��д";
	} else {
		$curr_attach_writeable = "����д";
		$msg .= "<font color=\"#FF0000\">���� $attachdir Ŀ¼���Է� 777 ���޷�д��, �޷�ʹ�ø�������.</font>\t";
	}

	if(dir_writeable("./datatemp")) {
		$curr_data_writeable = "��д";
	} else {
		$curr_data_writeable = "����д";
		$msg .= "<font color=\"#FF0000\">���� (./datatemp) Ŀ¼���Է� 777 ���޷�д��, �޷�ʹ�ñ��ݵ�������/������¼/���ݿ��¼�ȹ���.</font>\t";
	}

	$db->select_db($dbname);
	if($db->error()) {
		$db->query("CREATE DATABASE $dbname");
		if($db->error()) {
			$msg .= "<font color=\"#FF0000\">ָ�������ݿ� $dbname ������, ϵͳҲ�޷��Զ�����, �޷���װ Discuz!.</font>\t";
			$quit = TRUE;
		} else {
			$db->select_db($dbname);
			$msg .= "ָ�������ݿ� $dbname ������, ��ϵͳ�ѳɹ�����, ���Լ�����װ.\t";
		}
	}

	$query - $db->query("SELECT COUNT(*) FROM $tablepre"."settings", 1);
	if(!$db->error()) {
		$msg .= "<font color=\"#FF0000\">���ݿ����Ѿ���װ�� Discuz!, ������װ�����ԭ������.</font>\t";
		$alert = " onSubmit=\"return confirm('������װ�����ȫ��ԭ�����ݣ���ȷ��Ҫ������?');\"";
	} else {
		$alert = "";
	}

	if($quit) {
		$msg .= "<font color=\"#FF0000\">���ڷ���������ԭ��, ���޷���װ��ʹ�� Discuz!, ���˳���װ��.</font>";
	} else {
		$msg .= "���ķ��������԰�װ��ʹ�� Discuz!, �������һ����װ.";
	}
?>
        <tr>
          <td><b>��ǰ״̬��</b><font color="#0000EE">��鵱ǰ����������</font></td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> Discuz! ���軷���͵�ǰ���������öԱ�</font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <table width="80%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr bgcolor="#3A4273">
                <td align="center"></td>
                <td align="center" style="color: #FFFFFF">Discuz! ��������</td>
                <td align="center" style="color: #FFFFFF">Discuz! �������</td>
                <td align="center" style="color: #FFFFFF">��ǰ������</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">����ϵͳ</td>
                <td bgcolor="#EEEEF6" align="center">����</td>
                <td bgcolor="#E3E3EA" align="center">UNIX/Linux/FreeBSD</td>
                <td bgcolor="#E3E3EA" align="center"><?=$curr_os?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">PHP �汾</td>
                <td bgcolor="#EEEEF6" align="center">4.0.0 ����</td>
                <td bgcolor="#E3E3EA" align="center">4.0.6 ����</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_php_version?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">�����ϴ�</td>
                <td bgcolor="#EEEEF6" align="center">����</td>
                <td bgcolor="#E3E3EA" align="center">����</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_upload_status?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">MySQL �汾</td>
                <td bgcolor="#EEEEF6" align="center">3.23 ����</td>
                <td bgcolor="#E3E3EA" align="center">3.23.51</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_mysql_version?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">���̿ռ�</td>
                <td bgcolor="#EEEEF6" align="center">2M ����</td>
                <td bgcolor="#E3E3EA" align="center">50M ����</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_disk_space?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center"><?=$attachdir?> Ŀ¼д��</td>
                <td bgcolor="#EEEEF6" align="center">����</td>
                <td bgcolor="#E3E3EA" align="center">��д</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_attach_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">./datatemp Ŀ¼д��</td>
                <td bgcolor="#EEEEF6" align="center">��д</td>
                <td bgcolor="#E3E3EA" align="center">��д</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_data_writeable?></td>
              </tr>
            </table>
            <br>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ��ȷ������������²���</font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <ol>
              <li>�� Discuz! Ŀ¼��ȫ���ļ���Ŀ¼�ϴ���������.</li>
              <li>�޸ķ������ϵ� config.php �ļ����ʺ���������.</li>
              <li>�����ʹ�÷� WIN32 ϵͳ���޸���������:<br>&nbsp; &nbsp; ./config.php �ļ� 777<br>
              &nbsp; &nbsp; <?=$attachdir?> Ŀ¼ 777;&nbsp; &nbsp; ./datatemp Ŀ¼ 777;<br></li>
              <li>ȷ�� URL �� <?=$attachurl?> ���Է��ʷ�����Ŀ¼ <?=$attachdir?> ����.</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ��װ����ʾ</font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <ol>
<?

	$msgs = explode("\t", $msg);
	unset($msg);
	for($i = 0; $i < count($msgs); $i++) {
		echo "              <li>".$msgs[$i]."</li>\n";
	}
	echo"            </ol>\n";

	if($quit) {

?>
            <center>
            <input type="button" name="refresh" value="���¼������" style="height: 25" onclick="javascript: window.location=('<?=$PHP_SELF?>?action=environment');">&nbsp;
            <input type="button" name="exit" value="�˳���װ��" style="height: 25" onclick="javascript: window.close();">
            </center>
<?

	} else {

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ���ù���Ա�˺�</font></b></td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>"<?=$alert?>>
              <table width="300" cellspacing="1" bgcolor="#000000" border="0" align="center">
                <tr>
                  <td bgcolor="#E3E3EA" width="40%">&nbsp;����Ա�û���:</td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="text" name="username" value="Crossday" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA" width="40%">&nbsp;����Ա Email:</td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="text" name="email" value="name@domain.com" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA" width="40%">&nbsp;����Ա����:</td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="password" name="password1" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA" width="40%">&nbsp;�ظ�����:</td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="password" name="password2" size="30"></td>
                </tr>
              </table>
              <br>
              <input type="hidden" name="action" value="install">
              <input type="submit" name="submit" value="��ʼ��װ Discuz!" style="height: 25" >&nbsp;
              <input type="button" name="exit" value="�˳���װ��" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>

<?

	}	

} elseif($action == "install") {

	$username = $HTTP_POST_VARS["username"];
	$email = $HTTP_POST_VARS["email"];
	$password1 = $HTTP_POST_VARS["password1"];
	$password2 = $HTTP_POST_VARS["password2"];

?>
        <tr>
          <td><b>��ǰ״̬��</b><font color="#0000EE">������Ա�˺���Ϣ����ʼ��װ Discuz!��</font></td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ������Ա�˺�</font></b></td>
        </tr>
        <tr>
          <td>�����Ϣ�Ϸ���
<?

	$msg = "";
	if($username && $email && $password1 && $password2) {
		if($password1 != $password2) {
			$msg = "�����������벻һ��.";
		} elseif(strlen($username) > 25) {
			$msg = "�û������� 25 ���ַ�����.";
		} elseif(preg_match("/^$|^c:\\con\\con$|[\s\t\<\>]|^�ο�/is", $username)) {
			$msg = "�û����ջ�����Ƿ��ַ�.";
		} elseif(!strstr($email, "@") || $email != stripslashes($email) || $email != htmlspecialchars($email)) {
			$msg = "Email ��ַ��Ч";
		}
	} else {
		$msg = "������Ϣû����д����.";
	}

	if($msg) { 

?>
            ... <font color="#FF0000">ʧ��. ԭ��: <?=$msg?></font></td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <input type="button" name="back" value="������һҳ�޸�" onclick="javascript: history.go(-1);">
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td align="center">
            <b>Powered by <a href="http://www.Discuz.net" target="_blank">Discuz! <?=$version?></a> , &nbsp; Copyright &copy; <a href="http://www.crossday.com" target=\"_blank\">Crossday Studio</a>, 2002</b>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>


<?

		exit;
	} else {
		echo result(1, 0)."</td>\n";
		echo"        </tr>\n";
	}

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ѡ�����ݿ�</font></b></td>
        </tr>
<?
	include "./config.php";
	include "./lib/$database.php";
	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
	$db->select_db($dbname);

echo"        <tr>\n";
echo"          <td>ѡ�����ݿ� $dbname ".result(1, 0)."</td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";
echo"            <hr noshade align=\"center\" width=\"100%\" size=\"1\">\n";
echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td><b><font color=\"#FF0000\">&gt;</font><font color=\"#000000\"> �������ݱ��ṹ</font></b></td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";

process("announcements");

	$db->query("DROP TABLE IF EXISTS {$tablepre}announcements", 1);
	$db->query("CREATE TABLE {$tablepre}announcements (
		id smallint(6) unsigned NOT NULL auto_increment,
		author varchar(25) NOT NULL default '',
		subject varchar(250) NOT NULL default '',
		starttime int(10) unsigned NOT NULL default '0',
		endtime int(10) unsigned NOT NULL default '0',
		message text NOT NULL,
		PRIMARY KEY  (id)
	)");

result();

process("attachments");

	$db->query("DROP TABLE IF EXISTS {$tablepre}attachments", 1);
	$db->query("CREATE TABLE {$tablepre}attachments (
		aid mediumint(8) unsigned NOT NULL auto_increment,
		tid mediumint(8) unsigned NOT NULL default '0',
		pid int(10) unsigned NOT NULL default '0',
		creditsrequire smallint(6) unsigned NOT NULL default '0',
		filename varchar(255) NOT NULL default '',
		filetype varchar(50) NOT NULL default '',
		filesize int(12) unsigned NOT NULL default '0',
		attachment varchar(255) NOT NULL default '',
		downloads smallint(6) NOT NULL default '0',
		PRIMARY KEY (aid)
	)");

result();

process("banned");

	$db->query("DROP TABLE IF EXISTS {$tablepre}banned;", 1);
	$db->query("CREATE TABLE {$tablepre}banned (
		id smallint(6) unsigned NOT NULL auto_increment,
		ip1 smallint(3) NOT NULL default '0',
		ip2 smallint(3) NOT NULL default '0',
		ip3 smallint(3) NOT NULL default '0',
		ip4 smallint(3) NOT NULL default '0',
		admin varchar(25) NOT NULL default '',
		dateline int(10) unsigned NOT NULL default '0',
		PRIMARY KEY (id),
		KEY ip1 (ip1),
		KEY ip2 (ip2),
		KEY ip3 (ip3),
		KEY ip4 (ip1)
	)");

result();

process("buddys");

	$db->query("DROP TABLE IF EXISTS {$tablepre}buddys;", 1);
	$db->query("CREATE TABLE {$tablepre}buddys (
		username varchar(25) NOT NULL default '',
		buddyname varchar(25) NOT NULL default ''
	)");

result();

process("caches");

	$db->query("DROP TABLE IF EXISTS {$tablepre}caches;", 1);
	$db->query("CREATE TABLE {$tablepre}caches (
		cachename varchar(20) NOT NULL default '',
		cachevars text NOT NULL,
		KEY cachename (cachename)
	)");

result();

process("favorites");

	$db->query("DROP TABLE IF EXISTS {$tablepre}favorites;", 1);
	$db->query("CREATE TABLE {$tablepre}favorites (
		tid mediumint(8) unsigned NOT NULL default '0',
		username varchar(25) NOT NULL default '',
		KEY tid (tid)
	)");

result();

process("forumlinks");

	$db->query("DROP TABLE IF EXISTS {$tablepre}forumlinks;", 1);
	$db->query("CREATE TABLE {$tablepre}forumlinks (
		id smallint(6) unsigned NOT NULL auto_increment,
		displayorder tinyint(3) NOT NULL default '0',
		name varchar(100) NOT NULL default '',
		url varchar(100) NOT NULL default '',
		note varchar(200) NOT NULL default '',
		logo varchar(100) NOT NULL default '',
		PRIMARY KEY (id)
	)");

result();

process("forums");

	$db->query("DROP TABLE IF EXISTS {$tablepre}forums;", 1);
	$db->query("CREATE TABLE {$tablepre}forums (
		fid smallint(6) unsigned NOT NULL auto_increment,
		fup smallint(6) unsigned NOT NULL default '0',
		type enum('group','forum','sub') NOT NULL default 'forum',
		icon varchar(100) NOT NULL default '',
		name varchar(50) NOT NULL default '',
		description text NOT NULL,
		status tinyint(1) NOT NULL default '0',
		displayorder tinyint(3) NOT NULL default '0',
		moderator tinytext NOT NULL,
		threads smallint(6) unsigned NOT NULL default '0',
		posts mediumint(8) unsigned NOT NULL default '0',
		lastpost varchar(130) NOT NULL default '',
		allowsmilies tinyint(1) NOT NULL default '0',
		allowhtml tinyint(1) NOT NULL default '0',
		allowbbcode tinyint(1) NOT NULL default '0',
		allowimgcode tinyint(1) NOT NULL default '0',
		password varchar(12) NOT NULL default '',
		postcredits tinyint(1) NOT NULL default '-1',
		viewperm tinytext NOT NULL,
		postperm tinytext NOT NULL,
		getattachperm tinytext NOT NULL,
		postattachperm tinytext NOT NULL,
		PRIMARY KEY (fid),
		KEY status (status)
	)");

result();

process("members");

	$db->query("DROP TABLE IF EXISTS {$tablepre}members;", 1);
	$db->query("CREATE TABLE {$tablepre}members (
		uid mediumint(8) unsigned NOT NULL auto_increment,
		username varchar(25) NOT NULL default '',
		password varchar(40) NOT NULL default '',
		gender tinyint(1) NOT NULL default '0',
		status varchar(20) NOT NULL default '',
		regip varchar(20) NOT NULL default '',
		regdate int(10) unsigned NOT NULL default '0',
		lastvisit int(10) unsigned NOT NULL default '0',
		postnum smallint(6) unsigned NOT NULL default '0',
		credit smallint(6) NOT NULL default '0',
		charset varchar(10) NOT NULL default '',
		email varchar(60) NOT NULL default '',
		site varchar(75) NOT NULL default '',
		icq varchar(12) NOT NULL default '',
		oicq varchar(12) NOT NULL default '',
		yahoo varchar(40) NOT NULL default '',
		msn varchar(40) NOT NULL default '',
		location varchar(30) NOT NULL default '',
		bday date NOT NULL default '0000-00-00',
		bio text NOT NULL,
		avatar varchar(100) NOT NULL default '',
		signature text NOT NULL,
		customstatus varchar(20) NOT NULL default '',
		tpp tinyint(3) unsigned NOT NULL default '0',
		ppp tinyint(3) unsigned NOT NULL default '0',
		theme varchar(30) NOT NULL default '',
		dateformat varchar(10) NOT NULL default '',
		timeformat varchar(5) NOT NULL default '',
		showemail tinyint(1) NOT NULL default '0',
		newsletter tinyint(1) NOT NULL default '0',
		timeoffset char(3) NOT NULL default '',
		ignoreu2u text NOT NULL,
		newu2u tinyint(1) NOT NULL default '0',
		pwdrecover varchar(30) NOT NULL default '',
		pwdrcvtime int(10) unsigned NOT NULL default '0',
		PRIMARY KEY (uid),
		KEY username (username)
	)");

result();

process("memo");

	$db->query("DROP TABLE IF EXISTS {$tablepre}memo", 1);
	$db->query("CREATE TABLE {$tablepre}memo (
		id int(10) unsigned NOT NULL auto_increment,
		username varchar(25) NOT NULL default '',
		type enum('address','notebook','collections') NOT NULL default 'address',
		dateline int(10) unsigned NOT NULL default '0',
		var1 varchar(50) NOT NULL default '',
		var2 varchar(100) NOT NULL default '',
		var3 tinytext NOT NULL,
		PRIMARY KEY (id),
		KEY username (username),
		KEY type (type)
	)");

result();

process("news");

	$db->query("DROP TABLE IF EXISTS {$tablepre}news;", 1);
	$db->query("CREATE TABLE {$tablepre}news (
		id smallint(6) unsigned NOT NULL auto_increment,
		subject varchar(100) NOT NULL default '',
		link varchar(100) NOT NULL default '',
		PRIMARY KEY (id)
	)");

result();

process("posts");

	$db->query("DROP TABLE IF EXISTS {$tablepre}posts;", 1);
	$db->query("CREATE TABLE {$tablepre}posts (
		fid smallint(6) unsigned NOT NULL default '0',
		tid mediumint(8) unsigned NOT NULL default '0',
		pid int(10) unsigned NOT NULL auto_increment,
		aid mediumint(8) unsigned NOT NULL default '0',
		icon varchar(30) NOT NULL default '',
		author varchar(25) NOT NULL default '',
		subject varchar(100) NOT NULL default '',
		dateline int(10) unsigned NOT NULL default '0',
		message text NOT NULL,
		useip varchar(20) NOT NULL default '',
		usesig tinyint(1) NOT NULL default '0',
		bbcodeoff tinyint(1) NOT NULL default '0',
		smileyoff tinyint(1) NOT NULL default '0',
		parseurloff tinyint(1) NOT NULL default '0',
		PRIMARY KEY (pid),
		KEY fid (fid),
		KEY tid (tid, dateline)
	)");

result();

process("searchindex");

	$db->query("DROP TABLE IF EXISTS {$tablepre}searchindex;", 1);
	$db->query("CREATE TABLE {$tablepre}searchindex (
		keywords varchar(200) NOT NULL default '',
		num smallint(6) NOT NULL default '0',
		dateline int(10) unsigned NOT NULL default '0',
		KEY dateline (dateline)
	)");

result();

process("sessions");

	$db->query("DROP TABLE IF EXISTS {$tablepre}sessions;", 1);
	$db->query("CREATE TABLE {$tablepre}sessions (
		sid varchar(32) binary NOT NULL default '',
		username varchar(25) NOT NULL default '',
		status varchar(20) NOT NULL default '',
		time int(10) unsigned NOT NULL default '0',
		ip varchar(20) NOT NULL default '',
		fid smallint(6) unsigned NOT NULL default '0',
		action varchar(60) NOT NULL default '',
		sessionvars text NOT NULL,
		KEY sid (sid),
		KEY fid (fid)
	)");

result();

process("settings");

	$db->query("DROP TABLE IF EXISTS {$tablepre}settings;", 1);
	$db->query("CREATE TABLE {$tablepre}settings (
		bbname varchar(50) NOT NULL default '',
		regstatus tinyint(1) NOT NULL default '0',
		censoruser text NOT NULL,
		doublee tinyint(1) NOT NULL default '0',
		emailcheck tinyint(1) NOT NULL default '0',
		bbrules tinyint(1) NOT NULL default '0',
		bbrulestxt text NOT NULL,
		welcommsg tinyint(1) NOT NULL default '0',
		welcommsgtxt text NOT NULL,
		bbclosed tinyint(1) NOT NULL default '0',
		closedreason text NOT NULL,
		sitename varchar(50) NOT NULL default '',
		siteurl varchar(60) NOT NULL default '',
		theme varchar(30) NOT NULL default '',
		credittitle varchar(20) NOT NULL default '',
		creditunit varchar(10) NOT NULL default '',
		moddisplay enum('flat','selectbox') NOT NULL default 'flat',
		floodctrl smallint(6) unsigned NOT NULL default '0',
		karmactrl smallint(6) unsigned NOT NULL default '0',
		hottopic tinyint(3) unsigned NOT NULL default '0',
		topicperpage tinyint(3) unsigned NOT NULL default '0',
		postperpage tinyint(3) unsigned NOT NULL default '0',
		memberperpage tinyint(3) unsigned NOT NULL default '0',
		maxpostsize smallint(6) unsigned NOT NULL default '0',
		maxavatarsize tinyint(3) unsigned NOT NULL default '0',
		smcols tinyint(3) unsigned NOT NULL default '0',
		postcredits tinyint(3) NOT NULL default '0',
		digistcredits tinyint(3) NOT NULL default '0',
		whosonlinestatus tinyint(1) NOT NULL default '0',
		vtonlinestatus tinyint(1) NOT NULL default '0',
		chcode tinyint(1) NOT NULL default '0',
		gzipcompress tinyint(1) NOT NULL default '0',
		hideprivate tinyint(1) NOT NULL default '0',
		fastpost tinyint(1) NOT NULL default '0',
		memliststatus tinyint(1) NOT NULL default '0',
		statstatus tinyint(1) NOT NULL default '0',
		debug tinyint(1) NOT NULL default '0',
		reportpost tinyint(1) NOT NULL default '0',
		bbinsert tinyint(1) NOT NULL default '0',
		smileyinsert tinyint(1) NOT NULL default '0',
		editedby tinyint(1) NOT NULL default '0',
		dotfolders tinyint(1) NOT NULL default '0',
		attachimgpost tinyint(1) NOT NULL default '0',
		timeformat varchar(5) NOT NULL default '',
		dateformat varchar(10) NOT NULL default '',
		timeoffset char(3) NOT NULL default '',
		version varchar(30) NOT NULL default '',
		onlinerecord varchar(30) NOT NULL default '',
		lastmember varchar(25) NOT NULL default ''
	)");

result();

process("smilies");

	$db->query("DROP TABLE IF EXISTS {$tablepre}smilies;", 1);
	$db->query("CREATE TABLE {$tablepre}smilies (
		id smallint(6) unsigned NOT NULL auto_increment,
		type enum('smiley','picon') NOT NULL default 'smiley',
		code varchar(10) NOT NULL default '',
		url varchar(30) NOT NULL default '',
		PRIMARY KEY (id)
	)");

result();

process("stats");

	$db->query("DROP TABLE IF EXISTS {$tablepre}stats;", 1);
	$db->query("CREATE TABLE {$tablepre}stats (
		type varchar(20) NOT NULL default '',
		var varchar(20) NOT NULL default '',
		count int(10) unsigned NOT NULL default '0',
		KEY type (type),
		KEY var (var)
	)");

result();

process("subscriptions");

	$db->query("DROP TABLE IF EXISTS {$tablepre}subscriptions;", 1);
	$db->query("CREATE TABLE {$tablepre}subscriptions (
		username varchar(25) NOT NULL default '',
		email varchar(60) NOT NULL default '',
		tid mediumint(8) unsigned NOT NULL default '0',
		lastnotify int(10) unsigned NOT NULL default '0',
		KEY username (username),
		KEY tid (tid)
	)");

result();

process("templates");

	$db->query("DROP TABLE IF EXISTS {$tablepre}templates;", 1);
	$db->query("CREATE TABLE {$tablepre}templates (
		id smallint(6) NOT NULL auto_increment,
		name varchar(40) NOT NULL default '',
		modified tinyint(1) NOT NULL default '0',
		template text NOT NULL,
		PRIMARY KEY (id)
	)");

result();

process("themes");

	$db->query("DROP TABLE IF EXISTS {$tablepre}themes;", 1);
	$db->query("CREATE TABLE {$tablepre}themes (
		themeid smallint(6) unsigned NOT NULL auto_increment,
		themename varchar(30) NOT NULL default '',
		bgcolor varchar(25) NOT NULL default '',
		altbg1 varchar(15) NOT NULL default '',
		altbg2 varchar(15) NOT NULL default '',
		link varchar(15) NOT NULL default '',
		bordercolor varchar(15) NOT NULL default '',
		headercolor varchar(15) NOT NULL default '',
		headertext varchar(15) NOT NULL default '',
		catcolor varchar(15) NOT NULL default '',
		tabletext varchar(15) NOT NULL default '',
		text varchar(15) NOT NULL default '',
		borderwidth varchar(15) NOT NULL default '',
		tablewidth varchar(15) NOT NULL default '',
		tablespace varchar(15) NOT NULL default '',
		font varchar(40) NOT NULL default '',
		fontsize varchar(40) NOT NULL default '',
		nobold tinyint(1) NOT NULL default '0',
		boardimg varchar(50) NOT NULL default '',
		imgdir varchar(120) NOT NULL default '',
		smdir varchar(120) NOT NULL default '',
		cattext varchar(15) NOT NULL default '',
		PRIMARY KEY  (themeid),
		KEY themename (themename)
	)");

result();

process("threads");

	$db->query("DROP TABLE IF EXISTS {$tablepre}threads;", 1);
	$db->query("CREATE TABLE {$tablepre}threads (
		tid mediumint(8) unsigned NOT NULL auto_increment,
		fid smallint(6) NOT NULL default '0',
		creditsrequire smallint(6) unsigned NOT NULL default '0',
		icon varchar(30) NOT NULL default '',
		author varchar(25) NOT NULL default '',
		subject varchar(100) NOT NULL default '',
		dateline int(10) unsigned NOT NULL default '0',
		lastpost int(10) unsigned NOT NULL default '0',
		lastposter varchar(25) NOT NULL default '',
		views smallint(6) unsigned NOT NULL default '0',
		replies smallint(6) unsigned NOT NULL default '0',
		topped tinyint(1) NOT NULL default '0',
		digist tinyint(1) NOT NULL default '0',
		closed varchar(15) NOT NULL default '',
		pollopts text NOT NULL,
		attachment varchar(50) NOT NULL default '',
		PRIMARY KEY  (tid),
		KEY lastpost (topped,lastpost,fid)
	)");

result();

process("u2u");

	$db->query("DROP TABLE IF EXISTS {$tablepre}u2u;", 1);
	$db->query("CREATE TABLE {$tablepre}u2u (
		u2uid int(10) unsigned NOT NULL auto_increment,
		msgto varchar(25) NOT NULL default '',
		msgfrom varchar(25) NOT NULL default '',
		folder varchar(10) NOT NULL default '',
		new tinyint(1) NOT NULL default '0',
		subject varchar(75) NOT NULL default '',
		dateline int(10) unsigned NOT NULL default '0',
		message text NOT NULL,
		PRIMARY KEY (u2uid),
		KEY msgto (msgto)
	)");

result();

process("usergroups");

	$db->query("DROP TABLE IF EXISTS {$tablepre}usergroups;", 1);
	$db->query("CREATE TABLE {$tablepre}usergroups (
		groupid smallint(6) unsigned NOT NULL auto_increment,
		specifiedusers text NOT NULL,
		status varchar(20) NOT NULL default '',
		grouptitle varchar(30) NOT NULL default '',
		creditshigher int(10) NOT NULL default '0',
		creditslower int(10) NOT NULL default '0',
		stars tinyint(3) NOT NULL default '0',
		groupavatar varchar(60) NOT NULL default '',
		allowcstatus tinyint(1) NOT NULL default '0',
		allowavatar tinyint(1) NOT NULL default '0',
		allowvisit tinyint(1) NOT NULL default '0',
		allowview tinyint(1) NOT NULL default '0',
		allowpost tinyint(1) NOT NULL default '0',
		allowpostpoll tinyint(1) NOT NULL default '0',
		allowgetattach tinyint(1) NOT NULL default '0',
		allowpostattach tinyint(1) NOT NULL default '0',
		allowvote tinyint(1) NOT NULL default '0',
		allowsearch tinyint(1) NOT NULL default '0',
		allowkarma tinyint(1) NOT NULL default '0',
		allowsetviewperm tinyint(1) NOT NULL default '0',
		allowsetattachperm tinyint(1) NOT NULL default '0',
		allowsigbbcode tinyint(1) NOT NULL default '0',
		allowsigimgcode tinyint(1) NOT NULL default '0',
		allowviewstats tinyint(1) NOT NULL default '0',
		ismoderator tinyint(1) NOT NULL default '0',
		issupermod tinyint(1) NOT NULL default '0',
		isadmin tinyint(1) NOT NULL default '0',
		maxu2unum smallint(6) unsigned NOT NULL default '0',
		maxmemonum smallint(6) unsigned NOT NULL default '0',
		maxsigsize smallint(6) unsigned NOT NULL default '0',
		maxkarmavote tinyint(3) unsigned NOT NULL default '0',
		maxattachsize mediumint(8) unsigned NOT NULL default '0',
		attachextensions tinytext NOT NULL,
		PRIMARY KEY (groupid),
		KEY status (status),
		KEY creditshigher (creditshigher),
		KEY creditslower (creditslower)
	)");

result();

process("words");

	$db->query("DROP TABLE IF EXISTS {$tablepre}words;", 1);
	$db->query("CREATE TABLE {$tablepre}words (
		id smallint(6) unsigned NOT NULL auto_increment,
		find varchar(60) NOT NULL default '',
		replacement varchar(60) NOT NULL default '',
		PRIMARY KEY (id)
	)");

result();

echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";
echo"            <hr noshade align=\"center\" width=\"100%\" size=\"1\">\n";
echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td><b><font color=\"#FF0000\">&gt;</font><font color=\"#000000\"> ��������</font></b></td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";

insert("caches");

	$db->query("INSERT INTO {$tablepre}caches VALUES ('settings', 'a:43:{s:6:\"bbname\";s:13:\"Discuz! Board\";s:9:\"regstatus\";s:1:\"1\";s:8:\"bbclosed\";s:1:\"0\";s:12:\"closedreason\";s:0:\"\";s:8:\"sitename\";s:15:\"Crossday Studio\";s:7:\"siteurl\";s:24:\"http://www.crossday.com/\";s:5:\"theme\";s:8:\"��׼����\";s:11:\"credittitle\";s:4:\"����\";s:10:\"creditunit\";s:2:\"��\";s:10:\"moddisplay\";s:4:\"flat\";s:9:\"floodctrl\";s:2:\"15\";s:9:\"karmactrl\";s:3:\"300\";s:8:\"hottopic\";s:2:\"10\";s:12:\"topicperpage\";s:2:\"20\";s:11:\"postperpage\";s:2:\"10\";s:13:\"memberperpage\";s:2:\"25\";s:11:\"maxpostsize\";s:5:\"10000\";s:13:\"maxavatarsize\";s:1:\"0\";s:6:\"smcols\";s:1:\"3\";s:16:\"whosonlinestatus\";s:1:\"1\";s:14:\"vtonlinestatus\";s:1:\"1\";s:6:\"chcode\";s:1:\"0\";s:12:\"gzipcompress\";s:1:\"1\";s:11:\"postcredits\";s:1:\"1\";s:13:\"digistcredits\";s:2:\"10\";s:11:\"hideprivate\";s:1:\"1\";s:10:\"emailcheck\";s:1:\"0\";s:8:\"fastpost\";s:1:\"1\";s:13:\"memliststatus\";s:1:\"1\";s:10:\"statstatus\";s:1:\"0\";s:5:\"debug\";s:1:\"1\";s:10:\"reportpost\";s:1:\"1\";s:8:\"bbinsert\";s:1:\"1\";s:12:\"smileyinsert\";s:1:\"1\";s:8:\"editedby\";s:1:\"1\";s:10:\"dotfolders\";s:1:\"0\";s:13:\"attachimgpost\";s:1:\"1\";s:10:\"timeformat\";s:5:\"h:i A\";s:10:\"dateformat\";s:5:\"Y-n-j\";s:10:\"timeoffset\";s:1:\"8\";s:7:\"version\";s:4:\"1.01\";s:12:\"onlinerecord\";s:0:\"\";s:10:\"lastmember\";s:".strlen($username).":\"$username\";}');");
	$db->query("INSERT INTO {$tablepre}caches VALUES ('usergroups', 'a:17:{i:0;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:10:\"��̳����Ա\";s:10:\"grouptitle\";s:10:\"��̳����Ա\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"9\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"1\";}i:1;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��������\";s:10:\"grouptitle\";s:8:\"��������\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"8\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"1\";}i:2;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:4:\"����\";s:10:\"grouptitle\";s:4:\"����\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"7\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"1\";}i:3;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"������ؤ\";s:13:\"creditshigher\";s:8:\"-9999999\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"0\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"0\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:4;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"�ȴ���֤\";s:10:\"grouptitle\";s:12:\"�ȴ���֤��Ա\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"0\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"0\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:5;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:4:\"�ο�\";s:10:\"grouptitle\";s:4:\"�ο�\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"0\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"0\";s:14:\"allowsigbbcode\";s:1:\"0\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:6;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ֹ����\";s:10:\"grouptitle\";s:14:\"�û�����ֹ����\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"0\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"0\";s:14:\"allowsigbbcode\";s:1:\"0\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:7;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:6:\"��ֹIP\";s:10:\"grouptitle\";s:12:\"�û�IP����ֹ\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"0\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"0\";s:14:\"allowsigbbcode\";s:1:\"0\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:8;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ֹ����\";s:10:\"grouptitle\";s:14:\"�û�����ֹ����\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:1:\"0\";s:5:\"stars\";s:1:\"0\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"0\";s:14:\"allowsigbbcode\";s:1:\"0\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:9;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"������·\";s:13:\"creditshigher\";s:1:\"0\";s:12:\"creditslower\";s:2:\"10\";s:5:\"stars\";s:1:\"1\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"0\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:10;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"������Ա\";s:13:\"creditshigher\";s:2:\"10\";s:12:\"creditslower\";s:2:\"50\";s:5:\"stars\";s:1:\"2\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:11;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"�߼���Ա\";s:13:\"creditshigher\";s:2:\"50\";s:12:\"creditslower\";s:3:\"150\";s:5:\"stars\";s:1:\"3\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:12;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"֧����Ա\";s:13:\"creditshigher\";s:3:\"150\";s:12:\"creditslower\";s:3:\"300\";s:5:\"stars\";s:1:\"4\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:13;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"��ͭ����\";s:13:\"creditshigher\";s:3:\"300\";s:12:\"creditslower\";s:3:\"600\";s:5:\"stars\";s:1:\"5\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:14;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"�ƽ���\";s:13:\"creditshigher\";s:3:\"600\";s:12:\"creditslower\";s:4:\"1000\";s:5:\"stars\";s:1:\"6\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"0\";}i:15;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"�׽���\";s:13:\"creditshigher\";s:4:\"1000\";s:12:\"creditslower\";s:4:\"3000\";s:5:\"stars\";s:1:\"7\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"1\";}i:16;a:10:{s:14:\"specifiedusers\";s:0:\"\";s:6:\"status\";s:8:\"��ʽ��Ա\";s:10:\"grouptitle\";s:8:\"��վԪ��\";s:13:\"creditshigher\";s:4:\"3000\";s:12:\"creditslower\";s:7:\"9999999\";s:5:\"stars\";s:1:\"8\";s:11:\"groupavatar\";s:0:\"\";s:11:\"allowavatar\";s:1:\"1\";s:14:\"allowsigbbcode\";s:1:\"1\";s:15:\"allowsigimgcode\";s:1:\"1\";}}');");
	$db->query("INSERT INTO {$tablepre}caches VALUES ('announcements', 'a:0:{}');");
	$db->query("INSERT INTO {$tablepre}caches VALUES ('forums', 'a:1:{i:1;a:4:{s:4:\"type\";s:5:\"forum\";s:4:\"name\";s:8:\"Ĭ�ϰ��\";s:3:\"fup\";s:1:\"0\";s:8:\"viewperm\";s:0:\"\";}}');");
	$db->query("INSERT INTO {$tablepre}caches VALUES ('forumlinks', 'a:1:{i:0;a:6:{s:2:\"id\";s:1:\"2\";s:12:\"displayorder\";s:1:\"0\";s:4:\"name\";s:13:\"Discuz! Board\";s:3:\"url\";s:21:\"http://www.Discuz.net\";s:4:\"note\";s:91:\"��վ��̳���� Discuz! �Ĺٷ�վ�㣬ר������ Discuz! ��ʹ���� Hack���ṩ��̳�����뼼��֧�ֵȡ�\";s:4:\"logo\";s:15:\"images/logo.gif\";}}');");
	$db->query("INSERT INTO {$tablepre}caches VALUES ('smilies', 'a:9:{i:0;a:4:{s:2:\"id\";s:2:\"19\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:2:\":)\";s:3:\"url\";s:9:\"smile.gif\";}i:1;a:4:{s:2:\"id\";s:2:\"20\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:2:\":(\";s:3:\"url\";s:7:\"sad.gif\";}i:2;a:4:{s:2:\"id\";s:2:\"21\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:2:\":D\";s:3:\"url\";s:11:\"biggrin.gif\";}i:3;a:4:{s:2:\"id\";s:2:\"22\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:2:\";)\";s:3:\"url\";s:8:\"wink.gif\";}i:4;a:4:{s:2:\"id\";s:2:\"23\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:6:\":cool:\";s:3:\"url\";s:8:\"cool.gif\";}i:5;a:4:{s:2:\"id\";s:2:\"24\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:5:\":mad:\";s:3:\"url\";s:7:\"mad.gif\";}i:6;a:4:{s:2:\"id\";s:2:\"25\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:2:\":o\";s:3:\"url\";s:11:\"shocked.gif\";}i:7;a:4:{s:2:\"id\";s:2:\"26\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:2:\":P\";s:3:\"url\";s:10:\"tongue.gif\";}i:8;a:4:{s:2:\"id\";s:2:\"27\";s:4:\"type\";s:6:\"smiley\";s:4:\"code\";s:5:\":lol:\";s:3:\"url\";s:7:\"lol.gif\";}}');");
	$db->query("INSERT INTO {$tablepre}caches VALUES ('picons', 'a:9:{i:0;a:4:{s:2:\"id\";s:2:\"28\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon1.gif\";}i:1;a:4:{s:2:\"id\";s:2:\"29\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon2.gif\";}i:2;a:4:{s:2:\"id\";s:2:\"30\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon3.gif\";}i:3;a:4:{s:2:\"id\";s:2:\"31\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon4.gif\";}i:4;a:4:{s:2:\"id\";s:2:\"32\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon5.gif\";}i:5;a:4:{s:2:\"id\";s:2:\"33\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon6.gif\";}i:6;a:4:{s:2:\"id\";s:2:\"34\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon7.gif\";}i:7;a:4:{s:2:\"id\";s:2:\"35\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon8.gif\";}i:8;a:4:{s:2:\"id\";s:2:\"36\";s:4:\"type\";s:5:\"picon\";s:4:\"code\";s:0:\"\";s:3:\"url\";s:9:\"icon9.gif\";}}');");
	$db->query("INSERT INTO {$tablepre}caches VALUES ('censor', 'a:2:{s:7:\"replace\";a:0:{}s:4:\"find\";a:0:{}}');");
	$db->query("INSERT INTO {$tablepre}caches VALUES ('news', 'a:4:{i:0;a:3:{s:2:\"id\";s:1:\"1\";s:7:\"subject\";s:59:\"����������� Discuz! ����֧����̳�����ǻᾡ�����������⡣\";s:4:\"link\";s:22:\"http://www.Discuz!.net\";}i:1;a:3:{s:2:\"id\";s:1:\"2\";s:7:\"subject\";s:44:\"���ǻ᲻�����Ƴ���Ҳϣ���õ����ļ���֧�֡�\";s:4:\"link\";s:25:\"http://forum.crossday.com\";}i:2;a:3:{s:2:\"id\";s:1:\"3\";s:7:\"subject\";s:44:\"Crossday Studio �����ʺã���ӭ��ѡ�� Discuz!\";s:4:\"link\";s:0:\"\";}i:3;a:3:{s:2:\"id\";s:1:\"4\";s:7:\"subject\";s:32:\"��ӭ���ǵ��»�Ա {\$lastmember}��\";s:4:\"link\";s:48:\"member.php?action=viewpro&username=\$encodemember\";}}');");

result();

insert("forumlinks");

	$db->query("INSERT INTO {$tablepre}forumlinks VALUES (1, 0, 'Discuz! Board', 'http://www.Discuz.net', '��վ��̳���� Discuz! �Ĺٷ�վ�㣬ר������ Discuz! ��ʹ���� Hack���ṩ��̳�����뼼��֧�ֵȡ�', 'images/logo.gif')");

result();

insert("forums");

	$db->query("INSERT INTO {$tablepre}forums VALUES (1, 0, 'forum', '', 'Ĭ�ϰ��', '', 1, 0, '', 0, 0, '', 1, 0, 1, 1, '', 0, '', '', '', '');");

result();

insert("members");

	$db->query("INSERT INTO {$tablepre}members (username, password, status, regip, regdate, charset, email, tpp, ppp, dateformat, timeformat, showemail, newsletter, timeoffset)
		VALUES ('$username', '".encrypt($password1)."', '��̳����Ա', 'hidden', '".time()."', '$charset', '$email', '20', '10', 'Y-n-j', 'h:i A', '1', '1', '8');");

result();

insert("news");

	$db->query("INSERT INTO {$tablepre}news (subject, link) VALUES ('����������� Discuz! ����֧����̳�����ǻᾡ�����������⡣', 'http://www.Discuz.net');");
	$db->query("INSERT INTO {$tablepre}news (subject, link) VALUES ('���ǻ᲻�����Ƴ���Ҳϣ���õ����ļ���֧�֡�', 'http://www.Discuz.net');");
	$db->query("INSERT INTO {$tablepre}news (subject, link) VALUES ('Crossday Studio �����ʺã���ӭ��ѡ�� Discuz!', '');");
	$db->query("INSERT INTO {$tablepre}news (subject, link) VALUES ('��ӭ���ǵ��»�Ա {\$lastmember}��', 'member.php?action=viewpro&username=\$encodemember');");

result();

insert("templates");

	$tplfile = "./templates.cdb";
	if(is_readable($tplfile)) {
		$db->query("DELETE FROM {$tablepre}templates");
		$fp = fopen($tplfile, "r");
		$templates = explode("|#*CDB TEMPLATE FILE*#|", fread($fp, filesize($tplfile)));
		fclose($fp);

		ksort($templates);
		foreach($templates as $template) {
			$template = explode("|#*CDB TEMPLATE*#|", $template);
			if($template[0] && $template[1]) {
				$db->query("INSERT INTO {$tablepre}templates (name, template)
					VALUES ('".addslashes($template[0])."', '".addslashes(addslashes(trim($template[1])))."')");
			}
		}
	} else {
		echo " ... <font color=\"#FF0000\">ʧ��. ԭ��: ģ���ļ�������.</font>";
		exit;
	}

result();

insert("settings");

	$db->query("INSERT INTO {$tablepre}settings VALUES ('Discuz! Board', 1, '', 1, 0, 0, '', 0, '', 0, '', 'Crossday Studio', 'http://www.crossday.com/', '��׼����', '����', '��', 'flat', 15, 300, 10, 20, 10, 25, 10000, 0, 3, 1, 10, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 'h:i A', 'Y-n-j', '8', '1.01', '', '$username');");

result();

insert("smilies");

	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ':)', 'smile.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ':(', 'sad.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ':D', 'biggrin.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ';)', 'wink.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ':cool:', 'cool.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ':mad:', 'mad.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ':o', 'shocked.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ':P', 'tongue.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'smiley', ':lol:', 'lol.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon1.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon2.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon3.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon4.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon5.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon6.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon7.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon8.gif');");
	$db->query("INSERT INTO {$tablepre}smilies VALUES ('', 'picon', '', 'icon9.gif');");

result();

insert("stats");

	$db->query("INSERT INTO {$tablepre}stats VALUES ('total', 'hits', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('total', 'members', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('total', 'guests', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'Windows', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'Mac', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'Linux', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'FreeBSD', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'SunOS', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'BeOS', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'OS/2', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'AIX', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('os', 'Other', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('browser', 'MSIE', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('browser', 'Netscape', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('browser', 'Mozilla', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('browser', 'Lynx', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('browser', 'Opera', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('browser', 'Konqueror', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('browser', 'Other', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('week', '0', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('week', '1', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('week', '2', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('week', '3', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('week', '4', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('week', '5', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('week', '6', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '00', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '01', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '02', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '03', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '04', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '05', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '06', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '07', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '08', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '09', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '10', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '11', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '12', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '13', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '14', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '15', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '16', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '17', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '18', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '19', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '20', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '21', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '22', 0);");
	$db->query("INSERT INTO {$tablepre}stats VALUES ('hour', '23', 0);");

result();

insert("themes");

	$db->query("INSERT INTO {$tablepre}themes VALUES ('', '��׼����', '#FFFFFF', '#E3E3EA', '#EEEEF6', '#3A4273', '#000000', 'header_bg.gif', '#F1F3FB', 'cat_bg.gif', '#464F86', '#464F86', '1', '99%', '3', 'Tahoma, Verdana', '12px', 0, 'logo.gif', 'images/standard', 'images/smilies', '#D9D9E9');");

result();

insert("stats");

	$db->query("INSERT INTO {$tablepre}usergroups VALUES (1, '', '��̳����Ա', '��̳����Ա', 0, 0, 9, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 100, 100, 500, 16, 2048000, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (2, '', '��������', '��������', 0, 0, 8, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 90, 60, 300, 12, 2048000, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (3, '', '����', '����', 0, 0, 7, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 80, 40, 200, 10, 2048000, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (4, '', '��ʽ��Ա', '������ؤ', -9999999, 0, 0, '', 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (5, '', '��ʽ��Ա', '������·', 0, 10, 1, '', 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 30, 3, 50, 0, 0, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (6, '', '��ʽ��Ա', '������Ա', 10, 50, 2, '', 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 40, 5, 50, 0, 128000, 'gif,jpg,png');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (7, '', '��ʽ��Ա', '�߼���Ա', 50, 150, 3, '', 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 50, 10, 100, 2, 256000, 'gif,jpg,png');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (8, '', '��ʽ��Ա', '֧����Ա', 150, 300, 4, '', 1, 21, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 50, 15, 100, 3, 512000, 'zip,rar,chm,txt,gif,jpg,png');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (9, '', '��ʽ��Ա', '��ͭ����', 300, 600, 5, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 50, 20, 100, 4, 1024000, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (10, '', '��ʽ��Ա', '�ƽ���', 600, 1000, 6, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 50, 25, 100, 5, 1024000, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (11, '', '��ʽ��Ա', '�׽���', 1000, 3000, 7, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 50, 30, 100, 6, 2048000, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (12, '', '��ʽ��Ա', '��վԪ��', 3000, 9999999, 8, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 50, 40, 100, 8, 2048000, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (13, '', '�ȴ���֤', '�ȴ���֤��Ա', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 10, 0, 50, 0, 0, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (14, '', '�ο�', '�ο�', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (15, '', '��ֹ����', '�û�����ֹ����', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (16, '', '��ֹIP', '�û�IP����ֹ', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');");
	$db->query("INSERT INTO {$tablepre}usergroups VALUES (17, '', '��ֹ����', '�û�����ֹ����', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, '');");

result();

loginit("karmalog");
loginit("illegallog");
loginit("modslog");
loginit("cplog");

?>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td align="center">
            <font color="#FF0000"><b>��ϲ����Discuz! ��װ�ɹ���</font><br>
            ����Ա�˺ţ�</b><?=$username?><b> ���룺</b><?=$password1?><br><br>
            <a href="index.php" target="_blank">������������̳</a>
          </td>
        </tr>
<?

}

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td align="center">
            <b>Powered by <a href="http://www.Discuz.net" target="_blank">Discuz! <?=$version?></a> , &nbsp; Copyright &copy; <a href="http://www.crossday.com" target=\"_blank\">Crossday Studio</a>, 2002</b>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>

