<?php
//-----------------------------------------------------------------------------
//    Discuz! Board 1.0 Standard - Discuz! ������̳ (PHP & MySQL) 1.0 ��׼��
//-----------------------------------------------------------------------------
//    Copyright(C) Dai Zhikang, Crossday Studio, 2002. All rights reserved
//
//    Crossday ������ www.crossday.com    *Discuz! ����֧�� www.Discuz.net
//-----------------------------------------------------------------------------
//  ����ϸ�Ķ� Discuz! ��ȨЭ��,�鿴��ʹ�� Discuz! ���κβ�����ζ����ȫͬ��
//  Э���е�ȫ������,�����֮��֧�ֹ���������ҵ,�Ͻ�һ��Υ��Э�����Ȩ��Ϊ.
//-----------------------------------------------------------------------------
// Discuz! רע���ṩ��Чǿ�����̳�������,��������ҵ��;,�����빺��ʹ����Ȩ!
//-----------------------------------------------------------------------------


require "./header.php";
$tplnames = "css,header,footer";

if($action == "reg") {
	$cdbaction = "ע��";
	$useraction = "ע���Ϊ�»�Ա";
} elseif($action == "login") {
	$cdbaction = "��¼";
	$useraction = "��¼������̳";
} elseif($action == "logout") {
	$cdbaction = "�˳�";
	$useraction = "�˳���̳��¼";
} elseif($action == "online") {
	$cdbaction = "�����û�";
	$useraction = "�鿴�����û�";
} elseif($action == "list") {
	$cdbaction = "��Ա�б�";
	$useraction = "�鿴��Ա�б�";
} elseif($action == "viewpro") {
	$cdbaction = "�鿴��������";
	$useraction = "�鿴 $member ���û�����";
}

$navigation = "&raquo; $cdbaction";
$navtitle .= " - $cdbaction";

if($loginsubmit) {
	$referer = $referer ? $referer : "index.php";
	$errorlog = "$username\t".substr($password, 0, 2);
	for($i = 3; $i < strlen($password); $i++) {
		$errorlog .= "*";
	}
	$errorlog .= substr($password, -1)."\t$onlineip\t$timestamp\n";
	$password = encrypt($password);
	$query = $db->query("SELECT m.username as cdbuser, m.password as cdbpw, m.uid, m.charset, m.timeoffset, m.theme, m.tpp, m.ppp, m.credit,
		m.timeformat, m.dateformat, m.signature, m.avatar, m.lastvisit, m.newu2u, u.*, u.specifiedusers LIKE '%\t$username\t%' AS specifieduser
		FROM $table_members m LEFT JOIN $table_usergroups u ON u.specifiedusers LIKE '%\t$username\t%' OR (u.status=m.status
		AND ((u.creditshigher='0' AND u.creditslower='0' AND u.specifiedusers='') OR (m.credit>=u.creditshigher AND m.credit<u.creditslower)))
		WHERE username='$username' AND password='$password' ORDER BY specifieduser DESC");
	$member = $db->fetch_array($query);

	if($bbclosed && !$member[isadmin]) {
		showmessage($closedreason ? $closedreason : "����̳��ʱ�رա�");
	}

	if(!$member[uid]) {
		@$fp = fopen("./datatemp/illegallog.php", "a");
		@flock($fp, 3);
		@fwrite($fp, $errorlog);
		@fclose($fp);
		showmessage("�û�����Ч������������ڽ����ο�����ת��ԭҳ�档", $referer);
	} else {
		$member[signature] = $member[signature] ? 1 : 0;
		$CDB_SESSION_VARS = array_merge($CDB_SESSION_VARS, $member);
		$CDB_SESSION_VARS[theme] = $member[theme] ? $member[theme] : $CDB_CACHE_VARS[settings][theme];
		$CDB_SESSION_VARS[themename] = $style ? $style : "";

		$currtime = $timestamp + (86400 * 365);
		setcookie("cookietime", $cookie_time, $currtime, $cookiepath, $cookiedomain);
		$currtime = cookietime();
		$username = $CDB_SESSION_VARS[cdbuser];
		$CDB_SESSION_VARS[cdbuser] = addslashes($CDB_SESSION_VARS[cdbuser]);
		setcookie("_cdbuser", $CDB_SESSION_VARS[cdbuser], $currtime, $cookiepath, $cookiedomain);
		setcookie("_cdbpw", $CDB_SESSION_VARS[cdbpw], $currtime, $cookiepath, $cookiedomain);

		showmessage("��ӭ��������{$username}�����ڽ�ת���¼ǰҳ�档", $referer);
	}
}

if($action == "reg") {

	if(!$regstatus) {
		showmessage("�Բ���Ŀǰ��̳������ע�����û����뷵�ء�");
	}

	$query = $db->query("SELECT censoruser, doublee, bbrules, bbrulestxt, welcommsg, welcommsgtxt FROM $table_settings");
	extract($db->fetch_array($query), EXTR_OVERWRITE);

	$query = $db->query("SELECT allowcstatus, allowavatar FROM $table_usergroups WHERE creditshigher<=0 AND 0<creditslower");
	$groupinfo = $db->fetch_array($query);

	if(!$regsubmit) {

		preloader("member_reg,member_reg_avatar,member_reg_avatarlist,member_reg_changecode,member_reg_password");

		if($bbrules && !$rulesubmit) {
			$bbrulestxt = nl2br("\n$bbrulestxt\n\n");
			eval("\$page = \"".template("member_reg_rules")."\";");
			echo $page;
		} else {
			$themelist = "<select name=\"thememem\">\n<option value=\"\">--ʹ��Ĭ��ֵ--</option>";
			$query = $db->query("SELECT themename FROM $table_themes");
			while($themeinfo = $db->fetch_array($query)) {
				$themelist .= "<option value=\"$themeinfo[themename]\">$themeinfo[themename]</option>\n";
			}
			$themelist .= "</select>";

			$dayselect = "<select name=\"day\">\n";
			$dayselect .= "<option value=\"\">&nbsp;</option>\n";
			for($num = 1; $num <= 31; $num++) {
				$dayselect .= "<option value=\"$num\">$num</option>\n";
			}
			$dayselect .= "</select>";

			if($maxsigsize) {
				$allowmaxsigsize = " ($maxsigsize �ַ�����)";
			}

			$bbcodeis = $allowsigbbcode ? "On" : "Off";
			$imgcodeis = $allowsigimgcode ? "On" : "Off";
			$cdb_charset == "big5" ? $bigcheck = "selected=\"selected\"" : $gbcheck = "selected=\"selected\"";
			$currdate = gmdate($timeformat);

			$dateformatorig = $dateformat;
			$dateformatorig = str_replace("n", "mm", $dateformatorig);
			$dateformatorig = str_replace("j", "dd", $dateformatorig);
			$dateformatorig = str_replace("y", "yy", $dateformatorig);
			$dateformatorig = str_replace("Y", "yyyy", $dateformatorig);

			if($groupinfo[allowcstatus]) {
				eval("\$customstatus = \"".template("member_reg_cstatus")."\";");
			}

			if($groupinfo[allowavatar] == 1) {
				eval("\$avatarselect = \"".template("member_reg_avatarlist")."\";");
			} elseif($groupinfo[allowavatar] == 2) {
				eval("\$avatarselect = \"".template("member_reg_avatar")."\";");
			}

			if(!$emailcheck){
				eval("\$pwtd = \"".template("member_reg_password")."\";");
			}

			if($chcode){
				eval("\$changecode = \"".template("member_reg_changecode")."\";");
			}

			eval("\$page = \"".template("member_reg")."\";");
			echo $page;
		}

	} else {

		$referer = $referer ? $referer : "index.php";

		$email = trim($email);
		if(!$doublee && strstr($email, "@")) {
			$emailadd = "OR email='$email'";
		}

		$username = trim($username);

		$query = $db->query("SELECT COUNT(*) FROM $table_members WHERE username='$username' $emailadd");
		if($db->result($query, 0)) {
			showmessage("���û����� Email ��ַ�Ѿ���ע���ˣ��뷵��������д��");
		}

		if(strlen($username) > 15) {
			showmessage("�Բ��������û������� 15 ���ַ����뷵������һ���϶̵��û�����");
		}

		if($password != $password2) {
			showmessage("������������벻һ�£��뷵�ؼ������ԡ�");
		}

		if(@eregi(str_replace(",", "|", "^(".str_replace(" ", "", addslashes($censoruser)).")$"), $username)) {
			showmessage("�û�����ϵͳ���Σ��뷵��������д��");
		}

		if(preg_match("/^$|^c:\\con\\con$|��|[,\"\s\t\<\>]|^�ο�/is", $username)) {
			showmessage("�û����ջ���������ַ����뷵��������д��");
		}

		if(!$emailcheck && (!$password || $password != addslashes($password))) {
			showmessage("����ջ�����Ƿ��ַ����뷵��������д��");
		}

		if(!strstr($email, "@") || $email != addslashes($email) || $email != htmlspecialchars($email)) {
			showmessage("Email ��ַ��Ч���뷵��������д��");
		}

		if($maxsigsize && strlen($sig) > $maxsigsize) {
			showmessage("����ǩ�����ȳ��� $maxsigsize �ַ������ƣ��뷵���޸ġ�");
		}

		if($allowavatar == 2 && $avatar) {
			if($maxavatarsize) {
				if(strstr($avatar, ",")) {
					$avatarinfo = explode(",", $avatar);
					if(trim($avatarinfo[1]) > $maxavatarsize || trim($avatarinfo[2]) > $maxavatarsize) {
						showmessage("�����õ� Flash ͷ�񳬹���ϵͳ����Ŀ� $maxavatarsize ���أ��� $maxavatarsize ���أ��뷵��������д��");
					}
				} elseif($image_size = @getimagesize($avatar)) {
					if($image_size[0] > $maxavatarsize || $image_size[1] > $maxavatarsize) {
						showmessage("�����Զ���ͷ�񳬹���ϵͳ����Ŀ� $maxavatarsize ���أ��� $maxavatarsize ���أ��뷵��������д��");
					}
				}
			}
		} else {
			$avatar = "";
		}

		if($emailcheck){
			$password2 = random(8);
			$password = encrypt($password2);
		} else {
			$password = encrypt($password);
		}

		if(!$groupinfo[allowcstatus]) {
			$cstatus = "";
		}

		if(!$tppnew) {
			$tppnew = $topicperpage;
		}

		if(!$pppnew) {
			$pppnew = $postperpage;
		}

		if(!$chcode || !$usercharset) {
			$usercharset = $cdb_charset;
		}

		$bday = "$year-$month-$day";

		if($month == "" || $day == "" || $year == "") {
			$bday = "";
		}

		$dateformatnew = str_replace("mm", "n", $dateformatnew);
		$dateformatnew = str_replace("dd", "j", $dateformatnew);
		$dateformatnew = str_replace("yyyy", "Y", $dateformatnew);
		$dateformatnew = str_replace("yy", "y", $dateformatnew);
		$timeformatnew = $timeformatnew == "24" ? "H:i" : "h:i A";

		$avatar = cdbhtmlspecialchars($avatar);
		$locationnew = cdbhtmlspecialchars($locationnew);
		$icq = cdbhtmlspecialchars($icq);
		$yahoo = cdbhtmlspecialchars($yahoo);
		$oicq = cdbhtmlspecialchars($oicq);
		$email = cdbhtmlspecialchars($email);
		$site = cdbhtmlspecialchars($site);
		$bio = cdbhtmlspecialchars($bio);
		$bday = cdbhtmlspecialchars($bday);
		$cstatus = cdbhtmlspecialchars($cstatus);

		if($welcommsg) {
			$welcomtitle = "��ӭ����Ϊ $bbname ��һԱ��";
			if(!trim($welcommsgtxt)) {
				$welcommsgtxt = "���ã���л�������ǵ���̳ע�ᣬ��Ϊ $bbname ��һ���ӣ�ϣ��������Ϊ���ṩһ����г����Ǣ�Ľ���������\n\nףԸ���� $bbname �и������飡\n\n==============\n$bbname ����Ա����";
			}
			$welcomtitle = addslashes($welcomtitle);
			$welcommsgtxt = addslashes($welcommsgtxt);
			$db->query("INSERT INTO $table_u2u (msgto, msgfrom, folder, new, subject, dateline, message)
				VALUES ('$username', 'ϵͳ��Ϣ', 'inbox', '1', '$welcomtitle', '$timestamp','$welcommsgtxt')");
		}
		//$status = $emailcheck ? "�ȴ���֤" : "��ʽ��Ա";
		$db->query("INSERT INTO $table_members (username, password, gender, status, regip, regdate, lastvisit, postnum, credit, charset, email, site, icq, oicq, yahoo, msn, location, bday, bio, avatar, signature, customstatus, tpp, ppp, theme, dateformat, timeformat, showemail, newsletter, timeoffset)
			VALUES ('$username', '$password', '$gendernew', '��ʽ��Ա', '$onlineip', '$timestamp', '$timestamp', '0', '0', '$usercharset', '$email', '$site', '$icq', '$oicq', '$yahoo', '$msn', '$locationnew', '$bday', '$bio', '$avatar', '$sig', '$cstatus', '$tppnew', '$pppnew', '$thememem', '$dateformatnew', '$timeformatnew', '$showemail', '$newsletter', '$timeoffsetnew')");
		$db->query("UPDATE $table_settings SET lastmember='$username'");
		updatecache("settings");

		if($emailcheck){

			sendmail($email, "[Discuz!] �����˺��Ѿ���ͨ",
					"���� $bbname [ $boardurl ] �������ѱ����ܣ������������ϵ�¼��\n\n".
					"�û�����$username\n���룺$password2\n\n�����Ե�¼���޸Ĵ����롣\n".
					"�ǳ���л�������ǵ�������֧�֣���ӭ������ {$bbname}��",
				"From: $bbname <$adminemail>");
			showmessage("�ʼ��Ѿ����ͣ������ʼ��е��˺���Ϣ��¼��");

		} else {
			$query = $db->query("SELECT m.username as cdbuser, m.password as cdbpw, m.uid, m.charset, m.timeoffset, m.theme, m.tpp, m.ppp, m.credit,
				m.timeformat, m.dateformat, m.signature, m.avatar, m.lastvisit, m.newu2u, u.*, u.specifiedusers LIKE '%\t$username\t%' AS specifieduser
				FROM $table_members m LEFT JOIN $table_usergroups u ON u.specifiedusers LIKE '%\t$username\t%' OR (u.status=m.status
				AND ((u.creditshigher='0' AND u.creditslower='0' AND u.specifiedusers='') OR (m.credit>=u.creditshigher AND m.credit<u.creditslower)))
				WHERE username='$username' AND password='$password' ORDER BY specifieduser DESC");
			$member = $db->fetch_array($query);
			$member[signature] = $member[signature] ? 1 : 0;
			$CDB_SESSION_VARS = array_merge($CDB_SESSION_VARS, $member);
			$CDB_SESSION_VARS[theme] = $member[theme] ? $member[theme] : $CDB_CACHE_VARS[settings][theme];
			$CDB_SESSION_VARS[themename] = "";
			$CDB_SESSION_VARS[cdbuser] = addslashes($CDB_SESSION_VARS[cdbuser]);

			$cookietime = 2592001;
			setcookie("cookietime", "$cookietime", $timestamp + (86400 * 365), $cookiepath, $cookiedomain);
			$currtime = cookietime();
			setcookie("_cdbuser", $username, $currtime, $cookiepath, $cookiedomain);
			setcookie("_cdbpw", $password, $currtime, $cookiepath, $cookiedomain);

			showmessage("�ǳ���л����ע�ᣬ���ڽ��Ի�Ա���ݵ�¼��̳��", $referer);
		}
	}

} elseif($action == "logout") {

	$currtime = $timestamp - (86400 * 365);
	setcookie("_cdbuser", "", $currtime, $cookiepath, $cookiedomain);
	setcookie("_cdbpw", "", $currtime, $cookiepath, $cookiedomain);
	$sessionexists = -1;

	showmessage("�����˳���̳�����ڽ����ο�����ת���˳�ǰҳ�档", $referer ? $referer : "index.php");

} elseif($action == "login" && !$loginsubmit) {

	preloader("member_login");

	$themelist = "<select name=\"style\">\n<option value=\"\">--ʹ��Ĭ��ֵ--</option>";
	$query = $db->query("SELECT themename FROM $table_themes");
	while($themeinfo = $db->fetch_array($query)) {
		$themelist .= "<option value=\"$themeinfo[themename]\">$themeinfo[themename]</option>\n";
	}
	$themelist .= "</select>";

	if($cookietime == "31536000") {
		$year_checked = "checked";
	} elseif($cookietime == "86400") {
		$day_checked = "checked";
	} elseif($cookietime == "3600") {
		$hour_checked = "checked";
	} elseif($cookietime == " ") {
		$task_checked = "checked";
	} else {
		$month_checked = "checked";
	}

	eval("\$login = \"".template("member_login")."\";");
	echo $login;

} elseif($action == "online") {

	preloader($isadmin ? "member_online_row_admin,member_online_admin" : "member_online_row,member_online");

	$query = $db->query("SELECT s.*, f.name FROM $table_sessions s LEFT JOIN $table_forums f ON s.fid=f.fid ORDER BY time DESC");
	while($online = $db->fetch_array($query)){

		$online[time] = gmdate("$timeformat", $online[time] + ($timeoffset * 3600));
		$online[username] = $online[username] ? "<a href=\"member.php?action=viewpro&username=".rawurlencode($online[username])."\">$online[username]</a>" : "�ο�";
		$online[location] = "<a href=\"$online[location]\">$online[location]</a>";
		$online[forum] = $online[fid] ? "<a href=\"forumdisplay.php?fid=$online[fid]\">$online[name]</a>" : NULL;

		if($isadmin) {
			eval("\$onlinemembers .= \"".template("member_online_row_admin")."\";");
			eval("\$whosonline = \"".template("member_online_admin")."\";");
		} else {
			eval("\$onlinemembers .= \"".template("member_online_row")."\";");
			eval("\$whosonline = \"".template("member_online")."\";");
		}
	}
	echo $whosonline;

} elseif($action == "list") {

	if(!$memliststatus) {
		showmessage("�Բ���Ŀǰ����ʹ�û�Ա�б����ܡ�");
	}

	preloader("member_list_row_email,member_list_row_site,member_list_row,member_list");

	if(!$order || ($order != "regdate" && $order != "username" && $order != "credit")) {
		$order = "regdate";
	}

	$mpurl = "member.php?action=list&order=$order";
	if($desc) {
		$mpurl .= "&desc=$desc";
	}

	if($page) {
		$start_limit = ($page-1) * $memberperpage;
	}
	else {
		$start_limit = 0;
		$page = 1;
	}
	if(!$srchmem) {
		$query = $db->query("SELECT COUNT(*) FROM $table_members");
	} else {
		$query = $db->query("SELECT COUNT(*) FROM $table_members WHERE BINARY username LIKE '%$srchmem%' OR username='$srchmem'");
	}
	$num = $db->result($query,0);
	$multipage = multi($num, $memberperpage, $page, $mpurl);

	$order = $order == "username" ? "BINARY username" : $order;
	if(!$srchmem) {
		$querymem = $db->query("SELECT * FROM $table_members ORDER BY $order $desc LIMIT $start_limit, $memberperpage");
	} else {
		$querymem = $db->query("SELECT * FROM $table_members WHERE BINARY username LIKE '%$srchmem%' OR username='$srchmem' ORDER BY $order $desc LIMIT $start_limit, $memberperpage");
	}

	if($forumleaders == "010101") { 
		$querymem = $db->query("SELECT * FROM $table_members WHERE status = '��̳����Ա' OR status = '��������' OR status = '����' ORDER BY BINARY status DESC"); 
	}

	while ($member = $db->fetch_array($querymem)) {

		$member[regdate] = date("$dateformat", $member[regdate]);

		if($member[gender] == 1) {
			$member[gender] = "��";
		} elseif($member[gender] == 2) {
			$member[gender] = "Ů";
		} else {
			$member[gender] = "";
		}

		if($member[email] && $member[showemail]) {
			eval("\$email = \"".template("member_list_row_email")."\";");
		} else {
			$email = "&nbsp;";
		}

		$member[site] = str_replace("http://", "", $member[site]);
		$member[site] = "http://$member[site]";
		$member[site] == "http://" ? $site = "&nbsp;" : eval("\$site = \"".template("member_list_row_site")."\";");
		$member[location] = $member[location] ? $member[location] : "&nbsp;";

		$memurl = rawurlencode($member[username]);
		$member[lastvisit] = gmdate("$dateformat $timeformat", $member[lastvisit] + ($timeoffset * 3600));
		eval("\$members .= \"".template("member_list_row")."\";");
	}
	eval("\$memlist = \"".template("member_list")."\";");
	echo $memlist;

} elseif($action == "viewpro") {

	$query = $db->query("SELECT *, u.specifiedusers LIKE '%\t$username\t%' AS specifieduser FROM $table_members m
		LEFT JOIN $table_usergroups u ON u.specifiedusers LIKE '%\t$username\t%' OR (u.status=m.status AND
		((u.creditshigher='0' AND u.creditslower='0' AND u.specifiedusers='') OR (m.credit>=u.creditshigher
		AND m.credit<u.creditslower))) WHERE username='$username' ORDER BY specifieduser DESC");
	$memberinfo = $db->fetch_array($query);

	if(!$username) {
		showmessage("��û��ѡ���û�����");
	} elseif(!$memberinfo) {
		showmessage("��ָ�����û������ڡ�");
	} else {
		preloader("member_viewpro_email,member_viewpro_regip,member_viewpro");

		$member = $memberinfo[username];
		$daysreg = ($timestamp - $memberinfo[regdate]) / (24 * 3600);
		$ppd = $memberinfo[postnum] / $daysreg;
		$ppd = round($ppd, 2);

		$memberinfo[regdate] = gmdate("$dateformat",$memberinfo[regdate]);
		$memberinfo[site] = str_replace("http://", "", $memberinfo[site]);
		$memberinfo[site] = "http://$memberinfo[site]";
		$memberinfo[site] = $memberinfo[site] != "http://" ? "$memberinfo[site]" : NULL;

		$email = $memberinfo[email] && $memberinfo[showemail] ? $memberinfo[email] : NULL;
		$avatar = $memberinfo[avatar] ? image($memberinfo[avatar]) : "<br><br><br>";

		$lastmembervisittext = gmdate("$dateformat $timeformat", $memberinfo[lastvisit] + ($timeoffset * 3600));

		$query = $db->query("SELECT COUNT(*) FROM $table_posts");
		$posts = $db->result($query, 0);
		@$percent = round($memberinfo[postnum] * 100 / $posts, 2);

		$stars = "";
		for($i = 0; $i < $memberinfo[stars]; $i++) {
			$stars .= "<img src=\"$imgdir/star.gif\">";
		}

		if($memberinfo[gender] == 1) {
			$memberinfo[gender] = "��";
		} elseif($memberinfo[gender] == 2) {
			$memberinfo[gender] = "Ů";
		} else {
			$memberinfo[gender] = "��������";
		}

		$birthday = explode("-", $memberinfo[bday]);
		$memberinfo[bday] = $dateformat;
		$memberinfo[bday] = str_replace("n", $birthday[1], $memberinfo[bday]);
		$memberinfo[bday] = str_replace("j", $birthday[2], $memberinfo[bday]);
		$memberinfo[bday] = str_replace("Y", $birthday[0], $memberinfo[bday]);
		$memberinfo[bday] = str_replace("y", substr($birthday[0], 2, 4), $memberinfo[bday]);

		$memberinfo[bio] = nl2br($memberinfo[bio]);
		$memberinfo[signature] = postify($memberinfo[signature], "", "", "", 0, 0, $memberinfo[allowsigbbcode], $memberinfo[allowsigimgcode]);
		$encodeuser = rawurlencode(stripslashes($member));

		if($isadmin) {
			$ipaddr = $memberinfo[regip];
			$iplocation = convertip($memberinfo[regip]);
			eval("\$regip = \"".template("member_viewpro_regip")."\";");
			$edituser = " &nbsp; &nbsp; <a href=\"admincp.php?action=memberprofile&username=$encodeuser&showmsgtype=cdb_with_header\">[ �༭�û� ]</a>";
		}
		if($memberinfo[showemail]) {
			eval("\$emailblock = \"".template("member_viewpro_email")."\";");
		}

		eval("\$profile = \"".template("member_viewpro")."\";");
		echo $profile;
	}

} else {

	$useraction = "δ������� [MEMBER]";
	showmessage("δ����������뷵�ء�");

}

gettotaltime();
eval("\$footer = \"".template("footer")."\";");
echo $footer;

cdb_output();
?>