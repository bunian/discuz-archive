<?php
//-----------------------------------------------------------------------------
//    Discuz! Board 1.0 Standard - Discuz! ������̳ (PHP & MySQL) 1.0 ��׼��
//-----------------------------------------------------------------------------
//    Copyright(C) Dai Zhikang, Crossday Studio, 2002. All rights reserved
//
//    Crossday ������ www.crossday.com    *Discuz! ����֧�� www.Discuz.net
//-----------------------------------------------------------------------------
//  ����ϸ�Ķ� Discuz! ��ȨЭ��,�鿴��ʹ�� Discuz! ���κβ�����ζ����ȫͬ��
//  Э���е�ȫ������,�����֮��֧�ֹ���������ҵ,�Ͻ�һ��Υ��Э�����Ȩ��Ϊ.
//-----------------------------------------------------------------------------
// Discuz! רע���ṩ��Чǿ�����̳�������,��������ҵ��;,�����빺��ʹ����Ȩ!
//-----------------------------------------------------------------------------


$mtime = explode(" ", microtime());
$starttime = $mtime[1] + $mtime[0];

define("IN_CDB", TRUE);
require "./config.php";
require "./lib/$database.php";
require "./functions.php";

error_reporting(E_ERROR | E_WARNING | E_PARSE);
@set_magic_quotes_runtime(0);

$timestamp = time();
$cdb_charset = $charset;
$poweredbycdb = "CDB - Crossday Bulletin";
$magic_quotes_gpc = get_magic_quotes_gpc();
$register_globals = @get_cfg_var("register_globals");

$PHP_SELF = $HTTP_SERVER_VARS[PHP_SELF] ? $HTTP_SERVER_VARS[PHP_SELF] : $HTTP_SERVER_VARS[SCRIPT_NAME];
$boardurl = "http://$HTTP_SERVER_VARS[HTTP_HOST]".dirname($PHP_SELF)."/";
$CDB_SESSION_VARS = $CDB_CACHE_VARS = array();
$url_redirect = "";

$tables = array('attachments', 'announcements', 'banned', 'caches', 'favorites', 'forumlinks', 'forums', 'members', 'memo',
	'news', 'posts', 'searchindex', 'sessions', 'settings', 'smilies', 'stats', 'subscriptions', 'templates', 'themes',
	'threads', 'u2u', 'usergroups', 'words', 'buddys'); 
foreach($tables as $tablename) {
	${"table_".$tablename} = $tablepre.$tablename;
}
unset($tablename);

$db = new dbstuff;
$db->connect($dbhost, $dbuser, $dbpw, $pconnect);
$db->select_db($dbname);
unset($dbhost, $dbuser, $dbpw, $dbname, $pconnect);

$cachenames = "'settings'";
$currscript = basename($PHP_SELF); 
switch($currscript) {
	case "index.php": $cachenames .= !$gid ? ", 'announcements', 'news', 'forumlinks'" : NULL; break;
	case "forumdisplay.php": $cachenames .= ", 'forums', 'censor'"; break;
	case "viewthread.php": $cachenames .= ", 'forums', 'usergroups', 'censor', 'smilies'"; break;
	case "post.php": $cachenames .= ", 'smilies', 'picons', 'censor'"; break;
	case "misc.php": $cachenames .= $HTTP_GET_VARS[action] == "search" ? ", 'forums', 'censor'" : NULL; break;
	case "member.php": $cachenames .= ", 'censor'"; break;
	case "u2u.php": $cachenames .= ", 'censor', 'smilies'"; break;
}
$query = $db->query("SELECT * FROM $table_caches WHERE cachename IN ($cachenames)");
while($cache = $db->fetch_array($query)) {
	$CDB_CACHE_VARS[$cache[cachename]] = unserialize($cache[cachevars]);
}
@extract($CDB_CACHE_VARS[settings]);
unset($cache);

if($HTTP_POST_VARS[cookie_time]) {
	$cookietime = $HTTP_POST_VARS[cookie_time];
	setcookie("cookietime", $cookietime, $timestamp + (86400 * 365), $cookiepath, $cookiedomain);
} elseif(!$HTTP_COOKIE_VARS["cookietime"]) {
	$cookietime = 2592000;
	setcookie("cookietime", $cookietime, $timestamp + (86400 * 365), $cookiepath, $cookiedomain);
} else {
	$cookietime = $HTTP_COOKIE_VARS[cookietime];
}

if(getenv("HTTP_CLIENT_IP")) {
	$onlineip = getenv("HTTP_CLIENT_IP");
} elseif(getenv("HTTP_X_FORWARDED_FOR")) {
	$onlineip = getenv("HTTP_X_FORWARDED_FOR");
} elseif(getenv("REMOTE_ADDR")) {
	$onlineip = getenv("REMOTE_ADDR");
} else {
	$onlineip = $HTTP_SERVER_VARS[REMOTE_ADDR];
}

$sid = $HTTP_GET_VARS[sid] ? $HTTP_GET_VARS[sid] : $HTTP_COOKIE_VARS[sid];
$sid = $HTTP_POST_VARS[sid] ? $HTTP_POST_VARS[sid] : $sid;

$query = $db->query("SELECT ip, sessionvars FROM $table_sessions WHERE sid='$sid'");
@extract($db->fetch_array($query), EXTR_OVERWRITE);
if($ip != $onlineip || ($sid != $HTTP_COOKIE_VARS[sid] && $HTTP_COOKIE_VARS) || !$sid) {
	$sid = random(32, "session");
	$sessionvars = "";
}

$currtime = cookietime();
$currtime = $currtime <= ($timestamp + 3600) ? $currtime : $timestamp + 3600;
setcookie("sid", $sid, $timestamp + 3600, $cookiepath, $cookiedomain);
if(!$sessionvars) {
	$sessionexists = 0;
	$status = "�ο�";
	$ips = explode(".", $onlineip);
	$query = $db->query("SELECT id FROM $table_banned WHERE (ip1='$ips[0]' OR ip1='-1') AND (ip2='$ips[1]' OR ip2='-1') AND (ip3='$ips[2]' OR ip3='-1') AND (ip4='$ips[3]' OR ip4='-1')");
	if($db->num_rows($query)) {
		$CDB_SESSION_VARS[ipbanned] = 1;
		$status = "��ֹIP";
	} else {
		$CDB_SESSION_VARS[ipbanned] = 0;
	}

	$cdbuser = cdbaddslashes($HTTP_COOKIE_VARS[_cdbuser]);
	$cdbpw = cdbaddslashes($HTTP_COOKIE_VARS[_cdbpw]);
	if($cdbuser) {
		$query = $db->query("SELECT m.username as cdbuser, m.password as cdbpw, m.uid, m.charset, m.timeoffset,	m.theme, m.tpp, m.ppp, m.credit,
			m.timeformat, m.dateformat, m.signature, m.avatar, m.lastvisit,	m.newu2u, u.*, u.specifiedusers LIKE '%\t$cdbuser\t%' AS specifieduser
			FROM $table_members m LEFT JOIN $table_usergroups u ON u.specifiedusers LIKE '%\t$cdbuser\t%' OR (u.status=m.status
			AND ((u.creditshigher='0' AND u.creditslower='0' AND u.specifiedusers='') OR (m.credit>=u.creditshigher AND m.credit<u.creditslower)))
			WHERE username='$cdbuser' AND password='$cdbpw' ORDER BY specifieduser DESC");
		$member = $db->fetch_array($query);
	}
	if(!$member[uid]) {
		$query = $db->query("SELECT * FROM $table_usergroups WHERE status='$status'");
		$member = $db->fetch_array($query);
		$cdbuser = $CDB_SESSION_VARS[cdbuser] = $HTTP_COOKIE_VARS[_cdbuser] = "";
		$lastvisit = $CDB_SESSION_VARS[lastvisit] = $HTTP_COOKIE_VARS[lastvisit];
		if(($timestamp - $lastvisit) > $onlinehold) {
			setcookie("lastvisit", $timestamp, $timestamp + (86400 * 365), $cookiepath, $cookiedomain);
		}
	} else {
		$member[cdbuser] = addslashes($member[cdbuser]);
		$member[signature] = $member[signature] ? 1 : 0;
	}
	$CDB_SESSION_VARS = array_merge($CDB_SESSION_VARS, $member);
	$CDB_SESSION_VARS[theme] = $member[theme] ? $member[theme] : $CDB_CACHE_VARS[settings][theme];
	unset($member, $ips);
} else {
	$sessionexists = 1;
	$CDB_SESSION_VARS = unserialize($sessionvars);
	if($CDB_SESSION_VARS[ipbanned]) {
		$query = $db->query("SELECT * FROM $table_usergroups WHERE status='��ֹIP'");
		$CDB_SESSION_VARS = $db->fetch_array($query);
		$cdbuser = $CDB_SESSION_VARS[cdbuser] = $HTTP_COOKIE_VARS[_cdbuser] = "";
	}
	unset($sessionvars);
}

$style = $HTTP_GET_VARS[style] ? $HTTP_GET_VARS[style] : $HTTP_POST_VARS[style];
if($style) {
	$CDB_SESSION_VARS[theme] = $style;
	$CDB_SESSION_VARS[themename] = "";
}
if(!$CDB_SESSION_VARS[themename]) {
	$query = $db->query("SELECT * FROM $table_themes WHERE themename='$CDB_SESSION_VARS[theme]'");
	if(!$thememember = $db->fetch_array($query)) {
		$query = $db->query("SELECT * FROM $table_themes LIMIT 0, 1");
		$thememember = $db->fetch_array($query);
	}
	$CDB_SESSION_VARS = array_merge($CDB_SESSION_VARS, $thememember);
	unset($thememember);
}

@extract($CDB_SESSION_VARS, EXTR_OVERWRITE);
$cdbuserss = stripslashes($cdbuser);
$credit = intval($credit);

if($headercharset) {
	header("Content-Type: text/html; charset=$charset");
}

if($HTTP_POST_VARS) {
	if($cdb_charset != $charset) {
		$mode = $cdb_charset == "big5" ? "gb-big5" : "big5-gb";
		$table = "./lib/$mode.table";
		$fp = fopen($table, "r");
		$codelib = fread($fp, filesize($table));
		fclose($fp);

		@extract(cdbaddslashes(chcode_convert($HTTP_POST_VARS, $codelib)), EXTR_OVERWRITE);
		unset($codelib);
	} else {
		@extract(cdbaddslashes($HTTP_POST_VARS), EXTR_OVERWRITE);
	}
}

if(!$register_globals || !$magic_quotes_gpc) {
	@extract(cdbaddslashes($HTTP_GET_VARS), EXTR_OVERWRITE);
	if(!$register_globals) {
		foreach($HTTP_POST_FILES as $key => $val) {
			$$key = $val[tmp_name];
			${$key."_name"} = $val[name];
			${$key."_size"} = $val[size];
			${$key."_type"} = $val[type];
		}
	}
}

unset($HTTP_POST_VARS, $HTTP_POST_FILES);

if($statstatus) {
	include "./stats.php";
}

if(!$tpp || !$ppp) {
	$tpp = $topicperpage;
	$ppp = $postperpage;
}

if($regstatus && !$cdbuser) {
	$reglink = "<a href=\"member.php?action=reg\"><font class=\"navtd\">ע��</font></a>";
}

$poweredbycdb .= ", www.crossday.com, Dai Zhikang";
if(!$referer) {
	$referer = preg_replace("/(?:([\?&]sid\=[a-z0-9]{32}&?))/is", "", $HTTP_SERVER_VARS[HTTP_REFERER]);
	$referer = substr($referer, -1) == "?" ? substr($referer, 0, -1) : $referer;
}

if($cdbuser) {
	$welcome = "<span class=\"bold\">$cdbuserss</span>��";
	$loginout = "<a href=\"member.php?action=logout\"><font class=\"navtd\">�˳�</font></a>";
	$memcplink = " | <a href=\"memcp.php\"><font class=\"navtd\">�������</font></a>";
	$u2ulink = " | <a href=\"###\" onclick=\"Popup('u2u.php?sid=$sid', 'Window', 580, 450);\"><font class=\"navtd\">����Ϣ</font></a>";
	if($isadmin) {
		$cplink = " | <a href=\"admincp.php\" target=\"_blank\"><font class=\"navtd\">ϵͳ����</font></a>";
	}
	$header_welcome = "";
} else {
	$welcome = "<span class=\"bold\">$grouptitle</span>��";
	$loginout = " | <a href=\"member.php?action=login\"><font class=\"navtd\">��¼</font></a>";
	$header_welcome = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><form action=\"member.php?action=login\" method=\"post\"><tr><td nowrap><input type=\"text\" name=\"username\" size=\"7\">&nbsp;<input type=\"password\" name=\"password\" size=\"7\"> <input type=\"submit\" name=\"loginsubmit\" value=\"�� ¼\"></form></td></tr></table>";
}

if($tid){
	$query = $db->query("SELECT f.*, t.fid FROM $table_forums f, $table_threads t WHERE t.tid='$tid' AND f.fid=t.fid LIMIT 0, 1");
	$forum = $db->fetch_array($query);
	$fid = $forum[fid];
} elseif($fid) {
	$query = $db->query("SELECT * FROM $table_forums WHERE fid='$fid'");
	$forum = $db->fetch_array($query);
}

$lastvisittext = "����ʱ���� ".gmdate("$dateformat $timeformat", $timestamp + ($timeoffset * 3600));

if($lastvisit && $cdbuser) {
	$header_welcome = "��ӭ�ص� $bbname<br>���ϴη������� ".gmdate("$dateformat $timeformat", $lastvisit + ($timeoffset * 3600));
} else {
	$lastvisittext .= "<br><br>����û��<a href=\"member.php?action=reg\">ע��</a>��<a href=\"member.php?action=login\">��¼</a>����������Ҫ<a href=\"member.php?action=reg\">ע��</a>���ܷ����ͻظ�<br>�������һ�η��ʱ���̳�����Ķ���̳�Ϸ��� <a href=\"faq.php\">FAQ</a>";
}

$verify = "CD"."B - Cros"."sday Bul"."letin, w";
$gzipcompress && $cdb_charset == $charset && $HTTP_COOKIE_VARS[sid] ? ob_start("ob_gzhandler") : ob_start();

$faqlink = " | <a href=\"faq.php\"><font class=\"navtd\">FAQ</font></a>";
$searchlink = $allowsearch ? " | <a href=\"misc.php?action=search\"><font class=\"navtd\">����</font></a>" : NULL;
$memlistlink = $memliststatus ? " | <a href=\"member.php?action=list\"><font class=\"navtd\">��Ա</font></a>" : NULL;
$statslink = $statstatus ? " | <a href=\"misc.php?action=stats\"><font class=\"navtd\">ͳ��</font></a>" : NULL;
$memolink = $maxmemonum ? " | <a href=\"memo.php\"><font class=\"navtd\">����¼</font></a>" : NULL;

if(is_array($plugins)) {
	foreach($plugins as $plugarray) {
		if($plugarray[name] && $plugarray[url]) {
			$pluglink .= " | <a href=\"$plugarray[url]\"><font class=\"navtd\">$plugarray[name]</font></a> ";
		}
	}
}

$verify .= "ww.cr"."ossd"."ay.com, Da"."i Zhika"."ng";
$bgcode = strpos($bgcolor, ".") ? "background-image: url(\"$imgdir/$bgcolor\")" : "background-color: $bgcolor";
$catbgcode = strpos($catcolor, ".") ? "background-image: url(\"$imgdir/$catcolor\")" : "background-color: $catcolor";
$headerbgcode = strpos($headercolor, ".") ? "background-image: url(\"$imgdir/$headercolor\")" : "background-color: $headercolor";
$boardlogo = image($boardimg, $imgdir, "alt=\"$bbname\"");
$bold = $nobold ? "normal" : "bold";

if(is_integer($allowvisit) && $allowvisit == 0) {
	setcookie("_cdbuser", $CDB_SESSION_VARS[cdbuser], 86400 * 365, $cookiepath, $cookiedomain);
	setcookie("_cdbpw", $CDB_SESSION_VARS[cdbpw], 86400 * 365, $cookiepath, $cookiedomain);
	showmessage("�Բ��𣬱���̳����ӭ������á�");
} elseif($verify != $poweredbycdb || ($action != "login" && $bbclosed && !$isadmin)) {
	$currtime = $timestamp - (86400 * 365);
	setcookie("_cdbuser", "", $currtime, $cookiepath, $cookiedomain);
	setcookie("_cdbpw", "", $currtime, $cookiepath, $cookiedomain);
	showmessage($closedreason ? $closedreason : "����̳��ʱ�رա�");
}

?>