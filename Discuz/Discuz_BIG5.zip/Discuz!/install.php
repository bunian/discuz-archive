<?php

/*
	[DISCUZ!] install.php - installation of Discuz! Board
	This is NOT a freeware, use is subject to license terms

	Version: 2.0.0(BUG Fixed)
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2002/12/24 12:20
*/

error_reporting(7);
set_magic_quotes_runtime(0);
define('IN_DISCUZ', TRUE);

$action = ($HTTP_POST_VARS['action']) ? $HTTP_POST_VARS['action'] : $HTTP_GET_VARS['action'];
$PHP_SELF = $HTTP_SERVER_VARS['PHP_SELF'] ? $HTTP_SERVER_VARS['PHP_SELF'] : $HTTP_SERVER_VARS['SCRIPT_NAME'];

if (function_exists('set_time_limit') == 1 && @ini_get('safe_mode') == 0) {
	@set_time_limit(1000);
}

@include './config.php';

header('Content-Type: text/html; charset=gb2312');
$version = '2.0 <b style=\'color: #FF9900\'>COML</b>';

function loginit($log) {
	echo '��l�ưO�� '.$log;
	$fp = @fopen('./forumdata/illegallog.php', 'w');
	@fwrite($fp, "<?PHP exit(\"Access Denied\"); ?>\n");
	@fclose($fp);
	result();
}

function runquery($sql) {
	global $tablepre, $db;

	$sql = str_replace("\r", "\n", str_replace(' cdb_', ' '.$tablepre, $sql));
	$ret = array();
	$num = 0;
	foreach(explode(";\n", trim($sql)) as $query) {
		$queries = explode("\n", trim($query));
		foreach($queries as $query) {
			$ret[$num] .= $query[0] == '#' ? NULL : $query;
		}
		$num++;
	}
	unset($sql);

	foreach($ret as $query) {
		$query = trim($query);
		if($query) {
			if(substr($query, 0, 12) == 'CREATE TABLE') {
				$name = preg_replace("/CREATE TABLE ([a-z0-9_]+) .*/is", "\\1", $query);
				echo '�إ߼ƾڪ� '.$name.' ... <font color="#0000EE">���\</font><br>';
			}
			$db->query($query);
		}
	}
}

function result($result = 1, $output = 1) {
	if($result) {
		$text = '... <font color="#0000EE">���\</font><br>';
		if(!$output) {
			return $text;
		}
		echo $text;
	} else {
		$text = '... <font color="#FF0000">����</font><br>';
		if(!$output) {
			return $text;
		}
		echo $text;
	}
}

function dir_writeable($dir) {
	if(!is_dir($dir)) {
		@mkdir($dir, 0777);
	}
	if(is_dir($dir)) {
		if($fp = @fopen("$dir/test.test", 'w')) {
			@fclose($fp);
			@unlink("$dir/test.test");
			$writeable = 1;
		} else {
			$writeable = 0;
		}
	}
	return $writeable;
}

function dir_clear($dir) {
	echo '�M�ťؿ� '.$dir;
	$directory = dir($dir);
	while($entry = $directory->read()) {
		$filename = $dir.'/'.$entry;
		if(is_file($filename)) {
			@unlink($filename);
		}
	}
	$directory->close();
	result();
}

?>
<html>
<head>
<title>Discuz! Installation Wizard</title>
<style>
A:visited	{COLOR: #3A4273; TEXT-DECORATION: none}
A:link		{COLOR: #3A4273; TEXT-DECORATION: none}
A:hover		{COLOR: #3A4273; TEXT-DECORATION: underline}
p		{TEXT-INDENT : 15px}
body,table,td	{COLOR: #3A4273; FONT-FAMILY: Tahoma, Verdana, Arial; FONT-SIZE: 12px; LINE-HEIGHT: 20px; scrollbar-base-color: #E3E3EA; scrollbar-arrow-color: #5C5C8D}
input		{COLOR: #085878; FONT-FAMILY: Tahoma, Verdana, Arial; FONT-SIZE: 12px; background-color: #3A4273; color: #FFFFFF; scrollbar-base-color: #E3E3EA; scrollbar-arrow-color: #5C5C8D}
.install	{FONT-FAMILY: Arial, Verdana; FONT-SIZE: 20px; FONT-WEIGHT: bold; COLOR: #000000}
</style>
</head>

<body bgcolor="#3A4273" text="#000000">
<table width="95%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center">
  <tr>
    <td>
      <table width="98%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td class="install" height="30" valign="bottom"><font color="#FF0000">&gt;&gt;</font> 
            Discuz! Installation Wizard</td>
        </tr>
        <tr>
          <td> 
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td align="center"> 
            <b>�w��Ө� Crossday Discuz! Board �w���Q�ɡA�w�˫e�ХJ�Ӿ\Ū licence �ɪ��C�ӲӸ`�A�b�z�T�w�i�H�������� Discuz! �����v��ĳ����~��}�l�w�ˡCreadme �ɴ��ѤF�����n��w�˪������A�бz�P�˥J�Ӿ\Ū�A�H�O�Ҧw�˶i�{�����Q�i��C</b>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
<?

if(!$action) {

	$discuz_licence = <<<EOT
���v�Ҧ� (c) 2002�X2004, Comsenz Technology Ltd
�O�d�Ҧ��v�O.

    �P�±z��� Discuz! �׾²��~�C�Ʊ�ڭ̪��V�O�ର�z���Ѥ@�Ӱ��ħֳt�M�j�j�� web �׾¸ѨM��סC

    Discuz! �^����٬� Crossday Discuz! Board�A������٬� Discuz! �׾¡A�H�U²�� Discuz!�C
    �_�ʱd���@����ަ������q�� Discuz! ���~���ت��}�o�ӡA�̪k�֦� Discuz! �n�󪺵ۧ@�v�]���ؤH���@�M���a���v���ۧ@�v�n�O�� 2003SR6623�^�C����ĳ�A�Ω� Discuz! 2.x �t�C�����A�_�ʱd���@����ަ������q�֦��糧��ĳ���̲׸����v�M�ק��v�C

    Discuz! �x��޳N����׾¬� http://www.Discuz.net�FDiscuz! �x�貣�~������ http://www.Discuz.com�F�_�ʱd���@����ަ������q���x������� http://www.comsenz.com�C

    �b�}�l�w�� Discuz! ���e�A�аȥ��J�Ӿ\Ū�����v���ɡA�b�z�T�w�ŦX���v��ĳ�����������A�Y�i�~�� Discuz! �׾ª��w�ˡC�Y�G�z�@���}�l�w�� Discuz!�A�Y�Q���������P�N�����v��ĳ���������e�A�p�G�X�{�ȯɡA�ڭ̱N�ھڬ����k�ߩM��ĳ���ڰl�s�d���C

    Discuz! �׾¤w�b���ؤH���@�M���a���v���n�O�A�ۧ@�v����k�ߤΰ�ڤ����O�@�C2.x �������K�O�n��A�Τ�i�H�b�������u���̲ץΤ���v��ĳ����¦�W�A�K�O��o�B�w�ˤΦb���a�p����κ����W�ϥΥ��{�ǡA�Ӥ�����I�O�ΡC

    �z�i�H�d�� Discuz! ���������N�X�A�]�i�H�ھڦۤv���ݭn���i��ק�A���L�צp��A�Y�L�ץγ~�p��B�O�_��ʡB��ʵ{�צp��A�u�n Discuz! �{�Ǫ����󳡤��Q�]�t�b�z�ק�᪺�t�Τ��A�������O�d���}�B�� Discuz! �W�٩M Comsenz Technology Ltd (http://www.comsenz.com) ���챵�C�z�ק�᪺�N�X�A�b�S����o�_�ʱd���@����ަ������q�ѭ��\�i�����p�U�A�Y�T���}�o�G�εo��C

    �Τ�X����@�ӨϥΥ��n��A�ڭ̤��ӿչﴣ�ѥ���Φ����޳N����B�ϥξ�O�A�]���Ӿ����]�ϥΥ��n��Ӳ��Ͱ��D�������d���C

    ���B�ȹ��D��Q�ʭӤH�Τ�A������ Discuz! �O�}�񷽥N�X���K�O�n��A�w��z�b��˧���O�d�������v�H���M�����ɪ��e���U�A�Ǽ��M������{�ǡC�b���ʶR�ӷ~���v�e�A�Y�T�N�����n��Ω�ӷ~�γ~�άէQ�ʯ��I�A�Y�G���~�B��Q�ʪ��|����B�q�Ƹg��ʤ��p���~�Ȫ����q�P�ӤH�B��̲ץΤ᦬���O�Ϊ����O�����A���ݭn�ʶR�ӷ~�������v�~��ϥΥ��n��A�����ӷ~�����ʶR�Ʃy�гX�ݩx������]http://www.discuz.com�^�C�P���w��� Discuz! �P����æ���O������έӤH�� Discuz! ���}�o���Ѥ���C

    �w�� Discuz! �إߦb�����P�N�����v��ĳ����¦���W�A�]���Ӳ��ͪ��ȯɡA�H�ϥ���ĳ���@��N�Ӿ�������ƻP�D�Ƴd���C
EOT;

	$discuz_licence = str_replace('  ', '&nbsp; ', nl2br($discuz_licence));

?>
        <tr> 
          <td><b>���e���A�G</b><font color="#0000EE">Discuz! �Τ�\�i��ĳ</font></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> �бz�ȥ��J�Ӿ\Ū�U�����\�i��ĳ</font></b></td>
        </tr>
        <tr>
          <td><br>
            <table width="90%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr>
                <td bgcolor="#E3E3EA">
                  <table width="99%" cellspacing="1" border="0" align="center">
                    <tr>
                      <td>
                        <?=$discuz_licence?>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="config">
              <input type="submit" name="submit" value="�ڧ����P�N" style="height: 25">&nbsp;
              <input type="button" name="exit" value="�ڤ���P�N" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

} elseif($action == 'config') {

	$exist_error = FALSE;
	$write_error = FALSE;
	if(file_exists('./config.php')) {
		$fileexists = result(1, 0);
	} else {
		$fileexists = result(0, 0);
		$exist_error = TRUE;
	}
	if(is_writeable('./config.php')) {
		$filewriteable = result(1, 0);
	} else {
		$filewriteable = result(0, 0);
		$write_error = TRUE;
	}
	if($exist_error) {
		$config_info = '�z�� config.php ���s�b, �L�k�~��w��, �Х� FTP �N�Ӥ��W�ǫ�A��.';
	} elseif(!$write_error) {
		$config_info = '�Цb�U����g�z���ƾڮw�㸹�H��, �q�`���p�U�Ф��n�ק����ﶵ���e.';
	} elseif($write_error) {
		$config_info = '�w���Q�ɵL�k�g�J�t�m���, �Юֹ�{���H��, �p�ݭק�, �гq�L FTP �N��n�� config.php �W��.';
	}

?>
        <tr> 
          <td><b>���e���A�G</b><font color="#0000EE">�t�m config.php</font></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> �ˬd�t�m��󪬺A</font></b></td>
        </tr>
        <tr>
          <td>config.php �s�b�ˬd <?=$fileexists?></td>
        </tr>
        <tr>
          <td>config.php �i�g�ˬd <?=$filewriteable?></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> �s��/�s����e�t�m</font></b></td>
        </tr>
        <tr>
          <td align="center"><br><?=$config_info?></td>
        </tr>
<?

	if(!$exist_error) {

		if(!$write_error) {

			$dbhost = 'localhost';
			$dbuser = 'dbuser';
			$dbpw = 'dbpw';
			$dbname = 'dbname';
			$adminemail = 'admin@domain.com';
			$tablepre = 'cdb_';

			@include './config.php';

?>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <table width="500" cellspacing="1" bgcolor="#000000" border="0" align="center">
                <tr bgcolor="#3A4273">
                  <td align="center" width="20%" style="color: #FFFFFF">�]�m�ﶵ</td>
                  <td align="center" width="35%" style="color: #FFFFFF">���e��</td>
                  <td align="center" width="45%" style="color: #FFFFFF">����</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;�ƾڮw�A�Ⱦ�:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbhost" value="<?=$dbhost?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;�ƾڮw�A�Ⱦ��a�}, �@�묰 localhost</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;�ƾڮw�Τ�W:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbuser" value="<?=$dbuser?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;�ƾڮw�㸹�Τ�W</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;�ƾڮw�K�X:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="password" name="dbpw" value="<?=$dbpw?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;�ƾڮw�㸹�K�X</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;�ƾڮw�W:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbname" value="<?=$dbname?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;�ƾڮw�W��</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA">&nbsp;�t�� Email:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="adminemail" value="<?=$adminemail?>" size="30"></td>
                  <td bgcolor="#E3E3EA">&nbsp;�Ω�o�e�{�ǿ��~���i</td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA" style="color: #FF0000">&nbsp;���W�e��:</td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="tablepre" value="<?=$tablepre?>" size="30" onClick="javascript: alert('�w���Q�ɴ���:\n\n���D�z�ݭn�b�P�@�ƾڮw�w�˦h�� CDB\n�׾�,�_�h,�j�P��ĳ�z���n�ק���W�e��.');"></td>
                  <td bgcolor="#E3E3EA">&nbsp;�P�@�ƾڮw�w�˦h�׾®ɨϥ�</td>
                </tr>
              </table>
              <br>
              <input type="hidden" name="action" value="environment">
              <input type="hidden" name="saveconfig" value="1">
              <input type="submit" name="submit" value="�O�s�t�m�H��" style="height: 25">
              <input type="button" name="exit" value="�h�X�w���Q��" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

		} else {

			@include './config.php';

?>
        <tr>
          <td>
            <br>
            <table width="60%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr bgcolor="#3A4273">
                <td align="center" style="color: #FFFFFF">�ܶq</td>
                <td align="center" style="color: #FFFFFF">���e��</td>
                <td align="center" style="color: #FFFFFF">����</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$dbhost</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbhost?></td>
                <td bgcolor="#E3E3EA" align="center">�ƾڮw�A�Ⱦ�, �@�묰 localhost</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$dbuser</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbuser?></td>
                <td bgcolor="#E3E3EA" align="center">�ƾڮw�㸹(�Τ�W)</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$dbpw</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbpw?></td>
                <td bgcolor="#E3E3EA" align="center">�ƾڮw�K�X</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$dbname</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbname?></td>
                <td bgcolor="#E3E3EA" align="center">�ƾڮw�W��</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$adminemail</td>
                <td bgcolor="#EEEEF6" align="center"><?=$adminemail?></td>
                <td bgcolor="#E3E3EA" align="center">�t�� Email</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">$tablepre</td>
                <td bgcolor="#EEEEF6" align="center"><?=$tablepre?></td>
                <td bgcolor="#E3E3EA" align="center">�ƾڪ��W�e��</td>
              </tr>
            </table>
            <br>
          </td>
        </tr>
        <tr>
          <td align="center">
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="environment">
              <input type="submit" name="submit" value="�W�z�t�m���T" style="height: 25">
              <input type="button" name="exit" value="��s�קﵲ�G" style="height: 25" onclick="javascript: window.location=('<?=$PHP_SELF?>?action=config');">
            </form>
          </td>
        </tr>
<?

		}

	} else {

?>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="config">
              <input type="submit" name="submit" value="���s�ˬd�]�m" style="height: 25">
              <input type="button" name="exit" value="�h�X�w���Q��" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

	}

} elseif($action == 'environment') {

	if($HTTP_POST_VARS['saveconfig'] && is_writeable('./config.php')) {

		$dbhost = $HTTP_POST_VARS['dbhost'];
		$dbuser = $HTTP_POST_VARS['dbuser'];
		$dbpw = $HTTP_POST_VARS['dbpw'];
		$dbname = $HTTP_POST_VARS['dbname'];
		$adminemail = $HTTP_POST_VARS['adminemail'];
		$tablepre = $HTTP_POST_VARS['tablepre'];

		$fp = fopen('./config.php', 'r');
		$configfile = fread($fp, filesize('./config.php'));
		fclose($fp);

		$configfile = preg_replace("/[$]dbhost\s*\=\s*[\"'].*?[\"']/is", "\$dbhost = '$dbhost'", $configfile);
		$configfile = preg_replace("/[$]dbuser\s*\=\s*[\"'].*?[\"']/is", "\$dbuser = '$dbuser'", $configfile);
		$configfile = preg_replace("/[$]dbpw\s*\=\s*[\"'].*?[\"']/is", "\$dbpw = '$dbpw'", $configfile);
		$configfile = preg_replace("/[$]dbname\s*\=\s*[\"'].*?[\"']/is", "\$dbname = '$dbname'", $configfile);
		$configfile = preg_replace("/[$]adminemail\s*\=\s*[\"'].*?[\"']/is", "\$adminemail = '$adminemail'", $configfile);
		$configfile = preg_replace("/[$]tablepre\s*\=\s*[\"'].*?[\"']/is", "\$tablepre = '$tablepre'", $configfile);

		$fp = fopen('./config.php', 'w');
		fwrite($fp, trim($configfile));
		fclose($fp);

	}

	include './config.php';
	include './include/db_'.$database.'.php';
	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);

	$msg = '';
	$quit = FALSE;

	$curr_os = PHP_OS;

	$curr_php_version = PHP_VERSION;
	if($curr_php_version < '4.0.0') {
		$msg .= "<font color=\"#FF0000\">�z�� PHP �����p�� 4.0.0, �L�k�ϥ� Discuz!.</font>\t";
		$quit = TRUE;
	} elseif($curr_php_version < '4.0.6') {
		$msg .= "<font color=\"#FF0000\">�z�� PHP �����p�� 4.0.6, �L�k�ϥ��Y���ؤo�ˬd�M gzip ���Y�\��.</font>\t";
	}

	if(@ini_get(file_uploads)) {
		$max_size = @ini_get(upload_max_filesize);
		$curr_upload_status = "���\/�̤j $max_size";
		$msg .= "�z�i�H�W�Ǥؤo�b $max_size �H�U��������.\t";
	} else {
		$curr_upload_status = '�����\�W�Ǫ���';
		$msg .= "<font color=\"#FF0000\">�ѩ�A�Ⱦ��̽�, �z�L�k�ϥΪ���\��.</font>\t";
	}

	$query = $db->query("SELECT VERSION()");
	$curr_mysql_version = $db->result($query, 0);
	if($curr_mysql_version < '3.23') {
		$msg .= "<font color=\"#FF0000\">�z�� MySQL �����C�� 3.23, Discuz! ���@�ǥ\��i��L�k���`�ϥ�.</font>\t";
	}

	$curr_disk_space = intval(diskfreespace('.') / (1024 * 1024)).'M';

	if(dir_writeable('./templates')) {
		$curr_tpl_writeable = '�i�g';
	} else {
		$curr_tpl_writeable = '���i�g';
		$msg .= "<font color=\"#FF0000\">�ҪO ./templates �ؿ��ݩʫD 777 �εL�k�g�J, �L�k�ϥΦb�u�s��ҪO�M����ɤJ.</font>\t";
	}

	if(dir_writeable($attachdir)) {
		$curr_attach_writeable = '�i�g';
	} else {
		$curr_attach_writeable = '���i�g';
		$msg .= "<font color=\"#FF0000\">���� $attachdir �ؿ��ݩʫD 777 �εL�k�g�J, �L�k�ϥΪ���\��.</font>\t";
	}

	if(dir_writeable('./forumdata/')) {
		$curr_data_writeable = '�i�g';
	} else {
		$curr_data_writeable = '���i�g';
		$msg .= "<font color=\"#FF0000\">�ƾ� ./forumdata �ؿ��ݩʫD 777 �εL�k�g�J, �L�k�ϥγƥ���A�Ⱦ�/�׾¹B��O�����\��.</font>\t";
	}

	if(dir_writeable('./forumdata/templates/')) {
		$curr_template_writeable = '�i�g';
	} else {
		$curr_template_writeable = '���i�g';
		$msg .= "<font color=\"#FF0000\">�ҪO ./forumdata/templates �ؿ��ݩʫD 777 �εL�k�g�J, �L�k�w�� Discuz!.</font>\t";
		$quit = TRUE;
	}

	if(dir_writeable('./forumdata/cache/')) {
		$curr_cache_writeable = '�i�g';
	} else {
		$curr_cache_writeable = '���i�g';
		$msg .= "<font color=\"#FF0000\">�w�s ./forumdata/cache �ؿ��ݩʫD 777 �εL�k�g�J, �L�k�w�� Discuz!.</font>\t";
		$quit = TRUE;
	}

	$db->select_db($dbname);
	if($db->error()) {
		$db->query("CREATE DATABASE $dbname");
		if($db->error()) {
			$msg .= "<font color=\"#FF0000\">���w���ƾڮw $dbname ���s�b, �t�Τ]�L�k�۰ʫإ�, �L�k�w�� Discuz!.</font>\t";
			$quit = TRUE;
		} else {
			$db->select_db($dbname);
			$msg .= "���w���ƾڮw $dbname ���s�b, ���t�Τw���\�إ�, �i�H�~��w��.\t";
		}
	}

	$query - $db->query("SELECT COUNT(*) FROM $tablepre"."settings", 1);
	if(!$db->error()) {
		$msg .= "<font color=\"#FF0000\">�ƾڮw���w�g�w�˹L Discuz!, �~��w�˷|�M�ŭ즳�ƾ�.</font>\t";
		$alert = " onSubmit=\"return confirm('�~��w�˷|�M�ť����즳�ƾڡA�z�T�w�n�~���?');\"";
	} else {
		$alert = '';
	}

	if($quit) {
		$msg .= "<font color=\"#FF0000\">�ѩ�z�ؿ��ݩʩΪA�Ⱦ��t�m��], �L�k�~��w�� Discuz!, �ХJ�Ӿ\Ū�w�˻���.</font>";
	} else {
		$msg .= "�z���A�Ⱦ��i�H�w�˩M�ϥ� Discuz!, �жi�J�U�@�B�w��.";
	}
?>
        <tr>
          <td><b>���e���A�G</b><font color="#0000EE">�ˬd���e�A�Ⱦ�����</font></td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> Discuz! �һ����ҩM���e�A�Ⱦ��t�m���</font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <table width="80%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr bgcolor="#3A4273">
                <td align="center"></td>
                <td align="center" style="color: #FFFFFF">Discuz! �һݰt�m</td>
                <td align="center" style="color: #FFFFFF">Discuz! �̨ΰt�m</td>
                <td align="center" style="color: #FFFFFF">���e�A�Ⱦ�</td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">�ާ@�t��</td>
                <td bgcolor="#EEEEF6" align="center">����</td>
                <td bgcolor="#E3E3EA" align="center">UNIX/Linux/FreeBSD</td>
                <td bgcolor="#E3E3EA" align="center"><?=$curr_os?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">PHP ����</td>
                <td bgcolor="#EEEEF6" align="center">4.0.0 �H�W</td>
                <td bgcolor="#E3E3EA" align="center">4.0.6 �H�W</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_php_version?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">����W��</td>
                <td bgcolor="#EEEEF6" align="center">����</td>
                <td bgcolor="#E3E3EA" align="center">���\</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_upload_status?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">MySQL ����</td>
                <td bgcolor="#EEEEF6" align="center">3.23 �H�W</td>
                <td bgcolor="#E3E3EA" align="center">3.23.51</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_mysql_version?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">�ϽL�Ŷ�</td>
                <td bgcolor="#EEEEF6" align="center">2M �H�W</td>
                <td bgcolor="#E3E3EA" align="center">50M �H�W</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_disk_space?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">./templates �ؿ��g�J</td>
                <td bgcolor="#EEEEF6" align="center">����</td>
                <td bgcolor="#E3E3EA" align="center">�i�g</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_tpl_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center"><?=$attachdir?> �ؿ��g�J</td>
                <td bgcolor="#EEEEF6" align="center">����</td>
                <td bgcolor="#E3E3EA" align="center">�i�g</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_attach_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">./forumdata �ؿ��g�J</td>
                <td bgcolor="#EEEEF6" align="center">����</td>
                <td bgcolor="#E3E3EA" align="center">�i�g</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_data_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">./forumdata/templates �ؿ��g�J</td>
                <td bgcolor="#EEEEF6" align="center">�i�g</td>
                <td bgcolor="#E3E3EA" align="center">�i�g</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_template_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#E3E3EA" align="center">./forumdata/cache �ؿ��g�J</td>
                <td bgcolor="#EEEEF6" align="center">�i�g</td>
                <td bgcolor="#E3E3EA" align="center">�i�g</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_cache_writeable?></td>
              </tr>
            </table>
            <br>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> �нT�{�z�w�����H�U�B�J</font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <ol>
              <li>�N Discuz! �ؿ��U�������M�ؿ��W�Ǩ�A�Ⱦ�.</li>
              <li>�ק�A�Ⱦ��W�� config.php ���H�A�X�z���t�m.</li>
              <li>�p�G�z�ϥΫD WIN32/WINNT �t�νЭק�H�U�ݩ�:<br>&nbsp; &nbsp; <b>./templates</b> �ؿ� 777;&nbsp; &nbsp; <b><?=$attachdir?></b> �ؿ� 777;&nbsp; &nbsp; <b>./forumdata</b> �ؿ� 777;
              <br><b>&nbsp; &nbsp; ./forumdata/cache</b> �ؿ� 777;&nbsp; &nbsp; <b>./forumdata/templates</b> �ؿ� 777;<br></li>
              <li>�T�{ URL �� <?=$attachurl?> �i�H�X�ݪA�Ⱦ��ؿ� <?=$attachdir?> ���e.</li>
            </ol>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> �w���Q�ɴ���</font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <ol>
<?

	$msgs = explode("\t", $msg);
	unset($msg);
	for($i = 0; $i < count($msgs); $i++) {
		echo "              <li>".$msgs[$i]."</li>\n";
	}
	echo"            </ol>\n";

	if($quit) {

?>
            <center>
            <input type="button" name="refresh" value="���s�ˬd�]�m" style="height: 25" onclick="javascript: window.location=('<?=$PHP_SELF?>?action=environment');">&nbsp;
            <input type="button" name="exit" value="�h�X�w���Q��" style="height: 25" onclick="javascript: window.close();">
            </center>
<?

	} else {

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> �]�m�޲z���㸹</font></b></td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>"<?=$alert?>>
              <table width="300" cellspacing="1" bgcolor="#000000" border="0" align="center">
                <tr>
                  <td bgcolor="#E3E3EA" width="40%">&nbsp;�޲z���Τ�W:</td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="text" name="username" value="Crossday" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA" width="40%">&nbsp;�޲z�� Email:</td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="text" name="email" value="name@domain.com" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA" width="40%">&nbsp;�޲z���K�X:</td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="password" name="password1" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#E3E3EA" width="40%">&nbsp;���ƱK�X:</td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="password" name="password2" size="30"></td>
                </tr>
              </table>
              <br>
              <input type="hidden" name="action" value="install">
              <input type="submit" name="submit" value="�}�l�w�� Discuz!" style="height: 25" >&nbsp;
              <input type="button" name="exit" value="�h�X�w���Q��" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>

<?

	}	

} elseif($action == 'install') {

	$username = $HTTP_POST_VARS['username'];
	$email = $HTTP_POST_VARS['email'];
	$password1 = $HTTP_POST_VARS['password1'];
	$password2 = $HTTP_POST_VARS['password2'];

?>
        <tr>
          <td><b>���e���A�G</b><font color="#0000EE">�ˬd�޲z���㸹�H���ö}�l�w�� Discuz!�C</font></td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> �ˬd�޲z���㸹</font></b></td>
        </tr>
        <tr>
          <td>�ˬd�H���X�k��
<?

	$msg = '';
	if($username && $email && $password1 && $password2) {
		if($password1 != $password2) {
			$msg = "�⦸��J�K�X���@�P.";
		} elseif(strlen($username) > 15) {
			$msg = "�Τ�W�W�L 15 �Ӧr�ŭ���.";
		} elseif(preg_match("/^$|^c:\\con\\con$|�@|[,\"\s\t\<\>]|^�C��|^Guest/is", $username)) {
			$msg = "�Τ�W�ũΥ]�t�D�k�r��.";
		} elseif(!strstr($email, '@') || $email != stripslashes($email) || $email != htmlspecialchars($email)) {
			$msg = "Email �a�}�L��";
		}
	} else {
		$msg = '�z���H���S����g����.';
	}

	if($msg) { 

?>
            ... <font color="#FF0000">����. ��]: <?=$msg?></font></td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <input type="button" name="back" value="��^�W�@���ק�" onclick="javascript: history.go(-1);">
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td align="center">
            <b style="font-size: 11px">Powered by <a href="http://www.Discuz.net" target="_blank">Discuz! <?=$version?></a> , &nbsp; Copyright &copy; <a href="http://www.crossday.com" target=\"_blank\">Crossday Studio</a>, 2002</b>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>

<?

		exit;
	} else {
		echo result(1, 0)."</td>\n";
		echo"        </tr>\n";
	}

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> ��ܼƾڮw</font></b></td>
        </tr>
<?
	include './config.php';
	include './include/db_'.$database.'.php';
	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
	$db->select_db($dbname);

echo"        <tr>\n";
echo"          <td>��ܼƾڮw $dbname ".result(1, 0)."</td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";
echo"            <hr noshade align=\"center\" width=\"100%\" size=\"1\">\n";
echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td><b><font color=\"#FF0000\">&gt;</font><font color=\"#000000\"> �إ߼ƾڪ�</font></b></td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";

	$sql = <<<EOT
DROP TABLE IF EXISTS cdb_announcements;
CREATE TABLE cdb_announcements (
  id smallint(6) unsigned NOT NULL auto_increment,
  author varchar(15) NOT NULL default '',
  subject varchar(250) NOT NULL default '',
  starttime int(10) unsigned NOT NULL default '0',
  endtime int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (id)
);

DROP TABLE IF EXISTS cdb_attachments;
CREATE TABLE cdb_attachments (
  aid mediumint(8) unsigned NOT NULL auto_increment,
  tid mediumint(8) unsigned NOT NULL default '0',
  pid int(10) unsigned NOT NULL default '0',
  creditsrequire smallint(6) unsigned NOT NULL default '0',
  filename varchar(255) NOT NULL default '',
  filetype varchar(50) NOT NULL default '',
  filesize int(12) unsigned NOT NULL default '0',
  attachment varchar(255) NOT NULL default '',
  downloads smallint(6) NOT NULL default '0',
  PRIMARY KEY  (aid)
);

DROP TABLE IF EXISTS cdb_banned;
CREATE TABLE cdb_banned (
  id smallint(6) unsigned NOT NULL auto_increment,
  ip1 smallint(3) NOT NULL default '0',
  ip2 smallint(3) NOT NULL default '0',
  ip3 smallint(3) NOT NULL default '0',
  ip4 smallint(3) NOT NULL default '0',
  admin varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY ip1 (ip1),
  KEY ip2 (ip2),
  KEY ip3 (ip3),
  KEY ip4 (ip1)
);

DROP TABLE IF EXISTS cdb_buddys;
CREATE TABLE cdb_buddys (
  username varchar(15) NOT NULL default '',
  buddyname varchar(15) NOT NULL default ''
);

DROP TABLE IF EXISTS cdb_favorites;
CREATE TABLE cdb_favorites (
  tid mediumint(8) unsigned NOT NULL default '0',
  username varchar(15) NOT NULL default '',
  KEY tid (tid)
);

DROP TABLE IF EXISTS cdb_forumlinks;
CREATE TABLE cdb_forumlinks (
  id smallint(6) unsigned NOT NULL auto_increment,
  displayorder tinyint(3) NOT NULL default '0',
  name varchar(100) NOT NULL default '',
  url varchar(100) NOT NULL default '',
  note varchar(200) NOT NULL default '',
  logo varchar(100) NOT NULL default '',
  PRIMARY KEY  (id)
);

INSERT INTO cdb_forumlinks VALUES (1, 0, 'Discuz! Board', 'http://www.Discuz.net', '�����׾µ{�� Discuz! ���x�诸�I�A�M���Q�� Discuz! ���ϥλP Hack�A���ѽ׾¤ɯŻP�޳N������C', 'images/logo.gif');

DROP TABLE IF EXISTS cdb_forums;
CREATE TABLE cdb_forums (
  fid smallint(6) unsigned NOT NULL auto_increment,
  fup smallint(6) unsigned NOT NULL default '0',
  type enum('group','forum','sub') NOT NULL default 'forum',
  icon varchar(100) NOT NULL default '',
  name varchar(50) NOT NULL default '',
  description text NOT NULL,
  status tinyint(1) NOT NULL default '0',
  displayorder tinyint(3) NOT NULL default '0',
  moderator tinytext NOT NULL,
  styleid smallint(6) unsigned NOT NULL default '0',
  threads smallint(6) unsigned NOT NULL default '0',
  posts mediumint(8) unsigned NOT NULL default '0',
  lastpost varchar(130) NOT NULL default '',
  allowsmilies tinyint(1) NOT NULL default '0',
  allowhtml tinyint(1) NOT NULL default '0',
  allowbbcode tinyint(1) NOT NULL default '0',
  allowimgcode tinyint(1) NOT NULL default '0',
  password varchar(12) NOT NULL default '',
  postcredits tinyint(1) NOT NULL default '-1',
  viewperm tinytext NOT NULL,
  postperm tinytext NOT NULL,
  getattachperm tinytext NOT NULL,
  postattachperm tinytext NOT NULL,
  PRIMARY KEY  (fid),
  KEY status (status)
);

INSERT INTO cdb_forums VALUES (1, 0, 'forum', '', '�q�{�O��', '', 1, 0, '', 0, 0, 0, '', 1, 0, 1, 1, '', 0, '', '', '', '');

DROP TABLE IF EXISTS cdb_karmalog;
CREATE TABLE cdb_karmalog (
  username varchar(15) NOT NULL default '',
  pid int(10) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  score tinyint(3)  NOT NULL default '0'
);

DROP TABLE IF EXISTS cdb_members;
CREATE TABLE cdb_members (
  uid mediumint(8) unsigned NOT NULL auto_increment,
  username varchar(15) NOT NULL default '',
  password varchar(40) NOT NULL default '',
  gender tinyint(1) NOT NULL default '0',
  status enum('Member','Admin','SuperMod','Moderator','Banned','PostBanned','Inactive') NOT NULL default 'Member',
  regip varchar(15) NOT NULL default '',
  regdate int(10) unsigned NOT NULL default '0',
  lastvisit int(10) unsigned NOT NULL default '0',
  postnum smallint(6) unsigned NOT NULL default '0',
  credit int(10) NOT NULL default '0',
  charset varchar(10) NOT NULL default '',
  email varchar(60) NOT NULL default '',
  site varchar(75) NOT NULL default '',
  icq varchar(12) NOT NULL default '',
  oicq varchar(12) NOT NULL default '',
  yahoo varchar(40) NOT NULL default '',
  msn varchar(40) NOT NULL default '',
  location varchar(30) NOT NULL default '',
  bday date NOT NULL default '0000-00-00',
  bio text NOT NULL,
  avatar varchar(100) NOT NULL default '',
  signature text NOT NULL,
  customstatus varchar(20) NOT NULL default '',
  tpp tinyint(3) unsigned NOT NULL default '0',
  ppp tinyint(3) unsigned NOT NULL default '0',
  styleid smallint(6) unsigned NOT NULL default '0',
  dateformat varchar(10) NOT NULL default '',
  timeformat varchar(5) NOT NULL default '',
  showemail tinyint(1) NOT NULL default '0',
  newsletter tinyint(1) NOT NULL default '0',
  timeoffset char(3) NOT NULL default '',
  ignorepm text NOT NULL,
  newpm tinyint(1) NOT NULL default '0',
  pwdrecover varchar(30) NOT NULL default '',
  pwdrcvtime int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid),
  KEY username (username)
);


DROP TABLE IF EXISTS cdb_poll;
CREATE TABLE cdb_poll (
  pollid mediumint(8) unsigned NOT NULL auto_increment,
  tid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  multiple tinyint(1) NOT NULL default '0',
  options text NOT NULL,
  voters text NOT NULL,
  maxvotes smallint(6) unsigned NOT NULL default '0',
  totalvotes smallint(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (pollid),
  KEY tid (tid)
);

DROP TABLE IF EXISTS cdb_posts;
CREATE TABLE cdb_posts (
  fid smallint(6) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  pid int(10) unsigned NOT NULL auto_increment,
  aid mediumint(8) unsigned NOT NULL default '0',
  icon varchar(30) NOT NULL default '',
  author varchar(15) NOT NULL default '',
  subject varchar(100) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  message mediumtext NOT NULL,
  useip varchar(15) NOT NULL default '',
  usesig tinyint(1) NOT NULL default '0',
  bbcodeoff tinyint(1) NOT NULL default '0',
  smileyoff tinyint(1) NOT NULL default '0',
  parseurloff tinyint(1) NOT NULL default '0',
  rate smallint(6) NOT NULL default '0',
  ratetimes tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (pid),
  KEY fid (fid),
  KEY tid (tid,dateline),
  KEY dateline (dateline)
);

DROP TABLE IF EXISTS cdb_searchindex;
CREATE TABLE cdb_searchindex (
  keywords varchar(200) NOT NULL default '',
  results int(10) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  KEY dateline (dateline)
);

DROP TABLE IF EXISTS cdb_sessions;
CREATE TABLE cdb_sessions (
  sid varchar(8) binary NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  ipbanned tinyint(1) NOT NULL default '0',
  status enum('Guest','Member','Admin','SuperMod','Moderator','Banned','IPBanned','PostBanned','Inactive') NOT NULL default 'Guest',
  username varchar(15) NOT NULL default '',
  lastactivity int(10) unsigned NOT NULL default '0',
  groupid smallint(6) unsigned NOT NULL default '0',
  styleid smallint(6) unsigned NOT NULL default '0',
  action tinyint(1) unsigned NOT NULL default '0',
  fid smallint(6) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  KEY sid (sid)
) TYPE=HEAP MAX_ROWS=1000;

DROP TABLE IF EXISTS cdb_settings;
CREATE TABLE cdb_settings (
  bbname varchar(50) NOT NULL default '',
  regstatus tinyint(1) NOT NULL default '0',
  censoruser text NOT NULL,
  doublee tinyint(1) NOT NULL default '0',
  regverify tinyint(1) NOT NULL default '0',
  bbrules tinyint(1) NOT NULL default '0',
  bbrulestxt text NOT NULL,
  welcommsg tinyint(1) NOT NULL default '0',
  welcommsgtxt text NOT NULL,
  bbclosed tinyint(1) NOT NULL default '0',
  closedreason text NOT NULL,
  sitename varchar(50) NOT NULL default '',
  siteurl varchar(60) NOT NULL default '',
  moddisplay enum('flat','selectbox') NOT NULL default 'flat',
  styleid smallint(6) unsigned NOT NULL default '0',
  maxonlines smallint(6) unsigned NOT NULL default '0',
  floodctrl smallint(6) unsigned NOT NULL default '0',
  searchctrl smallint(6) unsigned NOT NULL default '0',
  hottopic tinyint(3) unsigned NOT NULL default '0',
  topicperpage tinyint(3) unsigned NOT NULL default '0',
  postperpage tinyint(3) unsigned NOT NULL default '0',
  memberperpage tinyint(3) unsigned NOT NULL default '0',
  maxpostsize mediumint(8) unsigned NOT NULL default '0',
  maxavatarsize tinyint(3) unsigned NOT NULL default '0',
  smcols tinyint(3) unsigned NOT NULL default '0',
  logincredits tinyint(3) unsigned NOT NULL default '0',
  postcredits tinyint(3) unsigned NOT NULL default '0',
  digestcredits tinyint(3) unsigned NOT NULL default '0',
  whosonlinestatus tinyint(1) NOT NULL default '0',
  vtonlinestatus tinyint(1) NOT NULL default '0',
  gzipcompress tinyint(1) NOT NULL default '0',
  hideprivate tinyint(1) NOT NULL default '0',
  fastpost tinyint(1) NOT NULL default '0',
  modshortcut tinyint(1) NOT NULL default '0',
  memliststatus tinyint(1) NOT NULL default '0',
  statstatus tinyint(1) NOT NULL default '0',
  debug tinyint(1) NOT NULL default '0',
  reportpost tinyint(1) NOT NULL default '0',
  bbinsert tinyint(1) NOT NULL default '0',
  smileyinsert tinyint(1) NOT NULL default '0',
  editedby tinyint(1) NOT NULL default '0',
  dotfolders tinyint(1) NOT NULL default '0',
  attachsave tinyint(1) NOT NULL default '0',
  attachimgpost tinyint(1) NOT NULL default '0',
  timeoffset varchar(5) NOT NULL default '',
  timeformat varchar(5) NOT NULL default '',
  dateformat varchar(10) NOT NULL default '',
  version varchar(100) NOT NULL default '',
  onlinerecord varchar(30) NOT NULL default '',
  totalmembers smallint(6) unsigned NOT NULL default '0',
  lastmember varchar(15) NOT NULL default ''
);

INSERT INTO cdb_settings VALUES ('Discuz! Board', 1, '', 1, 0, 0, '', 0, '', 0, '', 'Crossday Studio', 'http://www.crossday.com/', 'flat', 1, 1000, 15, 5, 10, 20, 10, 25, 10000, 0, 3, 0, 1, 10, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, '8', 'h:i A', 'Y-n-j', '2.0 <b style=\'color: #FF9900\'>COML</b>', '1	1040034649', 1, 'Crossday');

DROP TABLE IF EXISTS cdb_smilies;
CREATE TABLE cdb_smilies (
  id smallint(6) unsigned NOT NULL auto_increment,
  type enum('smiley','picon') NOT NULL default 'smiley',
  code varchar(10) NOT NULL default '',
  url varchar(30) NOT NULL default '',
  PRIMARY KEY  (id)
);

INSERT INTO cdb_smilies VALUES (1, 'smiley', ':)', 'smile.gif');
INSERT INTO cdb_smilies VALUES (2, 'smiley', ':(', 'sad.gif');
INSERT INTO cdb_smilies VALUES (3, 'smiley', ':D', 'biggrin.gif');
INSERT INTO cdb_smilies VALUES (4, 'smiley', ';)', 'wink.gif');
INSERT INTO cdb_smilies VALUES (5, 'smiley', ':cool:', 'cool.gif');
INSERT INTO cdb_smilies VALUES (6, 'smiley', ':mad:', 'mad.gif');
INSERT INTO cdb_smilies VALUES (7, 'smiley', ':o', 'shocked.gif');
INSERT INTO cdb_smilies VALUES (8, 'smiley', ':P', 'tongue.gif');
INSERT INTO cdb_smilies VALUES (9, 'smiley', ':lol:', 'lol.gif');
INSERT INTO cdb_smilies VALUES (10, 'picon', '', 'icon1.gif');
INSERT INTO cdb_smilies VALUES (11, 'picon', '', 'icon2.gif');
INSERT INTO cdb_smilies VALUES (12, 'picon', '', 'icon3.gif');
INSERT INTO cdb_smilies VALUES (13, 'picon', '', 'icon4.gif');
INSERT INTO cdb_smilies VALUES (14, 'picon', '', 'icon5.gif');
INSERT INTO cdb_smilies VALUES (15, 'picon', '', 'icon6.gif');
INSERT INTO cdb_smilies VALUES (16, 'picon', '', 'icon7.gif');
INSERT INTO cdb_smilies VALUES (17, 'picon', '', 'icon8.gif');
INSERT INTO cdb_smilies VALUES (18, 'picon', '', 'icon9.gif');

DROP TABLE IF EXISTS cdb_stats;
CREATE TABLE cdb_stats (
  type varchar(20) NOT NULL default '',
  var varchar(20) NOT NULL default '',
  count int(10) unsigned NOT NULL default '0',
  KEY type (type),
  KEY var (var)
);

INSERT INTO cdb_stats VALUES ('total', 'hits', 0);
INSERT INTO cdb_stats VALUES ('total', 'members', 0);
INSERT INTO cdb_stats VALUES ('total', 'guests', 0);
INSERT INTO cdb_stats VALUES ('os', 'Windows', 0);
INSERT INTO cdb_stats VALUES ('os', 'Mac', 0);
INSERT INTO cdb_stats VALUES ('os', 'Linux', 0);
INSERT INTO cdb_stats VALUES ('os', 'FreeBSD', 0);
INSERT INTO cdb_stats VALUES ('os', 'SunOS', 0);
INSERT INTO cdb_stats VALUES ('os', 'BeOS', 0);
INSERT INTO cdb_stats VALUES ('os', 'OS/2', 0);
INSERT INTO cdb_stats VALUES ('os', 'AIX', 0);
INSERT INTO cdb_stats VALUES ('os', 'Other', 0);
INSERT INTO cdb_stats VALUES ('browser', 'MSIE', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Netscape', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Mozilla', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Lynx', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Opera', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Konqueror', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Other', 0);
INSERT INTO cdb_stats VALUES ('week', '0', 0);
INSERT INTO cdb_stats VALUES ('week', '1', 0);
INSERT INTO cdb_stats VALUES ('week', '2', 0);
INSERT INTO cdb_stats VALUES ('week', '3', 0);
INSERT INTO cdb_stats VALUES ('week', '4', 0);
INSERT INTO cdb_stats VALUES ('week', '5', 0);
INSERT INTO cdb_stats VALUES ('week', '6', 0);
INSERT INTO cdb_stats VALUES ('hour', '00', 0);
INSERT INTO cdb_stats VALUES ('hour', '01', 0);
INSERT INTO cdb_stats VALUES ('hour', '02', 0);
INSERT INTO cdb_stats VALUES ('hour', '03', 0);
INSERT INTO cdb_stats VALUES ('hour', '04', 0);
INSERT INTO cdb_stats VALUES ('hour', '05', 0);
INSERT INTO cdb_stats VALUES ('hour', '06', 0);
INSERT INTO cdb_stats VALUES ('hour', '07', 0);
INSERT INTO cdb_stats VALUES ('hour', '08', 0);
INSERT INTO cdb_stats VALUES ('hour', '09', 0);
INSERT INTO cdb_stats VALUES ('hour', '10', 0);
INSERT INTO cdb_stats VALUES ('hour', '11', 0);
INSERT INTO cdb_stats VALUES ('hour', '12', 0);
INSERT INTO cdb_stats VALUES ('hour', '13', 0);
INSERT INTO cdb_stats VALUES ('hour', '14', 0);
INSERT INTO cdb_stats VALUES ('hour', '15', 0);
INSERT INTO cdb_stats VALUES ('hour', '16', 0);
INSERT INTO cdb_stats VALUES ('hour', '17', 0);
INSERT INTO cdb_stats VALUES ('hour', '18', 0);
INSERT INTO cdb_stats VALUES ('hour', '19', 0);
INSERT INTO cdb_stats VALUES ('hour', '20', 0);
INSERT INTO cdb_stats VALUES ('hour', '21', 0);
INSERT INTO cdb_stats VALUES ('hour', '22', 0);
INSERT INTO cdb_stats VALUES ('hour', '23', 0);

DROP TABLE IF EXISTS cdb_styles;
CREATE TABLE cdb_styles (
  styleid smallint(6) unsigned NOT NULL auto_increment,
  name varchar(20) NOT NULL default '',
  available tinyint(1) NOT NULL default '1',
  templateid smallint(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (styleid),
  KEY themename (name)
);

INSERT INTO cdb_styles VALUES (1, 'Default Style', 1, 1);

DROP TABLE IF EXISTS cdb_stylevars;
CREATE TABLE cdb_stylevars (
  stylevarid smallint(6) unsigned NOT NULL auto_increment,
  styleid smallint(6) unsigned NOT NULL default '0',
  variable text NOT NULL,
  substitute text NOT NULL,
  PRIMARY KEY  (stylevarid),
  KEY styleid (styleid)
);

INSERT INTO cdb_stylevars VALUES (1, 1, 'bgcolor', 'bg.gif');
INSERT INTO cdb_stylevars VALUES (2, 1, 'altbg1', '#F8F8F8');
INSERT INTO cdb_stylevars VALUES (3, 1, 'altbg2', '#FFFFFF');
INSERT INTO cdb_stylevars VALUES (4, 1, 'link', '#003366');
INSERT INTO cdb_stylevars VALUES (5, 1, 'bordercolor', '#000000');
INSERT INTO cdb_stylevars VALUES (6, 1, 'headercolor', 'headerbg.gif');
INSERT INTO cdb_stylevars VALUES (7, 1, 'headertext', '#FFFFFF');
INSERT INTO cdb_stylevars VALUES (8, 1, 'catcolor', 'catbg.gif');
INSERT INTO cdb_stylevars VALUES (9, 1, 'tabletext', '#000000');
INSERT INTO cdb_stylevars VALUES (10, 1, 'text', '#000000');
INSERT INTO cdb_stylevars VALUES (11, 1, 'borderwidth', '1');
INSERT INTO cdb_stylevars VALUES (12, 1, 'tablewidth', '98%');
INSERT INTO cdb_stylevars VALUES (13, 1, 'tablespace', '4');
INSERT INTO cdb_stylevars VALUES (14, 1, 'font', 'Tahoma, Verdana');
INSERT INTO cdb_stylevars VALUES (15, 1, 'fontsize', '12px');
INSERT INTO cdb_stylevars VALUES (16, 1, 'nobold', '0');
INSERT INTO cdb_stylevars VALUES (17, 1, 'boardimg', 'logo.gif');
INSERT INTO cdb_stylevars VALUES (18, 1, 'imgdir', 'images/default');
INSERT INTO cdb_stylevars VALUES (19, 1, 'smdir', 'images/smilies');
INSERT INTO cdb_stylevars VALUES (20, 1, 'cattext', '#000000');
INSERT INTO cdb_stylevars VALUES (21, 1, 'smfontsize', '11px');
INSERT INTO cdb_stylevars VALUES (22, 1, 'smfont', 'Arial');

DROP TABLE IF EXISTS cdb_subscriptions;
CREATE TABLE cdb_subscriptions (
  username varchar(15) NOT NULL default '',
  email varchar(60) NOT NULL default '',
  tid mediumint(8) unsigned NOT NULL default '0',
  lastnotify int(10) unsigned NOT NULL default '0',
  KEY username (username),
  KEY tid (tid)
);

DROP TABLE IF EXISTS cdb_templates;
CREATE TABLE cdb_templates (
  templateid smallint(6) unsigned NOT NULL auto_increment,
  name varchar(30) NOT NULL default '',
  charset varchar(30) NOT NULL default '',
  directory varchar(100) NOT NULL default '',
  copyright varchar(100) NOT NULL default '',
  PRIMARY KEY  (templateid)
);

INSERT INTO cdb_templates VALUES (1, 'Default', 'gb2312', './templates/default', 'Designed by Laogui(lgvbb.126.com)');

DROP TABLE IF EXISTS cdb_threads;
CREATE TABLE cdb_threads (
  tid mediumint(8) unsigned NOT NULL auto_increment,
  fid smallint(6) NOT NULL default '0',
  creditsrequire smallint(6) unsigned NOT NULL default '0',
  icon varchar(30) NOT NULL default '',
  author varchar(15) NOT NULL default '',
  subject varchar(100) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  lastposter varchar(15) NOT NULL default '',
  views smallint(6) unsigned NOT NULL default '0',
  replies smallint(6) unsigned NOT NULL default '0',
  topped tinyint(1) NOT NULL default '0',
  digest tinyint(1) NOT NULL default '0',
  closed varchar(15) NOT NULL default '',
  pollopts text NOT NULL,
  attachment varchar(50) NOT NULL default '',
  PRIMARY KEY  (tid),
  KEY lastpost (topped,lastpost,fid)
);

DROP TABLE IF EXISTS cdb_pm;
CREATE TABLE cdb_pm (
  pmid int(10) unsigned NOT NULL auto_increment,
  msgto varchar(15) NOT NULL default '',
  msgfrom varchar(15) NOT NULL default '',
  folder enum('inbox','outbox') NOT NULL default 'inbox',
  new tinyint(1) NOT NULL default '0',
  subject varchar(75) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (pmid),
  KEY msgto (msgto)
);

DROP TABLE IF EXISTS cdb_usergroups;
CREATE TABLE cdb_usergroups (
  groupid smallint(6) unsigned NOT NULL auto_increment,
  specifiedusers text NOT NULL,
  status enum('Guest','Member','Admin','SuperMod','Moderator','Banned','IPBanned','PostBanned','Inactive') NOT NULL default 'Member',
  grouptitle varchar(30) NOT NULL default '',
  creditshigher int(10) NOT NULL default '0',
  creditslower int(10) NOT NULL default '0',
  stars tinyint(3) NOT NULL default '0',
  groupavatar varchar(60) NOT NULL default '',
  allowcstatus tinyint(1) NOT NULL default '0',
  allowavatar tinyint(1) NOT NULL default '0',
  allowvisit tinyint(1) NOT NULL default '0',
  allowview tinyint(1) NOT NULL default '0',
  allowpost tinyint(1) NOT NULL default '0',
  allowpostpoll tinyint(1) NOT NULL default '0',
  allowgetattach tinyint(1) NOT NULL default '0',
  allowpostattach tinyint(1) NOT NULL default '0',
  allowvote tinyint(1) NOT NULL default '0',
  allowsearch tinyint(1) NOT NULL default '0',
  allowkarma tinyint(1) NOT NULL default '0',
  allowsetviewperm tinyint(1) NOT NULL default '0',
  allowsetattachperm tinyint(1) NOT NULL default '0',
  allowsigbbcode tinyint(1) NOT NULL default '0',
  allowsigimgcode tinyint(1) NOT NULL default '0',
  allowviewstats tinyint(1) NOT NULL default '0',
  ismoderator tinyint(1) NOT NULL default '0',
  issupermod tinyint(1) NOT NULL default '0',
  isadmin tinyint(1) NOT NULL default '0',
  maxpmnum smallint(6) unsigned NOT NULL default '0',
  maxmemonum smallint(6) unsigned NOT NULL default '0',
  maxsigsize smallint(6) unsigned NOT NULL default '0',
  maxkarmarate tinyint(3) unsigned NOT NULL default '0',
  maxrateperday smallint(6) unsigned NOT NULL default '0',
  maxattachsize int(10) unsigned NOT NULL default '0',
  attachextensions tinytext NOT NULL,
  PRIMARY KEY  (groupid),
  KEY status (status),
  KEY creditshigher (creditshigher),
  KEY creditslower (creditslower)
);

INSERT INTO cdb_usergroups VALUES (1, '', 'Guest', 'Guest', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (2, '', 'IPBanned', 'IP Banned', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (3, '', 'Banned', 'Banned', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (4, '', 'PostBanned', 'Banned to Post', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (5, '', 'Inactive', 'Inactive Member', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 50, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (6, '', 'Moderator', 'Moderator', 0, 0, 7, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 0, 0, 80, 0, 200, 10, 30, 2048000, '');
INSERT INTO cdb_usergroups VALUES (7, '', 'SuperMod', 'Super Moderator', 0, 0, 8, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 0, 120, 0, 300, 15, 50, 2048000, '');
INSERT INTO cdb_usergroups VALUES (8, '', 'Admin', 'Administrator', 0, 0, 9, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 200, 0, 500, 30, 500, 2048000, '');
INSERT INTO cdb_usergroups VALUES (9, '', 'Member', 'King', 1000, 3000, 6, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 0, 0, 0, 80, 0, 300, 15, 40, 1024000, '');
INSERT INTO cdb_usergroups VALUES (10, '', 'Member', 'Forum Legend', 3000, 9999999, 8, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 0, 500, 20, 50, 2048000, '');
INSERT INTO cdb_usergroups VALUES (11, '', 'Member', 'Lord', 500, 1000, 4, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 0, 1, 0, 1, 0, 0, 0, 60, 0, 200, 10, 30, 512000, 'zip,rar,chm,txt,gif,jpg,png');
INSERT INTO cdb_usergroups VALUES (12, '', 'Member', 'Beggar', -9999999, 0, 0, '', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (13, '', 'Member', 'Conqueror', 200, 500, 3, '', 0, 2, 1, 1, 1, 1, 1, 0, 1, 2, 0, 0, 0, 1, 0, 1, 0, 0, 0, 50, 0, 150, 6, 15, 256000, 'gif,jpg,png');
INSERT INTO cdb_usergroups VALUES (14, '', 'Member', 'Member', 50, 200, 2, '', 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 30, 0, 100, 4, 10, 0, '');
INSERT INTO cdb_usergroups VALUES (15, '', 'Member', 'Newbie', 0, 50, 1, '', 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 20, 0, 80, 0, 0, 0, '');

DROP TABLE IF EXISTS cdb_words;
CREATE TABLE cdb_words (
  id smallint(6) unsigned NOT NULL auto_increment,
  find varchar(60) NOT NULL default '',
  replacement varchar(60) NOT NULL default '',
  PRIMARY KEY  (id)
);

EOT;

	runquery($sql);
	$db->query("DELETE FROM {$tablepre}members");
	$db->query("INSERT INTO {$tablepre}members (username, password, status, regip, regdate, lastvisit, email, dateformat, timeformat, showemail, newsletter, timeoffset)
		VALUES ('$username', '".md5($password1)."', 'Admin', 'hidden', '".time()."', '".time()."', '$email', 'Y-n-j', 'h:i A', '1', '1', '8');");

echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";
echo"            <hr noshade align=\"center\" width=\"100%\" size=\"1\">\n";
echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td><b><font color=\"#FF0000\">&gt;</font><font color=\"#000000\"> ��l�ƹB��ؿ��P���</font></b></td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";

loginit('karmalog');
loginit('illegallog');
loginit('modslog');
loginit('cplog');
dir_clear('./forumdata/templates');
dir_clear('./forumdata/cache');

?>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td align="center">
            <font color="#FF0000"><b>���߱z�ADiscuz! �w�˦��\�I</font><br>
            �޲z���㸹�G</b><?=$username?><b> �K�X�G</b><?=$password1?><br><br>
            <a href="index.php" target="_blank">�I���o�̶i�J�׾�</a>
          </td>
        </tr>
<?

}

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td align="center">
            <b style="font-size: 11px">Powered by <a href="http://www.Discuz.net" target="_blank">Discuz! <?=$version?></a> , &nbsp; Copyright &copy; <a href="http://www.crossday.com" target=\"_blank\">Crossday Studio</a>, 2002</b>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>

