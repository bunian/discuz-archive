<?php

// Action Pack for Discuz! Version 1.0.0
// Translated by Crossday

$actioncode = array
(
	0 => 'Back to board',

	1 => 'View Main Index',
	2 => 'View Forums',
	3 => 'View Thread',
	5 => 'Register',
	6 => 'Log in',
	7 => 'Member CP',

	11 => 'Post New Thread',
	12 => 'Post Reply',
	13 => 'Edit Post',
	14 => 'Download Attchment',

	21 => 'View Announcements',
	31 => 'View Online List',
	41 => 'View Members List',
	51 => 'View FAQ',

	101 => 'View Member Profile',

	111 => 'Search Board',
	112 => 'Search Board',
	121 => 'Rate',
	122 => 'Email to Friend',
	123 => 'Report Post',

	131 => 'View Statistics',
	141 => 'Get Password',
	151 => 'Moderate',
	161 => 'Admin CP',

	201 => 'Private Messages',

	255 => 'Message/Forward'
);

?>