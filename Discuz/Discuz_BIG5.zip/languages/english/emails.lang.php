<?php

// Email Pack for Discuz! Version 1.0.0
// Translated by Crossday

$language = array
(
	'get_passwd_subject' =>		'[Discuz!] Email for Taking Back Your Password',
	'get_passwd_content' =>		'Hello, $member[username]��This is email sent by  $bbname system\n'.
					'Please visit the following link to modify your password.\n'.
					'{$boardurl}member.php?action=getpasswd&id=$newpass\n'.
					'Welcome back to $bbname\n'.
					'$boardurl',

	'email_verify_subject' =>	'[Discuz!] Email for Verifying Your Address',
	'email_verify_content' =>	'You have modified your email address in $bbname [ $boardurl ],\n'.
					'this is the confirmation e-mail sent by system, please note down the following information:\n'.
					'Username: $discuz_user\n'.
					'Password: $newpassword\n'.
					'You can modify this password after logged in.\n'.
					'Thanks a lot for your trust and support,welcome back to $bbname.',

	'activation_subject' =>		'[Discuz!] Your Account was Activated',
	'activation_content' =>		'Your application for $bbname [ $boardurl ] has been accepted,\n'.
					'Please login with the following account:\n'.
					'Username: $username\n'.
					'Password: $password2\n'.
					'You can change your password after logged in.\n'.
					'Thanks a lot for your trust and support, welcome to $bbname.',

	'email_notify_subject' =>	'[Discuz!] $thread[subject] Had New Reply(s)',
	'email_notify_content' =>	'Hello, $username has replied the subject you have subscribed to in $bbname,\n'.
					'please visit the following for more details:\n'.
					'{$boardurl}viewthread.php?tid=$tid\n'.
					'We will not send this notification in 12 hours\n'.
					'Welcome back to $bbname\n'.
					'$boardurl'
);

?>