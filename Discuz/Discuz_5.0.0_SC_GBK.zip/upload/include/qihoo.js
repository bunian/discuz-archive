

var qihoo_num = 0;
var qihoo_perpage = 0;
var qihoo_threads = "";

function qihoothreads(num) {
	var threadslist = "";
	if(num) {
		for(i = 0; i < num; i++) {
			threadslist += "<tr><td class=\"altbg2\"><a href=\"viewthread.php?tid=" + qihoo_threads[i][1] + "\" target=\"_blank\">" + qihoo_threads[i][0] + "</a></td>" +
				"<td class=\"altbg1\" align=\"center\"><a href=\"forumdisplay.php?fid=" + qihoo_threads[i][8] + "\" target=\"_blank\">" + qihoo_threads[i][2] + "</a></td>" +
				"<td class=\"altbg2\" align=\"center\"><a href=\"viewpro.php?username=" + qihoo_threads[i][3] + "\" target=\"_blank\">" + qihoo_threads[i][3] + "</a><br>" + qihoo_threads[i][6] + "</td>" +
				"<td class=\"altbg1\" align=\"center\">" + qihoo_threads[i][4] + "</td>" +
				"<td class=\"altbg2\" align=\"center\">" + qihoo_threads[i][5] + "</td>" +
				"<td class=\"altbg1\" align=\"center\">" + qihoo_threads[i][7] + "</td></tr>";
		}
	}
	return threadslist;
}

function multi(num, perpage, curpage, mpurl, maxpages) {
	var multipage = "";
	if(num > perpage) {
		var page = 10;
		var offset = 2;
		var form = 0;
		var to = 0;
		var maxpages = !maxpages ? 0 : maxpages;

		var realpages = Math.ceil(num / perpage);
		var pages = maxpages && maxpages < realpages ? maxpages : realpages;

		if(page > pages) {
			from = 1;
			to = pages;
		} else {
			from = curpage - offset;
			to = from + page - 1;
			if(from < 1) {
				to = curpage + 1 - from;
				from = 1;
				if(to - from < page) {
					to = page;
				}
			} else if(to > pages) {
				from = pages - page + 1;
				to = pages;
			}
		}

		multipage = (curpage - offset > 1 && pages > page ? "<a class=\"p_redirect\" href=\"" + mpurl + "&page=1\">|&lsaquo;</a>" : "") + (curpage > 1 ? "<a class=\"p_redirect\" href=\"" + mpurl + "&page=" + (curpage - 1) + "\">&lsaquo;&lsaquo;</a>" : "");
		for(i = from; i <= to; i++) {
			multipage += (i == curpage ? "<a class=\"p_curpage\">" + i + "</a>" : "<a href=\"" + mpurl + "&page=" + i + "\" class=\"p_num\">" + i + "</a>");
		}

		multipage += (curpage < pages ? "<a class=\"p_redirect\" href=\"" + mpurl + "\"page=" + (curpage + 1) + "\">&rsaquo;&rsaquo;</a>" : "") +
		(to < pages ? "<a class=\"p_redirect\" href=\"" + mpurl + "&page=" + pages + "\>&rsaquo;|</a>" : "") +
		(curpage == maxpages ? "<a class=\"p_redirect\" href=\"misc.php?action=maxpages&amp;pages=" + maxpages + "\">&rsaquo;?</a>" : "") +
		(pages > page ? "<a class=\"p_pages\" style=\"padding: 0px\"><input class=\"p_input\" type=\"text\" name=\"custompage\" onKeyDown=\"if(event.keyCode==13) {window.location='" + mpurl + "&page=\'+this.value;}\"></a>" : "");
		multipage = "<div class=\"p_bar\"><a class=\"p_total\">&nbsp;" + num + "&nbsp;</a><a class=\"p_pages\">&nbsp;" + curpage + "/" + realpages + "&nbsp;</a>" + multipage + "</div>";

	}
	return multipage;
}