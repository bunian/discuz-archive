<?php

/*
[Discuz!] (C)2001-2006 Comsenz Inc.
This is NOT a freeware, use is subject to license terms

$RCSfile: pushthreads_weekly.inc.php,v $
$Revision: 1.5 $
$Date: 2006/07/25 01:59:25 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$query = $db->query("SELECT max(id) FROM {$tablepre}pushedthreads");
$maxid = intval($db->result($query, 0));

$charsetenc = rawurlencode($charset);
$bbnameenc = rawurlencode($bbname);
$boardurlenc = rawurlencode($boardurl);
$md5hash = md5($boardurl.$bbname.$maxid);

$data = @implode('', file("http://customer.discuz.net/api/pushthreads.php?maxid=$maxid&ocs=$charsetenc&siteurl=$boardurlenc&sitename=$bbnameenc&md5hash=$md5hash"));

if($data) {
	$chs = '';
	if($charset != 'utf-8') {
		require_once DISCUZ_ROOT.'./include/chinese.class.php';
		$chs = new Chinese('utf-8', $charset);
	}

	$parser = xml_parser_create();
	xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
	xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
	xml_parse_into_struct($parser, $data, $values, $index);
	xml_parser_free($parser);

	$threadlist = array();
	if(is_array($index['tid'])) {
		foreach($index['tid'] as $k=>$v) {
			$threadlist[$k]['tid'] = $values[$v]['value'];
			$threadlist[$k]['subject'] = $chs->convert($values[$index['subject'][$k]]['value']);
			$threadlist[$k]['message'] = $chs->convert($values[$index['message'][$k]]['value']);
			$threadlist[$k]['dateline'] = $values[$index['dateline'][$k]]['value'];
		}
	}
	if(is_array($threadlist)) {
		foreach($threadlist as $thread) {
			if($thread['tid'] = intval($thread['tid'])) {
				$thread['subject'] = addslashes($thread['subject']);
				$thread['message'] = addslashes($thread['message']);
				$thread['dateline'] = intval($thread['dateline']);
				$db->query("REPLACE INTO {$tablepre}pushedthreads (id, tid, status, subject, message, dateline)
					VALUES ('$thread[tid]', '0', 0, '$thread[subject]', '$thread[message]', '$thread[dateline]')", 'SILENT');
			}
		}
	}
}

?>