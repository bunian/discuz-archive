<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: misc.php,v $
	$Revision: 1.80.2.2 $
	$Date: 2006/10/27 09:04:11 $
*/

require_once './include/common.inc.php';

if($action == 'maxpages') {

	$pages = intval($pages);
	if(empty($pages)) {
		showmessage('undefined_action', NULL, 'HALTED');
	} else {
		showmessage('max_pages');
	}

} elseif($action == 'customtopics') {

	if(!submitcheck('keywordsubmit', 1)) {

		if($_DCOOKIE['customkw']) {
			$customkwlist = array();
			foreach(explode("\t", trim($_DCOOKIE['customkw'])) as $key => $keyword) {
				$keyword = dhtmlspecialchars(trim(stripslashes($keyword)));
				$customkwlist[$key]['keyword'] = $keyword;
				$customkwlist[$key]['url'] = '<a href="topic.php?keyword='.rawurlencode($keyword).'" target="_blank">'.$keyword.'</a> ';
			}
		}

		include template('customtopics');

	} else {

		if(!empty($delete) && is_array($delete)) {
			$keywords = implode("\t", array_diff(explode("\t", $_DCOOKIE['customkw']), $delete));
		} else {
			$keywords = $_DCOOKIE['customkw'];
		}

		if($newkeyword = cutstr(dhtmlspecialchars(preg_replace("/[\s\|\t\,\'\<\>]/", '', $newkeyword)), 20)) {
			if($_DCOOKIE['customkw']) {
				if(!preg_match("/(^|\t)".preg_quote($newkeyword, '/')."($|\t)/i", $keywords)) {
					if(count(explode("\t", $keywords)) >= $qihoo_maxtopics) {
						$keywords = substr($keywords, (strpos($keywords, "\t") + 1))."\t".$newkeyword;
					} else {
						$keywords .= "\t".$newkeyword;
					}
				}
			} else {
				$keywords = $newkeyword;
			}
		}

		dsetcookie('customkw', stripslashes($keywords), 315360000);
		header("Location: {$boardurl}misc.php?action=customtopics");

	}

} else {

	if(empty($forum['allowview'])) {
		if(!$forum['viewperm'] && !$readaccess) {
			showmessage('group_nopermission', NULL, 'NOPERM');
		} elseif($forum['viewperm'] && !forumperm($forum['viewperm'])) {
			showmessage('forum_nopermission', NULL, 'NOPERM');
		}
	} elseif($thread['readperm'] && $thread['readperm'] > $readaccess && !$forum['ismoderator'] && $thread['authorid'] != $discuz_uid) {
		showmessage('thread_nopermission', NULL, 'NOPERM');
	}

	$query = $db->query("SELECT * FROM {$tablepre}threads WHERE tid='$tid' AND displayorder>='0'");
	if(!$thread = $db->fetch_array($query)) {
		showmessage('thread_nonexistence');
	}

	if($forum['type'] == 'forum') {
		$navigation = "&raquo; <a href=\"forumdisplay.php?fid=$fid\">$forum[name]</a> &raquo; <a href=\"viewthread.php?tid=$tid\">$thread[subject]</a> ";
		$navtitle = strip_tags($forum['name']).' - '.$thread['subject'];
	} elseif($forum['type'] == 'sub') {
		$query = $db->query("SELECT name, fid FROM {$tablepre}forums WHERE fid='$forum[fup]'");
		$fup = $db->fetch_array($query);
		$navigation = "&raquo; <a href=\"forumdisplay.php?fid=$fup[fid]\">$fup[name]</a> &raquo; <a href=\"forumdisplay.php?fid=$fid\">$forum[name]</a> &raquo; <a href=\"viewthread.php?tid=$tid\">$thread[subject]</a> ";
		$navtitle = strip_tags($fup['name']).' - '.strip_tags($forum['name']).' - '.$thread['subject'];
	}

}

if($action == 'votepoll' && submitcheck('pollsubmit')) {

	if(!$allowvote) {
		showmessage('group_nopermission', NULL, 'NOPERM');
	}

	if(!empty($thread['closed'])) {
		showmessage('thread_poll_closed');
	}

	if(empty($pollanswers)) {
		showmessage('thread_poll_invalid');
	}

	$query = $db->query("SELECT maxchoices, expiration FROM {$tablepre}polls WHERE tid='$tid'");
	if(!$pollarray = $db->fetch_array($query)) {
		showmessage('undefined_action', NULL, 'HALTED');
	} elseif($pollarray['expiration'] && $pollarray['expiration'] < $timestamp) {
		showmessage('poll_overdue');
	} elseif($pollarray['maxchoices'] && $pollarray['maxchoices'] < count($pollanswers)) {
		showmessage('poll_choose_most');
	}

	$voterids = $discuz_uid ? $discuz_uid : $onlineip;

	$query = $db->query("SELECT polloptionid, voterids FROM {$tablepre}polloptions WHERE tid='$tid'");
	while($pollarray = $db->fetch_array($query)) {
		if(strexists("\t".$pollarray['voterids']."\t", "\t".$voterids."\t")) {
			showmessage('thread_poll_voted');
		}
		$polloptionid[] = $pollarray['polloptionid'];
	}

	$polloptionids = '';
	foreach($pollanswers as $key => $id) {
		if(!in_array($id, $polloptionid)) {
			showmessage('undefined_action', NULL, 'HALTED');
		}
		unset($polloptionid[$key]);
		$polloptionids[] = $id;
	}

	$pollanswers = implode('\',\'', $polloptionids);

	$db->query("UPDATE {$tablepre}polloptions SET votes=votes+1, voterids=CONCAT(voterids,'$voterids\t') WHERE polloptionid IN ('$pollanswers')", 'UNBUFFERED');
	$db->query("UPDATE {$tablepre}threads SET lastpost='$timestamp' WHERE tid='$tid'", 'UNBUFFERED');

	updatecredits($discuz_uid, $creditspolicy['votepoll']);

	showmessage('thread_poll_succeed', "viewthread.php?tid=$tid");

} elseif($action == 'emailfriend') {

	if(!$discuz_uid) {
		showmessage('not_loggedin', NULL, 'NOPERM');
	}

	$discuz_action = 122;

	if(!submitcheck('sendsubmit')) {

		$threadurl = "{$boardurl}viewthread.php?tid=$tid";

		$query = $db->query("SELECT email FROM {$tablepre}members WHERE uid='$discuz_uid'");
		$email = $db->result($query, 0);

		include template('emailfriend');

	} else {

		if(empty($fromname) || empty($fromemail) || empty($sendtoname) || empty($sendtoemail)) {
			showmessage('email_friend_invalid');
		}

		sendmail($sendtoemail, 'email_to_friend_subject', 'email_to_friend_message', "$fromname <$fromemail>");

		showmessage('email_friend_succeed', "viewthread.php?tid=$tid");

	}

} elseif($action == 'rate' && $pid) {

	if(!$raterange) {
		showmessage('group_nopermission', NULL, 'NOPERM');
	} elseif($modratelimit && $adminid == 3 && !$forum['ismoderator']) {
		showmessage('thread_rate_moderator_invalid');
	}

	$reasonpmcheck = $reasonpm == 2 || $reasonpm == 3 ? 'checked disabled' : '';
	if(($reasonpm == 2 || $reasonpm == 3) || !empty($sendreasonpm)) {
		$forumname = strip_tags($forum['name']);
		$sendreasonpm = 1;
	} else {
		$sendreasonpm = 0;
	}

	foreach($raterange as $id => $rating) {
		$maxratetoday[$id] = $rating['mrpd'];
	}

	//maxratetoday: how much quota of rating left today
	$query = $db->query("SELECT extcredits, SUM(ABS(score)) AS todayrate FROM {$tablepre}ratelog
		WHERE uid='$discuz_uid' AND dateline>=$timestamp-86400
		GROUP BY extcredits");
	while($rate = $db->fetch_array($query)) {
		$maxratetoday[$rate['extcredits']] = $raterange[$rate['extcredits']]['mrpd'] - $rate['todayrate'];
	}

	$query = $db->query("SELECT * FROM {$tablepre}posts WHERE pid='$pid' AND invisible='0' AND authorid<>'0'");
	if(!($post = $db->fetch_array($query)) || $post['tid'] != $thread['tid'] || !$post['authorid']) {
		showmessage('undefined_action');
	} elseif(!$forum['ismoderator'] && $karmaratelimit && $timestamp - $post['dateline'] > $karmaratelimit * 3600) {
		showmessage('thread_rate_timelimit');
	} elseif($post['authorid'] == $discuz_uid || $post['tid'] != $tid) {
		showmessage('thread_rate_member_invalid');
	} elseif($post['anonymous']) {
		showmessage('thread_rate_anonymous');
	}

	if(!$dupkarmarate) {
		$query = $db->query("SELECT pid FROM {$tablepre}ratelog WHERE uid='$discuz_uid' AND pid='$pid' LIMIT 1");
		if($db->num_rows($query)) {
			showmessage('thread_rate_duplicate');
		}
	}

	$discuz_action = 71;

	$page = intval($page);

	if(!submitcheck('ratesubmit')) {

		$referer = $boardurl.'viewthread.php?tid='.$tid.'&page='.$page.'#pid'.$pid;

		$ratelist = array();
		foreach($raterange as $id => $rating) {
			if(isset($extcredits[$id])) {
				$ratelist[$id] = '';
				$offset = abs(ceil(($rating['max'] - $rating['min']) / 32));
				for($vote = $rating['min']; $vote <= $rating['max']; $vote += $offset) {
					$ratelist[$id] .= $vote ? '<option value="'.$vote.'">'.($vote > 0 ? '+'.$vote : $vote).'</option>' : '';
				}
			}
		}

		include template('rate');

	} else {

		require_once DISCUZ_ROOT.'./include/misc.func.php';
		checkreasonpm();

		$rate = $ratetimes = 0;
		$creditsarray = array();
		foreach($raterange as $id => $rating) {
			$score = intval(${'score'.$id});
			if(isset($extcredits[$id]) && !empty($score)) {
				if(abs($score) <= $maxratetoday[$id]) {
					if($score > $rating['max'] || $score < $rating['min']) {
						showmessage('thread_rate_range_invalid');
					} else {
						$creditsarray[$id] = $score;
						$rate += $score;
						$ratetimes += ceil(max(abs($rating['min']), abs($rating['max'])) / 5);
					}
				} else {
					showmessage('thread_rate_ctrl');
				}
			}
		}

		if(!$creditsarray) {
			showmessage('thread_rate_range_invalid');
		}

		updatecredits($post['authorid'], $creditsarray);

		$db->query("UPDATE {$tablepre}posts SET rate=rate+($rate), ratetimes=ratetimes+$ratetimes WHERE pid='$pid'");
		if($post['first']) {
			$threadrate = intval(@($post['rate'] + $rate) / abs($post['rate'] + $rate));
			$db->query("UPDATE {$tablepre}threads SET rate='$threadrate' WHERE tid='$tid'");
		}

		$sqlvalues = $comma = '';
		$sqlreason = cutstr($reason, 40);
		foreach($creditsarray as $id => $addcredits) {
			$sqlvalues .= "$comma('$pid', '$discuz_uid', '$discuz_user', '$id', '$timestamp', '$addcredits', '$sqlreason')";
			$comma = ', ';
		}
		$db->query("INSERT INTO {$tablepre}ratelog (pid, uid, username, extcredits, dateline, score, reason)
			VALUES $sqlvalues", 'UNBUFFERED');

		if($sendreasonpm) {
			require_once DISCUZ_ROOT.'./include/misc.func.php';
			$ratescore = $slash = '';
			foreach($creditsarray as $id => $addcredits) {
				$ratescore .= $slash.$extcredits[$id]['title'].' '.($addcredits > 0 ? '+'.$addcredits : $addcredits).' '.$extcredits[$id]['unit'];
				$slash = ' / ';
			}
			sendreasonpm('post', 'rate_reason');
		}

		$reason = dhtmlspecialchars($reason);
		@$fp = fopen(DISCUZ_ROOT.'./forumdata/ratelog.php', 'a');
		@flock($fp, 2);
		foreach($creditsarray as $id => $addcredits) {
			@fwrite($fp, "<?PHP exit('Access Denied'); ?>\t$timestamp\t".dhtmlspecialchars($discuz_userss)."\t$adminid\t".dhtmlspecialchars($post['author'])."\t$id\t$addcredits\t$tid\t$thread[subject]\t$reason\n");
		}
		@fclose($fp);

		showmessage('thread_rate_succeed', dreferer());

	}

} elseif($action == 'viewratings' && $pid) {

	$queryr = $db->query("SELECT * FROM {$tablepre}ratelog WHERE pid='$pid' ORDER BY dateline");
	$queryp = $db->query("SELECT p.* ".($bannedmessages ? ", m.groupid " : '').
		" FROM {$tablepre}posts p ".
		($bannedmessages ? "LEFT JOIN {$tablepre}members m ON m.uid=p.authorid" : '').
		" WHERE p.pid='$pid' AND p.invisible='0'");

	if(!($db->num_rows($queryr)) || !($db->num_rows($queryp))) {
		showmessage('thread_rate_log_nonexistence');
	}

	$post = $db->fetch_array($queryp);
	if($post['tid'] != $thread['tid']) {
		showmessage('undefined_action', NULL, 'HALTED');
	}

	$discuz_action = 72;

	if(!$bannedmessages || !$post['authorid'] || ($bannedmessages && $post['authorid'] && !in_array(intval($author['groupid']), array(0, 4, 5)))) {
		require_once DISCUZ_ROOT.'./include/discuzcode.func.php';
		$post['dateline'] = gmdate("$dateformat $timeformat", $post['dateline'] + $timeoffset * 3600);
		$post['message'] = discuzcode($post['message'], $post['smileyoff'], $post['bbcodeoff'], $post['htmlon'], $forum['allowsmilies'], $forum['allowbbcode'], $forum['allowimgcode'], $forum['allowhtml'], $forum['jammer']);
	} else {
		$post['message'] = '';
	}

	$loglist = array();
	while($log = $db->fetch_array($queryr)) {
		$log['dateline'] = gmdate("$dateformat $timeformat", $log['dateline'] + $timeoffset * 3600);
		$log['score'] = $log['score'] > 0 ? '+'.$log['score'] : $log['score'];
		$log['reason'] = dhtmlspecialchars($log['reason']);
		$loglist[] = $log;
	}

	include template('rate_view');

} elseif($action == 'pay') {

	if(!isset($extcredits[$creditstrans])) {
		showmessage('credits_transaction_disabled');
	} elseif($thread['price'] <= 0 || $thread['special'] <> 0) {
		showmessage('undefined_action', NULL, 'HALTED');
	} elseif(!$discuz_uid) {
		showmessage('group_nopermission', NULL, 'NOPERM');
	}

	if(($balance = ${'extcredits'.$creditstrans} - $thread['price']) < ($minbalance = 0)) {
		showmessage('credits_balance_insufficient');
	}

	$query = $db->query("SELECT COUNT(*) FROM {$tablepre}paymentlog WHERE tid='$tid' AND uid='$discuz_uid'");
	if($db->result($query, 0)) {
		showmessage('credits_buy_thread', 'viewthread.php?tid='.$tid);
	}

	$discuz_action = 81;

	$thread['netprice'] = floor($thread['price'] * (1 - $creditstax));

	if(!submitcheck('paysubmit')) {

		include template('pay');

	} else {

		$updateauthor = true;
		if($maxincperthread > 0) {
			$query = $db->query("SELECT SUM(netamount) FROM {$tablepre}paymentlog WHERE tid='$tid'");
			if(($db->result($query, 0)) > $maxincperthread) {
				$updateauthor = false;
			}
		}

		if($updateauthor) {
			$db->query("UPDATE {$tablepre}members SET extcredits$creditstrans=extcredits$creditstrans+$thread[netprice] WHERE uid='$thread[authorid]'");
		}

		$db->query("UPDATE {$tablepre}members SET extcredits$creditstrans=extcredits$creditstrans-$thread[price] WHERE uid='$discuz_uid'");
		$db->query("INSERT INTO {$tablepre}paymentlog (uid, tid, authorid, dateline, amount, netamount)
			VALUES ('$discuz_uid', '$tid', '$thread[authorid]', '$timestamp', '$thread[price]', '$thread[netprice]')");

		showmessage('thread_pay_succeed', "viewthread.php?tid=$tid");

	}

} elseif($action == 'viewpayments') {

	$discuz_action = 82;

	$loglist = array();
	$query = $db->query("SELECT p.*, m.username FROM {$tablepre}paymentlog p
		LEFT JOIN {$tablepre}members m USING (uid)
		WHERE tid='$tid' ORDER BY dateline");
	while($log = $db->fetch_array($query)) {
		$log['dateline'] = gmdate("$dateformat $timeformat", $log['dateline'] + $timeoffset * 3600);
		$loglist[] = $log;
	}

	include template('pay_view');

} elseif($action == 'report') {

	if(!$reportpost) {
		showmessage('thread_report_disabled');
	}

	if(!$discuz_uid) {
		showmessage('not_loggedin', NULL, 'HALTED');
	}

	if(!$thread || !is_numeric($pid)) {
		showmessage('undefined_action', NULL, 'HALTED');
	}

	$discuz_action = 123;

	$floodctrl = $floodctrl * 3;
	if($timestamp - $lastpost < $floodctrl) {
		showmessage('thread_report_flood_ctrl');
	}

	if(!submitcheck('reportsubmit')) {

		include template('reportpost');

	} else {

		$posturl = "{$boardurl}viewthread.php?tid=$tid".($page || $pid ? "&amp;page=$page#pid$pid" : NULL);

		$uids = 0;
		$adminids = '';
		$reportto = array();

		if(is_array($to) && count($to)) {

			if(isset($to[3])) {
				$query = $db->query("SELECT uid FROM {$tablepre}moderators WHERE fid='$fid'");
				while($member = $db->fetch_array($query)) {
					$uids .= ','.$member['uid'];
				}
			}

			if(!$uids || ($reportpost >= 2 && $to[2])) {
				$adminids .= ',2';
			}

			if($reportpost == 3 && $to[1]) {
				$adminids .= ',1';
			}

			if($adminids) {
				$query = $db->query("SELECT uid FROM {$tablepre}members WHERE adminid IN (".substr($adminids, 1).")");
				if(!$db->num_rows($query)) {
					$query = $db->query("SELECT uid FROM {$tablepre}members WHERE adminid='1'");
				}
				while($member = $db->fetch_array($query)) {
					$uids .= ','.$member['uid'];
				}
			}

			$query = $db->query("SELECT uid, ignorepm FROM {$tablepre}memberfields WHERE uid IN ($uids)");
			while($member = $db->fetch_array($query)) {
				if(!preg_match("/(^{ALL}$|(,|^)\s*".preg_quote($discuz_user, '/')."\s*(,|$))/i", $member['ignorepm'])) {
					if(!in_array($member['uid'], $reportto)) {
						$reportto[] = $member['uid'];
					}
				}
			}

			if($reportto) {
				$reason = stripslashes($reason);
				sendpm(implode(',', $reportto), 'reportpost_subject', 'reportpost_message');
			}

			$db->query("UPDATE {$tablepre}members SET lastpost='$timestamp' WHERE uid='$discuz_uid'");

			showmessage('thread_report_succeed', "viewthread.php?tid=$tid");

		} else {

			showmessage('thread_report_invalid');

		}

	}

} elseif($action == 'blog') {

	if(!$discuz_uid || (!$thread['blog'] && (!$allowuseblog || !$forum['allowshare']))) {
		showmessage('group_nopermission', NULL, 'NOPERM');
	}

	if($thread['authorid'] != $discuz_uid) {
		$query = $db->query("SELECT adminid FROM {$tablepre}members WHERE uid='$thread[authorid]'");
		$thread['adminid'] = $db->result($query, 0);
		if(!$forum['ismoderator'] || (in_array($thread['adminid'], array(1, 2, 3)) && $adminid > $thread['adminid'])) {
			showmessage('blog_add_illegal');
		}
	}

	if(!submitcheck('blogsubmit')) {

		include template('blog_addremove');

	} else {

		$blog = $thread['blog'] ? 0 : 1;
		$db->query("UPDATE {$tablepre}threads SET blog='$blog' WHERE tid='$tid'", 'UNBUFFERED');

		if($forum['ismoderator'] && $thread['authorid'] != $discuz_uid && $blog != $thread['blog']) {
			$reason = '';
			require_once DISCUZ_ROOT.'./include/misc.func.php';
			modlog($thread, ($thread['blog'] ? 'RBL' : 'ABL'));
		}

		showmessage('blog_add_succeed', "viewthread.php?tid=$tid");

	}

} elseif($action == 'viewthreadmod' && $tid) {

	$loglist = array();
	$query = $db->query("SELECT * FROM {$tablepre}threadsmod WHERE tid='$tid' ORDER BY dateline DESC");
	while($log = $db->fetch_array($query)) {
		$log['dateline'] = gmdate("$dateformat $timeformat", $log['dateline'] + $timeoffset * 3600);
		$log['expiration'] = !empty($log['expiration']) ? gmdate("$dateformat", $log['expiration'] + $timeoffset * 3600) : '';
		$log['status'] = empty($log['status']) ? 'style="text-decoration: line-through" disabled' : '';
		$loglist[] = $log;
	}

	if(empty($loglist)) {
		showmessage('threadmod_nonexistence');
	} else {
		include_once language('modactions');
	}

	include template('viewthread_mod');

} elseif($action == 'bestanswer' && $tid && $pid && submitcheck('bestanswersubmit')) {

	$forward = 'viewthread.php?tid='.$tid;

	$query = $db->query("SELECT authorid, first FROM {$tablepre}posts WHERE pid='$pid' and tid='$tid'");

	if(!($thread['special'] == 3 && ($post = $db->fetch_array($query)) && ($forum['ismoderator'] || $thread['authorid'] == $discuz_uid) && $post['authorid'] != $thread['authorid'] && $post['first'] == 0 && $discuz_uid != $post['authorid'])){
		showmessage('reward_cant_operate');
	} elseif($post['authorid'] == $thread['authorid']) {
		showmessage('reward_cant_self');
	} elseif($thread['price'] < 0) {
		showmessage('reward_repeat_selection');
	}
	$thread['netprice'] = ceil($price * ( 1 + $creditstax) );
	$db->query("UPDATE {$tablepre}members SET extcredits$creditstrans=extcredits$creditstrans+$thread[price] WHERE uid='$post[authorid]'");
	$db->query("DELETE FROM {$tablepre}rewardlog WHERE tid='$tid' and answererid='$post[authorid]'");
	$db->query("UPDATE {$tablepre}rewardlog SET answererid='$post[authorid]' WHERE tid='$tid' and authorid='$thread[authorid]'");
	$thread['price'] = '-'.$thread['price'];
	$db->query("UPDATE {$tablepre}threads SET price='$thread[price]' WHERE tid='$tid'");
	$db->query("UPDATE {$tablepre}posts SET dateline=$thread[dateline]+1 WHERE pid='$pid'");

	$thread['dateline'] = gmdate("$dateformat $timeformat", $thread['dateline'] + $timeoffset * 3600);
	if($discuz_uid != $thread['authorid']) {
		sendpm($thread['authorid'], 'reward_question_subject', 'reward_question_message', $discuz_uid, $discuz_user);
	}
	sendpm($post['authorid'], 'reward_bestanswer_subject', 'reward_bestanswer_message', $discuz_uid, $discuz_user);

	showmessage('reward_completion', $forward);

} elseif($action == 'activityapplies') {

	if(!$discuz_uid) {
		showmessage('undefined_action', NULL, 'HALTED');
	}

	if(submitcheck('activitysubmit')) {
		$query = $db->query("SELECT expiration FROM {$tablepre}activities WHERE tid='$tid'");
		$expiration = $db->result($query, 0);
		if($expiration && $expiration < $timestamp - date('Z')) {
			showmessage('activity_stop');
		}

		$query = $db->query("SELECT applyid FROM {$tablepre}activityapplies WHERE tid='$tid' and username='$discuz_user'");
		if($db->num_rows($query)) {
			showmessage('activity_repeat_apply', "viewthread.php?tid=$tid&amp;extra=$extra");
		}
		$payvalue = intval($payvalue);
		$payment = $payment ? $payvalue : -1;
		$message = dhtmlspecialchars($message);

		$db->query("INSERT INTO {$tablepre}activityapplies (tid, username, uid, message, verified, dateline, payment)
			VALUES ('$tid', '$discuz_user', '$discuz_uid', '$message', '0', '$timestamp', '$payment')");

		showmessage('activity_completion', "viewthread.php?tid=$tid&amp;extra=$extra");
	}

} elseif($action == 'activityapplylist') {

	$query = $db->query("SELECT * FROM {$tablepre}activities WHERE tid='$tid'");
	$activity = $db->fetch_array($query);

	if(!submitcheck('applylistsubmit')) {

		$page = empty($page) || !ispage($page) ? 1 : $page;
		$start_limit = ($page - 1) * $tpp;

		$query = $db->query("SELECT fid, name FROM {$tablepre}forums WHERE fid='$forum[fup]'");
		$fup = $db->fetch_array($query);
		$navigation = "&raquo; <a href=\"forumdisplay.php?fid=$fid\">$forum[name]</a> ";
		$query = $db->query("SELECT subject, authorid FROM {$tablepre}threads WHERE tid='$tid'");
		if($thread = $db->fetch_array($query)) {
			$navigation .= " &raquo; <a href=\"viewthread.php?tid=$tid\">$thread[subject]</a> ";
		} else {
			showmessage('thread_nonexistence');
		}

		$isverified = $applied = 0;
		if($discuz_uid) {
			$query = $db->query("SELECT verified FROM {$tablepre}activityapplies WHERE tid='$tid' AND uid='$discuz_uid'");
			if($db->num_rows($query)) {
				$isverified = $db->result($query, 0);
				$applied = 1;
			}
		}

		$sqlverified = $thread['authorid'] == $discuz_uid ? '' : 'AND verified=1';

		$query = $db->query("SELECT COUNT(*) FROM {$tablepre}activityapplies WHERE tid='$tid' $sqlverified");
		$multipage = multi($db->result($query, 0), $tpp, $page, "misc.php?action=activityapplylist&amp;tid=$tid");

		$query = $db->query("SELECT applyid, username, uid, message, verified, dateline, payment FROM {$tablepre}activityapplies WHERE tid='$tid' $sqlverified ORDER BY dateline DESC LIMIT $start_limit, $tpp");
		while($activityapplies = $db->fetch_array($query)) {
			$activityapplies['dateline'] = gmdate("$dateformat $timeformat", $activityapplies['dateline'] + $timeoffset * 3600);
			$applylist[] = $activityapplies;
		}

		$activity['starttimefrom'] = date("$dateformat $timeformat", $activity['starttimefrom'] + $timeoffset * 3600);
		$activity['starttimeto'] = $activity['starttimeto'] ? date("$dateformat $timeformat", $activity['starttimeto'] + $timeoffset * 3600) : 0;
		$activity['expiration'] = $activity['expiration'] ? date("$dateformat $timeformat", $activity['expiration'] + $timeoffset * 3600) : 0;

		$frommisc = $applied = 1;

		$query = $db->query("SELECT COUNT(*) FROM {$tablepre}activityapplies WHERE tid='$tid' AND verified=1");
		$applynumbers = $db->result($query, 0);

		include template('activity_applylist');
	} else {
		$query = $db->query("SELECT subject, authorid FROM {$tablepre}threads WHERE tid='$tid'");
		if($thread = $db->fetch_array($query)) {
			if($thread['authorid'] != $discuz_uid || empty($applyidarray)) {
				showmessage('activity_choice_applicant', "misc.php?action=activityapplylist&amp;tid=$tid");
			} else {
				$uidarray = array();
				$applyid = implode('\',\'', $applyidarray);
				$db->query("UPDATE {$tablepre}activityapplies SET verified=1 WHERE applyid IN ('$applyid')", 'UNBUFFERED');

				$query=$db->query("SELECT m.uid FROM {$tablepre}activityapplies a JOIN {$tablepre}members m USING (username) WHERE applyid IN ('$applyid')");
				while($uid = $db->fetch_array($query)) {
					$uidarray[] = $uid['uid'];
				}
				$activity_subject = $thread['subject'];

				sendpm(implode(',', $uidarray), 'activity_apply_subject', 'activity_apply_message', $fromid = '0', $from = 'System Message');

				showmessage('activity_auditing_completion', "misc.php?action=activityapplylist&amp;tid=$tid");
			}
		} else {
			showmessage('thread_nonexistence');
		}
	}

}

?>