<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: tradelog.inc.php,v $
	$Revision: 1.16 $
	$Date: 2006/08/28 00:33:07 $
*/

if(!defined('IN_DISCUZ') || !isset($PHP_SELF) || !preg_match("/[\/\\\\]admincp\.php$/", $PHP_SELF)) {
        exit('Access Denied');
}

require_once DISCUZ_ROOT.'./api/tradeapi.php';
include_once language('misc');

cpheader();

$page = empty($page) || !ispage($page) ? 1 : $page;
$start_limit = ($page - 1) * $tpp;

$filter = !isset($filter) ? -1 : $filter;
$sqlfilter = $filter >= 0 ? "WHERE status='$filter'" : '';

$query = $db->query("SELECT sum(price) as pricesum, sum(tax) as taxsum FROM {$tablepre}tradelog status $sqlfilter");
$count = $db->fetch_array($query);

$query = $db->query("SELECT COUNT(*) FROM {$tablepre}tradelog $sqlfilter");
$num = $db->result($query, 0);
$multipage = multi($num, $tpp, $page, "admincp.php?action=tradelog");

$query = $db->query("SELECT * FROM {$tablepre}tradelog $sqlfilter ORDER BY lastupdate DESC LIMIT $start_limit, $tpp");

shownav('menu_ecommerce_trade_orders');

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">
<tr class="header"><td colspan=6"><?=$lang['tradelog_order_status']?> <select onchange="location.href='admincp.php?action=tradelog&filter=' + this.value"><option value='-1'><?=$lang['tradelog_all_order']?></option>
<?

$statuss = trade_getstatus(0, -1);
foreach($statuss as $key => $value) {
	echo "<option value=\"$key\" ".($filter == $key ? 'selected' : '').">$value</option>";
}

?>
</select>
</td></tr>
<tr class="altbg1"><td colspan=6"><?=$lang['tradelog_order_count']?> <? echo $num;if($count['pricesum']) {?>, <?=$lang['tradelog_trade_total']?> <?=$count['pricesum']?> <?=$lang['rmb_yuan']?>, <?=$lang['tradelog_fee_total']?> <?=$count['taxsum']?> <?=$lang['rmb_yuan']?><?}?></td></tr>
</table><br>

<?=$multipage?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tableborder">
<tr class="header">
<td align="center" width="10%"><?=$lang['tradelog_trade_no']?></td>
<td align="center" width="15%"><?=$lang['tradelog_trade_name']?></td>
<td align="center" width="7%"><?=$lang['tradelog_buyer']?></td>
<td align="center" width="7%"><?=$lang['tradelog_seller']?></td>
<td align="center" width="10%"><?=$lang['tradelog_money']?></td>
<td align="center" width="10%"><?=$lang['tradelog_fee']?></td>
<td align="center" width="20%"><?=$lang['tradelog_trade_status']?></td>
</tr>
<?

while($tradelog = $db->fetch_array($query)) {

$tradelog['status'] = trade_getstatus($tradelog['status']);
$tradelog['lastupdate'] = gmdate("$dateformat $timeformat", $tradelog['lastupdate'] + $timeoffset * 3600);

?>
	<tr>
	<td align="center" class="altbg1">&nbsp;<?=$tradelog['tradeno']?></td>
	<td align="center" class="altbg2"><a target="_blank" href="viewthread.php?tid=<?=$tradelog['tid']?>"><?=$tradelog['subject']?></a></td>
	<td align="center" class="altbg1"><a target="_blank" href="viewpro.php?uid=<?=$tradelog['buyerid']?>"><?=$tradelog['buyer']?></a></td>
	<td align="center" class="altbg2"><a target="_blank" href="viewpro.php?uid=<?=$tradelog['sellerid']?>"><?=$tradelog['seller']?></a></td>
	<td align="center" class="altbg1"><?=$tradelog['price']?></td>
	<td align="center" class="altbg2"><?=$tradelog['tax']?></td>
	<td align="center" class="altbg1"><a target="_blank" href="trade.php?orderid=<?=$tradelog['orderid']?>"><?=$tradelog['status']?><br><?=$tradelog['lastupdate']?></td>
	</tr>

<?}?>
</table>
<?=$multipage?>