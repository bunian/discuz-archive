<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: index.php,v $
	$Revision: 1.23.2.3 $
	$Date: 2006/09/26 08:27:30 $
*/

define('CURSCRIPT', 'index');

require_once './include/common.inc.php';
require_once DISCUZ_ROOT.'./include/forum.func.php';

$discuz_action = 1;

$validdays = $discuz_uid && !empty($groupexpiry) && $groupexpiry >= $timestamp ?
	ceil(($groupexpiry - $timestamp) / 86400) : 0;
if(isset($showoldetails)) {
	switch($showoldetails) {
		case 'no': dsetcookie('onlineindex', 0, 86400 * 365); break;
		case 'yes': dsetcookie('onlineindex', 1, 86400 * 365); break;
	}
} else {
	$showoldetails = false;
}

$currenttime = gmdate($timeformat, $timestamp + $timeoffset * 3600);
$lastvisittime = gmdate("$dateformat $timeformat", $lastvisit + $timeoffset * 3600);

$memberenc = rawurlencode($lastmember);
$newthreads = round(($timestamp - $lastvisit + 600) / 1000) * 1000;
$navigation = $navtitle = '';

$searchboxstatus = substr(sprintf('%03b', $qihoo_searchbox), -1, 1);
$keywordlist = isset($qihoo_links['keywords']) ? $qihoo_links['keywords'] : '';
$topiclist = isset($qihoo_links['topics']) ? $qihoo_links['topics'] : '';
if($qihoo_maxtopics) {
	$customtopics = '';
	foreach(explode("\t", isset($_DCOOKIE['customkw']) ? $_DCOOKIE['customkw'] : '') as $topic) {
		$topic = dhtmlspecialchars(trim(stripslashes($topic)));
		$customtopics .= '<a href="topic.php?keyword='.rawurlencode($topic).'" target="_blank">'.$topic.'</a> ';
	}
}

$catlist = $forumlist = $sublist = array();
$threads = $posts = $todayposts = $fids = 0;

if(empty($gid)) {
	$announcements = $space = '';
	if($_DCACHE['announcements']) {
		foreach($_DCACHE['announcements'] as $announcement) {
			if(empty($announcement['redirect'])) {
				$announcements .= $space.'<a href="announcement.php?id='.$announcement['id'].'#'.$announcement['id'].'"><span class="bold">'.$announcement['subject'].'</span> '.
					'('.gmdate($dateformat, $announcement['starttime'] + $timeoffset * 3600).')</a>';
			} else {
				$announcements .= $space.'<a href="'.$announcement['message'].'" target="_blank"><span class="bold">'.$announcement['subject'].'</span> '.
					'('.gmdate($dateformat, $announcement['starttime'] + $timeoffset * 3600).')</a>';
			}
			$space = '&nbsp; &nbsp; &nbsp; &nbsp;';
		}
	}
	unset($_DCACHE['announcements']);

	$threads = $posts = $todayposts = 0;

	$sql = !empty($accessmasks) ?
				"SELECT f.fid, f.fup, f.type, f.name, f.threads, f.posts, f.todayposts, f.lastpost, f.inheritedmod, f.forumcolumns, ff.description, ff.moderators, ff.icon, ff.viewperm, a.allowview FROM {$tablepre}forums f
					LEFT JOIN {$tablepre}forumfields ff ON ff.fid=f.fid
					LEFT JOIN {$tablepre}access a ON a.uid='$discuz_uid' AND a.fid=f.fid
					WHERE f.status='1' ORDER BY f.type, f.displayorder"
				: "SELECT f.fid, f.fup, f.type, f.name, f.threads, f.posts, f.todayposts, f.lastpost, f.inheritedmod, f.forumcolumns, ff.description, ff.moderators, ff.icon, ff.viewperm FROM {$tablepre}forums f
					LEFT JOIN {$tablepre}forumfields ff USING(fid)
					WHERE f.status='1' ORDER BY f.type, f.displayorder";

	$query = $db->query($sql);

	while($forum = $db->fetch_array($query)) {
		$forumname[$forum['fid']] = strip_tags($forum['name']);
		if($forum['type'] != 'group') {
			$threads += $forum['threads'];
			$posts += $forum['posts'];
			$todayposts += $forum['todayposts'];

			if($forum['type'] == 'forum') {

				if(forum($forum)) {
					$catlist[$forum['fup']]['forums'][] = $forum['fid'];
					$forum['orderid'] = $catlist[$forum['fup']]['forumscount']++;
					$forum['subforums'] = '';
					$forumlist[$forum['fid']] = $forum;
				}

			} elseif(isset($forumlist[$forum['fup']])) {

				$forumlist[$forum['fup']]['threads'] += $forum['threads'];
				$forumlist[$forum['fup']]['posts'] += $forum['posts'];
				$forumlist[$forum['fup']]['todayposts'] += $forum['todayposts'];
				if($subforumsindex && $forumlist[$forum['fup']]['permission'] == 2) {
					$forumlist[$forum['fup']]['subforums'] .= '<a href="forumdisplay.php?fid='.$forum['fid'].'"><u>'.$forum['name'].'</u></a>&nbsp;&nbsp;';
				}

			}

		} else {

			if(!isset($_COOKIE['discuz_collapse']) || strpos($_COOKIE['discuz_collapse'], 'category_'.$forum['fid'].' ') === FALSE) {
				$forum['collapseimg'] = 'collapsed_no.gif';
				$collapse['category_'.$forum['fid']] = '';
			} else {
				$forum['collapseimg'] = 'collapsed_yes.gif';
				$collapse['category_'.$forum['fid']] = 'display: none';
			}

			if($forum['moderators']) {
			 	$forum['moderators'] = moddisplay($forum['moderators'], 'flat');
			}
			$forum['forumscount'] 	= 0;
			$catlist[$forum['fid']] = $forum;
		}
	}

	foreach($catlist as  $catid => $category) {
		if($catlist[$catid]['forumscount'] && $category['forumcolumns']) {
			$catlist[$catid]['forumcolwidth'] = floor(100 / $category['forumcolumns']).'%';
			$catlist[$catid]['endrows'] = '';
			if($colspan = $category['forumscount'] % $category['forumcolumns']) {
				while(($category['forumcolumns'] - $colspan) > 0) {
					$catlist[$catid]['endrows'] .= '<td class="altbg2"></td>';
					$colspan ++;
				}
				$catlist[$catid]['endrows'] .= '</tr>';
			}

		} elseif(empty($category['forumscount'])) {
			unset($catlist[$catid]);
		}
	}

	if(isset($catlist[0]) && $catlist[0]['forumscount']) {
		$catlist[0]['fid'] = 0;
		$catlist[0]['type'] = 'group';
		$catlist[0]['name'] = $bbname;
		$catlist[0]['collapseimg'] = 'collapsed_no.gif';
	} else {
		unset($catlist[0]);
	}

	foreach(array('forumlinks', 'birthdays', 'supe_updateusers') as $key) {
		if(!isset($_COOKIE['discuz_collapse']) || strpos($_COOKIE['discuz_collapse'], $key.' ') === FALSE) {
			$collapseimg[$key] = 'collapsed_no.gif';
			$collapse[$key] = '';
		} else {
			$collapseimg[$key] = 'collapsed_yes.gif';
			$collapse[$key] = 'display: none';
		}
	}

	if($whosonlinestatus == 1 || $whosonlinestatus == 3) {
		$whosonlinestatus = 1;

		$onlineinfo = explode("\t", $onlinerecord);
		$detailstatus = ((empty($_DCOOKIE['onlineindex']) && $onlineinfo[0] < 500) || (!empty($_DCOOKIE['onlineindex']) || $showoldetails == 'yes')) && $showoldetails != 'no';

		if($detailstatus) {
			@include language('actions');

			updatesession();
			$onlinenum = $membercount = $invisiblecount = 0;
			$whosonline = array();

			if($maxonlinelist) {
				if($db->version() < '4.0.0') {
					$query = $db->query("SELECT uid, username, groupid, invisible, action, lastactivity, fid FROM {$tablepre}sessions ORDER BY uid DESC LIMIT ".$maxonlinelist);
					$onlinenum = $db->result($db->query("SELECT COUNT(*) FROM {$tablepre}sessions"), 0);
					if($onlinenum > $maxonlinelist) {
						$membercount = $db->result($db->query("SELECT COUNT(*) FROM {$tablepre}sessions WHERE uid <> '0'"), 0);
						$invisiblecount = $db->result($db->query("SELECT COUNT(*) FROM {$tablepre}sessions WHERE invisible = '1'"), 0);
					}
				} else {
					$query = $db->query("SELECT SQL_CALC_FOUND_ROWS uid, username, groupid, invisible, action, lastactivity, fid FROM {$tablepre}sessions ORDER BY uid DESC LIMIT ".$maxonlinelist);
					$onlinenum = $db->result($db->query("SELECT FOUND_ROWS()"), 0);
					if($onlinenum > $maxonlinelist) {
						$membercount = $db->result($db->query("SELECT COUNT(*) FROM {$tablepre}sessions WHERE uid <> '0'"), 0);
						$invisiblecount = $db->result($db->query("SELECT COUNT(*) FROM {$tablepre}sessions WHERE invisible = '1'"), 0);
					}
				}
			} else {
				$query = $db->query("SELECT uid, username, groupid, invisible, action, lastactivity, fid FROM {$tablepre}sessions ORDER BY uid DESC");
				$onlinenum = $db->num_rows($query);
			}

			while($online = $db->fetch_array($query)) {
				if($online['uid']) {
					if(!$maxonlinelist || $maxonlinelist && $onlinenum <= $maxonlinelist) $membercount++;
					if(!$online['invisible']) {
						$online['icon'] = isset($_DCACHE['onlinelist'][$online['groupid']]) ? $_DCACHE['onlinelist'][$online['groupid']] : $_DCACHE['onlinelist'][0];
					} else {
						if(!$maxonlinelist || $maxonlinelist && $onlinenum <= $maxonlinelist) $invisiblecount++;
						continue;
					}
					$online['fid'] = $online['fid'] ? $forumname[$online['fid']] : 0;
					$online['action'] = $actioncode[$online['action']];
					$online['lastactivity'] = gmdate($timeformat, $online['lastactivity'] + ($timeoffset * 3600));
					$whosonline[] = $online;
				} else {
					if(isset($_DCACHE['onlinelist'][7])) {
						$online['icon'] = $_DCACHE['onlinelist'][7];
						$online['username'] = 'Guest';
						$online['fid'] = $online['fid'] ? $forumname[$online['fid']] : 0;
						$online['action'] = $actioncode[$online['action']];
						$online['lastactivity'] = gmdate($timeformat, $online['lastactivity'] + ($timeoffset * 3600));
						$whosonline[] = $online;
					}
				}
			}
			$guestcount = $onlinenum - $membercount;
			unset($online);
		} else {
			$query = $db->query("SELECT COUNT(*) FROM {$tablepre}sessions");
			$onlinenum = $db->result($query, 0);
		}

		if($onlinenum > $onlineinfo[0]) {
			$db->query("UPDATE {$tablepre}settings SET value='$onlinenum\t$timestamp' WHERE variable='onlinerecord'");
			require_once DISCUZ_ROOT.'./include/cache.func.php';
			updatecache('settings');
			$onlineinfo = array($onlinenum, $timestamp);
		}

		$onlineinfo[1] = gmdate($dateformat, $onlineinfo[1] + ($timeoffset * 3600));
	} else {
		$whosonlinestatus = 0;
	}

	if($discuz_uid && $newpm) {
		require_once DISCUZ_ROOT.'./include/pmprompt.inc.php';
	}

} else {
	require_once DISCUZ_ROOT.'./include/category.inc.php';

}

include template('discuz');

?>