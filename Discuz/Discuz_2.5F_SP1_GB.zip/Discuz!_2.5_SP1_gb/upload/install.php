<?php

/*
 ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 :: [DISCUZ!]  Crossday Discuz! Board                                    ::
 :: (c) 2001-2005 Comsenz Technology Ltd (www.discuz.com)                ::
 ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 :: Author:  Crossday (tech@discuz.com) Cnteacher (cnteacher@discuz.com) ::
 :: Version: 2.5F   2004/10/01 05:15                                     ::
 ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
*/
define('DISCUZ_ROOT', dirname(__FILE__).'/');
$languageset['chinese_gb2312'] = array
	(

	'charset' => 'gb2312',

	'username' => '����Ա�˺�:',
	'password' => '����Ա����:',
	'repeat_password' => '�ظ�����:',
	'admin_email' => '����Ա Email:',

	'succeed' => '�ɹ�',
	'fail' => 'ʧ��',
	'exit' => '�˳���װ��',
	'enabled' => '����',
	'writeable' => '��д',
	'unwriteable' => '����д',
	'unlimited' => '����',

	'env_os' => '����ϵͳ',
	'env_php' => 'PHP �汾',
	'env_mysql' => 'MySQL �汾',
	'env_attach' => '�����ϴ�',
	'env_diskspace' => '���̿ռ�',
	'env_dir_writeable' => 'Ŀ¼д��',

	'init_log' => '��ʼ����¼',
	'clear_dir' => '���Ŀ¼',
	'select_db' => 'ѡ�����ݿ�',
	'create_table' => '�������ݱ�',
	
	'install_wizard' => 'Discuz! Board Installation Wizard',
	'welcome' => '<p align=left>��ӭ���� Crossday Discuz! Board 2.5 Free ��װ�򵼡�</p>',
	'current_process' => '��ǰ״̬:',
	'show_license' => 'Discuz! �û�����Э��',
	'agreement' => '���������ϸ�Ķ����������Э��',
	'agreement_yes' => '����ȫͬ��',
	'agreement_no' => '�Ҳ���ͬ��',
	'configure' => '���� config.php',
	'check_config' => '��������ļ�״̬',
	'check_existence' => '���ڼ��',
	'check_writeable' => '��д���',
	'edit_config' => '���/�༭��ǰ����',
	'variable' => '����ѡ��',
	'value' => '��ǰֵ',
	'comment' => 'ע��',
	'dbhost' => '���ݿ������:',
	'dbhost_comment' => '���ݿ��������ַ, һ��Ϊ localhost',
	'dbuser' => '���ݿ��û���:',
	'dbuser_comment' => '���ݿ��˺��û���',
	'dbpw' => '���ݿ�����:',
	'dbpw_comment' => '���ݿ��˺�����',
	'dbname' => '���ݿ���:',
	'dbname_comment' => '���ݿ�����',
	'email' => 'ϵͳ Email:',
	'email_comment' => '���ڷ��ͳ�����󱨸�',
	'tablepre' => '����ǰ׺:',
	'tablepre_comment' => 'ͬһ���ݿⰲװ����̳ʱ�ɸı�Ĭ��',
	'tablepre_prompt' => '��������Ҫ��ͬһ���ݿⰲװ��� Discuz! \n��̳,����,ǿ�ҽ�������Ҫ�޸ı���ǰ׺.',
	'save_config' => '����������Ϣ',
	'confirm_config' => '����������ȷ',
	'refresh_config' => 'ˢ���޸Ľ��',
	'recheck_config' => '���¼������',
	'check_env' => '��鵱ǰ����������',
	'compare_env' => 'Discuz! ���軷���͵�ǰ���������öԱ�',
	'env_required' => 'Discuz! ��������',
	'env_best' => 'Discuz! �������',
	'env_current' => '��ǰ������',
	'confirm_preparation' => '��ȷ����������²���',
	'install_note' => '��װ����ʾ',
	'add_admin' => '���ù���Ա�˺�',
	'start_install' => '��ʼ��װ Discuz!',
	'installing' => '������Ա�˺���Ϣ����ʼ��װ Discuz!��',
	'check_admin' => '������Ա�˺�',
	'check_admin_validity' => '�����Ϣ�Ϸ���',
	'admin_username_invalid' => '�û�����, ���ȳ������ƻ�����Ƿ��ַ�.',
	'admin_password_invalid' => '�����������벻һ��.',
	'admin_email_invalid' => 'Email ��ַ��Ч',
	'admin_invalid' => '������Ϣû����д����.',
	'fail_reason' => 'ʧ��. ԭ��:',
	'go_back' => '������һҳ�޸�',
	'init_file' => '��ʼ������Ŀ¼���ļ�',

	'config_nonexistence' => '���� config.php ������, �޷�������װ, ���� FTP �����ļ��ϴ�������.',
	'config_comment' => '����������д�������ݿ��˺���Ϣ, ͨ������²���Ҫ�޸ĺ�ɫѡ������.',
	'config_unwriteable' => '��װ���޷�д�������ļ�, ��˶�������Ϣ, �����޸�, ��ͨ�� FTP ���ĺõ� config.php �ϴ�.',

	'php_version_400' => '���� PHP �汾С�� 4.0.0, �޷�ʹ�� Discuz!��',
	'php_version_406' => '���� PHP �汾С�� 4.0.6, �޷�ʹ��ͷ��ߴ���� gzip ѹ�����ܡ�',
	'attach_enabled' => '����/���ߴ� ',
	'attach_enabled_info' => '�������ϴ����������ߴ�: ',
	'attach_disabled' => '�������ϴ�����',
	'attach_disabled_info' => '�����ϴ�����ز�������������ֹ��',
	'mysql_version_323' => '���� MySQL �汾���� 3.23����װ�޷��������С�',
	'unwriteable_template' => 'ģ��Ŀ¼(./templates)���Է� 777 ���޷�д�룬���߱༭ģ�幦�ܽ��޷�ʹ�á�',
	'unwriteable_attach' => '����Ŀ¼(Ĭ���� ./attachments)���Է� 777 ���޷�д�룬�����ϴ����ܽ��޷�ʹ�á�',
	'unwriteable_avatar' => '�Զ���ͷ��Ŀ¼(./customavatars)���Է� 777 ���޷�д�룬�ϴ�ͷ���ܽ��޷�ʹ�á�',
	'unwriteable_forumdata' => '����Ŀ¼(./forumdata)���Է� 777 ���޷�д�룬��̳���м�¼�ͱ��ݵ����ݿ⹦�ܽ��޷�ʹ�á�',
	'unwriteable_forumdata_template' => '����ģ��Ŀ¼(./forumdata/templates)���Է� 777 ���޷�д�룬��װ�޷��������С�',
	'unwriteable_forumdata_cache' => '���ݻ���Ŀ¼(./forumdata/cache)���Է� 777 ���޷�д�룬��װ�޷��������С�',
	'unwriteable_forumdata_accesslog' => '���ʿ���Ŀ¼(./forumdata/accesslog)���Է� 777 ���޷�д�룬��ֹ DOS �������ܽ��޷�ʹ�á�',
	'tablepre_invalid' => '��ָ�������ݱ�ǰ׺�������ַ�(".")���뷵���޸ġ�',
	'db_invalid' => 'ָ�������ݿⲻ����, ϵͳҲ�޷��Զ�����, �޷���װ Discuz!.',
	'db_auto_created' => 'ָ�������ݿⲻ����, ��ϵͳ�ѳɹ�����, ���Լ�����װ.',
	'db_not_null' => '���ݿ����Ѿ���װ�� Discuz!, ������װ�����ԭ������.',
	'db_drop_table_confirm' => '������װ�����ȫ��ԭ�����ݣ���ȷ��Ҫ������?',

	'install_abort' => '������Ŀ¼���Ի����������ԭ��, �޷�������װ Discuz!, ����ϸ�Ķ���װ˵��.',
	'install_process' => '���ķ��������԰�װ��ʹ�� Discuz!, �������һ����װ.',
	'install_succeed' => '��ϲ����Discuz! ��װ�ɹ���',
	'goto_forum' => '������������̳',

	'license' => '<p>��Ȩ���� (c) 2001-2005, Comsenz Technology Ltd<br>
��������Ȩ��.

<p>    ��л��ѡ�� Discuz! ��̳��Ʒ��ϣ�����ǵ�Ŭ����Ϊ���ṩһ����Ч���ٺ�ǿ��� web
��̳���������

<p>    Discuz! Ӣ��ȫ��Ϊ Crossday Discuz! Board������ȫ��Ϊ Discuz! ��̳�����¼��
Discuz!��
<p>    ������ʢ���ͿƼ����޹�˾Ϊ Discuz! ��Ʒ��Ŀ�Ŀ����̣�����ӵ�� Discuz! ������
����Ȩ���л����񹲺͹����Ұ�Ȩ������Ȩ�ǼǺ� 2003SR6623������Э�������� Discuz! 
2.x ϵ�а汾��������ʢ���ͿƼ����޹�˾ӵ�жԱ�Э������ս���Ȩ���޸�Ȩ��

<p>    Discuz! �ٷ�����֧����̳Ϊ http://www.Discuz.net��Discuz! �ٷ���Ʒ��վΪ
http://www.Discuz.com��������ʢ���ͿƼ����޹�˾�Ĺٷ���վΪ http://www.comsenz.com��

<p>    �ڿ�ʼ��װ Discuz! ֮ǰ���������ϸ�Ķ�����Ȩ�ĵ�������ȷ��������ȨЭ���ȫ��
�����󣬼��ɼ��� Discuz! ��̳�İ�װ��������һ����ʼ��װ Discuz!��������Ϊ��ȫͬ��
����ȨЭ���ȫ�����ݣ�������־��ף����ǽ�������ط��ɺ�Э������׷�����Ρ�

<p>    Discuz! ��̳�����л����񹲺͹����Ұ�Ȩ�ֵǼǣ�����Ȩ�ܵ����ɼ����ʹ�Լ������
2.x �汾Ϊ����������û���������ȫ���ر������û���ȨЭ��Ļ����ϣ���ѻ�á���װ
���ڷ���ҵ��;ʹ�ñ����򣬶�����֧�����á�

<p>    �����Բ鿴 Discuz! ��ȫ��Դ���룬Ҳ���Ը����Լ�����Ҫ��������޸ģ���������Σ�
��������;��Ρ��Ƿ�Ķ����Ķ��̶���Σ�ֻҪ Discuz! ������κβ��ֱ����������޸�
���ϵͳ�У������뱣��ҳ�Ŵ��� Discuz! ���ƺ� Comsenz Technology Ltd 
(http://www.comsenz.com) �����ӡ����޸ĺ�Ĵ��룬��û�л�ñ�����ʢ���ͿƼ����޹�˾
�������ɵ�����£��Ͻ������������ۡ�

<p>    �û�������Ը��ʹ�ñ����������ǲ���ŵ���ṩ�κ���ʽ�ļ���֧�֡�ʹ�õ�����Ҳ��
�е��κ���ʹ�ñ����������������������Ρ�

<p>    �����ҽ����ڷ�Ӫ���Ը����û������汾 Discuz! �ǿ���Դ����������������ӭ����ԭ��
��������ȫ����Ȩ��Ϣ��˵������ǰ���£�������ת�ر�������δ������ҵ��Ȩǰ���Ͻ�����
������������ҵ��;��ӯ����վ�㣬������ҵ��Ӫ����������塢���¾�Ӫ�Ի�����ҵ��Ĺ�˾
����ˡ��������û���ȡ���õ��շ���վ������Ҫ������ҵ�汾��Ȩ����ʹ�ñ��������й���ҵ
�汾������������ʹٷ���վ��http://www.discuz.com����ͬʱ��ӭ�� Discuz! ����Ȥ����ʵ��
���������˶� Discuz! �Ŀ����ṩ֧�֡�

<p>    ��װ Discuz! ��������ȫͬ�Ȿ��ȨЭ��Ļ���֮�ϣ���˶������ľ��ף�Υ����Э���
һ�����е�ȫ���������������Ρ�',

	'preparation' => '<li>��ѹ������ Discuz! Ŀ¼��ȫ���ļ���Ŀ¼�ϴ���������.</li><li>�޸ķ������ϵ� config.php �ļ����ʺ���������, �й����ݿ��˺���Ϣ����ѯ���Ŀռ�����ṩ��.</li><li>�����ʹ�÷� WINNT ϵͳ���޸���������:<br>&nbsp; &nbsp; <b>./templates</b> Ŀ¼ 777;&nbsp; &nbsp; <b>./attachments</b> Ŀ¼ 777;&nbsp; &nbsp; <b>./customavatars</b> Ŀ¼ 777;&nbsp; &nbsp; <b>./forumdata</b> Ŀ¼ 777;<br><b>&nbsp; &nbsp; ./forumdata/cache</b> Ŀ¼ 777;&nbsp; &nbsp; <b>./forumdata/templates</b> Ŀ¼ 777;&nbsp; &nbsp; <b>./forumdata/accesslogs</b> Ŀ¼ 777;<br></li><li>ȷ�� URL �� /attachments ���Է��ʷ�����Ŀ¼ ./attachments ����.</li>',

	);

error_reporting(7);
set_magic_quotes_runtime(0);
define('IN_DISCUZ', TRUE);
$action		= $_POST['action'] ? $_POST['action'] : $_GET['action'];
$language	= $_POST['language'] ? $_POST['language'] : $_GET['language'];
$PHP_SELF	= ($_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME']).'?language='.$language;

@set_time_limit(1000);
@include DISCUZ_ROOT.'./config.php';

header('Content-Type: text/html; charset='.$lang['charset']);
$version = '2.5F_SP1';

function loginit($log) {
	global $lang;

	echo $lang['init_log'].' '.$log;
	$fp = @fopen(DISCUZ_ROOT.'./forumdata/'.$log.'.php','w');
	@fwrite($fp, "<?PHP exit(\"Access Denied\"); ?>\n");
	@fclose($fp);
	result();
}

function runquery($sql) {
	global $lang, $tablepre, $db;

	$sql = str_replace("\r", "\n", str_replace(' cdb_', ' '.$tablepre, $sql));
	$ret = array();
	$num = 0;
	foreach(explode(";\n", trim($sql)) as $query) {
		$queries = explode("\n", trim($query));
		foreach($queries as $query) {
			$ret[$num] .= $query[0] == '#' ? NULL : $query;
		}
		$num++;
	}
	unset($sql);

	foreach($ret as $query) {
		$query = trim($query);
		if($query) {
			if(substr($query, 0, 12) == 'CREATE TABLE') {
				$name = preg_replace("/CREATE TABLE ([a-z0-9_]+) .*/is", "\\1", $query);
				echo $lang['create_table'].' '.$name.' ... <font color="#0000EE">'.$lang['succeed'].'</font><br>';
			}
			$db->query($query);
		}
	}
}

function result($result = 1, $output = 1) {
	global $lang;

	if($result) {
		$text = '... <font color="#0000EE">'.$lang['succeed'].'</font><br>';
		if(!$output) {
			return $text;
		}
		echo $text;
	} else {
		$text = '... <font color="#FF0000">'.$lang['fail'].'</font><br>';
		if(!$output) {
			return $text;
		}
		echo $text;
	}
}

function dir_writeable($dir) {
	$writeable = 0;
	$dir = DISCUZ_ROOT.$dir;
	if(!is_dir($dir)) {
		@mkdir($dir, 0777);
	}
	if(is_dir($dir)) {
		if($fp = @fopen("$dir/test.test", 'w')) {
			@fclose($fp);
			@unlink("$dir/test.test");
			$writeable = 1;
		} else {
			$writeable = 0;
		}
	}
	return $writeable;
}

function dir_clear($dir) {
	global $lang;
	echo $lang['clear_dir'].' '.$dir;
	$dir = DISCUZ_ROOT.$dir;
	$directory = dir($dir);
	while($entry = $directory->read()) {
		$filename = $dir.'/'.$entry;
		if(is_file($filename)) {
			@unlink($filename);
		}
	}
	$directory->close();
	result();
}


?>
<html>
<head>
<title>Discuz! Board Installation Wizard</title>
<style>
A:visited	{COLOR: #3A4273; TEXT-DECORATION: none}
A:link		{COLOR: #3A4273; TEXT-DECORATION: none}
A:hover		{COLOR: #3A4273; TEXT-DECORATION: underline}
body,table,td	{COLOR: #000000; FONT-FAMILY: Tahoma, Verdana, Arial; FONT-SIZE: 12px; LINE-HEIGHT: 20px; scrollbar-base-color: #F8F8F8; scrollbar-arrow-color: #5C5C8D}
input		{COLOR: #085878; FONT-FAMILY: Tahoma, Verdana, Arial; FONT-SIZE: 12px;  color: #00000; scrollbar-base-color: #F8F8F8; scrollbar-arrow-color: #5C5C8D}
.install	{FONT-FAMILY: Arial, Verdana; FONT-SIZE: 20px; FONT-WEIGHT: bold; COLOR: #000000}
</style>
</head>
<?

if(!in_array($language, array('chinese_gb2312', 'chinese_big5', 'english'))) {

?>
<body bgcolor="#9EB6D8">
<table cellpadding="0" cellspacing="0" border="0" width="100%" height="100%" align="center">
<tr><td valign="middle" align="center">

<table cellpadding="0" cellspacing="0" border="0" align="center">
  <tr align="center" valign="middle">
    <td bgcolor="#000000">
    <table cellpadding="10" cellspacing="1" border="0" width="600" height="100%" align="center">
    <tr>
      <td valign="middle" align="center" bgcolor="#FFFFFF">
        <br><br><b>Discuz! Board Installation Wizard</b><br><br>Please choose your prefered language<br><br><center><a href="?language=chinese_gb2312">[Simplfied Chinese]</a> &nbsp; <a href="#">[Traditional Chinese]</a> &nbsp; <a href="#">[English]</a><br><br>
      </td>
    </tr>
    </table>
    </td>
  </tr>
</table>

</td></td></table>
</body>
</html>
<?

	exit();
} else {
	$lang = $languageset[$language];

?>
<body bgcolor="#9EB6D8" text="#000000">
<table width="95%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center">
  <tr>
    <td>
      <table width="98%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td class="install" height="30" valign="bottom"><font color="#FF0000">&gt;&gt;</font> 
            <?=$lang['install_wizard']?></td>
        </tr>
        <tr>
          <td> 
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td align="center"> 
            <b><?=$lang['welcome']?></b>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
<?

}

if(!$action) {

	//$discuz_license = str_replace('  ', '&nbsp; ', nl2br(trim($lang['license'])));

?>
        <tr> 
          <td><b><?=$lang['current_process']?> </b><font color="#0000EE"><?=$lang['show_license']?></font></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['agreement']?></font></b></td>
        </tr>
        <tr>
          <td><br>
            <table width="90%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr>
                <td bgcolor="#F8F8F8">
                  <table width="99%" cellspacing="1" border="0" align="center">
                    <tr>
                      <td>
                        <?=$lang['license']?>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="config">
              <input type="submit" name="submit" value="<?=$lang['agreement_yes']?>" style="height: 25">&nbsp;
              <input type="button" name="exit" value="<?=$lang['agreement_no']?>" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

} elseif($action == 'config') {

	$exist_error = FALSE;
	$write_error = FALSE;
	if(file_exists('./config.php')) {
		$fileexists = result(1, 0);
	} else {
		$fileexists = result(0, 0);
		$exist_error = TRUE;
	}
	if(is_writeable('./config.php')) {
		$filewriteable = result(1, 0);
	} else {
		$filewriteable = result(0, 0);
		$write_error = TRUE;
	}
	if($exist_error) {
		$config_info = $lang['config_nonexistence'];
	} elseif(!$write_error) {
		$config_info = $lang['config_comment'];
	} elseif($write_error) {
		$config_info = $lang['config_unwriteable'];
	}

?>
        <tr> 
          <td><b><?=$lang['current_process']?> </b><font color="#0000EE"><?=$lang['configure']?></font></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['check_config']?></font></b></td>
        </tr>
        <tr>
          <td>config.php <?=$lang['check_existence']?> <?=$fileexists?></td>
        </tr>
        <tr>
          <td>config.php <?=$lang['check_writeable']?> <?=$filewriteable?></td>
        </tr>
        <tr> 
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['edit_config']?></font></b></td>
        </tr>
        <tr>
          <td align="center"><br><?=$config_info?></td>
        </tr>
<?

	if(!$exist_error) {

		if(!$write_error) {

			$dbhost = 'localhost';
			$dbuser = 'dbuser';
			$dbpw = 'dbpw';
			$dbname = 'dbname';
			$adminemail = 'admin@domain.com';
			$tablepre = 'cdb_';

			@include './config.php';

?>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <table width="650" cellspacing="1" bgcolor="#698CC3" border="0" align="center">
                <tr bgcolor="#698CC3">
                  <td align="center" width="20%" style="color: #FFFFFF"><?=$lang['variable']?></td>
                  <td align="center" width="30%" style="color: #FFFFFF"><?=$lang['value']?></td>
                  <td align="center" width="50%" style="color: #FFFFFF"><?=$lang['comment']?></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8" style="color: #FF0000">&nbsp;<?=$lang['dbhost']?></td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbhost" value="<?=$dbhost?>" size="30"></td>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['dbhost_comment']?></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['dbuser']?></td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbuser" value="<?=$dbuser?>" size="30"></td>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['dbuser_comment']?></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['dbpw']?></td>
                  <td bgcolor="#EEEEF6" align="center"><input type="password" name="dbpw" value="<?=$dbpw?>" size="30"></td>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['dbpw_comment']?></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['dbname']?></td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="dbname" value="<?=$dbname?>" size="30"></td>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['dbname_comment']?></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['email']?></td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="adminemail" value="<?=$adminemail?>" size="30"></td>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['email_comment']?></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8" style="color: #FF0000">&nbsp;<?=$lang['tablepre']?></td>
                  <td bgcolor="#EEEEF6" align="center"><input type="text" name="tablepre" value="<?=$tablepre?>" size="30" onClick="javascript: alert('<?=$lang['install_note']?>:\n\n<?=$lang['tablepre_prompt']?>');"></td>
                  <td bgcolor="#F8F8F8">&nbsp;<?=$lang['tablepre_comment']?></td>
                </tr>
              </table>
              <br>
              <input type="hidden" name="action" value="environment">
              <input type="hidden" name="saveconfig" value="1">
              <input type="submit" name="submit" value="<?=$lang['save_config']?>" style="height: 25">
              <input type="button" name="exit" value="<?=$lang['exit']?>" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

		} else {

			@include './config.php';

?>
        <tr>
          <td>
            <br>
            <table width="60%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr bgcolor="#698CC3">
                <td align="center" style="color: #FFFFFF"><?=$lang['variable']?></td>
                <td align="center" style="color: #FFFFFF"><?=$lang['value']?></td>
                <td align="center" style="color: #FFFFFF"><?=$lang['comment']?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">$dbhost</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbhost?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['dbhost_comment']?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">$dbuser</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbuser?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['dbuser_comment']?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">$dbpw</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbpw?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['dbpw_comment']?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">$dbname</td>
                <td bgcolor="#EEEEF6" align="center"><?=$dbname?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['dbname_comment']?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">$adminemail</td>
                <td bgcolor="#EEEEF6" align="center"><?=$adminemail?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['email_comment']?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">$tablepre</td>
                <td bgcolor="#EEEEF6" align="center"><?=$tablepre?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['tablepre_comment']?></td>
              </tr>
            </table>
            <br>
          </td>
        </tr>
        <tr>
          <td align="center">
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="environment">
              <input type="submit" name="submit" value="<?=$lang['confirm_config']?>" style="height: 25">
              <input type="button" name="exit" value="<?=$lang['refresh_config']?>" style="height: 25" onclick="javascript: window.location=('<?=$PHP_SELF?>&action=config');">
            </form>
          </td>
        </tr>
<?

		}

	} else {

?>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>">
              <input type="hidden" name="action" value="config">
              <input type="submit" name="submit" value="<?=$lang['recheck_config']?>" style="height: 25">
              <input type="button" name="exit" value="<?=$lang['exit']?>" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>
<?

	}

} elseif($action == 'environment') {

	if($_POST['saveconfig'] && is_writeable('./config.php')) {

		$dbhost = $_POST['dbhost'];
		$dbuser = $_POST['dbuser'];
		$dbpw = $_POST['dbpw'];
		$dbname = $_POST['dbname'];
		$adminemail = $_POST['adminemail'];
		$tablepre = $_POST['tablepre'];

		$fp = fopen('./config.php', 'r');
		$configfile = fread($fp, filesize('./config.php'));
		fclose($fp);

		$configfile = preg_replace("/[$]dbhost\s*\=\s*[\"'].*?[\"']/is", "\$dbhost = '$dbhost'", $configfile);
		$configfile = preg_replace("/[$]dbuser\s*\=\s*[\"'].*?[\"']/is", "\$dbuser = '$dbuser'", $configfile);
		$configfile = preg_replace("/[$]dbpw\s*\=\s*[\"'].*?[\"']/is", "\$dbpw = '$dbpw'", $configfile);
		$configfile = preg_replace("/[$]dbname\s*\=\s*[\"'].*?[\"']/is", "\$dbname = '$dbname'", $configfile);
		$configfile = preg_replace("/[$]adminemail\s*\=\s*[\"'].*?[\"']/is", "\$adminemail = '$adminemail'", $configfile);
		$configfile = preg_replace("/[$]tablepre\s*\=\s*[\"'].*?[\"']/is", "\$tablepre = '$tablepre'", $configfile);

		$fp = fopen('./config.php', 'w');
		fwrite($fp, trim($configfile));
		fclose($fp);

	}

	include './config.php';
	include './include/db_'.$database.'.php';
	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);

	$msg = '';
	$quit = FALSE;

	$curr_os = PHP_OS;

	$curr_php_version = PHP_VERSION;
	if($curr_php_version < '4.0.0') {
		$msg .= "<font color=\"#FF0000\">$lang[php_version_400]</font>\t";
		$quit = TRUE;
	} elseif($curr_php_version < '4.0.6') {
		$msg .= "<font color=\"#FF0000\">$lang[php_version_406]</font>\t";
	}

	if(@ini_get(file_uploads)) {
		$max_size = @ini_get(upload_max_filesize);
		$curr_upload_status = $lang['attach_enabled'].$max_size;
		$msg .= $lang['attach_enabled_info'].$max_size."\t";
	} else {
		$curr_upload_status = $lang['attach_disabled'];
		$msg .= "<font color=\"#FF0000\">$lang[attach_disabled_info]</font>\t";
	}

	$query = $db->query("SELECT VERSION()");
	$curr_mysql_version = $db->result($query, 0);
	if($curr_mysql_version < '3.23') {
		$msg .= "<font color=\"#FF0000\">$lang[mysql_version_323]</font>\t";
		$quit = TRUE;
	}

	$curr_disk_space = intval(diskfreespace('.') / (1024 * 1024)).'M';

	if(dir_writeable('./templates')) {
		$curr_tpl_writeable = $lang['writeable'];
	} else {
		$curr_tpl_writeable = $lang['unwriteable'];
		$msg .= "<font color=\"#FF0000\">$lang[unwriteable_template]</font>\t";
	}

	if(dir_writeable('./customavatars')) {
		$curr_avatar_writeable = $lang['writeable'];
	} else {
		$curr_avatar_writeable = $lang['unwriteable'];
		$msg .= "<font color=\"#FF0000\">$lang[unwriteable_avatar]</font>\t";
	}

	if(dir_writeable($attachdir)) {
		$curr_attach_writeable = $lang['writeable'];
	} else {
		$curr_attach_writeable = $lang['unwriteable'];
		$msg .= "<font color=\"#FF0000\">$lang[unwriteable_attach]</font>\t";
	}

	if(dir_writeable('./forumdata')) {
		$curr_data_writeable = $lang['writeable'];
	} else {
		$curr_data_writeable = $lang['unwriteable'];
		$msg .= "<font color=\"#FF0000\">$lang[unwriteable_forumdata]</font>\t";
	}

	if(dir_writeable('./forumdata/templates')) {
		$curr_template_writeable = $lang['writeable'];
	} else {
		$curr_template_writeable = $lang['unwriteable'];
		$msg .= "<font color=\"#FF0000\">$lang[unwriteable_forumdata_template]</font>\t";
		$quit = TRUE;
	}

	if(dir_writeable('./forumdata/cache')) {
		$curr_cache_writeable = $lang['writeable'];
	} else {
		$curr_cache_writeable = $lang['unwriteable'];
		$msg .= "<font color=\"#FF0000\">$lang[unwriteable_forumdata_cache]</font>\t";
		$quit = TRUE;
	}

	if(dir_writeable('./forumdata/accesslogs')) {
		$curr_accesslog_writeable = $lang['writeable'];
	} else {
		$curr_accesslog_writeable = $lang['unwriteable'];
		$msg .= "<font color=\"#FF0000\">$lang[unwriteable_forumdata_accesslog]</font>\t";
	}

	if(strstr($tablepre, '.')) {
		$msg .= "<font color=\"#FF0000\">$lang[tablepre_invalid]</font>\t";
		$quit = TRUE;
	}

	$db->select_db($dbname);
	if($db->error()) {
		$db->query("CREATE DATABASE $dbname");
		if($db->error()) {
			$msg .= "<font color=\"#FF0000\">$lang[db_invalid]</font>\t";
			$quit = TRUE;
		} else {
			$db->select_db($dbname);
			$msg .= "$lang[db_auto_created]\t";
		}
	}

	$query - $db->query("SELECT COUNT(*) FROM $tablepre"."settings", 'SILENT');
	if(!$db->error()) {
		$msg .= "<font color=\"#FF0000\">$lang[db_not_null]</font>\t";
		$alert = " onSubmit=\"return confirm('$lang[db_drop_table_confirm]');\"";
	} else {
		$alert = '';
	}

	if($quit) {
		$msg .= "<font color=\"#FF0000\">$lang[install_abort]</font>";
	} else {
		$msg .= $lang['install_process'];
	}
?>
        <tr>
          <td><b><?=$lang['current_process']?> </b><font color="#0000EE"><?=$lang['check_env']?></font></td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['compare_env']?></font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <table width="80%" cellspacing="1" bgcolor="#000000" border="0" align="center">
              <tr bgcolor="#698CC3">
                <td align="center"></td>
                <td align="center" style="color: #FFFFFF"><?=$lang['env_required']?></td>
                <td align="center" style="color: #FFFFFF"><?=$lang['env_best']?></td>
                <td align="center" style="color: #FFFFFF"><?=$lang['env_current']?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['env_os']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$lang['unlimited']?></td>
                <td bgcolor="#F8F8F8" align="center">UNIX/Linux/FreeBSD</td>
                <td bgcolor="#F8F8F8" align="center"><?=$curr_os?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['env_php']?></td>
                <td bgcolor="#EEEEF6" align="center">4.0.0+</td>
                <td bgcolor="#F8F8F8" align="center">4.0.6+</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_php_version?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['env_attach']?></td>
                <td bgcolor="#EEEEF6" align="center"3><?=$lang['unlimited']?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['enabled']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_upload_status?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['env_mysql']?></td>
                <td bgcolor="#EEEEF6" align="center">3.23+</td>
                <td bgcolor="#F8F8F8" align="center">4.0.13</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_mysql_version?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['env_diskspace']?></td>
                <td bgcolor="#EEEEF6" align="center">2M+</td>
                <td bgcolor="#F8F8F8" align="center">50M+</td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_disk_space?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">./templates <?=$lang['env_dir_writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$lang['unlimited']?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_tpl_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center"><?=$attachdir?> <?=$lang['env_dir_writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$lang['unlimited']?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_attach_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">./customavatars <?=$lang['env_dir_writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$lang['unlimited']?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_avatar_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">./forumdata <?=$lang['env_dir_writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$lang['unlimited']?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_data_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">./forumdata/templates <?=$lang['env_dir_writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_template_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">./forumdata/cache <?=$lang['env_dir_writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_cache_writeable?></td>
              </tr>
              <tr>
                <td bgcolor="#F8F8F8" align="center">./forumdata/accesslogs <?=$lang['env_dir_writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#F8F8F8" align="center"><?=$lang['writeable']?></td>
                <td bgcolor="#EEEEF6" align="center"><?=$curr_accesslog_writeable?></td>
              </tr>
            </table>
            <br>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['confirm_preparation']?></font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <ol><?=$lang['preparation']?></ol>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['install_note']?></font></b></td>
        </tr>
        <tr>
          <td>
            <br>
            <ol>
<?

	foreach(explode("\t", $msg) as $message) {
		echo "              <li>$message</li>\n";
	}
	echo"            </ol>\n";

	if($quit) {

?>
            <center>
            <input type="button" name="refresh" value="<?=$lang['recheck_config']?>" style="height: 25" onclick="javascript: window.location=('<?=$PHP_SELF?>&action=environment');">&nbsp;
            <input type="button" name="exit" value="<?=$lang['exit']?>" style="height: 25" onclick="javascript: window.close();">
            </center>
<?

	} else {

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['add_admin']?></font></b></td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <form method="post" action="<?=$PHP_SELF?>"<?=$alert?>>
              <table width="350" cellspacing="1" bgcolor="#000000" border="0" align="center">
                <tr>
                  <td bgcolor="#F8F8F8" width="40%">&nbsp;<?=$lang['username']?></td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="text" name="username" value="Crossday" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8" width="40%">&nbsp;<?=$lang['admin_email']?></td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="text" name="email" value="name@domain.com" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8" width="40%">&nbsp;<?=$lang['password']?></td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="password" name="password1" size="30"></td>
                </tr>
                <tr>
                  <td bgcolor="#F8F8F8" width="40%">&nbsp;<?=$lang['repeat_password']?></td>
                  <td bgcolor="#EEEEF6" width="60%"><input type="password" name="password2" size="30"></td>
                </tr>
              </table>
              <br>
              <input type="hidden" name="action" value="install">
              <input type="submit" name="submit" value="<?=$lang['start_install']?>" style="height: 25" >&nbsp;
              <input type="button" name="exit" value="<?=$lang['exit']?>" style="height: 25" onclick="javascript: window.close();">
            </form>
          </td>
        </tr>

<?

	}	

} elseif($action == 'install') {

	$username = $_POST['username'];
	$email = $_POST['email'];
	$password1 = $_POST['password1'];
	$password2 = $_POST['password2'];

?>
        <tr>
          <td><b><?=$lang['current_process']?> </b><font color="#0000EE"> <?=$lang['installing']?></font></td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['check_admin']?></font></b></td>
        </tr>
        <tr>
          <td><?=$lang['check_admin_validity']?>
<?

	$msg = '';
	if($username && $email && $password1 && $password2) {
		if($password1 != $password2) {
			$msg = $lang['admin_password_invalid'];
		} elseif(strlen($username) > 15 || preg_match("/^$|^c:\\con\\con$|��|[,\"\s\t\<\>&]|^�ο�|^Guest/is", $username)) {
			$msg = $lang['admin_username_invalid'];
		} elseif(!strstr($email, '@') || $email != stripslashes($email) || $email != htmlspecialchars($email)) {
			$msg = $lang['admin_email_invalid'];
		}
	} else {
		$msg = $lang['admin_invalid'];
	}

	if($msg) { 

?>
            ... <font color="#FF0000"><?=$lang['fail_reason']?> <?=$msg?></font></td>
        </tr>
        <tr>
          <td align="center">
            <br>
            <input type="button" name="back" value="<?=$lang['go_back']?>" onclick="javascript: history.go(-1);">
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td align="center">
            <b style="font-size: 11px">Powered by <a href="http://discuz.net" target="_blank">Discuz! <?=$version?></a> , &nbsp; Copyright &copy; <a href="http://www.discuz.com" target=\"_blank\">Comsenz Technology Ltd </a>, 2001-2005</b>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>

<?

		exit();
	} else {
		echo result(1, 0)."</td>\n";
		echo"        </tr>\n";
	}

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td><b><font color="#FF0000">&gt;</font><font color="#000000"> <?=$lang['select_db']?></font></b></td>
        </tr>
<?
	include './config.php';
	include './include/db_'.$database.'.php';
	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
	$db->select_db($dbname);

echo"        <tr>\n";
echo"          <td>$lang[select_db] $dbname ".result(1, 0)."</td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";
echo"            <hr noshade align=\"center\" width=\"100%\" size=\"1\">\n";
echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td><b><font color=\"#FF0000\">&gt;</font><font color=\"#000000\"> $lang[create_table]</font></b></td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";

	$sql = <<<EOT
DROP TABLE IF EXISTS cdb_access;
CREATE TABLE cdb_access (
  uid mediumint(8) unsigned NOT NULL default '0',
  fid smallint(6) unsigned NOT NULL default '0',
  allowview tinyint(1) NOT NULL default '0',
  allowpost tinyint(1) NOT NULL default '0',
  allowreply tinyint(1) NOT NULL default '0',
  allowgetattach tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (uid,fid)
);

DROP TABLE IF EXISTS cdb_admingroups;
CREATE TABLE cdb_admingroups (
  admingid smallint(3) unsigned NOT NULL auto_increment,
  admintitle char(30) NOT NULL default '',
  adminglobal tinyint(1) NOT NULL default '0',
  alloweditpost tinyint(1) NOT NULL default '0',
  alloweditpoll tinyint(1) NOT NULL default '0',
  allowdelpost tinyint(1) NOT NULL default '0',
  allowmassprune tinyint(1) NOT NULL default '0',
  allowcensorword tinyint(1) NOT NULL default '0',
  allowviewip tinyint(1) NOT NULL default '0',
  allowbanip tinyint(1) NOT NULL default '0',
  allowedituser tinyint(1) NOT NULL default '0',
  allowbanuser tinyint(1) NOT NULL default '0',
  allowpostannounce tinyint(1) NOT NULL default '0',
  allowviewlog tinyint(1) NOT NULL default '0',
  allowhighlight tinyint(1) NOT NULL default '0',
  allowdigest tinyint(1) NOT NULL default '0',
  allowclose tinyint(1) NOT NULL default '0',
  allowmove tinyint(1) NOT NULL default '0',
  allowtop tinyint(1) NOT NULL default '0',
  allowmerge tinyint(1) NOT NULL default '0',
  allowsplit tinyint(1) NOT NULL default '0',
  disablepostctrl tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (admingid)
) ;


INSERT INTO cdb_admingroups VALUES (1, 'Administrator', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO cdb_admingroups VALUES (2, 'SuperModerator', 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO cdb_admingroups VALUES (3, 'Moderator', 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1);
    

DROP TABLE IF EXISTS cdb_adminsessions;
CREATE TABLE cdb_adminsessions (
  uid mediumint(8) NOT NULL default '0',
  ip char(20) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  errorlog tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (uid,ip,dateline)
);

DROP TABLE IF EXISTS cdb_announcements;
CREATE TABLE cdb_announcements (
  id smallint(6) unsigned NOT NULL auto_increment,
  author varchar(15) NOT NULL default '',
  subject varchar(250) NOT NULL default '',
  posturl varchar(250) NOT NULL default '',
  displayorder tinyint(3) NOT NULL default '0',
  starttime int(10) unsigned NOT NULL default '0',
  endtime int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (id)
);

DROP TABLE IF EXISTS cdb_attachments;
CREATE TABLE cdb_attachments (
  aid mediumint(8) unsigned NOT NULL auto_increment,
  tid mediumint(8) unsigned NOT NULL default '0',
  pid int(10) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  creditsrequire smallint(6) unsigned NOT NULL default '0',
  filename char(100) NOT NULL default '',
  filetype char(50) NOT NULL default '',
  filesize int(10) unsigned NOT NULL default '0',
  attachment char(100) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  downloads smallint(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (aid),
  KEY tid (tid),
  KEY pid (pid),
  KEY uid (uid)

);

DROP TABLE IF EXISTS cdb_attachtypes;
CREATE TABLE cdb_attachtypes (
  id smallint(6) unsigned NOT NULL auto_increment,
  extension char(10) NOT NULL default '',
  maxsize int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (id)
);

DROP TABLE IF EXISTS cdb_banned;
CREATE TABLE cdb_banned (
  id smallint(6) unsigned NOT NULL auto_increment,
  ip1 smallint(3) NOT NULL default '0',
  ip2 smallint(3) NOT NULL default '0',
  ip3 smallint(3) NOT NULL default '0',
  ip4 smallint(3) NOT NULL default '0',
  admin varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  expiration int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (id)
);

DROP TABLE IF EXISTS cdb_bbcodes;
CREATE TABLE cdb_bbcodes (
  id mediumint(8) unsigned NOT NULL auto_increment,
  available tinyint(1) NOT NULL default '0',
  tag varchar(100) NOT NULL default '',
  replacement text NOT NULL,
  example varchar(255) NOT NULL default '',
  explanation text NOT NULL,
  params tinyint(1) unsigned NOT NULL default '1',
  nest tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (id)
);

DROP TABLE IF EXISTS cdb_buddys;
CREATE TABLE cdb_buddys (
  uid mediumint(8) unsigned NOT NULL default '0',
  buddyid mediumint(8) unsigned NOT NULL default '0',
  KEY uid (uid)
);

DROP TABLE IF EXISTS cdb_caches;
CREATE TABLE cdb_caches (
  cid int(10) unsigned NOT NULL auto_increment,
  ckey varchar(80) NOT NULL default '',
  cval text NOT NULL,
  dateline int(10) NOT NULL default '0',
  extr varchar(80) NOT NULL default '',
  PRIMARY KEY  (cid),
  KEY ckey (ckey)
);

DROP TABLE IF EXISTS cdb_failedlogins;
CREATE TABLE cdb_failedlogins (
  ip char(15) NOT NULL default '',
  count tinyint(1) unsigned NOT NULL default '0',
  lastupdate int(10) unsigned NOT NULL default '0'
);

DROP TABLE IF EXISTS cdb_favorites;
CREATE TABLE cdb_favorites (
  uid mediumint(8) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  KEY tid (tid)
);

DROP TABLE IF EXISTS cdb_forumlinks;
CREATE TABLE cdb_forumlinks (
  id smallint(6) unsigned NOT NULL auto_increment,
  displayorder tinyint(3) NOT NULL default '0',
  name varchar(100) NOT NULL default '',
  url varchar(200) NOT NULL default '',
  note varchar(200) NOT NULL default '',
  logo varchar(100) NOT NULL default '',
  PRIMARY KEY  (id)
);

INSERT INTO cdb_forumlinks VALUES (1, 0, 'Discuz! Board', 'http://www.discuz.com', 'Discuz! �ٷ���վ���ṩ���� Discuz! �������ء�ʹ�������뼼������', 'images/logo.gif');
INSERT INTO cdb_forumlinks VALUES (2, 0, 'Free Discuz!', 'http://www.freediscuz.net', 'Free Discuz!����� Discuz! �������', 'http://www.freediscuz.net/bbs/images/logo4.gif');

DROP TABLE IF EXISTS cdb_forums;
CREATE TABLE cdb_forums (
  fid smallint(6) unsigned NOT NULL auto_increment,
  fup smallint(6) unsigned NOT NULL default '0',
  type enum('group','forum','sub') NOT NULL default 'forum',
  icon char(50) NOT NULL default '',
  name char(255) NOT NULL default '',
  description char(255) NOT NULL default '',
  status tinyint(1) NOT NULL default '0',
  displayorder tinyint(3) NOT NULL default '0',
  moderator char(255) NOT NULL default '',
  styleid smallint(6) unsigned NOT NULL default '0',
  threads mediumint(8) unsigned NOT NULL default '0',
  posts mediumint(8) unsigned NOT NULL default '0',
  lastpost char(110) NOT NULL default '',
  allowsmilies tinyint(1) NOT NULL default '0',
  allowhtml tinyint(1) NOT NULL default '0',
  allowbbcode tinyint(1) NOT NULL default '0',
  allowimgcode tinyint(1) NOT NULL default '0',
  postcredits tinyint(3) NOT NULL default '-1',
  replycredits tinyint(3) NOT NULL default '-1',
  password char(12) NOT NULL default '',
  viewperm char(100) NOT NULL default '',
  postperm char(100) NOT NULL default '',
  replyperm char(100) NOT NULL default '',
  getattachperm char(100) NOT NULL default '',
  PRIMARY KEY  (fid),
  KEY forum (status,type,displayorder)
);

INSERT INTO cdb_forums VALUES (1, 0, 'forum', '', 'Ĭ����̳', '', 1, 0, '', 0, 0, 0, '', 1, 0, 1, 1, -1, -1, '', '', '', '', '');

DROP TABLE IF EXISTS cdb_karmalog;
CREATE TABLE cdb_karmalog (
  kid int(10) NOT NULL auto_increment,
  uid mediumint(8) unsigned NOT NULL default '0',
  pid int(10) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  score tinyint(3) NOT NULL default '0',
  PRIMARY KEY  (kid),
  KEY pid (pid),
  KEY dateline (dateline)
);

DROP TABLE IF EXISTS cdb_members;
CREATE TABLE cdb_members (
  uid mediumint(8) unsigned NOT NULL auto_increment,
  username varchar(15) NOT NULL default '',
  password varchar(32) NOT NULL default '',
  secques varchar(8) NOT NULL default '',
  gender tinyint(1) NOT NULL default '0',
  adminid smallint(3) NOT NULL default '0',
  groupid smallint(6) unsigned NOT NULL default '0',
  regip varchar(15) NOT NULL default '',
  regdate int(10) unsigned NOT NULL default '0',
  lastip varchar(15) NOT NULL default '',
  lastvisit int(10) unsigned NOT NULL default '0',
  lastactivity int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  postnum smallint(6) unsigned NOT NULL default '0',
  credit int(10) NOT NULL default '0',
  extracredit int(10) NOT NULL default '0',
  email varchar(60) NOT NULL default '',
  site varchar(75) NOT NULL default '',
  icq varchar(12) NOT NULL default '',
  oicq varchar(12) NOT NULL default '',
  yahoo varchar(40) NOT NULL default '',
  msn varchar(40) NOT NULL default '',
  location varchar(30) NOT NULL default '',
  bday date NOT NULL default '0000-00-00',
  bio text NOT NULL,
  avatar varchar(100) NOT NULL default '',
  avatarwidth tinyint(3) unsigned NOT NULL default '0',
  avatarheight tinyint(3) unsigned NOT NULL default '0',
  signature text NOT NULL,
  customstatus varchar(30) NOT NULL default '',
  tpp tinyint(3) unsigned NOT NULL default '0',
  ppp tinyint(3) unsigned NOT NULL default '0',
  styleid smallint(6) unsigned NOT NULL default '0',
  dateformat varchar(10) NOT NULL default '',
  timeformat varchar(5) NOT NULL default '',
  showemail tinyint(1) NOT NULL default '0',
  newsletter tinyint(1) NOT NULL default '0',
  invisible tinyint(1) NOT NULL default '0',
  timeoffset char(4) NOT NULL default '',
  ignorepm text NOT NULL,
  newpm tinyint(1) NOT NULL default '0',
  accessmasks tinyint(1) NOT NULL default '0',
  identifying varchar(20) NOT NULL default '',
  PRIMARY KEY  (uid),
  KEY username (username)
);

DROP TABLE IF EXISTS cdb_onlinelist;
CREATE TABLE cdb_onlinelist (
  groupid smallint(6) unsigned NOT NULL default '0',
  displayorder tinyint(3) NOT NULL default '0',
  title varchar(30) NOT NULL default '',
  url varchar(30) NOT NULL default ''
);

INSERT INTO cdb_onlinelist VALUES (1, 1, '����Ա', 'online_admin.gif');
INSERT INTO cdb_onlinelist VALUES (2, 2, '��������', 'online_supermod.gif');
INSERT INTO cdb_onlinelist VALUES (3, 3, '����', 'online_moderator.gif');
INSERT INTO cdb_onlinelist VALUES (0, 4, 'ע���û�', 'online_member.gif');

DROP TABLE IF EXISTS cdb_pms;
CREATE TABLE cdb_pms (
  pmid int(10) unsigned NOT NULL auto_increment,
  msgfrom varchar(15) NOT NULL default '',
  msgfromid mediumint(8) unsigned NOT NULL default '0',
  msgtoid mediumint(8) unsigned NOT NULL default '0',
  folder enum('inbox','outbox') NOT NULL default 'inbox',
  new tinyint(1) NOT NULL default '0',
  subject varchar(75) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (pmid),
  KEY msgtoid (msgtoid),
  KEY msgfromid (msgfromid)
);

DROP TABLE IF EXISTS cdb_polls;
CREATE TABLE cdb_polls (
  tid mediumint(8) unsigned NOT NULL default '0',
  pollopts mediumtext NOT NULL,
  PRIMARY KEY  (tid)
);

DROP TABLE IF EXISTS cdb_posts;
CREATE TABLE cdb_posts (
  pid int(10) unsigned NOT NULL auto_increment,
  fid smallint(6) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  aid tinyint(1) NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  authorid mediumint(8) unsigned NOT NULL default '0',
  subject varchar(80) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  message mediumtext NOT NULL,
  useip varchar(15) NOT NULL default '',
  usesig tinyint(1) NOT NULL default '0',
  bbcodeoff tinyint(1) NOT NULL default '0',
  smileyoff tinyint(1) NOT NULL default '0',
  parseurloff tinyint(1) NOT NULL default '0',
  rate smallint(6) NOT NULL default '0',
  ratetimes tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (pid),
  KEY fid (fid),
  KEY dateline (dateline),
  KEY authorid (authorid),
  KEY tid (tid,dateline)
);

DROP TABLE IF EXISTS cdb_ranks;
CREATE TABLE cdb_ranks (
  rankid smallint(6) unsigned NOT NULL auto_increment,
  ranktitle varchar(30) NOT NULL default '',
  postshigher smallint(6) unsigned NOT NULL default '0',
  stars tinyint(3) NOT NULL default '0',
  color varchar(7) NOT NULL default '',
  PRIMARY KEY  (rankid)
);

INSERT INTO cdb_ranks VALUES (1, 'Beginner', 0, 1, '');
INSERT INTO cdb_ranks VALUES (2, 'Poster', 50, 2, '');
INSERT INTO cdb_ranks VALUES (3, 'Cool Poster', 300, 5, '');
INSERT INTO cdb_ranks VALUES (4, 'Writer', 1000, 4, '');
INSERT INTO cdb_ranks VALUES (5, 'Excellent Writer', 3000, 5, '');

DROP TABLE IF EXISTS cdb_searchindex;
CREATE TABLE cdb_searchindex (
  searchid int(10) unsigned NOT NULL auto_increment,
  keywords varchar(255) NOT NULL default '',
  searchstring varchar(255) NOT NULL default '',
  useip varchar(15) NOT NULL default '',
  uid mediumint(10) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  expiration int(10) unsigned NOT NULL default '0',
  threads smallint(6) unsigned NOT NULL default '0',
  tids text NOT NULL,
  PRIMARY KEY  (searchid)
);

DROP TABLE IF EXISTS cdb_sessions;
CREATE TABLE cdb_sessions (
  sid char(6) binary NOT NULL default '',
  ip1 tinyint(3) unsigned NOT NULL default '0',
  ip2 tinyint(3) unsigned NOT NULL default '0',
  ip3 tinyint(3) unsigned NOT NULL default '0',
  ip4 tinyint(3) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  groupid smallint(6) unsigned NOT NULL default '0',
  styleid smallint(6) unsigned NOT NULL default '0',
  invisible tinyint(1) NOT NULL default '0',
  action tinyint(1) unsigned NOT NULL default '0',
  lastactivity int(10) unsigned NOT NULL default '0',
  fid smallint(6) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  UNIQUE KEY sid (sid)
) TYPE=HEAP MAX_ROWS=2000;

DROP TABLE IF EXISTS cdb_settings;
CREATE TABLE cdb_settings (
  variable varchar(32) NOT NULL default '',
  value text NOT NULL,
  PRIMARY KEY  (variable)
);

INSERT INTO cdb_settings VALUES ('announcements_num', 0x31);
INSERT INTO cdb_settings VALUES ('attachimgpost', 0x31);
INSERT INTO cdb_settings VALUES ('attachrefcheck', 0x30);
INSERT INTO cdb_settings VALUES ('attachsave', 0x31);
INSERT INTO cdb_settings VALUES ('attachimgcheck', 0x30);
INSERT INTO cdb_settings VALUES ('attachsoftdownload', 0x30);
INSERT INTO cdb_settings VALUES ('attach_max', 0x30);
INSERT INTO cdb_settings VALUES ('attach_newpost', 0x32);
INSERT INTO cdb_settings VALUES ('attach_editpost', 0x31);
INSERT INTO cdb_settings VALUES ('attach_replypost', 0x31);
INSERT INTO cdb_settings VALUES ('bbclosed', 0x30);
INSERT INTO cdb_settings VALUES ('bbinsert', 0x31);
INSERT INTO cdb_settings VALUES ('bbname', 0x44697363757a2120426f617264);
INSERT INTO cdb_settings VALUES ('bbrules', 0x30);
INSERT INTO cdb_settings VALUES ('bbrulestxt', '');
INSERT INTO cdb_settings VALUES ('censoruser', '');
INSERT INTO cdb_settings VALUES ('closedreason', '');
INSERT INTO cdb_settings VALUES ('statcacherefresh', 0x33363030);
INSERT INTO cdb_settings VALUES ('dateformat', 0x592d6e2d6a);
INSERT INTO cdb_settings VALUES ('debug', 0x31);
INSERT INTO cdb_settings VALUES ('delayviewcount', 0x30);
INSERT INTO cdb_settings VALUES ('delayeditpost', 0x30);
INSERT INTO cdb_settings VALUES ('delayreply', 0x30);
INSERT INTO cdb_settings VALUES ('delaykarma', 0x30);
INSERT INTO cdb_settings VALUES ('deletedcredits', 0x31);
INSERT INTO cdb_settings VALUES ('digestcredits', 0x3130);
INSERT INTO cdb_settings VALUES ('dosevasive', 0x30);
INSERT INTO cdb_settings VALUES ('doublee', 0x31);
INSERT INTO cdb_settings VALUES ('editedby', 0x31);
INSERT INTO cdb_settings VALUES ('fastpost', 0x31);
INSERT INTO cdb_settings VALUES ('floodctrl', 0x3135);
INSERT INTO cdb_settings VALUES ('forumjump', 0x31);
INSERT INTO cdb_settings VALUES ('gzipcompress', 0x30);
INSERT INTO cdb_settings VALUES ('hideprivate', 0x31);
INSERT INTO cdb_settings VALUES ('hottopic', 0x3130);
INSERT INTO cdb_settings VALUES ('loadctrl', 0x30);
INSERT INTO cdb_settings VALUES ('logincredits', 0x30);
INSERT INTO cdb_settings VALUES ('maxavatarpixel', 0x313230);
INSERT INTO cdb_settings VALUES ('maxavatarsize', 0x30);
INSERT INTO cdb_settings VALUES ('maxonlines', 0x31303030);
INSERT INTO cdb_settings VALUES ('maxpolloptions', 0x3130);
INSERT INTO cdb_settings VALUES ('maxpostsize', 0x3130303030);
INSERT INTO cdb_settings VALUES ('maxsearchresults', 0x353132);
INSERT INTO cdb_settings VALUES ('memberperpage', 0x3235);
INSERT INTO cdb_settings VALUES ('memliststatus', 0x31);
INSERT INTO cdb_settings VALUES ('minpostsize', 0x30);
INSERT INTO cdb_settings VALUES ('moddisplay', 0x666c6174);
INSERT INTO cdb_settings VALUES ('modshortcut', 0x30);
INSERT INTO cdb_settings VALUES ('newbiespan', 0x30);
INSERT INTO cdb_settings VALUES ('nocacheheaders', 0x30);
INSERT INTO cdb_settings VALUES ('onlinerecord', 0x310931303430303334363439);
INSERT INTO cdb_settings VALUES ('postcredits', 0x31);
INSERT INTO cdb_settings VALUES ('postperpage', 0x3130);
INSERT INTO cdb_settings VALUES ('regctrl', 0x30);
INSERT INTO cdb_settings VALUES ('regstatus', 0x31);
INSERT INTO cdb_settings VALUES ('regverify', 0x30);
INSERT INTO cdb_settings VALUES ('replycredits', 0x31);
INSERT INTO cdb_settings VALUES ('reportpost', 0x31);
INSERT INTO cdb_settings VALUES ('searchctrl', 0x3330);
INSERT INTO cdb_settings VALUES ('sitename', '������ʢ���ͿƼ����޹�˾');
INSERT INTO cdb_settings VALUES ('siteurl', 0x687474703a2f2f7777772e63726f73736461792e636f6d2f);
INSERT INTO cdb_settings VALUES ('smcols', 0x33);
INSERT INTO cdb_settings VALUES ('smileyinsert', 0x31);
INSERT INTO cdb_settings VALUES ('statstatus', 0x30);
INSERT INTO cdb_settings VALUES ('styleid', 0x31);
INSERT INTO cdb_settings VALUES ('timeformat', 0x683a692041);
INSERT INTO cdb_settings VALUES ('timeoffset', 0x38);
INSERT INTO cdb_settings VALUES ('topicperpage', 0x3230);
INSERT INTO cdb_settings VALUES ('userstatusby', 0x31);
INSERT INTO cdb_settings VALUES ('version', 0x322e35);
INSERT INTO cdb_settings VALUES ('vtonlinestatus', 0x30);
INSERT INTO cdb_settings VALUES ('welcomemsg', 0x30);
INSERT INTO cdb_settings VALUES ('welcomemsgtxt', '');
INSERT INTO cdb_settings VALUES ('whosonlinestatus', 0x31);
INSERT INTO cdb_settings VALUES ('useimagemessage', 0x31);

DROP TABLE IF EXISTS cdb_smilies;
CREATE TABLE cdb_smilies (
  id smallint(6) unsigned NOT NULL auto_increment,
  type enum('smiley','icon') NOT NULL default 'smiley',
  code varchar(10) NOT NULL default '',
  url varchar(30) NOT NULL default '',
  PRIMARY KEY  (id)
);

INSERT INTO cdb_smilies VALUES (1, 'smiley', ':)', 'smile.gif');
INSERT INTO cdb_smilies VALUES (2, 'smiley', ':(', 'sad.gif');
INSERT INTO cdb_smilies VALUES (3, 'smiley', ':D', 'biggrin.gif');
INSERT INTO cdb_smilies VALUES (4, 'smiley', ';)', 'wink.gif');
INSERT INTO cdb_smilies VALUES (5, 'smiley', ':cool:', 'cool.gif');
INSERT INTO cdb_smilies VALUES (6, 'smiley', ':mad:', 'mad.gif');
INSERT INTO cdb_smilies VALUES (7, 'smiley', ':o', 'shocked.gif');
INSERT INTO cdb_smilies VALUES (8, 'smiley', ':P', 'tongue.gif');
INSERT INTO cdb_smilies VALUES (9, 'smiley', ':lol:', 'lol.gif');
INSERT INTO cdb_smilies VALUES (10, 'icon', '', 'icon1.gif');
INSERT INTO cdb_smilies VALUES (11, 'icon', '', 'icon2.gif');
INSERT INTO cdb_smilies VALUES (12, 'icon', '', 'icon3.gif');
INSERT INTO cdb_smilies VALUES (13, 'icon', '', 'icon4.gif');
INSERT INTO cdb_smilies VALUES (14, 'icon', '', 'icon5.gif');
INSERT INTO cdb_smilies VALUES (15, 'icon', '', 'icon6.gif');
INSERT INTO cdb_smilies VALUES (16, 'icon', '', 'icon7.gif');
INSERT INTO cdb_smilies VALUES (17, 'icon', '', 'icon8.gif');
INSERT INTO cdb_smilies VALUES (18, 'icon', '', 'icon9.gif');

DROP TABLE IF EXISTS cdb_stats;
CREATE TABLE cdb_stats (
  type varchar(20) NOT NULL default '',
  var varchar(20) NOT NULL default '',
  count int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (type,var)
);

INSERT INTO cdb_stats VALUES ('total', 'hits', 0);
INSERT INTO cdb_stats VALUES ('total', 'members', 0);
INSERT INTO cdb_stats VALUES ('total', 'guests', 0);
INSERT INTO cdb_stats VALUES ('os', 'Windows', 0);
INSERT INTO cdb_stats VALUES ('os', 'Mac', 0);
INSERT INTO cdb_stats VALUES ('os', 'Linux', 0);
INSERT INTO cdb_stats VALUES ('os', 'FreeBSD', 0);
INSERT INTO cdb_stats VALUES ('os', 'SunOS', 0);
INSERT INTO cdb_stats VALUES ('os', 'BeOS', 0);
INSERT INTO cdb_stats VALUES ('os', 'OS/2', 0);
INSERT INTO cdb_stats VALUES ('os', 'AIX', 0);
INSERT INTO cdb_stats VALUES ('os', 'Other', 0);
INSERT INTO cdb_stats VALUES ('browser', 'MSIE', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Netscape', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Mozilla', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Lynx', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Opera', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Konqueror', 0);
INSERT INTO cdb_stats VALUES ('browser', 'Other', 0);
INSERT INTO cdb_stats VALUES ('week', '0', 0);
INSERT INTO cdb_stats VALUES ('week', '1', 0);
INSERT INTO cdb_stats VALUES ('week', '2', 0);
INSERT INTO cdb_stats VALUES ('week', '3', 0);
INSERT INTO cdb_stats VALUES ('week', '4', 0);
INSERT INTO cdb_stats VALUES ('week', '5', 0);
INSERT INTO cdb_stats VALUES ('week', '6', 0);
INSERT INTO cdb_stats VALUES ('hour', '00', 0);
INSERT INTO cdb_stats VALUES ('hour', '01', 0);
INSERT INTO cdb_stats VALUES ('hour', '02', 0);
INSERT INTO cdb_stats VALUES ('hour', '03', 0);
INSERT INTO cdb_stats VALUES ('hour', '04', 0);
INSERT INTO cdb_stats VALUES ('hour', '05', 0);
INSERT INTO cdb_stats VALUES ('hour', '06', 0);
INSERT INTO cdb_stats VALUES ('hour', '07', 0);
INSERT INTO cdb_stats VALUES ('hour', '08', 0);
INSERT INTO cdb_stats VALUES ('hour', '09', 0);
INSERT INTO cdb_stats VALUES ('hour', '10', 0);
INSERT INTO cdb_stats VALUES ('hour', '11', 0);
INSERT INTO cdb_stats VALUES ('hour', '12', 0);
INSERT INTO cdb_stats VALUES ('hour', '13', 0);
INSERT INTO cdb_stats VALUES ('hour', '14', 0);
INSERT INTO cdb_stats VALUES ('hour', '15', 0);
INSERT INTO cdb_stats VALUES ('hour', '16', 0);
INSERT INTO cdb_stats VALUES ('hour', '17', 0);
INSERT INTO cdb_stats VALUES ('hour', '18', 0);
INSERT INTO cdb_stats VALUES ('hour', '19', 0);
INSERT INTO cdb_stats VALUES ('hour', '20', 0);
INSERT INTO cdb_stats VALUES ('hour', '21', 0);
INSERT INTO cdb_stats VALUES ('hour', '22', 0);
INSERT INTO cdb_stats VALUES ('hour', '23', 0);

DROP TABLE IF EXISTS cdb_styles;
CREATE TABLE cdb_styles (
  styleid smallint(6) unsigned NOT NULL auto_increment,
  name varchar(20) NOT NULL default '',
  available tinyint(1) NOT NULL default '1',
  templateid smallint(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (styleid),
  KEY themename (name)
);

INSERT INTO cdb_styles VALUES (1, 'Default Style', 1, 1);

DROP TABLE IF EXISTS cdb_stylevars;
CREATE TABLE cdb_stylevars (
  stylevarid smallint(6) unsigned NOT NULL auto_increment,
  styleid smallint(6) unsigned NOT NULL default '0',
  variable text NOT NULL,
  substitute text NOT NULL,
  PRIMARY KEY  (stylevarid),
  KEY styleid (styleid)
);

INSERT INTO cdb_stylevars VALUES (1, 1, 'bgcolor', '#E9EDF7');
INSERT INTO cdb_stylevars VALUES (2, 1, 'altbg1', '#F8F9FC');
INSERT INTO cdb_stylevars VALUES (3, 1, 'altbg2', '#FFFFFF');
INSERT INTO cdb_stylevars VALUES (4, 1, 'link', '#003366');
INSERT INTO cdb_stylevars VALUES (5, 1, 'bordercolor', '#DDE3EC');
INSERT INTO cdb_stylevars VALUES (6, 1, 'headercolor', 'headerbg.gif');
INSERT INTO cdb_stylevars VALUES (7, 1, 'headertext', '#FFFFFF');
INSERT INTO cdb_stylevars VALUES (8, 1, 'catcolor', 'catbg.gif');
INSERT INTO cdb_stylevars VALUES (9, 1, 'tabletext', '#000000');
INSERT INTO cdb_stylevars VALUES (10, 1, 'text', '#000000');
INSERT INTO cdb_stylevars VALUES (11, 1, 'borderwidth', '1');
INSERT INTO cdb_stylevars VALUES (12, 1, 'tablewidth', '99%');
INSERT INTO cdb_stylevars VALUES (13, 1, 'tablespace', '4');
INSERT INTO cdb_stylevars VALUES (14, 1, 'font', 'Tahoma, Verdana');
INSERT INTO cdb_stylevars VALUES (15, 1, 'fontsize', '12px');
INSERT INTO cdb_stylevars VALUES (16, 1, 'nobold', '0');
INSERT INTO cdb_stylevars VALUES (17, 1, 'boardimg', 'logo.gif');
INSERT INTO cdb_stylevars VALUES (18, 1, 'imgdir', 'images/default');
INSERT INTO cdb_stylevars VALUES (19, 1, 'smdir', 'images/smilies');
INSERT INTO cdb_stylevars VALUES (20, 1, 'cattext', '#000000');
INSERT INTO cdb_stylevars VALUES (21, 1, 'smfontsize', '11px');
INSERT INTO cdb_stylevars VALUES (22, 1, 'smfont', 'Tahoma');
INSERT INTO cdb_stylevars VALUES (23, 1, 'maintablespace', '8');
INSERT INTO cdb_stylevars VALUES (24, 1, 'maintablewidth', '98%');
INSERT INTO cdb_stylevars VALUES (25, 1, 'maintablecolor', '#FFFFFF');


DROP TABLE IF EXISTS cdb_subscriptions;
CREATE TABLE cdb_subscriptions (
  uid mediumint(8) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  email varchar(60) NOT NULL default '',
  lastnotify int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid,tid)
);

DROP TABLE IF EXISTS cdb_templates;
CREATE TABLE cdb_templates (
  templateid smallint(6) unsigned NOT NULL auto_increment,
  name varchar(30) NOT NULL default '',
  charset varchar(30) NOT NULL default '',
  directory varchar(100) NOT NULL default '',
  copyright varchar(100) NOT NULL default '',
  PRIMARY KEY  (templateid)
);

INSERT INTO cdb_templates VALUES (1, 'Default', '$lang[charset]', './templates/default', 'Designed by ARTERY');

DROP TABLE IF EXISTS cdb_threads;
CREATE TABLE cdb_threads (
  tid mediumint(8) unsigned NOT NULL auto_increment,
  fid smallint(6) unsigned NOT NULL default '0',
  creditsrequire smallint(6) unsigned NOT NULL default '0',
  iconid smallint(6) unsigned NOT NULL default '0',
  author char(15) NOT NULL default '',
  authorid mediumint(8) unsigned NOT NULL default '0',
  subject char(80) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  lastposter char(15) NOT NULL default '',
  views mediumint(8) unsigned NOT NULL default '0',
  replies smallint(6) unsigned NOT NULL default '0',
  displayorder tinyint(1) NOT NULL default '0',
  highlight tinyint(1) NOT NULL default '0',
  digest tinyint(1) NOT NULL default '0',
  poll tinyint(1) NOT NULL default '0',
  attachment tinyint(1) NOT NULL default '0',
  closed mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (tid),
  KEY displayorder (fid,displayorder,lastpost),
  KEY digest (digest)
);

DROP TABLE IF EXISTS cdb_usergroups;
CREATE TABLE cdb_usergroups (
  groupid smallint(6) unsigned NOT NULL auto_increment,
  type enum('system','special','member') NOT NULL default 'member',
  grouptitle char(30) NOT NULL default '',
  creditshigher int(10) NOT NULL default '0',
  creditslower int(10) NOT NULL default '0',
  stars tinyint(3) NOT NULL default '0',
  color char(7) NOT NULL default '',
  groupavatar char(60) NOT NULL default '',
  allowcstatus tinyint(1) NOT NULL default '0',
  allowavatar tinyint(1) NOT NULL default '0',
  allowvisit tinyint(1) NOT NULL default '0',
  allowview tinyint(1) NOT NULL default '0',
  allowpost tinyint(1) NOT NULL default '0',
  allowpostpoll tinyint(1) NOT NULL default '0',
  allowgetattach tinyint(1) NOT NULL default '0',
  allowpostattach tinyint(1) NOT NULL default '0',
  allowvote tinyint(1) NOT NULL default '0',
  allowsearch tinyint(1) NOT NULL default '0',
  allowkarma tinyint(1) NOT NULL default '0',
  allowinvisible tinyint(1) NOT NULL default '0',
  allowsetviewperm tinyint(1) NOT NULL default '0',
  allowsetattachperm tinyint(1) NOT NULL default '0',
  allowhidecode tinyint(1) NOT NULL default '0',
  allowsigbbcode tinyint(1) NOT NULL default '0',
  allowsigimgcode tinyint(1) NOT NULL default '0',
  allowviewstats tinyint(1) NOT NULL default '0',
  maxpmnum smallint(6) unsigned NOT NULL default '0',
  maxsigsize smallint(6) unsigned NOT NULL default '0',
  maxkarmarate tinyint(3) unsigned NOT NULL default '0',
  maxrateperday smallint(6) unsigned NOT NULL default '0',
  maxattachsize int(10) unsigned NOT NULL default '0',
  attachextensions char(255) NOT NULL default '',
  PRIMARY KEY  (groupid),
  KEY creditsrange (creditshigher,creditslower)
);

INSERT INTO cdb_usergroups VALUES (1, 'system', '����Ա', 0, 0, 9, '', '', 1, 3, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 200, 500, 30, 500, 2048000, '');
INSERT INTO cdb_usergroups VALUES (2, 'system', '��������', 0, 0, 8, '', '', 1, 3, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 120, 300, 15, 50, 2048000, '');
INSERT INTO cdb_usergroups VALUES (3, 'system', '����', 0, 0, 7, '', '', 1, 3, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 80, 200, 10, 30, 2048000, 'chm,pdf,zip,rar,tar,tgz,gif,jpg,jpeg,png');
INSERT INTO cdb_usergroups VALUES (4, 'system', '��ֹ����', 0, 0, 0, '', '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (5, 'system', '��ֹ����', 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (6, 'system', 'IP ��ֹ', 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (7, 'system', '�ο�', 0, 0, 0, '', '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (8, 'system', '�ȴ���֤�û�', 0, 0, 0, '', '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 50, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (9, 'member', '������ؤ', -9999999, 0, 0, '', '', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (10, 'member', '������·', 0, 50, 1, '', '', 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 20, 80, 0, 0, 0, '');
INSERT INTO cdb_usergroups VALUES (11, 'member', 'ע���û�', 50, 200, 2, '', '', 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 30, 100, 4, 10, 0, '');
INSERT INTO cdb_usergroups VALUES (12, 'member', '�м��û�', 200, 500, 3, '', '', 0, 2, 1, 1, 1, 1, 1, 0, 1, 2, 0, 0, 0, 0, 0, 1, 0, 1, 50, 150, 6, 15, 256000, 'gif,jpg,jpeg,png');
INSERT INTO cdb_usergroups VALUES (13, 'member', '�߼��û�', 500, 1000, 4, '', '', 1, 3, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 0, 0, 0, 1, 0, 1, 60, 200, 10, 30, 512000, 'zip,rar,tar,tgz,gif,jpg,jpeg,png');
INSERT INTO cdb_usergroups VALUES (14, 'member', '���ƻ�Ա', 1000, 3000, 6, '', '', 1, 3, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 0, 1, 1, 1, 80, 300, 15, 40, 1024000, 'chm,pdf,zip,rar,tar,tgz,gif,jpg,jpeg,png');
INSERT INTO cdb_usergroups VALUES (15, 'member', '���ƻ�Ա', 3000, 9999999, 8, '', '', 1, 3, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 0, 1, 1, 1, 100, 500, 20, 50, 2048000, 'chm,pdf,zip,rar,tar,tgz,gif,jpg,jpeg,png');

DROP TABLE IF EXISTS cdb_words;
CREATE TABLE cdb_words (
  id smallint(6) unsigned NOT NULL auto_increment,
  admin varchar(15) NOT NULL default '',
  find varchar(60) NOT NULL default '',
  replacement varchar(60) NOT NULL default '',
  PRIMARY KEY  (id)
);

DROP TABLE IF EXISTS cdb_plugins;
CREATE TABLE cdb_plugins (
  plug_id smallint(6) NOT NULL auto_increment,
  plug_title varchar(255) NOT NULL default '',
  plug_version varchar(255) NOT NULL default '',
  plug_author varchar(255) NOT NULL default '0',
  plug_key varchar(255) NOT NULL default '',
  plug_stats tinyint(1) NOT NULL default '0',
  plug_cp varchar(255) NOT NULL default '',
  plug_tables varchar(255) NOT NULL default '',
  plug_license text NOT NULL,
  plug_desc text NOT NULL,
  PRIMARY KEY  (plug_id),
  KEY plug_keyword (plug_key)
);

DROP TABLE IF EXISTS cdb_plugins_settings;
CREATE TABLE cdb_plugins_settings (
  conf_id int(10) unsigned NOT NULL auto_increment,
  conf_title varchar(255) NOT NULL default '',
  conf_desc text NOT NULL,
  conf_group varchar(255) NOT NULL default '',
  conf_type varchar(255) NOT NULL default '',
  conf_key varchar(255) NOT NULL default '',
  conf_value text NOT NULL,
  conf_extra text NOT NULL,
  conf_position smallint(3) unsigned NOT NULL default '0',
  conf_cached tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (conf_id),
  KEY conf_group (conf_group)
);

EOT;

	runquery($sql);
	$db->query("DELETE FROM {$tablepre}members");
	$db->query("INSERT INTO {$tablepre}members (username, password, adminid, groupid, regip, regdate, lastvisit, lastpost, email, dateformat, timeformat, showemail, newsletter, timeoffset)
		VALUES ('$username', '".md5($password1)."', '1', '1', 'hidden', '".time()."', '".time()."', '".time()."', '$email', 'Y-n-j', 'h:i A', '1', '1', '8');");

echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";
echo"            <hr noshade align=\"center\" width=\"100%\" size=\"1\">\n";
echo"          </td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td><b><font color=\"#FF0000\">&gt;</font><font color=\"#000000\"> $lang[init_file]</font></b></td>\n";
echo"        </tr>\n";
echo"        <tr>\n";
echo"          <td>\n";

loginit('karmalog');
loginit('illegallog');
loginit('modslog');
loginit('cplog');
dir_clear('./forumdata/templates');
dir_clear('./forumdata/cache');
dir_clear('./forumdata/accesslogs');

?>
          </td>
        </tr>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr>
          <td align="center">
            <font color="#FF0000"><b><?=$lang['install_succeed']?></font><br>
            <?=$lang['username']?></b> <?=$username?><b> &nbsp; <?=$lang['password']?></b> <?=$password1?><br><br>
            <a href="index.php" target="_blank"><?=$lang['goto_forum']?></a>
          </td>
        </tr>
<?

	
}

?>
        <tr>
          <td>
            <hr noshade align="center" width="100%" size="1">
          </td>
        </tr>
        <tr> 
          <td align="center">
            <b style="font-size: 11px">Powered by <a href="http://discuz.net" target="_blank">Discuz! <?=$version?></a> , &nbsp; Copyright &copy; <a href="http://www.discuz.com" target=\"_blank\">Comsenz Technology Ltd </a>, 2001-2005</b>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
</body>
</html>

