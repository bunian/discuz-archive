<?php  if(!defined('IN_ADMINCP')) exit('Access Denied'); ?>
<br><br><br><br><hr size="0" noshade color="<?=BORDERCOLOR?>" width="80%">
<center><font style="font-size: 11px; font-family: Tahoma, Verdana, Arial">Powered by <a href="http://www.discuz.net" target="_blank" style="color: <?=TEXT?>"><b>Discuz!</b> <?=$version?></a> &nbsp;&copy; 2001-2005, <b>
<a href="http://www.discuz.com" target="_blank" style="color: <?=TEXT?>">&#x5317;&#x4EAC;&#x5EB7;&#x76DB;&#x4E16;&#x7EAA;&#x79D1;&#x6280;&#x6709;&#x9650;&#x516C;&#x53F8;</a></b></font>
</body>
</html>
