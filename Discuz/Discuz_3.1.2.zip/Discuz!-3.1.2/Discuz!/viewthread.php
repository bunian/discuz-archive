<?php

/*
	[DISCUZ!] viewthread.php - view thread posts
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.2
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/10/11 05:52
*/

require_once './include/common.php';
require_once DISCUZ_ROOT.'./include/forum.php';
require_once DISCUZ_ROOT.'./include/discuzcode.php';

$discuz_action = 3;

$query = $db->query("SELECT * FROM $table_threads WHERE tid='$tid'");
if(!$thread = $db->fetch_array($query)) {
	showmessage('thread_nonexistence');
}

$codecount = 0;
$oldtopics = $HTTP_COOKIE_VARS['oldtopics'] ? $HTTP_COOKIE_VARS['oldtopics'] : "\t";
if(!strstr($oldtopics, "\t$tid\t")) {
	$oldtopics .= "$tid\t";
	setcookie('oldtopics', $oldtopics, $timestamp + 900, $cookiepath, $cookiedomain);
}

if($forum['type'] == 'forum') {
	$navigation .= "&raquo; <a href=\"forumdisplay.php?fid=$fid&page=$fpage\"> $forum[name]</a> &raquo; $thread[subject]";
	$navtitle .= ' - '.strip_tags($forum['name']).' - '.$thread['subject'];
} else {
	$query = $db->query("SELECT fid, name, moderator FROM $table_forums WHERE fid='$forum[fup]'");
	$fup = $db->fetch_array($query);
	$navigation .= "&raquo; <a href=\"forumdisplay.php?fid=$fup[fid]\">$fup[name]</a> &raquo; <a href=\"forumdisplay.php?fid=$fid&page=$fpage\"> $forum[name]</a> &raquo; $thread[subject]";
	$navtitle .= ' - '.strip_tags($fup['name']).' - '.strip_tags($forum['name']).' - '.$thread['subject'];
}

$ismoderator = modcheck($discuz_user);

if(!$forum['allowview']) {
	if(!$forum['viewperm'] && !$allowview) {
		showmessage('group_nopermission', NULL, 'HALTED');
	} elseif($forum['viewperm'] && !strstr($forum['viewperm'], "\t$groupid\t")) {
		showmessage('forum_nopermission', NULL, 'HALTED');
	}
}

if($thread['creditsrequire'] && $thread['creditsrequire'] > $credit && !$ismoderator) {
	showmessage('thread_nopermission', NULL, 'HALTED');
}

if($forum['password'] && $forum['password'] != $HTTP_COOKIE_VARS["fidpw$fid"]) {
	header("Location: {$boardurl}forumdisplay.php?fid=$fid&sid=$sid");
	exit();
}

if(!$action && $tid) {

	if($discuz_uid && $newpm) {
		require DISCUZ_ROOT.'./include/pmprompt.php';
	}

	$highlightstatus = str_replace('+', '', $highlight) ? 1 : 0;
	$karmaoptions = '';
	if($allowkarma && $maxkarmarate) {
		$offset = ceil($maxkarmarate / 6);
		for($vote = - $maxkarmarate + $offset; $vote <= $maxkarmarate; $vote += $offset) {
			$votenum = $vote > 0 ? '+'.$vote : $vote;
			$karmaoptions .= $vote ? "<option value=\"$vote\">$votenum</option>\n" : NULL;
		}
	}
	unset($vote, $votenum, $offset);
	
	if(empty($page)) {
		$start_limit = 0;
		$page = 1;
	} else {
		$start_limit = ($page - 1) * $ppp;
	}

	$multipage = multi($thread['replies'] + 1, $ppp, $page, "viewthread.php?tid=$tid&highlight=".rawurlencode($highlight));

	if($thread['poll']) {
		$query = $db->query("SELECT pollopts FROM $table_polls WHERE tid='$tid'");
		$pollopts = unserialize($db->result($query, 0));
		$polloptions = array();
		foreach($pollopts['options'] as $option) {
			$polloptions[] = array(	'option'	=> dhtmlspecialchars(stripslashes($option[0])),
						'votes'		=> $option[1],
						'width'		=> @round($option[1] * 300 / $pollopts['max']) + 2,
						'percent'	=> @sprintf ("%01.2f", $option[1] * 100 / $pollopts['total'])
						);
		}

		$allowvote = $allowvote && $discuz_uid && (empty($thread['closed']) || $alloweditpoll) && !in_array($discuz_user, $pollopts['voters']);
		$optiontype = $pollopts['multiple'] ? 'checkbox' : 'radio';
	}

	$altbg1 = ALTBG1;
	$altbg2 = ALTBG2;
	$postlist = array();
	$fieldadd = '';
	$newpostanchor = $postcount = 0;
	foreach($_DCACHE['fields_thread'] as $field) {
		$fieldsadd .= ', m.field_'.$field['fieldid'];
	}

	$query = $db->query("SELECT p.*, a.aid AS aaid, a.creditsrequire, a.filetype, a.filename, a.attachment, a.filesize,
					a.downloads, m.username, m.gender, m.groupid, m.regdate, m.lastactivity, m.postnum,
					m.credit, m.email, m.site, m.icq, m.oicq, m.yahoo, m.msn, m.location, m.avatar, m.avatarwidth,
					m.avatarheight, m.signature, m.customstatus, m.showemail $fieldsadd FROM $table_posts p
					LEFT JOIN $table_attachments a USING (aid)
					LEFT JOIN $table_members m ON m.uid=p.authorid
					WHERE p.tid='$tid' ORDER BY dateline LIMIT $start_limit, $ppp");

	while($post = $db->fetch_array($query)) {

		if(!$newpostanchor && $post['dateline'] > $lastvisit) {
			$post['newpostanchor'] = '<a name="newpost"></a>';
			$newpostanchor = 1;
		} else {
			$post['newpostanchor'] = '';
		}

		$post['thisbg'] = ${'altbg'.($postcount++ % 2 + 1)};
		$post['dateline'] = gmdate("$dateformat $timeformat", $post['dateline'] + $timeoffset * 3600);

		if($post['username']) {
			if($userstatusby == 1 || $_DCACHE['usergroups'][$post['groupid']]['byrank'] === 0) {
				$post['authortitle'] = $_DCACHE['usergroups'][$post['groupid']]['grouptitle'];
				$post['stars'] = $_DCACHE['usergroups'][$post['groupid']]['stars'];
			} elseif($userstatusby == 2) {
				foreach($_DCACHE['ranks'] as $rank) {
					if($post['postnum'] > $rank['postshigher']) {
						$post['authortitle'] = $rank['ranktitle'];
						$post['stars'] = $rank['stars'];
						break;
					}
				}
			}

			$post['regdate'] = gmdate($dateformat, $post['regdate'] + $timeoffset * 3600);

			if($_DCACHE['usergroups'][$post['groupid']]['groupavatar']) {
				$post['avatar'] = '<img src="'.$_DCACHE['usergroups'][$post['groupid']]['groupavatar'].'" border="0">';
			} elseif($_DCACHE['usergroups'][$post['groupid']]['allowavatar'] && $post['avatar']) {
				$post['avatar'] = '<img src="'.$post['avatar'].'" width="'.$post['avatarwidth'].'" height="'.$post['avatarheight'].'" border="0">';
			} else {
				$post['avatar'] = '';
			}
		} else {
			if(!$post['authorid']) {
				$post['useip'] = substr($post['useip'], 0, strrpos($post['useip'], '.')).'.x';
			}
			$post['postnum'] = $post['credit'] = $post['regdate'] = 'N/A';
		}

		$post['karma'] = '';
		if($post['rate'] && $post['ratetimes']) {
			$rateimg = $post['rate'] > 0 ? 'agree.gif' : 'disagree.gif';
			for($i = 0; $i < round(abs($post['rate']) / $post['ratetimes']); $i++) {
				$post['karma'] .= '<img src="'.IMGDIR.'/'.$rateimg.'" align="right">';
			}
		}

		$post['subject'] = $post['subject'] ? $post['subject'].'<br><br>' : NULL;
		$post['message'] = postify($post['message'], $post['smileyoff'], $post['bbcodeoff'], $forum['allowsmilies'], $forum['allowhtml'], $forum['allowbbcode'], $forum['allowimgcode']);
		$post['signature'] = $post['usesig'] && $post['signature'] ? postify($post['signature'], 1, 0, 0, 0, $_DCACHE['usergroups'][$post['groupid']]['allowsigbbcode'], $_DCACHE['usergroups'][$post['groupid']]['allowsigimgcode']) : NULL;

		if($post['aaid']) {
			require_once DISCUZ_ROOT.'./include/attachment.php';
			$extension = strtolower(fileext($post['filename']));
			$post['attachicon'] = attachtype($extension."\t".$post['filetype']);
			if($attachimgpost && in_array($extension, array('jpg', 'jpeg', 'jpe', 'gif', 'png', 'bmp'))) {
				$post['attachimg'] = 1;
			} else {
				$post['attachimg'] = 0;
				$post['attachsize'] = sizecount($post['filesize']);
			}
		}

		$postlist[] = $post;

	}

	if(empty($postlist)) {
		showmessage('undefined_action', NULL, 'HALTED');
	}

	$forumselect = $forumjump ? forumselect() : NULL;

	$usesigcheck = $signature ? 'checked' : NULL;
	$allowpost = (!$forum['postperm'] && $allowpost) || ($forum['postperm'] && strstr($forum['postperm'], "\t$groupid\t")) || $forum['allowpost'];
	$allowpostreply = (!$thread['closed'] || $ismoderator) && ((!$forum['replyperm'] && $allowpost) || ($forum['replyperm'] && strstr($forum['replyperm'], "\t$groupid\t")) || $forum['allowreply']);

	if($delayviewcount) {
		$logfile = DISCUZ_ROOT.'./forumdata/viewcount.log';
		if(substr($timestamp, -2) == '00') {
			require DISCUZ_ROOT.'./include/misc.php';
			updateviews();
		}

		if(@$fp = fopen($logfile, 'a')) {
			fwrite($fp, "$tid\n");
			fclose($fp);
		} elseif($adminid == 1) {
			showmessage('view_log_invalid');
		}
	} else {
		$db->query("UPDATE $table_threads SET views=views+1 WHERE tid='$tid'", 'UNBUFFERED');
	}

	include template('viewthread');

} elseif($action == 'printable' && $tid) {

	require DISCUZ_ROOT.'./include/printable.php';

}

?>