<?php

/*
	[DISCUZ!] attachment.php - attachment downloading
	This is NOT a freeware, use is subject to license terms

	Version: 3.0.1
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/8/5 06:04
*/

require './include/common.php';

$discuz_action = 14;

if($attachrefcheck && preg_replace("/https?:\/\/([^\/]+).*/i", "\\1", $HTTP_SERVER_VARS['HTTP_REFERER']) != $HTTP_SERVER_VARS['HTTP_HOST']) {
	showmessage('attachment_referer_invalid', NULL, 'HALTED');
}

$query = $db->query("SELECT a.*, t.fid FROM $table_attachments a LEFT JOIN $table_threads t ON a.tid=t.tid WHERE aid='$aid'");
$attach = $db->fetch_array($query);
if($allowgetattach && $attach['creditsrequire'] && $attach['creditsrequire'] > $credit && $adminid <= 0) {
	showmessage('attachment_nopermission', NULL, 'HALTED');
}

$query = $db->query("SELECT f.getattachperm, a.allowgetattach FROM $table_forums f
			LEFT JOIN $table_access a ON a.uid='$discuz_uid' AND a.fid=f.fid
			WHERE f.fid='$attach[fid]'");
$forum = $db->fetch_array($query);

if(!$forum['allowgetattach']) {
	if(!$forum['getattachperm'] && !$allowgetattach) {
		showmessage('group_nopermission', NULL, 'HALTED');
	} elseif($forum['getattachperm'] && !strstr($forum['getattachperm'], "\t$groupid\t")) {
		showmessage('attachment_forum_nopermission', NULL, 'HALTED');
	}
}

$db->query("UPDATE $table_attachments SET downloads=downloads+1 WHERE aid='$aid'", 'UNBUFFERED');
$filename = DISCUZ_ROOT.$attachdir.'/'.$attach['attachment'];

if(is_readable($filename) && $attach) {
	$filesize = filesize($filename);

	ob_end_clean();
	header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
	header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
	header('Cache-Control: no-cache, must-revalidate');
	header('Pragma: no-cache');
	header('Content-Encoding: none');
	header('Content-Length: '.$filesize);

	//forbid flash be opened directly
	//header('Content-Disposition: '.(strpos($HTTP_SERVER_VARS['HTTP_USER_AGENT'], 'MSIE') ? 'inline; ' : 'attachment; ').'filename='.$attach['filename']);

	header('Content-Disposition: attachment; filename='.$attach['filename']);
	header('Content-Type: '.$attach['filetype']);

	@$fp = fopen($filename, 'rb');
	@flock($fp, 2);
	$attachment = @fread($fp, $filesize);
	@fclose($fp);
	echo $attachment;
} else {
	showmessage('attachment_nonexistence');
}

?>