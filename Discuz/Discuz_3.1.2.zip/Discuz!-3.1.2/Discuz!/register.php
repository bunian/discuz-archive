<?php

/*
	[DISCUZ!] register.php - new member registration
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.2
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/10/11 05:51
*/

require './include/common.php';
require DISCUZ_ROOT.'./forumdata/cache/cache_profilefields.php';

$discuz_action = 5;

if($discuz_uid) {
	showmessage('login_succeed', 'index.php');
}

if(!$regstatus) {
	showmessage('register_disable');
}

$query = $db->query("SELECT * FROM $table_settings WHERE variable IN ('censoruser', 'doublee', 'bbrules', 'bbrulestxt', 'welcomemsg', 'welcomemsgtxt')");
while($setting = $db->fetch_array($query)) {
	$$setting['variable'] = $setting['value'];
}

$query = $db->query("SELECT groupid, allowcstatus, allowavatar, allowsigbbcode, allowsigimgcode, maxsigsize FROM $table_usergroups WHERE ".($regverify == 1 ? "groupid='8'" : "creditshigher<=0 AND 0<creditslower LIMIT 1"));
$groupinfo = $db->fetch_array($query);
$groupinfo['allowavatar']  = 3;//debug
if(!submitcheck('regsubmit')) {

	if($bbrules && !submitcheck('rulesubmit')) {
		$bbrulestxt = nl2br("\n$bbrulestxt\n\n");
	} else {

		$enctype = $groupinfo['allowavatar'] == 3 ? 'enctype="multipart/form-data"' : NULL;

		$styleselect = $dayselect = '';
		$query = $db->query("SELECT styleid, name FROM $table_styles WHERE available='1'");
		while($styleinfo = $db->fetch_array($query)) {
			$styleselect .= '<option value="'.$styleinfo['styleid'].'">'.$styleinfo['name'].'</option>'."\n";
		}

		for($num = 1; $num <= 31; $num++) {
			$dayselect .= '<option value="'.$num.'">'.$num.'</option>';
		}

		$bbcodeis = $groupinfo['allowsigbbcode'] ? 'On' : 'Off';
		$imgcodeis = $groupinfo['allowsigimgcode'] ? 'On' : 'Off';
		$toselect = array((float)strval($_DCACHE['settings']['timeoffset']) => 'selected="selected"');

		$dateformatorig = $dateformat;
		$dateformatorig = str_replace('n', 'mm', $dateformatorig);
		$dateformatorig = str_replace('j', 'dd', $dateformatorig);
		$dateformatorig = str_replace('y', 'yy', $dateformatorig);
		$dateformatorig = str_replace('Y', 'yyyy', $dateformatorig);

	}

	include template('register');

} else {

	require DISCUZ_ROOT.'./include/discuzcode.php';

	$email = trim($email);
	$username = trim($username);

	if(strlen($username) > 15) {
		showmessage('profile_username_toolang');
	}

	if($password != $password2) {
		showmessage('profile_passwd_notmatch');
	}


	if(preg_match("/^\s*$|^c:\\con\\con$|��|[%,\*\"\s\t\<\>\&]|^�ο�|^Guest/is", $username) || @preg_match('/^'.str_replace(array('\\*', ',', ' '), array('.*', '|', ''), preg_quote($censoruser, '/')).'$/i', $username)) {
		showmessage('profile_username_illegal');
	}

	if(!$password || $password != addslashes($password)) {
		showmessage('profile_passwd_illegal');
	}

	if(!isemail($email)) {
		showmessage('profile_email_illegal');
	}

	$fieldadd1 = $fieldadd2 = '';
	foreach(array_merge($_DCACHE['fields_required'], $_DCACHE['fields_optional']) as $field) {
		$field_key = 'field_'.$field['fieldid'];
		$field_val = ${'field_'.$field['fieldid'].'new'};
		if($field['required'] && trim($field_val) == '') {
			showmessage('profile_required_info_invalid');
		} elseif($field['selective'] && $field_val != '' && !isset($field['choices'][$field_val])) {
			showmessage('undefined_action', NULL, 'HALTED');
		} else {
			$fieldadd1 .= ", $field_key";
			$fieldadd2 .= ", '".dhtmlspecialchars($field_val)."'";
		}
	}

	if($groupinfo['maxsigsize'] && strlen($sig) > $groupinfo['maxsigsize']) {
		$maxsigsize = $groupinfo['maxsigsize'];
		showmessage('profile_sig_toolang');
	}

	$emailadd = !$doublee ? "OR email='$email'" : '';
	$regctrladd = $regctrl ? "OR (regip='$onlineip' AND regdate>$timestamp-'$regctrl'*3600)" : '';
	$query = $db->query("SELECT username, email, regip FROM $table_members WHERE username='$username' $emailadd $regctrladd LIMIT 1");
	if($member = $db->fetch_array($query)) {
		if(addslashes($member['email']) == $email) {
			showmessage('profile_email_duplicate');
		} elseif($member['regip'] == $onlineip) {
			showmessage('register_ctrl');
		} else {
			showmessage('profile_username_duplicate');
		}
	}

	if(($groupinfo['allowavatar'] == 2 || $groupinfo['allowavatar'] == 3) && $avatar) {
		$avatar = dhtmlspecialchars($avatar);
		$avatarext = strtolower(fileext($avatar));
		if(!preg_match("/^((customavatars\/\d+\.[a-z]+)|(images\/avatars\/.+?)|(http:\/\/.+?))$/i", $avatar)
			|| !in_array($avatarext, array('gif', 'jpg', 'png'))) {
			showmessage('profile_avatar_invalid');
		}
	} elseif($groupinfo['allowavatar'] == 3 && $customavatar) {
		if(!((function_exists('is_uploaded_file') && !is_uploaded_file($customavatar)) || !($customavatar != 'none' && $customavatar && trim($customavatar_name)))) {
			$avatarext = strtolower(fileext($customavatar_name));
			if(!in_array($avatarext, array('gif', 'jpg', 'png'))) {
				showmessage('profile_avatar_invalid');
			}
			if($maxavatarsize && filesize($customavatar_name) > $maxavatarsize) {
				showmessage('profile_avatar_toobig');
			}
		} else {
			$customavatar = '';
		}
	} else {
		$avatar = '';
	}

	$password = md5($password);
	$secques = quescrypt($questionid, $answer);

	if(!$groupinfo['allowcstatus']) {
		$cstatus = '';
	}

	$bday = "$year-$month-$day";

	if(!$month || !$day || !$year) {
		$bday = '';
	}

	$dateformatnew = str_replace('mm', 'n', $dateformatnew);
	$dateformatnew = str_replace('dd', 'j', $dateformatnew);
	$dateformatnew = str_replace('yyyy', 'Y', $dateformatnew);
	$dateformatnew = str_replace('yy', 'y', $dateformatnew);
	$timeformatnew = $timeformatnew == '24' ? 'H:i' : 'h:i A';

	if(!is_numeric($icq) || strlen($icq) < 5 || strlen($icq) > 15) {
		$icq = '';
	}

	$avatar = dhtmlspecialchars($avatar);
	$yahoo = dhtmlspecialchars($yahoo);
	$oicq = dhtmlspecialchars($oicq);
	$email = dhtmlspecialchars($email);
	$bday = dhtmlspecialchars($bday);

	$site = trim(str_replace('http://', '', $site));
	$site = $site ? dhtmlspecialchars('http://'.$site) : '';

	$sig = censor($sig);
	$bio = censor(dhtmlspecialchars($bio));
	$locationnew = cutstr(censor(dhtmlspecialchars($locationnew)), 30);
	$cstatus = cutstr(censor(dhtmlspecialchars($cstatus)), 30);

	$invisiblenew = $invisiblenew && $groupinfo['allowinvisible'] ? 1 : 0;

	$idstring = random(6);
	$identifyingnew = $regverify == 1 ? "$timestamp\t2\t$idstring" : '';

	$db->query("INSERT INTO $table_members (username, password, secques, gender, adminid, groupid, regip, regdate, lastvisit, lastactivity, postnum, credit, email, site, icq, oicq, yahoo, msn, location, bday, bio, signature, customstatus, tpp, ppp, styleid, dateformat, timeformat, showemail, newsletter, invisible, timeoffset, identifying $fieldadd1)
		VALUES ('$username', '$password', '$secques', '$gendernew', '0', '$groupinfo[groupid]', '$onlineip', '$timestamp', '$timestamp', '$timestamp', '0', '0', '$email', '$site', '$icq', '$oicq', '$yahoo', '$msn', '$locationnew', '$bday', '$bio', '$sig', '$cstatus', '$tppnew', '$pppnew', '$styleidnew', '$dateformatnew', '$timeformatnew', '$showemail', '$newsletter', '$invisiblenew', '$timeoffsetnew', '$identifyingnew' $fieldadd2)");
	$uid = $db->insert_id();

	if($avatar || $customavatar) {
		if($customavatar) {
			$avatar = 'customavatars/'.$uid.'.'.$avatarext;
			$avatartarget = DISCUZ_ROOT.'./'.$avatar;
			if(!@copy($customavatar, $avatartarget)) {
				@move_uploaded_file($customavatar, $avatartarget);
			}
			$avatarimagesize = @getimagesize($avatartarget);
			if(!$avatarimagesize) {
				@unlink($avatartarget);
				showmessage('profile_avatar_invalid');
			}
		}

		if($avatarwidth == '*' || $avatarheight == '*') {
			$avatarwidth = $avatarheight = 80;
			@list($avatarwidth, $avatarheight) = $avatarimagesize;
		}
		$maxsize = max($avatarwidth, $avatarheight);
		if($maxsize > $maxavatarpixel) {
			$avatarwidth = $avatarwidth * $maxavatarpixel / $maxsize;
			$avatarheight = $avatarheight * $maxavatarpixel / $maxsize;
		}

		$db->query("UPDATE $table_members SET avatar='$avatar', avatarwidth='$avatarwidth', avatarheight='$avatarheight' WHERE uid='$uid'");
	}

	if($welcomemsg && !empty($welcomemsgtxt)) {
		$welcomtitle = "Welcome to $bbname!";
		$welcomemsgtxt = addslashes($welcomemsgtxt);
		$db->query("INSERT INTO $table_pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message)
			VALUES ('System Message', '0', '$uid', 'inbox', '1', '$welcomtitle', '$timestamp','$welcomemsgtxt')");
		$db->query("UPDATE $table_members SET newpm='1' WHERE uid='$uid'");
	}

	require DISCUZ_ROOT.'./include/cache.php';
	updatecache('settings');

	$discuz_uid = $uid;
	$discuz_user = $username;
	$discuz_userss = stripslashes($discuz_user);
	$discuz_pw = $password;
	$discuz_secques = $secques;
	$groupid = $groupinfo['groupid'];
	$styleid = $styleid ? $styleid : $_DCACHE['settings']['styleid'];

	setcookie('cookietime', 2592000, $timestamp + 86400 * 365, $cookiepath, $cookiedomain);
	setcookie('_discuz_uid', $discuz_uid, $timestamp + 2592000, $cookiepath, $cookiedomain);
	setcookie('_discuz_pw', $discuz_pw, $timestamp + 2592000, $cookiepath, $cookiedomain);
	setcookie('_discuz_secques', $discuz_secques, $timestamp + 2592000, $cookiepath, $cookiedomain);

	if($regverify == 1){
		sendmail($email, 'email_verify_subject', 'email_verify_message');
		showmessage('profile_email_verify');
	} else {
		showmessage('register_succeed', dreferer());
	}

}

?>