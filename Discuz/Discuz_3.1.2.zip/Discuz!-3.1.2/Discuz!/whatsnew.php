<?php

/*
	[DISCUZ!] whatsnew.php - new threads list for html pages
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.1 Rebuilded
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/10/16 06:12
*/

// [EN] Embed new threads in html pages for Discuz! For further information, please read utilities/whatsnew.txt
// [CH] Html ҳ����̳��������, ������ο� utilities/whatsnew.txt

// [EN] Warning!! This program may increase your server load obviously, Using is at your own risk. 
// [CH] ����!! ������������Լ��ط���������, ʹ�ñ���������Ҫ�Ե�����.

error_reporting(E_ERROR | E_WARNING | E_PARSE);


$enabled = 0;				// Whether enable what's new feature, 1=yes, 0=no
					// �Ƿ����� what's new ����, 1=��, 0=��

$num = 10;				// Default amount of new threads
					// Ĭ����ʾ��������

$length = 50;				// Max. length of title(bytes)
					// ��������ֽ���

$pre = '<li>';				// Prefix of title
					// ������ʾǰ׺


$enabled ? define('IN_DISCUZ', TRUE) : exit("document.write(\"Access denied. If you'd like to display new threads in html pages,<br>please switch \$enabled to \\\"1\\\" in whatsnew.php and try again.\");");

$PHP_SELF = $HTTP_SERVER_VARS['PHP_SELF'] ? $HTTP_SERVER_VARS['PHP_SELF'] : $HTTP_SERVER_VARS['SCRIPT_NAME'];
$boardurl = 'http://'.$HTTP_SERVER_VARS['HTTP_HOST'].substr($PHP_SELF, 0, strrpos($PHP_SELF, '/'));

$fidin = addslashes(trim($HTTP_GET_VARS['fidin']));
$fidout = addslashes(trim($HTTP_GET_VARS['fidout']));
$num = $HTTP_GET_VARS['num'] ? addslashes($HTTP_GET_VARS['num']) : $num;

if(substr(time(), -3) == '000' && @$dir = dir('./forumdata/')) {
	while($entry = $dir->read()) {
		if(preg_match("/whatsnew_[0-9a-f]{32}\.php/", $entry)) {
			@unlink('./forumdata/'.$entry);
		}
	}
	$dir->close();
}

$cachefile = './forumdata/whatsnew_'.md5("$fidin\t$fidout\t$num").'.php';

if(@!include($cachefile)) {

	require './config.php';
	require './include/db_'.$database.'.php';

	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
	$db->select_db($dbname);
	unset($dbhost, $dbuser, $dbpw, $dbname, $pconnect);

	if(@!$fp = fopen($cachefile, 'wb')) {
		exit("document.write(\"Unable to write to whatsnew's cache file!<br>Please chmod ./forumdata to 777, delete all<br>\\\"whatsnew_xxx.php\\\" files and try again.\");");
	}

	fwrite($fp, "<?php if(!defined('IN_DISCUZ') exit('Access Denied'); ?>\n");

	$pre = addslashes($pre);
	$fidin = $fidin ? ' AND fid IN (\''.str_replace('_', '\',\'', $fidin).'\')' : '';
	$fidout = $fidout ? ' AND fid NOT IN (\''.str_replace('_', '\',\'', $fidout).'\')' : '';

	$forumfilter = $fidin || $fidout ? 'WHERE '.substr($fidin.$fidout, 5) : '';

	$query = $db->query("SELECT subject, tid, closed, lastpost FROM {$tablepre}threads $forumfilter ORDER BY lastpost DESC LIMIT $num");
	while($threads = $db->fetch_array($query)) {
		if($thread['closed'] > 2) {
			$thread['tid'] = $thread['closed'];
		}
		$threads['subject'] = cutstr($threads['subject'], $length);
		$row = "document.write(\"<a href=$boardurl/viewthread.php?tid=$threads[tid] target=_blank>$pre$threads[subject]</a><br>\");\n";
		fwrite($fp, $row);
		echo $row;
	}

	fclose($fp);

}

function cutstr($string, $length) {

	if(strlen($string) > $length) {
		for($i = 0; $i < $length - 3; $i++) {
			if(ord($string[$i]) > 127) {
				$wordscut .= $string[$i].$string[$i + 1];
				$i++;
			} else {
				$wordscut .= $string[$i];
			}
		}
		return $wordscut.' ...';
	}
	return $string;

}

?>

