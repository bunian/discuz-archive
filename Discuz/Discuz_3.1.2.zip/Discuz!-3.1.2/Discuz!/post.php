<?php

/*
	[DISCUZ!] post.php - post module for new threads & replies or editing post
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.2
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/10/11 05:51
*/

require './include/common.php';
require DISCUZ_ROOT.'./include/discuzcode.php';
require DISCUZ_ROOT.'./include/post.php';
require DISCUZ_ROOT.'./include/attachment.php';

$ismoderator = modcheck($discuz_user);
$postcredits = $forum['postcredits'] != -1 ? $forum['postcredits'] : $postcredits;
$replycredits = $forum['replycredits'] != -1 ? $forum['replycredits'] : $replycredits;

if(empty($action)) {
	showmessage('undefined_action', NULL, 'HALTED');
}

if($tid && $fid) {
	$query = $db->query("SELECT * FROM $table_threads WHERE tid='$tid'");
	$thread = $db->fetch_array($query);
	$fid = $thread['fid'];
	$navigation = "&raquo; <a href=\"viewthread.php?tid=$tid\">$thread[subject]</a>";
	$navtitle = " - $thread[subject]";
}

$navigation = "&raquo; <a href=\"forumdisplay.php?fid=$fid\">$forum[name]</a> $navigation";
$navtitle = ' - '.strip_tags($forum['name']).$navtitle;
if($forum['type'] == 'sub') {
	$query = $db->query("SELECT name, fid FROM $table_forums WHERE fid='$forum[fup]'");
	$fup = $db->fetch_array($query);
	$navigation = "&raquo; <a href=\"forumdisplay.php?fid=$fup[fid]\">$fup[name]</a> $navigation";
	$navtitle = ' - '.strip_tags($fup['name']).$navtitle;
}

if(!$forum['allowview']) {
	if(!$forum['viewperm'] && !$allowview) {
		showmessage('group_nopermission', NULL, 'HALTED');
	} elseif($forum['viewperm'] && !strstr($forum['viewperm'], "\t$groupid\t")) {
		showmessage('forum_nopermission', NULL, 'HALTED');
	}
}

if($thread['creditsrequire'] && $thread['creditsrequire'] > $credit && !$ismoderator) {
	showmessage('thread_nopermission', NULL, 'HALTED');
}

if(!$bbcodeoff && !$allowhidecode && preg_match("/\[hide=?\d*\].+?\[\/hide\]/is", $message)) {
	showmessage('post_hide_nopermission');
}

if(!$adminid && !$lastpost && $newbiespan) {
	$query = $db->query("SELECT regdate FROM $table_members WHERE uid='$discuz_uid'");
	if($timestamp - ($db->result($query, 0)) < $newbiespan * 3600) {
		showmessage('post_newbie_span');
	}
}

if($previewpost || (!$previewpost && !$topicsubmit && !$replysubmit && !$editsubmit)) {

	$enctype = $allowpostattach ? 'enctype="multipart/form-data"' : NULL;

	if($smileyinsert && is_array($_DCACHE['smilies'])) {
		$smileyinsert = 1;
		$smcols = $smcols ? $smcols : 3;
		$smilies .= '<tr>';
		foreach(array_reverse($_DCACHE['smilies']) as $key => $smiley) {
			$smilies .= '<td align="center" valign="top"><img src="'.SMDIR.'/'.$smiley['url'].'" border="0" onmouseover="this.style.cursor=\'hand\';" onclick="AddText(\''.htmlspecialchars(addcslashes($smiley['code'], '\\\'')).'\');"></td>'."\n";
			$smilies .= !(++$key % $smcols) ? '</tr><tr>' : NULL;
		}
	} else {
		$smileyinsert = 0;
	}

	$maxattachsize_kb = $maxattachsize / 1000;
	$allowimgcode = $forum['allowimgcode'] ? 'On' : 'Off';
	$allowhtml = $forum['allowhtml'] ? 'On' : 'Off';
	$allowsmilies = $forum['allowsmilies'] ? 'On' : 'Off';
	$allowbbcode = $forum['allowbbcode'] ? 'On' : 'Off';

	if($discuz_user && $signature && !$usesigcheck) {
		$usesigcheck = 'checked';
	}

} else {

	if(!$parseurloff) {
		$message = parseurl($message);
	}

	$subject = censor(trim($subject));
	$message = censor(trim($message));

}

if($forum['password'] != $HTTP_COOKIE_VARS["fidpw$fid"] && $forum['password'] != $_DSESSION["fidpw$fid"] && $forum['password']) {
	header("Location: {$boardurl}forumdisplay.php?fid=$fid&sid=$sid");
	exit();
}

if($previewpost) {
	$currtime = gmdate("$dateformat $timeformat", $timestamp + $timeoffset * 3600);
	$author = $discuz_userss;
	$subject = stripslashes($subject);
	$message = stripslashes($message);
	$subject_preview = $subject;
	$message_preview = postify($message, $smileyoff, $bbcodeoff, $forum['allowsmilies'], $forum['allowhtml'], $forum['allowbbcode'], $forum['allowimgcode']);
	$message =dhtmlspecialchars($message);  

	$urloffcheck = $parseurloff ? 'checked' : NULL;
	$usesigcheck = $usesig ? 'checked' : NULL;
	$smileoffcheck = $smileyoff ? 'checked' : NULL;
	$codeoffcheck = $bbcodeoff ? 'checked' : NULL;

	$topicsubmit = $replysubmit = $editsubmit = '';
}

if($action == 'newthread') {
	require DISCUZ_ROOT.'./include/newthread.php';
} elseif($action == 'reply') {
	require DISCUZ_ROOT.'./include/newreply.php';
} elseif($action == 'edit') {
	require DISCUZ_ROOT.'./include/editpost.php';
}

?>