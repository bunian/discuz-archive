<?php

/*
	[DISCUZ!] topicadmin - moderator's administration
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.2
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/10/11 05:52
*/


require './include/common.php';
require DISCUZ_ROOT.'./include/post.php';

$discuz_action = 151;

$tid = $tid ? $tid : $delete[0];
if($tid) {
	$query = $db->query("SELECT * FROM $table_threads WHERE tid='$tid'");
	$thread = $db->fetch_array($query);
	$thread['subject'] .= $action == 'delthread' ? ", etc." : NULL;
}

if($forum['type'] == 'forum') {
	$navigation = "&raquo; <a href=\"forumdisplay.php?fid=$fid\">$forum[name]</a> &raquo; <a href=\"viewthread.php?tid=$tid\">$thread[subject]</a> ";
	$navtitle = ' - '.strip_tags($forum['name']).' - '.$thread['subject'];
} else {
	$query = $db->query("SELECT name, fid, moderator FROM $table_forums WHERE fid='$forum[fup]'");
	$fup = $db->fetch_array($query);
	$navigation = "&raquo; <a href=\"forumdisplay.php?fid=$fup[fid]\">$fup[name]</a> &raquo; <a href=\"forumdisplay.php?fid=$fid\">$forum[name]</a> &raquo; <a href=\"viewthread.php?tid=$tid\">$thread[subject]</a> ";
	$navtitle = ' - '.strip_tags($fup['name']).' - '.strip_tags($forum['name']).' - '.$thread['subject'];
}

if(!$discuz_user || !$discuz_pw || !modcheck($discuz_user)) {
	showmessage('admin_nopermission', NULL, 'HALTED');
}

$fupadd = $fup ? "OR (fid='$fup[fid]' && type<>'group')" : NULL;

if($action == 'delthread') {

	if(!is_array($delete) && !count($delete)) {
		showmessage('admin_delthread_invalid');
	} else {
		if(!submitcheck('delthreadsubmit')) {

			$deleteid = '';
			foreach($delete as $id) {
				$deleteid .= '<input type="hidden" name="delete[]" value="'.$id.'">';
			}

			include template('topicadmin_delthread');

		} else {

			$tids = $comma = '';
			foreach($delete as $id) {
				$tids .= "$comma'$id'";
				$comma = ", ";
			}

			$uids = $comma = '';
			$query = $db->query("SELECT authorid FROM $table_posts WHERE tid IN ($tids)");
			while($post = $db->fetch_array($query)) {
				$uids .= "$comma$post[authorid]";
				$comma = ',';
			}
			updatemember('-', $uids, $deletedcredits);

			$query = $db->query("SELECT attachment FROM $table_attachments WHERE tid IN ($tids)");
			while($attach = $db->fetch_array($query)) {
				@unlink(DISCUZ_ROOT.$attachdir.'/'.$attach['attachment']);
			}

			$db->query("DELETE FROM $table_threads WHERE tid IN ($tids)");
			$db->query("DELETE FROM $table_posts WHERE tid IN ($tids)");
			$db->query("DELETE FROM $table_attachments WHERE tid IN ($tids)");
			updateforumcount($fid);

			modlog();
			showmessage('admin_succeed', "forumdisplay.php?fid=$fid&page=$page");

		}
	}		

} elseif($action == 'delpost') {

	if(!$allowdelpost) {
		showmessage('admin_nopermission', NULL, 'HALTED');
	} elseif(!is_array($delete) && !count($delete)) {
		showmessage('admin_delpost_invalid');
	}

	if(!submitcheck('delpostsubmit')) {

		$query = $db->query("SELECT COUNT(*) FROM $table_posts WHERE tid='$tid'");
		if(count($delete) < $db->result($query, 0)) {

			$deleteid = '';
			foreach($delete as $id) {
				$deleteid .= '<input type="hidden" name="delete[]" value="'.$id.'">';
			}

			include template('topicadmin_delpost');
			
		} else {
			header("Location: {$boardurl}topicadmin.php?action=delete&fid=$fid&tid=$tid");
		}

	} else {

		$pids = $comma = '';
		foreach($delete as $id) {
			$pids .= "$comma'$id'";
			$comma = ", ";
		}

		$uids = $comma = '';
		$query = $db->query("SELECT authorid FROM $table_posts WHERE pid IN ($pids)");
		while($post = $db->fetch_array($query)) {
			$uids .= "$comma$post[authorid]";
			$comma = ',';
		}
		updatemember('-', $uids, $deletedcredits);

		$attach_type = '';
		$query = $db->query("SELECT pid, attachment, filetype FROM $table_attachments WHERE tid='$tid'");
		while($attach = $db->fetch_array($query)) {
			if(in_array($attach['pid'], $delete)) {
				@unlink(DISCUZ_ROOT.$attachdir.'/'.$attach['attachment']);
			} else {
				$attach_type = fileext($attach['attachment'])."\t".$attach['filetype'];
			}
		}

		if($attach_type) {
			require DISCUZ_ROOT.'./include/attachment.php';
			$db->query("UPDATE $table_threads SET attachment='".attachtype($attach_type, 'id')."' WHERE tid='$tid'");
		}

		$db->query("DELETE FROM $table_posts WHERE pid IN ($pids)");
		$db->query("DELETE FROM $table_attachments WHERE pid IN ($pids)");
		updatethreadcount($tid);
		updateforumcount($fid);

		modlog();
		showmessage('admin_succeed', "viewthread.php?tid=$tid&page=$page");

	}

} elseif($action == 'highlight') {

	if(!submitcheck('highlightsubmit')) {

		$string = sprintf('%02d', $thread['highlight']);
		$stylestr = sprintf('%03b', $string[0]);

		for($i = 1; $i <= 3; $i++) {
			$stylecheck[$i] = $stylestr[$i - 1] ? 'checked' : NULL;
		}
		$colorcheck = array($string[1] => 'checked');
		
		include template('topicadmin_highlight');

	} else {

		$stylebin = '';
		for($i = 1; $i <= 3; $i++) {
			$stylebin .= empty($highlight_style[$i]) ? '0' : '1';
		}
		$highlight_style = bindec($stylebin);

		if($highlight_style < 0 || $highlight_style > 7 || $highlight_color < 0 || $highlight_color > 8) {
			showmessage('undefined_action', NULL, 'HALTED');
		}
		$db->query("UPDATE $table_threads SET highlight='$highlight_style$highlight_color' WHERE tid='$tid'");

		modlog();
		showmessage('admin_succeed', "forumdisplay.php?fid=$fid");

	}

} elseif($action == 'digest') {

	if(!submitcheck('digestsubmit')) {

		include template('topicadmin_digest');

	} else {

		if($level < 0 || $level > 3) {
			showmessage('undefined_action', NULL, 'HALTED');
		}
		$db->query("UPDATE $table_threads SET digest='$level' WHERE tid='$tid'");
		if($digestcredits) {
			$db->query("UPDATE $table_members SET credit=credit".($level == 0 ? '-' : '+')."($digestcredits) WHERE uid='$thread[authorid]'");
		}
		modlog();
		showmessage('admin_succeed', "forumdisplay.php?fid=$fid");

	}

} elseif($action == 'recount') {

	$query = $db->query("SELECT COUNT(*) FROM $table_posts WHERE tid='$tid'");
	$replies = $db->result($query, 0) - 1;

	$query  = $db->query("SELECT author, dateline FROM $table_posts WHERE tid='$tid' ORDER BY dateline DESC LIMIT 1");
	$post = $db->fetch_array($query);

	$db->query("UPDATE $table_threads SET replies='$replies', lastpost='$post[dateline]', lastposter='".addslashes($post['author'])."' WHERE tid='$tid'");
	showmessage('admin_succeed', "viewthread.php?tid=$tid");

} elseif($action == 'delete') {

	if(!submitcheck('deletesubmit')) {

		include template('topicadmin_delete');

	} else {

		$uids = $comma = '';
		$query = $db->query("SELECT authorid FROM $table_posts WHERE tid='$tid'");
		while($post = $db->fetch_array($query)) {
			$uids .= "$comma$post[authorid]";
			$comma = ',';
		}
		updatemember('-', $uids, $deletedcredits);

		$db->query("DELETE FROM $table_threads WHERE tid='$tid'");
		$db->query("DELETE FROM $table_posts WHERE tid='$tid'");
		$query = $db->query("SELECT attachment FROM $table_attachments WHERE tid='$tid'");
		while($attach = $db->fetch_array($query)) {
			@unlink(DISCUZ_ROOT.$attachdir.'/'.$attach['attachment']);
		}
		$db->query("DELETE FROM $table_attachments WHERE tid='$tid'");
		updateforumcount($fid);
		if ($forum['type'] == 'sub') {
			updateforumcount($fup['fid']);
		}

		modlog();
		showmessage('admin_succeed', "forumdisplay.php?fid=$fid");

	}

} elseif($action == 'close') {

	if(!submitcheck('closesubmit')) {

		include template('topicadmin_openclose');

	} else {
		$openclose = $thread['closed'] ? 0 : 1;
		$db->query("UPDATE $table_threads SET closed='$openclose' WHERE tid='$tid' AND fid='$fid'");
		modlog();
		showmessage('admin_succeed', "forumdisplay.php?fid=$fid");
	}

} elseif($action == 'move') {

	if(!submitcheck('movesubmit')) {

		require DISCUZ_ROOT.'./include/forum.php';

		$forumselect = forumselect();
		include template('topicadmin_move');

	} else {

		if(!$moveto) {
			showmessage('admin_move_invalid');
		}

		$displayorderadd = $adminid == 3 ? ", displayorder='0'" : NULL;
		if($type == 'normal') {
			$db->query("UPDATE $table_threads SET fid='$moveto' $displayorderadd WHERE tid='$tid' AND fid='$fid'");
			$db->query("UPDATE $table_posts SET fid='$moveto' WHERE tid='$tid' AND fid='$fid'");
		} else {
			$db->query("INSERT INTO $table_threads (fid, creditsrequire, iconid, author, authorid, subject, dateline, lastpost, lastposter, views, replies, displayorder, digest, closed, poll, attachment)
				VALUES ('$thread[fid]', '$thread[creditsrequire]', '$thread[iconid]', '".addslashes($thread['author'])."', '$thread[authorid]', '$thread[subject]', '$thread[dateline]', '$thread[lastpost]', '$thread[lastposter]', '0', '0', '0', '0', '$thread[tid]', '0', '0')");

			$db->query("UPDATE $table_threads SET fid='$moveto' $displayorderadd WHERE tid='$tid' AND fid='$fid'");
			$db->query("UPDATE $table_posts SET fid='$moveto' WHERE tid='$tid' AND fid='$fid'");
		}

		if ($forum['type'] == 'sub') {
			$query= $db->query("SELECT fup FROM $table_forums WHERE fid='$fid' LIMIT 1");
			$fup = $db->result($query, 0);
			updateforumcount($fup);
		}

		modlog();
		updateforumcount($moveto);
		updateforumcount($fid);
		showmessage('admin_succeed', "forumdisplay.php?fid=$fid");
	}

} elseif($action == 'top') {

	if(!submitcheck('topsubmit')) {

		include template('topicadmin_topuntop');

	} else {

		if($level < 0 || $level > 3) {
			showmessage('undefined_action');
		}
		$db->query("UPDATE $table_threads SET displayorder='$level' WHERE tid='$tid' AND fid='$fid'");

		modlog();
		showmessage('admin_succeed', "forumdisplay.php?fid=$fid");

	}

} elseif($action == 'getip' && $allowviewip) {

	require DISCUZ_ROOT.'./include/misc.php';

	$query = $db->query("SELECT m.adminid, p.useip FROM $table_posts p
				LEFT JOIN $table_members m ON m.uid=p.authorid
				WHERE pid='$pid' AND tid='$tid'");
	if(!$member = $db->fetch_array($query)) {
		showmessage('thread_nonexistence', NULL, 'HALTED');
	} elseif(($member['adminid'] == 1 && $adminid > 1) || ($member['adminid'] == 2 && $adminid > 2)) {
		showmessage('admin_getip_nopermission', NULL, 'HALTED');
	}

	$member['iplocation'] = convertip($member['useip']);

	include template('topicadmin_getip');

} elseif($action == 'bump') {

	if(!submitcheck('bumpsubmit')) {

		include template('topicadmin_bump');

	} else {

		$query = $db->query("SELECT subject, lastposter, lastpost FROM $table_threads WHERE tid='$tid' LIMIT 1");
		$thread = $db->fetch_array($query);
		$thread[lastposter] = addslashes($thread['lastposter']);
		$db->query("UPDATE $table_threads SET lastpost='$timestamp' WHERE tid='$tid' AND fid='$fid'");
		$db->query("UPDATE $table_forums SET lastpost='$thread[subject]\t$timestamp\t$thread[lastposter]' WHERE fid='$fid' $fupadd");

		modlog();
		showmessage('admin_succeed', "forumdisplay.php?fid=$fid");

	}

} elseif($action == 'split') {

	if(!submitcheck('splitsubmit')) {

		require DISCUZ_ROOT.'./include/discuzcode.php';

		$replies = $thread['replies'];
		if($replies <= 0) {
			showmessage('admin_split_invalid');
		}

		$postlist = array();
		$query = $db->query("SELECT * FROM $table_posts WHERE tid='$tid' ORDER BY dateline");
		while($post = $db->fetch_array($query)) {
			$post['message'] = postify($post['message'], $post['smileyoff'], $post['bbcodeoff']);
			$postlist[] = $post;
		}

		include template('topicadmin_split');

	} else {

		if(!trim($subject)) {
			showmessage('admin_split_subject_invalid');
		}

		$pids = $comma = '';
		if(is_array($split)) {
			foreach($split as $pid) {
				$pids .= $comma.$pid;
				$comma = ',';
			}
		}
		if($pids) {

			$db->query("INSERT INTO $table_threads (fid, subject) VALUES ('$fid', '$subject')");
			$newtid = $db->insert_id();

			$db->query("UPDATE $table_posts SET tid='$newtid' WHERE pid IN ($pids)");
			$db->query("UPDATE $table_attachments SET tid='$newtid' WHERE pid IN ($pids)");

			$query = $db->query("SELECT author, authorid, dateline FROM $table_posts WHERE tid='$tid' ORDER BY dateline ASC LIMIT 1");
			$fpost = $db->fetch_array($query);
			$db->query("UPDATE $table_threads SET author='$fpost[author]', authorid='$fpost[authorid]', dateline='$fpost[dateline]' WHERE tid='$tid'");

			$query = $db->query("SELECT author, authorid, dateline FROM $table_posts WHERE tid='$newtid' ORDER BY dateline ASC LIMIT 1");
			$fpost = $db->fetch_array($query);
			$db->query("UPDATE $table_threads SET author='$fpost[author]', authorid='$fpost[authorid]', dateline='$fpost[dateline]' WHERE tid='$newtid'");

			updatethreadcount($tid);
			updatethreadcount($newtid);
			updateforumcount($fid);

			modlog();
			showmessage('admin_succeed', "forumdisplay.php?fid=$fid");

		} else {
			showmessage('admin_split_new_invalid');
		}
	}

} elseif($action == 'merge') {

	if(!submitcheck('mergesubmit')) {

		include template('topicadmin_merge');

	} else {

		$query = $db->query("SELECT fid, views, replies FROM $table_threads WHERE tid='$othertid'");
		if(!$other = $db->fetch_array($query)) {
			showmessage('admin_merge_nonexistence');
		}
		if($adminid == 3 && $other['fid'] != $forum['fid']) {
			showmessage('admin_merge_invalid');
		}

		$other['views'] = intval($other['views']);
		$other['replies']++;

		$db->query("UPDATE $table_posts SET tid='$tid' WHERE tid='$othertid'");
		$postsmerged = $db->affected_rows();

		$db->query("UPDATE $table_attachments SET tid='$tid' WHERE tid='$othertid'");
		$db->query("DELETE FROM $table_threads WHERE tid='$othertid'");
		$db->query("UPDATE $table_threads SET views=views+$other[views], replies=replies+$other[replies] WHERE tid='$tid'");
		
		if($fid == $other['fid']) {
			$db->query("UPDATE $table_forums SET threads=threads-1 WHERE fid='$fid' $fupadd");
		} else {
			$db->query("UPDATE $table_forums SET threads=threads-1, posts=posts-$postsmerged WHERE fid='$other[fid]'");
			$db->query("UPDATE $table_forums SET posts=$posts+$postsmerged WHERE fid='$fid' $fupadd");
		}

		modlog();
		showmessage('admin_succeed', "forumdisplay.php?fid=$fid");

	}

} else {

	showmessage('undefined_action', NULL, 'HALTED');

}

function modlog($action = '') {
	global $discuz_user, $adminid, $onlineip, $timestamp, $forum, $thread;

	if(!$action) {
		$action = $GLOBALS['action'];
	}

	@$fp = fopen(DISCUZ_ROOT.'./forumdata/modslog.php', 'a');
	@flock($fp, 2);
	@fwrite($fp, "$timestamp\t$discuz_user\t$adminid\t$onlineip\t$forum[fid]\t$forum[name]\t$thread[tid]\t$thread[subject]\t$action\n");
	@fclose($fp);
}

?>