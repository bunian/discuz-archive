<?php

/*
	[DISCUZ!] include/newreply.php - post replying for post module
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.2
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/10/11 05:50
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$discuz_action = 12;

if(!$discuz_uid && !((!$forum['replyperm'] && $allowpost) || ($forum['replyperm'] && strstr($forum['replyperm'], "\t$groupid\t")))) {
	header('Location: logging.php?action=login&referer='.rawurlencode("$PHP_SELF?action=$action&fid=$fid&tid=$tid&pid=$pid&repquote=$repquote"));
	exit();
} elseif(!$forum['allowreply']) {
	if(!$forum['replyperm'] && !$allowpost) {
		showmessage('group_nopermission', NULL, 'HALTED');
	} elseif($forum['replyperm'] && !strstr($forum['replyperm'], "\t$groupid\t")) {
		showmessage('post_forum_newreply_nopermission', NULL, 'HALTED');
	}
}

if(empty($thread)) {
	showmessage('thread_nonexistence');
}

if(!submitcheck('replysubmit')) {

	if($repquote) {
		$query = $db->query("SELECT tid, fid, author, message, useip, dateline FROM $table_posts WHERE pid='$repquote'");
		$thaquote = $db->fetch_array($query);
		if($thaquote['tid'] != $tid) {
			showmessage('undefined_action', NULL, 'HALTED');
		}
		$quotefid = $thaquote['fid'];
		$message = $thaquote['message'];

		$time = gmdate("$dateformat $timeformat", $thaquote[dateline] + ($timeoffset * 3600));
		$message = preg_replace("/\[hide=?\d*\](.+?)\[\/hide\]/is", "[b]**** Hidden message by originally poster *****[/b]", $message);
		$message = preg_replace("/(\[quote])(.*)(\[\/quote])/siU", "", $message);
		$message = cutstr(dhtmlspecialchars($message), 200);

		$thaquote['useip'] = substr($thaquote['useip'], 0, strrpos($thaquote['useip'], '.')).'.x';
		$thaquote['author'] = $thaquote['author'] ? "[i]$thaquote[author][/i]" : "[i]Guest[/i] from $thaquote[useip]";
		$message = preg_replace("/\n{2}\[ Last edited by .+? on .+? at .+? \]$/s", '', $message);
		$message = "[quote]Originally posted by $thaquote[author] at $time:\n$message [/quote]\n";
	}

	if($thread['replies'] <= $ppp) {
		$altbg1 = ALTBG1;
		$altbg2 = ALTBG2;
		$postcount = 0;
		$postlist = array();
		$query = $db->query("SELECT * FROM $table_posts WHERE tid='$tid' ORDER BY dateline DESC");
		while($post = $db->fetch_array($query)) {
			$bgno = $postcount++ % 2 + 1;
			$post['thisbg'] = ${altbg.$bgno};
			$post['dateline'] = gmdate("$dateformat $timeformat", $post[dateline] + $timeoffset * 3600);;
			$post['message'] = preg_replace("/\[hide=?\d*\](.+?)\[\/hide\]/is","[b]**** Hidden message by originally poster *****[/b]", $post['message']);
			$post['message'] = postify($post['message'], $post['smileyoff'], $post['bbcodeoff'], $forum['allowsmilies'], $forum['allowhtml'], $forum['allowbbcode'], $forum['allowimgcode']);

			$postlist[] = $post;
		}
	}

	include template('post_newreply');

} else {

	if($subject == '' && $message == '') {
		showmessage('post_sm_isnull');
	}

	if($post_invalid = checkpost()) {
		showmessage($post_invalid);
	}

	if(checkflood()) {
		showmessage('post_flood_ctrl');
	}

	$subject = dhtmlspecialchars($subject);
	if($thread['closed'] && !$ismoderator) {
		showmessage('post_thread_closed');
	}

	$lastnotifytime = $timestamp - 86400;
	$emails = $comma = '';
	$query = $db->query("SELECT email FROM $table_subscriptions WHERE uid<>'$discuz_uid' AND tid='$tid' AND lastnotify<'$lastnotifytime'");
	while($subs = $db->fetch_array($query)) {
		$emails .= $comma.$subs['email'];
		$comma = ', ';
	}
	if($emails) {
		sendmail($emails, 'email_notify_subject', 'email_notify_message');
		$db->query("UPDATE $table_subscriptions SET lastnotify=$timestamp WHERE tid='$tid' AND lastnotify<'$lastnotifytime'", 'UNBUFFERED');
	}
	if($emailnotify && $discuz_uid) {
		$db->query("INSERT INTO $table_subscriptions (uid, email, tid)
				VALUES ('$discuz_uid', '$email', '$tid')", 'SILENT');
	}
	//exit(attach_upload().'|'.$allowpostattach);//debug
	if(attach_upload() && $allowpostattach) {
		$attachperm = $allowsetattachperm ? $attachperm : 0;
		$db->query("INSERT INTO $table_attachments (tid, pid, creditsrequire, filename, filetype, filesize, attachment)
			VALUES ('$tid', '', '$attachperm', '$attach_name', '$attach_type', '$attach_size', '$attach_fname')");
		$aid = $db->insert_id();
		$attach_type = fileext($attach_name)."\t".$attach_type;
	} else {
		$attach_type = '';
		$aid = 0;
	}

	$bbcodeoff = checkbbcodes($message, $bbcodeoff);
	$smileyoff = checksmilies($message, $smileyoff);
	$db->query("INSERT INTO $table_posts (fid, tid, aid, author, authorid, subject, dateline, message, useip, usesig, bbcodeoff, smileyoff, parseurloff)
			VALUES ('$fid', '$tid', '$aid', '$discuz_user', '$discuz_uid', '$subject', '$timestamp', '$message', '$onlineip', '$usesig', '$bbcodeoff', '$smileyoff', '$parseurloff')");
	$pid = $db->insert_id();
	if($aid) {
		$db->query("UPDATE $table_attachments SET pid='$pid' WHERE aid='$aid'", 'UNBUFFERED');
		$db->query("UPDATE $table_threads SET lastposter='$discuz_user', lastpost='$timestamp', replies=replies+1, attachment='".attachtype($attach_type, 'id')."' WHERE tid='$tid' AND fid='$fid'", 'UNBUFFERED');
	} else {
		$db->query("UPDATE $table_threads SET lastposter='$discuz_user', lastpost='$timestamp', replies=replies+1 WHERE tid='$tid' AND fid='$fid'", 'UNBUFFERED');
	}

	updatemember('+', $discuz_uid, $replycredits);

	$db->query("UPDATE $table_forums SET lastpost='".addslashes($thread['subject'])."\t$timestamp\t$discuz_user', posts=posts+1 WHERE fid='$fid'", 'UNBUFFERED');

	@$topicpages = ceil(($thread['replies'] + 2) / $ppp);

	showmessage('post_reply_succeed', "viewthread.php?tid=$tid&pid=$pid&page=$topicpages#pid$pid");
}

?>