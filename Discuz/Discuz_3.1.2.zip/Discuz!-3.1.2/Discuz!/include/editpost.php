<?

/*
	[DISCUZ!] include/editpost.php - post editing for post module
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.2 guest editing bug fixed
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/10/11 05:50
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$discuz_action = 13;

$query = $db->query("SELECT pid FROM $table_posts WHERE tid='$tid' ORDER BY dateline LIMIT 1");
$isfirstpost = $db->result($query, 0) == $pid ? 1 : 0;

$query = $db->query("SELECT m.adminid, p.authorid, p.dateline FROM $table_posts p LEFT JOIN $table_members m ON m.uid=p.authorid WHERE pid='$pid' AND tid='$tid' AND fid='$fid'");
$orig = $db->fetch_array($query);
$isorigauthor = $discuz_uid && $discuz_uid == $orig['authorid'];
$alloweditpost = $alloweditpost && !(in_array($orig['adminid'], array(1, 2, 3)) && $adminid > $orig['adminid']) ? 1 : 0;

if((!$ismoderator || !$alloweditpost) && !$isorigauthor) {
	showmessage('post_edit_nopermission', NULL, 'HALTED');
}

if(!submitcheck('editsubmit')) {

	if(is_array($_DCACHE['icons']) && $isfirstpost) {
		foreach($_DCACHE['icons'] as $id => $icon) {
			$icons .= ' <input type="radio" name="iconid" value="'.$id.'" '.($thread['iconid'] == $id ? 'checked' : NULL).'><img src="'.SMDIR.'/'.$icon.'">';
			$icons .= !(++$key % 9) ? '<br>' : NULL;
		}
	}

	$query = $db->query("SELECT * FROM $table_posts WHERE pid='$pid' AND tid='$tid' AND fid='$fid'");
	$postinfo = $db->fetch_array($query);

	$usesigcheck = $postinfo['usesig'] ? 'checked="checked"' : NULL;
	$urloffcheck = $postinfo['parseurloff'] ? 'checked="checked"' : NULL;
	$smileyoffcheck = $postinfo['smileyoff'] == 1 ? 'checked="checked"' : NULL;
	$codeoffcheck = $postinfo['bbcodeoff'] == 1 ? 'checked="checked"' : NULL;

	if($alloweditpoll && $thread['poll']) {
		$query = $db->query("SELECT pollopts FROM $table_polls WHERE tid='$tid'");
		$polloptions = unserialize($db->result($query, 0));
		for($i = 0; $i < count($polloptions['options']); $i++) {
			$polloptions['options'][$i][0] = htmlspecialchars(stripslashes($polloptions['options'][$i][0]))."\n";
		}
	} else {
		$polloptions = '';
	}
	if($allowpostattach) {
		if($postinfo['aid']) {
			$query = $db->query("SELECT * FROM $table_attachments WHERE aid='$postinfo[aid]'");
			$postattach = $db->fetch_array($query);
			$attachsize = sizecount($postattach[filesize]);
			$attachicon = attachtype(fileext($postattach['attachment'])."\t".$postattach['filetype']);
		}
	}

	$postinfo['subject'] = str_replace('"', "&quot;", $postinfo['subject']);
	$postinfo['message'] = dhtmlspecialchars($postinfo['message']);
	$postinfo['message'] = preg_replace("/\n{2}\[\[i\] Last edited by .+? on .+? at .+? \[\/i\]\]$/s", '', $postinfo['message']);
	if($previewpost) {
		$postinfo['message'] = $message;
	}

	include template('post_editpost');

} else {

	if(!$delete) {

		if($post_invalid = checkpost()) {
			showmessage($post_invalid);
		}

		$viewpermadd = ($allowsetviewperm && $isfirstpost) ? "creditsrequire='$viewperm'" : NULL;
		$attachpermadd = $allowsetattachperm ? "creditsrequire='$origattachperm'" : NULL;

		$subject = dhtmlspecialchars($subject);

		if($isfirstpost) {
			if($subject == '' || $message == '') {
				showmessage('post_sm_isnull');
			}

			$pollopts = '';
			if($alloweditpoll && $thread['poll'] && trim($polloptions)) {
				$query = $db->query("SELECT pollopts FROM $table_polls WHERE tid='$tid'");
				$pollarray = unserialize($db->result($query, 0));

				$optsdeleted = 0;
				$pollarray['max'] = 0;
				foreach($polloptions as $key => $option) {
					if(trim($option)) {
						$pollarray['options'][$key][0] = $option;
						if($pollarray['options'][$key][1] > $pollarray['max']) {
							$pollarray['max'] = $pollarray['options'][$key][1];
						
						}
					} else {
						$optsdeleted = 1;
						$pollarray['total'] -= $pollarray['options'][$key][1];
						unset($pollarray['options'][$key]);
					}
				}

				if($optsdeleted) {
					$newoptions = array();
					foreach($pollarray['options'] as $option) {
						$newoptions[] = $option;
					}
					$pollarray['options'] = $newoptions;
					unset($newoptions);
				}

				$pollarray['multiple'] = $multiplepoll;
				$pollopts = addslashes(serialize($pollarray));
			}

			$db->query("UPDATE $table_threads SET iconid='$iconid', subject='$subject' WHERE tid='$tid'", 'UNBUFFERED');
			if($pollopts) {
				$db->query("UPDATE $table_polls SET pollopts='$pollopts' WHERE tid='$tid'", 'UNBUFFERED');
			}
		} else {
			if($subject == '' && $message == '') {
				showmessage('post_sm_isnull');
			}
		}

		if($editedby && ($timestamp - $orig['dateline']) > 60 && $adminid != 1){
			$editdate = gmdate($_DCACHE['settings']['dateformat'], $timestamp + $timeoffset * 3600);
			$edittime = gmdate($_DCACHE['settings']['timeformat'], $timestamp + $timeoffset * 3600);
			$message .= "\n\n[[i] Last edited by $discuz_user on $editdate at $edittime [/i]]";
		}

		$bbcodeoff = checkbbcodes($message, $bbcodeoff);
		$smileyoff = checksmilies($message, $smileyoff);
		if(($attachedit == 'delete' || ($attachedit == 'new' && attach_upload())) && $allowpostattach) {
			$query = $db->query("SELECT attachment FROM $table_attachments WHERE pid='$pid'");
			$thread_attachment = $db->result($query, 0);
			@unlink(DISCUZ_ROOT.'./'.$attachdir.'/'.$thread_attachment);
			$db->query("DELETE FROM $table_attachments WHERE pid='$pid'", 'UNBUFFERED');

			if($attachedit == 'new') {
				$attachperm = $allowsetattachperm ? $attachperm : 0;
				$db->query("INSERT INTO $table_attachments (tid, pid, creditsrequire, filename, filetype, filesize, attachment, downloads)
					VALUES ('$tid', '$pid', '$attachperm', '$attach_name', '$attach_type', '$attach_size', '$attach_fname', '0')");
				$attach_type = fileext($attach_name)."\t".$attach_type;
				$aid = $db->insert_id();
			} else {
				$query = $db->query("SELECT attachment, filetype FROM $table_attachments WHERE tid='$tid' ORDER BY pid DESC LIMIT 1");
				if($thread_attachment = $db->fetch_array($query)) {
					$attach_type = fileext($thread_attachment['attachment'])."\t".$thread_attachment['filetype'];
				} else {
					$attach_type = '';
				}
				$aid = 0;
			}
			if($viewpermadd) {
				$viewpermadd = ", $viewpermadd";
			}

			$db->query("UPDATE $table_posts SET aid='$aid', message='$message', usesig='$usesig', bbcodeoff='$bbcodeoff', parseurloff='$parseurloff',
				smileyoff='$smileyoff', subject='$subject' WHERE pid='$pid'");
			$db->query("UPDATE $table_threads SET attachment='".attachtype($attach_type, 'id')."' $viewpermadd WHERE tid='$tid'", 'UNBUFFERED');
		} else {
			$db->query("UPDATE $table_posts SET message='$message', usesig='$usesig', bbcodeoff='$bbcodeoff', parseurloff='$parseurloff',
				smileyoff='$smileyoff', subject='$subject' WHERE pid='$pid'");
			if($attachpermadd) {
				$db->query("UPDATE $table_attachments SET $attachpermadd WHERE pid='$pid'", 'UNBUFFERED');
			}
			if($viewpermadd) {
				$db->query("UPDATE $table_threads SET $viewpermadd WHERE tid='$tid'", 'UNBUFFERED');
			}
		}

		$modaction = 'editpost';

	} else {

		if(!$allowdelpost && !$isorigauthor) {
			showmessage('post_edit_nopermission', NULL, 'HALTED');
		}

		if(!$isfirstpost) {

			updatemember('-', $orig['authorid'], $deletedcredits);

			$query = $db->query("SELECT pid, filetype, attachment FROM $table_attachments WHERE tid='$tid'");
			$attach_type = '';
			while($thread_attachment = $db->fetch_array($query)) {
				if($thread_attachment['filetype']) {
					$attach_type = fileext($thread_attachment['attachment'])."\t".$thread_attachment['filetype'];
				}
				if($thread_attachment[pid] == $pid) {
					@unlink(DISCUZ_ROOT.'./'.$attachdir.'/'.$thread_attachment['attachment']);
				}
			}
			$db->query("UPDATE $table_threads SET attachment='".attachtype($attach_type, 'id')."' WHERE tid='$tid'", 'UNBUFFERED');
			$db->query("DELETE FROM $table_attachments WHERE pid='$pid'", 'UNBUFFERED');
			$db->query("DELETE FROM $table_posts WHERE pid='$pid'");
			updateforumcount($fid);
			updatethreadcount($tid);

			$modaction = 'delposts';

		} else {

			if(!$allowdelpost && $isorigauthor && $thread['replies'] >= 1) {
				showmessage('post_edit_nopermission', NULL, 'HALTED');
			}

			$uids = $comma = '';
			$query = $db->query("SELECT authorid FROM $table_posts WHERE tid='$tid'");
			while($post = $db->fetch_array($query)) {
				$uids .= "$comma$post[authorid]";
				$comma = ',';
			}
			updatemember('-', $uids, $deletedcredits);

			$db->query("DELETE FROM $table_threads WHERE tid='$tid' OR closed='$tid'", 'UNBUFFERED');

			$query = $db->query("SELECT attachment FROM $table_attachments WHERE tid='$tid'");
			while($thread_attachment = $db->fetch_array($query)) {
				@unlink(DISCUZ_ROOT.'./'.$attachdir.'/'.$thread_attachment['attachment']);
			}

			$db->query("DELETE FROM $table_attachments WHERE tid='$tid'", 'UNBUFFERED');
			$db->query("DELETE FROM $table_posts WHERE tid='$tid'");
			updateforumcount($fid);

			$modaction = 'delete';

		}

	}

	if(!$isorigauthor) {
		@$fp = fopen(DISCUZ_ROOT.'./forumdata/modslog.php', 'a');
		@flock($fp, 2);
		@fwrite($fp, "$timestamp\t$discuz_user\t$groupid\t$onlineip\t$forum[fid]\t$forum[name]\t$thread[tid]\t$thread[subject]\t$modaction\n");
		@fclose($fp);
	}

	if($delete && $isfirstpost) {
		showmessage('post_edit_delete_succeed', "forumdisplay.php?fid=$fid");
	} else {
		showmessage('post_edit_succeed', "viewthread.php?tid=$tid&page=$page#pid$pid");
	}

}

?>