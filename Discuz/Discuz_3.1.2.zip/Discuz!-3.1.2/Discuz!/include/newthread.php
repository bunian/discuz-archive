<?php

/*
	[DISCUZ!] include/newthread.php - starting new thread for post module
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.2
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/10/11 05:50
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$discuz_action = 11;

if(empty($forum['fid']) || $forum['type'] == 'group') {
	showmessage('forum_nonexistence');
}

if(!$discuz_uid && !((!$forum['postperm'] && $allowpost) || ($forum['postperm'] && strstr($forum['postperm'], "\t$groupid\t")))) {
	header('Location: logging.php?action=login&referer='.rawurlencode("$PHP_SELF?action=$action&fid=$fid&poll=$poll"));
	exit();
} elseif(!$forum['allowpost']) {
	if(!$forum['postperm'] && !$allowpost) {
		showmessage('group_nopermission', NULL, 'HALTED');
	} elseif($forum['postperm'] && !strstr($forum['postperm'], "\t$groupid\t")) {
		showmessage('post_forum_newthread_nopermission', NULL, 'HALTED');
	}
}

if(!submitcheck('topicsubmit')) {

	if(is_array($_DCACHE['icons'])) {
		foreach($_DCACHE['icons'] as $id => $icon) {
			$icons .= ' <input type="radio" name="iconid" value="'.$id.'"><img src="'.SMDIR.'/'.$icon.'">';
			$icons .= !(++$key % 9) ? '<br>' : NULL;
		}
	}

	include template('post_newthread');

} else {

	if(!$subject || !$message) {
		showmessage('post_sm_isnull');
	}

	if($post_invalid = checkpost()) {
		showmessage($post_invalid);
	}

	if(checkflood()) {
		showmessage('post_flood_ctrl');
	}

	$subject = dhtmlspecialchars($subject);
	$displayorder = ($ismoderator && $toptopic) ? 1 : 0;
	$digest = ($ismoderator && $addtodigest) ? 1 : 0;
	$viewperm = $allowsetviewperm ? $viewperm : 0;

	if($poll == 'yes' && $allowpostpoll && trim($polloptions)) {
		$poll = 1;
		$pollarray = array();
		$polloptions = explode("\n", $polloptions);
		if(count($polloptions) > $maxpolloptions) {
			showmessage('post_poll_option_toomany');
		}

		foreach($polloptions as $polloption) {
			$polloption = trim($polloption);
			if($polloption) {
				$pollarray['options'][] = array($polloption, 0);
			}
		}
		$pollarray['multiple'] = $multiplepoll;
		$pollarray['voters'] = array();
		$pollopts = addslashes(serialize($pollarray));
	} else {
		$poll = 0;
		$pollopts = '';
	}

	if(attach_upload() && $allowpostattach) {
		$attachperm = $allowsetattachperm ? $attachperm : 0;
		$db->query("INSERT INTO $table_attachments (creditsrequire, filename, filetype, filesize, attachment, downloads)
			VALUES ('$attachperm', '$attach_name', '$attach_type', '$attach_size', '$attach_fname', '0')");
		$aid = $db->insert_id();
		$attach_type = fileext($attach_name)."\t".$attach_type;
	} else {
		$attach_type = '';
		$aid = 0;
	}

	$db->query("INSERT INTO $table_threads (fid, creditsrequire, iconid, author, authorid, subject, dateline, lastpost, lastposter, displayorder, digest, poll, attachment)
		VALUES ('$fid', '$viewperm', '$iconid', '$discuz_user', '$discuz_uid', '$subject', '$timestamp', '$timestamp', '$discuz_user', '$displayorder', '$digest', '$poll', '".attachtype($attach_type, 'id')."')");
	$tid = $db->insert_id();

	if($poll) {
		$db->query("INSERT INTO $table_polls (tid, pollopts)
			VALUES ('$tid', '$pollopts')");
	}

	$bbcodeoff = checkbbcodes($message, $bbcodeoff);
	$smileyoff = checksmilies($message, $smileyoff);
	$db->query("INSERT INTO $table_posts (fid, tid, aid, author, authorid, subject, dateline, message, useip, usesig, bbcodeoff, smileyoff, parseurloff)
		VALUES ('$fid', '$tid', '$aid', '$discuz_user', '$discuz_uid', '$subject', '$timestamp', '$message', '$onlineip', '$usesig', '$bbcodeoff', '$smileyoff', '$parseurloff')");
	$pid = $db->insert_id();

	if($aid) {
		$db->query("UPDATE $table_attachments SET tid='$tid', pid='$pid' WHERE aid='$aid'", 'UNBUFFERED');
	}

	updatemember('+', $discuz_uid, $postcredits);

	$db->query("UPDATE $table_forums SET lastpost='$subject\t$timestamp\t$discuz_user', threads=threads+1, posts=posts+1 WHERE fid='$fid'", 'UNBUFFERED');

	if($emailnotify && $discuz_uid) {
		$query = $db->query("SELECT tid FROM $table_subscriptions WHERE uid='$discuz_uid' AND tid='$tid'");
		if(!$db->result($query, 0)) {
			$db->query("INSERT INTO $table_subscriptions (uid, email, tid)
				VALUES ('$discuz_uid', '$email', '$tid')", 'UNBUFFERED');
		}
	}

	showmessage('post_newthread_succeed', "viewthread.php?tid=$tid");
}

?>