<?php

/*
	[DISCUZ!] include/post.php - common functions for post module
	This is NOT a freeware, use is subject to license terms

	Version: 3.1.0
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/5/12 09:02
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function attach_upload() {
	global $db, $table_attachtypes, $extension, $typemaxsize;
	global $attachsave, $attach, $attach_name, $attach_size, $attach_fname, $attachdir, $maxattachsize, $attachextensions;

	// [EN] Due to the bug on some specified WIN+IIS+PHP_ISAPI platform, if ur attachments uploading does not work,
	// try to get rid of "(function_exists('is_uploaded_file') && !is_uploaded_file($attach)) || " in the following condition.
	// [CH] ���ڸ����ض� WIN+IIS+PHP_ISAPI ƽ̨�ϵ� BUG,���������������,�������ϴ�û���κ���ʾ,��ʵ�ʲ����ļ��ϴ�
	// ��������,���޷���ʾ����,��ȥ�����������е� "(function_exists('is_uploaded_file') && !is_uploaded_file($attach)) || "
	// ����(˫�������ڵĲ���)����

	if((function_exists('is_uploaded_file') && !is_uploaded_file($attach)) || !($attach != 'none' && $attach && trim($attach_name))) {
		return false;
	}

	$attach_name = $filename  = daddslashes($attach_name);
	$attach_ext = $extension = strtolower(fileext($attach_name));

	if($attachextensions && @!eregi($attach_ext, $attachextensions)) {
		showmessage('post_attachment_ext_notallowed');
	}

	if(!$attach_size || ($maxattachsize && $attach_size > $maxattachsize)) {
		showmessage('post_attachment_toobig');
	}

	$query = $db->query("SELECT maxsize FROM $table_attachtypes WHERE extension='".addslashes($attach_ext)."'");
	if($type = $db->fetch_array($query)) {
		if($type['maxsize'] == 0) {
			showmessage('post_attachment_ext_notallowed');
		} elseif($attach_size > $type['maxsize']) {
			$typemaxsize = sizecount($type['maxsize']);
			showmessage('post_attachment_type_toobig');
		}
	}

	if($attachsave) {
		switch($attachsave) {
			case 1: $attach_subdir = 'forumid_'.$GLOBALS['fid']; break;
			case 2: $attach_subdir = 'ext_'.$extension; break;
			case 3: $attach_subdir = 'month_'.date('ym'); break;
			case 4: $attach_subdir = 'day_'.date('ymd'); break;
		}
		$attach_dir = DISCUZ_ROOT.'./'.$attachdir.'/'.$attach_subdir;
		if(!is_dir($attach_dir)) {
			mkdir($attach_dir, 0777);
			fclose(fopen($attach_dir.'/index.htm', 'w'));
		}
		$attach_fname = $attach_subdir.'/';
	} else {
		$attach_fname = '';
	}

	$filename = substr($filename, 0, strlen($filename) - strlen($extension) - 1);
	if(preg_match("/[\x7f-\xff]+/s", $filename)) {
		$filename = str_replace('/', '', base64_encode(substr($filename, 0, 20)));
	}
	if(in_array($attach_ext, array('php', 'php3', 'jsp', 'asp', 'aspx', 'cgi', 'pl'))) {
		$extension = '_'.$extension;
	}

	$attach_saved = false;
	$attach_fname .= substr($filename, 0, 64).'_'.random(12).'.'.$extension;
	$target = DISCUZ_ROOT.'./'.$attachdir.'/'.$attach_fname;

	if(@copy($attach, $target) || (function_exists('move_uploaded_file') && @move_uploaded_file($attach, $target))) {
		$attach_saved = true;
	}

	if(!$attach_saved && @is_readable($attach)) {
		@$fp = fopen($attach, 'rb');
		@flock($fp, 2);
		@$attachedfile = fread($fp, $attach_size);
		@fclose($fp);

		@$fp = fopen($target, 'wb');
		@flock($fp, 2);
		if(@fwrite($fp, $attachedfile)) {
			$attach_saved = true;
		}
		@fclose($fp);
	}

	if($attach_saved) {
		if(in_array($attach_ext, array('jpg', 'gif', 'png', 'swf', 'bmp')) && function_exists('getimagesize') && !getimagesize($target)) {
			@unlink($target);
			showmessage('post_attachment_ext_notallowed');
		} else {
			return true;
		}
	} else {
		showmessage('post_attachment_save_error');
	}
}

function checkflood() {
	global $disablepostctrl, $floodctrl, $discuz_uid, $timestamp, $lastpost, $forum;
	if(!$disablepostctrl && $floodctrl) {
		if($discuz_uid) {
			if($timestamp - $floodctrl <= $lastpost) {
				return TRUE;
			}
		} else {
			$lastpost = explode("\t", $forum['lastpost']);
			if(($timestamp - $floodctrl) <= $lastpost[1] && $discuz_user == $lastpost[2]) {
				return TRUE;
			}
		}
	}
	return FALSE;
}

function checkpost() {
	global $subject, $message, $disablepostctrl, $minpostsize, $maxpostsize;
	if(strlen($subject) > 80) {
		return 'post_subject_toolang';
	}
	if(!$disablepostctrl) {
		if($maxpostsize && strlen($message) > $maxpostsize) {
			return 'post_message_toolang';
		} elseif($minpostsize && strlen(preg_replace("/\[quote\].+?\[\/quote\]/is", '', $message)) < $minpostsize) {
			return 'post_message_tooshort';
		}
	}
	return FALSE;
}

function checkbbcodes($message, $bbcodeoff) {
	return !$bbcodeoff && !preg_match("/\[.+\].*\[\/.+\]/s", $message) ? -1 : $bbcodeoff;
}

function checksmilies($message, $smileyoff) {
	$smilies = array();
	foreach($GLOBALS['_DCACHE']['smilies'] as $smiley) {
		$smilies[]= preg_quote($smiley['code'], '/');
	}

	return !$smileyoff && !preg_match('/'.implode('|', $smilies).'/', $message) ? -1 : $smileyoff;
}

function updatemember($operator, $uid, $credits) {
	global $db, $table_members, $table_usergroups, $discuz_uid, $adminid, $groupid, $credit, $timestamp;

	if($uid) {
		if($uid == $discuz_uid) {
			if($adminid) {
				$groupidadd = NULL;
			} else {
				eval("\$credit = intval(\$credit$operator($credits));");
	
				$query = $db->query("SELECT groupid FROM $table_usergroups WHERE type='member' AND '$credit'>=creditshigher AND '$credit'<creditslower");
				$groupidadd = ", groupid='".$db->result($query, 0)."'";
			}
			$db->query("UPDATE $table_members SET postnum=postnum$operator(1), credit=credit$operator$credits, lastpost='$timestamp' $groupidadd WHERE uid='$uid'");
		} else {
			$member = array();
			foreach(explode(',', $uid) as $id) {
				$member[trim($id)]++;
			}
	
			foreach($member as $uid => $posts) {
				if($credits) {
					$query = $db->query("SELECT m.adminid, u.groupid FROM $table_members m
								LEFT JOIN $table_usergroups u ON (u.creditshigher<>'0' || u.creditslower<>'0') AND m.credit$operator$credits*$posts>=u.creditshigher AND m.credit$operator$credits*$posts<u.creditslower
								WHERE uid='$uid'");
					if($member = $db->fetch_array($query)) {
						$groupidadd = $member['adminid'] == 0 ? ", groupid='$member[groupid]'" : NULL;
						$db->query("UPDATE $table_members SET postnum=postnum$operator$posts, credit=credit$operator($credits*$posts) $groupidadd WHERE uid='$uid'", 'UNBUFFERED');
					}
				} else {
					$db->query("UPDATE $table_members SET postnum=postnum$operator$posts WHERE uid='$uid'", 'UNBUFFERED');
				}
			}
		}
	}
}

function updateforumcount($fid) {
	global $db, $table_threads, $table_forums;
	$query = $db->query("SELECT COUNT(*) AS threadcount, SUM(t.replies)+COUNT(*) AS replycount FROM $table_threads t, $table_forums f WHERE f.fid='$fid' AND t.fid=f.fid");
	extract($db->fetch_array($query));

	$query = $db->query("SELECT subject, lastpost, lastposter FROM $table_threads WHERE fid='$fid' ORDER BY lastpost DESC LIMIT 1");
	$thread = $db->fetch_array($query);
	$thread['subject'] = addslashes($thread['subject']);
	$thread['lastposter'] = addslashes($thread['lastposter']);
	$db->query("UPDATE $table_forums SET posts='$replycount', threads='$threadcount', lastpost='$thread[subject]\t$thread[lastpost]\t$thread[lastposter]' WHERE fid='$fid'", 'UNBUFFERED');
}

function updatethreadcount($tid) {
	global $db, $table_threads, $table_posts;
	$query = $db->query("SELECT COUNT(*) FROM $table_posts WHERE tid='$tid'");
	$replycount = $db->result($query, 0) - 1;
	if($replycount < 0) {
		$db->query("DELETE FROM $table_threads WHERE tid='$tid'");
	}
	$query = $db->query("SELECT author, dateline FROM $table_posts WHERE tid='$tid' ORDER BY dateline DESC LIMIT 1");
	$lastpost = $db->fetch_array($query);
	$lastpost['author'] = addslashes($lastpost['author']);
	$db->query("UPDATE $table_threads SET replies='$replycount', lastposter='$lastpost[author]', lastpost='$lastpost[dateline]' WHERE tid='$tid'", 'UNBUFFERED');
}

?>