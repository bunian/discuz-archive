<?php

/*
	[DISCUZ!] viewpro.php - view member's profile
	This is NOT a freeware, use is subject to license terms

	Version: 3.0.0
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2003/5/21 06:58
*/

require './include/common.php';
require DISCUZ_ROOT.'./include/discuzcode.php';
require DISCUZ_ROOT.'./forumdata/cache/cache_profilefields.php';

$discuz_action = 61;

$query = $db->query("SELECT m.*, u.grouptitle, u.color AS groupcolor, u.stars AS groupstars,
		r.ranktitle, r.color AS rankcolor, r.stars AS rankstars FROM $table_members m
		LEFT JOIN $table_usergroups u USING(groupid)
		LEFT JOIN $table_ranks r ON m.postnum>=r.postshigher
		WHERE ".(isset($uid) ? "uid='$uid'" : "username='$username'")."ORDER BY r.postshigher DESC LIMIT 1");

if(!@$member = $db->fetch_array($query)) {
	showmessage('member_nonexistence');
}

$query = $db->query("SELECT COUNT(*) FROM $table_posts");
@$percent = round($member['postnum'] * 100 / $db->result($query, 0), 2);
$postperday = $timestamp - $member['regdate'] > 86400 ? round(86400 * $member['postnum'] / ($timestamp - $member['regdate']), 2) : $member['postnum'];

$member['grouptitle'] = $member['groupcolor'] ? '<font color="'.$member['groupcolor'].'">'.$member['grouptitle'].'</font>' : $member['grouptitle'];
$member['ranktitle'] = $member['rankcolor'] ? '<font color="'.$member['rankcolor'].'">'.$member['ranktitle'].'</font>' : $member['ranktitle'];

$member['regdate'] = gmdate($dateformat, $member['regdate']);
$member['site'] = $member['site'] ? 'http://'.str_replace('http://', '', $member['site']) : '';
$member['avatar'] = $member['avatar'] ? "<img src=\"$member[avatar]\" width=\"$member[avatarwidth]\" height=\"$member[avatarheight]\" border=\"0\">" : '<br><br><br>';
$member['lastactivity'] = gmdate("$dateformat $timeformat", $member['lastactivity'] + ($timeoffset * 3600));
$member['lastpost'] = $member['lastpost'] ? gmdate("$dateformat $timeformat", $member['lastpost'] + ($timeoffset * 3600)) : 'x';
$member['bio'] = nl2br($member['bio']);
$member['signature'] = postify($member['signature'], 1, 0, 0, 0, $member['allowsigbbcode'], $member['allowsigimgcode']);

$birthday = explode('-', $member['bday']);
$member['bday'] = $dateformat;
$member['bday'] = str_replace('n', $birthday[1], $member['bday']);
$member['bday'] = str_replace('j', $birthday[2], $member['bday']);
$member['bday'] = str_replace('Y', $birthday[0], $member['bday']);
$member['bday'] = str_replace('y', substr($birthday[0], 2, 4), $member['bday']);

if($allowviewip && !($adminid == 2 && $member['adminid'] == 1) && !($adminid == 3 && ($member['adminid'] == 1 || $member['adminid'] == 2))) {
	require DISCUZ_ROOT.'./include/misc.php';
	$member['regiplocation'] = convertip($member['regip']);
	$member['lastiplocation'] = convertip($member['lastip']);
} else {
	$allowviewip = 0;
}

foreach(array_merge($_DCACHE['fields_required'], $_DCACHE['fields_optional']) as $field) {
	if(!$field['invisible'] || $adminid == 1) {
		$_DCACHE['fields'][] = $field;
	}
}

unset($_DCACHE['fields_required'], $_DCACHE['fields_optional']);

include template('viewpro');

?>