<?php

// Message Pack for Discuz! Version 1.0.0
// Translated by Crossday & cknuke

$credittitle = 'credit';
$creditunit = '';

$language = array
(
	'undefined_action' => 'Undefined action.',
	'group_nopermission' => 'Sorry, your usergroup($grouptitle) does not have permission to access this page.',
	'submit_invalid' => 'Your request was forbidden due to security reason.',
	'not_loggedin' => 'Sorry, You are not logged in and do not have permission to access this page.',
	'board_closed' => 'Sorry, this bulletin board is temporality closed, please <a href=\"mailto:$adminemail\">contact the administrator</a>.',

	'login_invalid' => 'Invalid username, password or answer of security question, you may have 5 attempts at most, please return.',
	'login_strike' => 'Your failed login quota has been used up, please wait 15 minutes before trying again.',
	'login_succeed' => 'Thank you for logging in, $discuz_userss. Now will forward you to where you were.',
	'logout_succeed' => 'You are logged out, now will forward you to where you were.',

	'user_banned' => 'You are BANNED in this forum.',

	'forum_nonexistence' => 'Specified forum does not exist.',
	'forum_passwd_correct' => 'Your password was verified, now will forward you to the forum.',
	'forum_passwd_incorrect' => 'Invaild password and have no permission to access this forum.',
	'forum_nopermission' => 'Sorry, only specified users have permission to access this forum.',

	'thread_nonexistence' => 'Specified thread does not exist or has been deleted.',
	'thread_nopermission' => 'Sorry, this thread requires your $credittitle at least $thread[creditsrequire] $creditunit.',
	'thread_poll_closed' => 'Specified poll has been closed and you are not able to vote in.',
	'thread_poll_voted' => 'You have already voted on this poll, please return.',
	'thread_poll_invalid' => 'You submitted an invalid vote, please return to correct this problem.',
	'thread_poll_succeed' => 'Your vote on this thread has been added, now will forward you to the thread.',
	'thread_karma_range_invalid' => 'Your vote must be ranged from $minkarmarate to $maxkarmarate, please return.',
	'thread_karma_member_invalid' => 'You can not vote for yourself, please return.',
	'thread_karma_ctrl' => 'Sorry, your could not vote out of $maxrateperday $creditunit in 24 hours, please return.',
	'thread_karma_duplicate' => 'You could not vote for the same post again, please return.',
	'thread_karma_succeed' => 'Thanks for your $score $creditunit votes for $post[author]. Now will forward you to the thread.',
	'thread_report_disable' => 'Reporting post has been disabled by the administrator, please return.',
	'thread_report_succeed' => 'Thanks for your report, it will be dealt with as appropriate in due course. Now will forward you to the thread.',

	'view_log_invalid' => 'Views log file(./forumdata/viewcount.log) is unwriteable, please set mode 777 or rebuild it.',

	'attachment_referer_invalid' => 'Sorry, you can not download attachments from other sites.',
	'attachment_nopermission' => 'Sorry, this attachment requires your $credittitle at least $attach[creditsrequire] $creditunit, please return.',
	'attachment_forum_nopermission' => 'Sorry, only specified users have permission to download attachments from this forum, please return.',
	'attachment_nonexistence' => 'Attachment file not found, please contact the administrator.',

	'post_hide_nopermission' => 'You do not have permission to posting with [hide], please return.',
	'post_newbie_span' => 'Sorry, you do not have permission to postting in $newbiespan hour(s) after registration, please return.',
	'post_forum_newthread_nopermission' => 'Sorry, only specified groups have permission to post new thread in this forum, please return.',
	'post_forum_newreply_nopermission' => 'Sorry, only specified groups have permission to post reply in this forum, please return.',
	'post_thread_closed' => 'Sorry,  the thread is closed and do not accept new posts, please return.',
	'post_subject_toolang' => 'Sorry, your subject is more than 80 bytes, please return to correct this problem.',
	'post_message_tooshort' => 'Sorry, your message is less than $minpostsize bytes, please return to correct this problem.',
	'post_message_toolang' => 'Sorry, your message is more than $maxpostsize bytes, please return to correct this problem.',
	'post_sm_isnull' => 'Sorry, you didn\'t enter the subject or message, please return to correct this problem.',
	'post_flood_ctrl' => 'Sorry, you could only post one message every $floodctrl seconds, please do not flood!',
	'post_poll_option_toomany' => 'Your poll have more than $maxpolloptions options, please return to correct this problem.',
	'post_edit_nopermission' => 'You do not have permission to edit or delete this post.',
	'post_edit_delete_succeed' => 'The topic has been deleted successfully, now will forward you to the forum.',
	'post_attachment_toobig' => 'The file you uploaded is too big, please return.',
	'post_attachment_type_toobig' => 'The file you uploaded is over $typemaxsize limitation of \".$extension\" type, please return.',
	'post_attachment_ext_notallowed' => 'You have attempted to upload an invalid type of attachment, please return.',
	'post_attachment_save_error' => 'Error occurs when uploading the file. Please try again, if the error continues, please contact the administrator',
	'post_edit_succeed' => 'The post has been successfully edited, now will forward you to the thread.',
	'post_reply_succeed' => 'Thank you for your posting, now will forward you to the thread.',
	'post_newthread_succeed' => 'Thank you for your posting, now will forward you to the thread.',

	'register_disable' => 'Sorry, registering is disabled by the administrator, please return.',
	'register_ctrl' => 'Sorry, you could only register once for each IP address every $regctrl hours.',
	'register_succeed' => 'Thank you for registering, now will forward you to where you were.',

	'profile_username_toolang' => 'Sorry, your username could not be greater than 15 charactors, please return to correct this problem.',
	'profile_passwd_notmatch' => 'The two passwords that you typed do not match, please return to correct this problem.',
	'profile_passwd_wrong' => 'The old pssword is incorrect, you can not modify it!',
	'profile_admin_security_invalid' => 'As administrator or moderator, you are required to use security questions to looks after the forums\' security, please return to correct this problem.',
	'profile_username_duplicate' => 'Sorry, your username is already in use, please return.',
	'profile_email_duplicate' => 'Sorry, your email is already in use, please return.',
	'profile_username_illegal' => 'Your username is illegal or not allowed to register, please return.',
	'profile_passwd_illegal' => 'Your password is illegal, please return.',
	'profile_email_illegal' => 'Your email is illegal, please return.',
	'profile_required_info_invalid' => 'You did not complete the required information, please return.',
	'profile_sig_toolang' => 'Your signature is more than $maxsigsize bytes, please return.',
	'profile_avatar_invalid' => 'The type of your specified avatar is invalid, please return.',
	'profile_avatar_toobig' => 'Your specified avatar must be limited to $maxavatarsize bytes, please return.',
	'profile_avatardir_nonexistence' => 'The avatars\' directory ./images/avatars not found, please contact the administrator.',
	'profile_avatar_succeed' => 'Your avatar has been updated, now will forward you to profile index.',
	'profile_email_verify' => 'An email including instructions for activation of your account has been dispatched. If you can not receive the email, please click \"Re-verify My Email\" in Member\'s CP Home for more attampts, or changing another email address. Note: You could only visit our forums as \"Inactive Member\" before your activation, the state of being restricted will be over after you activated successfully.',
	'profile_succeed' => 'Your profile has been updated, now will forward you to Member\'s CP Home.',

	'buddy_add_invalid' => 'Specified member has already been in your buddy list, please return.',
	'buddy_add_nonexistence' => 'User $buddy does not exist, please return to correct this problem.',
	'buddy_update_succeed' => 'Your buddy list has been updated, now will forward you to Member\'s CP Home.',

	'redirect_nextnewset_nonexistence' => 'There are no threads newer than the previous one, please return.',
	'redirect_nextoldset_nonexistence' => 'There are no threads older than the previous one, please return.',

	'favorite_exists' => 'The thread is already in your favorites, please return.',
	'favorite_add_succeed' => 'The favorites have been updated, now will forward you to where you were.',
	'favorite_update_succeed' => 'The favorite has been updated, now will forward you to where you were.',
	'subscription_exists' => 'The thread has already been subscribed, please return.',
	'subscription_add_succeed' => 'The selected topic has been subscibed, now will forward you to where you were.',
	'subscription_update_succeed' => 'The subsciption has been updated, now will forward you to where you were.',

	'search_ctrl' => 'Sorry, you could only search once every $searchctrl seconds, please return.',
	'search_invalid' => 'You did not entered the keyword or username to search on, please return.',
	'search_forum_invalid' => 'You did not specify forums to search in, please return.',
	'search_id_invalid' => 'Your specified search was nonexistence or expired, please return.',
	'search_redirect' => 'Search completed, now will forward you to related thread list.',

	'member_nonexistence' => 'Invaild member specified, please return.',
	'member_list_disable' => 'Sorry, the members list is disabled by the administrator.',
	'email_friend_invalid' => 'You did not fill all required fields, please return to correct the problem.',
	'email_friend_succeed' => 'An email has been dispatched, now will forward you to the thread.',
	'announcement_nonexistence' => 'There is no announcement available, please return.',
	'mark_read_succeed' => 'All forums have been marked as read, now will forward you to the home.',
	'email_verify_invalid' => 'You can not request email verification twice in 24 hours, please return.',
	'email_verify_succeed' => 'An email including instructions for activation of your account has been dispatched.',
	'activate_succeed' => 'Hi, $member[username], your account was activated, now will forward you to the home.',
	'activate_illegal' => 'Sorry, specified ID does not exist or you are not an inactive member.',

	'getpasswd_account_notmatch' => 'The username, email or answer of security question you entered did not match, please return.',
	'getpasswd_account_invalid' => 'Sorry, getting password is not available for administrators or super moderators, please return.',
	'getpasswd_illegal' => 'Sorry, specified ID does not exist or was expired, you can not get back your password back.',
	'getpasswd_send_succeed' => 'The way of getting password back has been dispatched to you by email.',
	'getpasswd_succeed' => 'Your password has been changed, please login with the new one.',

	'pm_box_isfull' => 'Your P.M. boxes is full, and you could not read messages until it is cleaned out.',
	'pm_nonexistence' => 'Specified P.M. does not exist or has been deleted.',
	'pm_flood_ctrl' => 'Sorry, you could only send one P.M. every $floodctrl seconds, please do not flood!',
	'pm_send_nonexistence' => 'Invalid recipient username, please return.',
	'pm_send_invalid' => 'You did not entered subject or message, please return.',
	'pm_send_toomany' => 'The number of recipients is more than $maxpmsend, please return.',
	'pm_send_ignore' => '$member[username] refused to receive messages from you, please return.',
	'pm_send_succeed' => 'The message has been processed, now will forward you to message list.',
	'pm_delete_succeed' => 'The specified message(s) have been deleted, now will forward you to message list.',
	'pm_ignore_succeed' => 'Your ignore list has been updated, now will forward you to message lsit.',

	'admin_nopermission' => 'Sorry, you do not have permission to moderate this forum.',
	'admin_getip_nopermission' => 'Sorry, you do not have permission to view ip of higher administrator, please return.',
	'admin_delthread_invalid' => 'You did not specify the threads to delete, please return.',
	'admin_delpost_invalid' => 'You did not specify the posts to delete, please return.',
	'admin_move_invalid' => 'You did not specified the forum to move to, please return to correct the problem.',
	'admin_split_invalid' => 'This specified thread do not contain replies to split, please return.',
	'admin_split_subject_invalid' => 'The subject you entered is invaild, please return to correct the problem.',
	'admin_split_new_invalid' => 'You did not specify the posts to split to new thread, please return to correct the problem.',
	'admin_merge_nonexistence' => 'The thread ID you specified does not exist, please return to correct the problem.',
	'admin_merge_invalid' => 'Sorry, you do not have permission not merge with thread outside of current forum, please return.',
	'admin_succeed' => 'Your action has been executed, now will forward you to the forum.'

);

?>