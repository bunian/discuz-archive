<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE);
@set_magic_quotes_runtime(0);
@set_time_limit(0);

define('DISCUZ_ROOT', getcwd().'/');
define('IN_DISCUZ', TRUE);
$PHP_SELF = htmlspecialchars($_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME']);
$newfunction_set = array("<h3>【新手任務】（擴展 -> 論壇任務）</h3>
		此功能用來幫助新手掌握論壇生存必備的基本技能。建議站長在進行該功能的設置時認真考慮任務獎勵類型和具體的獎勵量值。一般來講，同時使用多種獎勵形式(論壇設定開啟【<a href='./admincp.php?frames=yes&action=magics&operation=config' target='_blank'>道具</a>】和【<a href='./admincp.php?frames=yes&action=medals' target='_blank'>勳章</a>】功能)更能激勵新手們把所有新手任務做完。對積分的設置也要拉開層次，不要所有任務的獎勵都獎勵相同的積份量值。站長也可以修改任務描述，用更友好，更具吸引力的語言來描述任務，提高用戶對完成任務的興趣。

		下面是一個示例：
		任務一的任務名可以寫「學習回帖」 ，獎勵10個金錢 。任務二的任務名寫成「開始我的第一次」，獎勵一種道具。 任務三的任務名寫成「與眾不同」，獎勵一枚勳章。

		<a href='./admincp.php?frames=yes&action=tasks' target='_blank'><b>現在就進入後台設置</b></a>",
"<h3>【主題推薦】（版塊 -> 編輯版塊）</h3>
		此功能通過自動或手動方式從論壇數據中提取一些主題作為系統推薦的主題，這些主題一般為論壇裡內容精彩，用戶參與度高的話題。

		推薦主題的數量應設置合理，太多則讓人眼花繚亂，太少則不美觀。

		數據緩存時間也要設置得當，該值設置太大則數據長時間不更新，造成吸引力下降，設置太小頻繁更新緩存又會增加服務器負擔。

		<a href='./admincp.php?frames=yes&action=forums' target='_blank'><b>現在就進入後台設置</b></a>",
"<h3>【主題熱度】（全局 -> 論壇功能）</h3>
		此功能會影響主題在主題列表顯示時標題後圖標的顯示，主題的熱度根據回複數、評價值等參量根據一定算法計算得到。當熱度值達到設定的顯示級別如50，100，200 時 ，在主題列表中主題的標題後會顯示對應級別的圖標，來表示該主題的熱門程度。

		站長應該根據站點當前運營情況來設定這些值，一般推薦的方案是保證主題列表中，熱門主題和普通主題的比例在 1:7 左右。

		<a href='./admincp.php?frames=yes&action=settings&operation=functions' target='_blank'><b>現在就進入後台設置</b></a>
","<h3>【主題評價】（全局 -> 論壇功能）</h3>
		此功能通過收集用戶對主題的評價，來計算評價圖標的顯示級別，當達到設定的級別閾值時，在主題列表中顯示主題標題後的對應級別的推薦圖標。

		<a href='./admincp.php?frames=yes&action=settings&operation=functions' target='_blank'><b>現在就進入後台設置</b></a>
","<h3>【論壇動態】（全局 -> 論壇動態設置）</h3>
		此功能通過指定條件產生論壇動態消息，促進會員之間互動的產生。各項目的值應該根據當前論壇運營狀況仔細斟酌而定。

		例如：論壇日發帖量在100左右的，設置【主題回複數達到一定值發送動態】時可以如下設置 「10, 30, 80」 ， 這樣當主題被回復了10次，30次，80次的時候都在論壇動態頁產生一個動態消息。日發帖量在1000左右的論壇，就可以設置「30，100，200」。

		總結起來論壇小，活躍用戶少， 日發帖量不大，那麼應該將各項目的閾值調低，這樣讓論壇動態更容易產生。相反，論壇大，活躍用戶多，日發帖量很大，那麼應該將各項目的閾值調高，避免論壇動態氾濫，影響用戶體驗。

		<a href='./admincp.php?frames=yes&action=settings&operation=dzfeed' target='_blank'><b>現在就進入後台設置</b></a>");


if(!function_exists('file_put_contents')) {
	define('FILE_APPEND', 'FILE_APPEND');
	if(!defined('LOCK_EX')) {
		define('LOCK_EX', 'LOCK_EX');
	}

	function file_put_contents($file, $data, $flags = '') {
		$contents = (is_array($data)) ? implode('', $data) : $data;

		$mode = ($flags == 'FILE_APPEND') ? 'ab+' : 'wb';

		if(($fp = @fopen($file, $mode)) === false) {
			return false;
		} else {
			$bytes = fwrite($fp, $contents);
			fclose($fp);
			return $bytes;
		}
	}
}

$lang = array(
	'error_message' => '錯誤信息',
	'message_return' => '返回',
	'old_step' => '上一步',
	'new_step' => '下一步',
	'uc_appname' => '論壇',
	'uc_appreg' => '註冊',
	'uc_appreg_succeed' => '到 UCenter 成功，',
	'uc_continue' => '點擊這裡繼續',
	'uc_setup' => '<font color="red">如果沒有安裝過，點擊這裡安裝 UCenter</font>',
	'uc_title_ucenter' => '請填寫 UCenter 的相關信息',
	'uc_url' => 'UCenter 的 URL',
	'uc_ip' => 'UCenter 的 IP',
	'uc_admin' => 'UCenter 的管理員帳號',
	'uc_adminpw' => 'UCenter 的管理員密碼',
	'uc_title_app' => '相關信息',
	'uc_app_name' => '的名稱',
	'uc_app_url' => '的 URL',
	'uc_app_ip' => '的 IP',
	'uc_app_ip_comment' => '當主機 DNS 有問題時需要設置，默認請保留為空',
	'uc_connent_invalid1' => '連接服務器',
	'uc_connent_invalid2' => ' 失敗，請返回檢查。',
	'error_message' => '提示信息',
	'error_return' => '返回',

	'tagtemplates_subject' => '標題',
	'tagtemplates_uid' => '用戶 ID',
	'tagtemplates_username' => '發帖者',
	'tagtemplates_dateline' => '日期',
	'tagtemplates_url' => '主題地址',
);

$msglang = array(
	'redirect_msg' => '瀏覽器會自動跳轉頁面，無需人工干預。除非當您的瀏覽器長時間沒有自動跳轉時，請點擊這裡',
	'uc_url_empty' => '您沒有填寫 UCenter 的 URL，請返回填寫。',
	'uc_url_invalid' => 'UCenter 的 URL 格式不合法，正常的格式為： http://www.domain.com ，請返回檢查。',
	'uc_ip_invalid' => '<font color="red">無法連接 UCenter 所在的 Web 服務器，請填寫 UCenter 服務器的IP，如果 UCenter 與論壇在同一台服務器，可以嘗試填寫：127.0.0.1。</font>',
	'uc_admin_invalid' => '<font color="red">登錄 UCenter 的管理員帳號密碼錯誤。</font>',
	'uc_data_invalid' => 'UCenter 獲取數據失敗，請返回檢查 UCenter URL、管理員帳號、密碼。 ',
);

require DISCUZ_ROOT.'./include/db_mysql.class.php';
@include DISCUZ_ROOT.'./config.inc.php';

$version['old'] = 'Discuz! 7.0 正式版';
$version['new'] = 'Discuz! 7.1';
$lock_file = DISCUZ_ROOT.'./forumdata/upgrade12.lock';

if(!$dbhost || !$dbname || !$dbuser) {
	instmsg('論壇數據庫的主機，數據庫名，用戶名為空。');
}

$db = new dbstuff();
$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect, true, $dbcharset);
function get_charset($tablename) {
	global $db;
	$tablestruct = $db->fetch_first("show create table $tablename");
	preg_match("/CHARSET=(\w+)/", $tablestruct['Create Table'], $m);
	return $m[1];
}

if($db->version() > '4.1.0') {
	$tablethreadcharset = get_charset($tablepre.'threads');
	$dbcharset = strtolower($dbcharset);
	$tablethreadcharset = strtolower($tablethreadcharset);
	if($dbcharset && $dbcharset !=  $tablethreadcharset) {
		instmsg("您的配置文件 (./config.inc.php) 中的字符集 ($dbcharset) 與表的字符集 ($tablethreadcharset) 不匹配。");
	}
}

$upgrade1 = <<<EOT

#主題關注;
DROP TABLE IF EXISTS cdb_favoritethreads;
CREATE TABLE cdb_favoritethreads (
	`tid` mediumint(8) NOT NULL DEFAULT '0',
	`uid` mediumint(8) NOT NULL DEFAULT '0',
	`dateline` int(10) NOT NULL DEFAULT '0',
	`newreplies` smallint(6) NOT NULL DEFAULT '0',
	PRIMARY KEY (tid, uid)
) TYPE=MYISAM;

#版塊關注;
DROP TABLE IF EXISTS cdb_favoriteforums;
CREATE TABLE cdb_favoriteforums (
	`fid` smallint(6) NOT NULL DEFAULT '0',
	`uid` mediumint(8) NOT NULL DEFAULT '0',
	`dateline` int(10) NOT NULL DEFAULT '0',
	`newthreads` mediumint(8) NOT NULL DEFAULT '0',
	PRIMARY KEY (fid, uid)
) TYPE=MYISAM;

#消息通知提示系統;
DROP TABLE IF EXISTS cdb_prompt;
CREATE TABLE cdb_prompt (
  `uid` MEDIUMINT(8) UNSIGNED NOT NULL,
  `typeid` SMALLINT(6) UNSIGNED NOT NULL,
  `number` SMALLINT(6) UNSIGNED NOT NULL,
  PRIMARY KEY (`uid`, `typeid`)
) TYPE=MyISAM;
DROP TABLE IF EXISTS cdb_prompttype;
CREATE TABLE cdb_prompttype (
  `id` SMALLINT(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `key` VARCHAR(255) NOT NULL DEFAULT '',
  `name` VARCHAR(255) NOT NULL DEFAULT '',
  `script` VARCHAR(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) TYPE=MyISAM;
DROP TABLE IF EXISTS cdb_promptmsgs;
CREATE TABLE cdb_promptmsgs (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `typeid` SMALLINT(6) UNSIGNED NOT NULL DEFAULT '0',
  `uid` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0',
  `extraid` INTEGER(10) UNSIGNED NOT NULL DEFAULT '0',
  `new` TINYINT(1) NOT NULL DEFAULT '0',
  `dateline` INTEGER(10) UNSIGNED NOT NULL DEFAULT '0',
  `message` TEXT NOT NULL,
  `actor` TEXT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`, `typeid`),
  KEY `new` (`new`),
  KEY `dateline` (`dateline`),
  KEY `extraid` (`extraid`)
) TYPE=MyISAM;

#dz內部feed;
DROP TABLE IF EXISTS cdb_feeds;
CREATE TABLE cdb_feeds (
  feed_id mediumint(8) unsigned NOT NULL auto_increment,
  type varchar(255) NOT NULL DEFAULT 'default',
  fid smallint(6) unsigned NOT NULL DEFAULT '0',
  typeid smallint(6) unsigned NOT NULL DEFAULT '0',
  sortid smallint(6) unsigned NOT NULL DEFAULT '0',
  appid varchar(30) NOT NULL DEFAULT '',
  uid mediumint(8) unsigned NOT NULL DEFAULT '0',
  username varchar(15) NOT NULL DEFAULT '',
  data text NOT NULL DEFAULT '',
  template text NOT NULL DEFAULT '',
  dateline int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (feed_id),
  KEY type(type),
  KEY dateline (dateline),
  KEY uid(uid),
  KEY appid(appid)
) TYPE=MyISAM;

#評價;
DROP TABLE IF EXISTS cdb_memberrecommend;
CREATE TABLE cdb_memberrecommend (
  `tid` mediumint(8) unsigned NOT NULL,
  `recommenduid` mediumint(8) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  KEY `tid` (`tid`),
  KEY `uid` (`recommenduid`)
) TYPE=MyISAM;

#擴展中心;
DROP TABLE IF EXISTS cdb_addons;
CREATE TABLE cdb_addons (
  `key` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `sitename` varchar(255) NOT NULL DEFAULT '',
  `siteurl` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`key`)
) TYPE=MyISAM;

EOT;

$upgradetable = array(

	#用戶組的每天最大附件數量限制
	array('usergroups', 'ADD', 'maxattachnum', "smallint( 6 ) NOT NULL DEFAULT '0'"),

	#詞語過濾增強
	array('words', 'ADD', 'extra', "varchar(255) NOT NULL DEFAULT ''"),

	#商品主題用積分購買
	array('trades', 'ADD', 'credit', "int(10) unsigned NOT NULL DEFAULT '0'"),
	array('trades', 'ADD', 'costcredit', "int(10) unsigned NOT NULL DEFAULT '0'"),
	array('trades', 'ADD', 'credittradesum', "int(10) unsigned NOT NULL DEFAULT '0'"),
	array('trades', 'INDEX', '', "ADD INDEX(`credittradesum`)"),
	array('tradelog', 'ADD', 'credit', "int(10) unsigned NOT NULL DEFAULT '0'"),
	array('tradelog', 'ADD', 'basecredit', "int(10) unsigned NOT NULL DEFAULT '0'"),

	#特殊主題插件
	array('forumfields', 'ADD', 'threadplugin', "text NOT NULL"),

	#是否新手任務  0 不是   1 針對新註冊用戶的任務   2 針對不熟悉新功能會員的新手任務
	array('tasks', 'ADD', 'newbietask', "TINYINT(1) NOT NULL DEFAULT '0' AFTER relatedtaskid"),

	#當前正在進行的新手任務
	array('members', 'ADD', 'newbietaskid', "smallint(6) unsigned NOT NULL DEFAULT '0'"),

	#任務顯示順序可以是負數
	array('tasks', 'CHANGE', 'displayorder', "`displayorder` SMALLINT(6) NOT NULL DEFAULT '0'"),
	array('taskvars', 'CHANGE', 'sort', "`sort` enum('apply','complete','setting') NOT NULL DEFAULT 'complete'"),

	#isimage可以是負數 通過附件上傳的圖片
	array('attachments', 'CHANGE', 'isimage', "`isimage` TINYINT( 1 ) NOT NULL DEFAULT '0'"),

	#插件版本
	array('plugins', 'ADD', 'version', "varchar(20) NOT NULL default ''"),

	#用戶主題數
	array('members', 'ADD', 'threads', "MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0' AFTER `posts`"),

	#主題推薦（暫定）
	array('forumrecommend', 'ADD', 'typeid', "SMALLINT(6) NOT NULL AFTER `tid`"),
	array('forumrecommend', 'ADD', 'position', "tinyint(1) NOT NULL DEFAULT '0'"),
	array('forumrecommend', 'ADD', 'highlight', "tinyint(1) NULL NOT NULL DEFAULT '0'"),
	array('forumrecommend', 'ADD', 'aid', "mediumint(8) unsigned NOT NULL DEFAULT '0'"),
	array('forumrecommend', 'ADD', 'filename', "CHAR(100) NOT NULL DEFAULT ''"),
	array('forumrecommend', 'INDEX', '', "ADD INDEX (`position`)"),
	array('threads', 'ADD', 'recommends', "SMALLINT(6) NOT NULL"),
	array('threads', 'ADD', 'recommend_add', "SMALLINT(6) NOT NULL"),
	array('threads', 'ADD', 'recommend_sub', "SMALLINT(6) NOT NULL"),
	array('threads', 'INDEX', '', "ADD INDEX (`recommends`)"),

	#用戶組發表URL控制
	array('usergroups', 'ADD', 'allowposturl', "TINYINT(1) NOT NULL DEFAULT '3'"),

	#用戶評價主題
	array('usergroups', 'ADD', 'allowrecommend', "TINYINT(1) unsigned NOT NULL DEFAULT '1'"),
	array('usergroups', 'DROP', 'allowavatar', ""),

	#刪除訂閱相關
	array('threads', 'DROP', 'subscribed', ""),

	#刪除video相關功能
	array('usergroups', 'DROP', 'allowpostvideo', ""),

	#道具功能改進
	array('magics', 'ADD', 'recommend', "TINYINT(1) NOT NULL AFTER `weight`"),

	#刪除內置的bbcodes
	array('bbcodes', 'DROP', 'type', ""),

	#帖子熱度
	array('threads', 'ADD', 'heats', "INT(10) unsigned NOT NULL DEFAULT '0'"),
	array('threads', 'INDEX', '', "ADD INDEX (`heats`)"),

	#去除 mythreads myposts
	array('threads', 'INDEX', '', "ADD INDEX (`authorid`)"),

	# 分離cdb_attachments.description
	array('attachments', 'DROP', 'description', ""),
	array('attachmentfields', 'INDEX', '', "ADD INDEX (`tid`)"),
	array('attachmentfields', 'INDEX', '', "ADD INDEX (`pid`)"),
	array('attachmentfields', 'INDEX', '', "ADD INDEX (`uid`)"),

	#數據調用擴展
	array('request', 'ADD', 'system', "tinyint(1) NOT NULL DEFAULT '0'"),
);

$upgrade3 = <<<EOT
#特殊主題插件;
REPLACE INTO cdb_settings (variable, value) VALUES ('allowthreadplugin', '');

#編輯器改進;
DELETE FROM cdb_bbcodes WHERE `id` = 13 ;
UPDATE cdb_bbcodes SET `tag` = 'p', `icon` = 'cmd_paragraph', `explanation` = '段落' WHERE `id` =5 ;

#新手任務列表;
UPDATE cdb_settings SET variable='newbietasks' WHERE variable='newbietask';

#新手任務更新時間;
REPLACE INTO cdb_settings (variable, value) VALUES ('newbietaskupdate', '');

#消息系統類型;
REPLACE INTO cdb_prompttype (`id`, `key`, `name`, `script`) VALUES (1,'pm','私人消息','pm.php?filter=newpm');
REPLACE INTO cdb_prompttype (`id`, `key`, `name`, `script`) VALUES (2,'announcepm','公共消息','pm.php?filter=announcepm');
REPLACE INTO cdb_prompttype (`id`, `key`, `name`, `script`) VALUES (3,'task','論壇任務','task.php?item=doing');
REPLACE INTO cdb_prompttype (`id`, `key`, `name`, `script`) VALUES (4,'systempm','系統消息','');
REPLACE INTO cdb_prompttype (`id`, `key`, `name`, `script`) VALUES (5,'friend','好友消息','');
REPLACE INTO cdb_prompttype (`id`, `key`, `name`, `script`) VALUES (6,'threads','帖子消息','');

#JS文件緩存;
REPLACE INTO cdb_settings (variable, value) VALUES ('jspath', 'forumdata/cache/');

#支付寶簽約用戶兼容;
REPLACE INTO cdb_settings (variable, value) VALUES ('ec_contract', '');

#財付通;
REPLACE INTO cdb_settings (`variable`, `value`) VALUES ('ec_tenpay_bargainor', '');
REPLACE INTO cdb_settings (`variable`, `value`) VALUES ('ec_tenpay_key', '');

#用戶推薦主題;
REPLACE INTO cdb_settings (`variable`, `value`) VALUES ('recommendthread', '');

#刪除Insenz相關功能;
DELETE FROM cdb_settings WHERE variable='insenz';
DROP TABLE IF EXISTS cdb_advcaches;
DROP TABLE IF EXISTS cdb_virtualforums;
DROP TABLE IF EXISTS cdb_campaigns;

#刪除訂閱相關功能
DELETE FROM cdb_settings WHERE variable='maxsubscriptions';
DROP TABLE IF EXISTS cdb_subscriptions;

#刪除video相關功能;
DELETE FROM cdb_settings WHERE variable='videoinfo';
DROP TABLE IF EXISTS cdb_videos;
DROP TABLE IF EXISTS cdb_videotags;

#刪除內置的bbcodes;
DELETE FROM cdb_bbcodes WHERE tag='flash';

#浮動窗口開關改進;
REPLACE INTO cdb_settings (variable, value) VALUES ('allowfloatwin', 'a:17:{i:0;s:5:"login";i:1;s:8:"register";i:2;s:6:"sendpm";i:3;s:9:"newthread";i:4;s:5:"reply";i:5;s:9:"attachpay";i:6;s:3:"pay";i:7;s:11:"viewratings";i:8;s:11:"viewwarning";i:9;s:13:"viewthreadmod";i:10;s:8:"viewvote";i:11;s:10:"tradeorder";i:12;s:8:"activity";i:13;s:6:"debate";i:14;s:3:"nav";i:15;s:10:"usergroups";i:16;s:4:"task";}');

#首頁顯示風格;
REPLACE INTO cdb_settings (variable, value) VALUES ('indextype', 'classics');

#帖子熱度;
REPLACE INTO cdb_settings (variable, value) VALUES ('heatthread', 'a:3:{s:5:"reply";i:5;s:9:"recommend";i:3;s:8:"hottopic";s:10:"50,100,200";}');

#去除 mythreads myposts 留到下一個版本去做;
DELETE FROM cdb_settings WHERE variable='myrecorddays';

#增加發送論壇內部feed的設置;
REPLACE INTO cdb_settings (variable, value) VALUES ('dzfeed_limit', 'a:9:{s:14:"thread_replies";a:4:{i:0;s:3:"100";i:1;s:4:"1000";i:2;s:4:"2000";i:3;s:5:"10000";}s:12:"thread_views";a:3:{i:0;s:3:"500";i:1;s:4:"5000";i:2;s:5:"10000";}s:11:"thread_rate";a:3:{i:0;s:2:"50";i:1;s:3:"200";i:2;s:3:"500";}s:9:"post_rate";a:3:{i:0;s:2:"20";i:1;s:3:"100";i:2;s:3:"300";}s:14:"user_usergroup";a:4:{i:0;s:2:"12";i:1;s:2:"13";i:2;s:2:"14";i:3;s:2:"15";}s:11:"user_credit";a:3:{i:0;s:4:"1000";i:1;s:5:"10000";i:2;s:6:"100000";}s:12:"user_threads";a:5:{i:0;s:3:"100";i:1;s:3:"500";i:2;s:4:"1000";i:3;s:4:"5000";i:4;s:5:"10000";}s:10:"user_posts";a:4:{i:0;s:3:"500";i:1;s:4:"1000";i:2;s:4:"5000";i:3;s:5:"10000";}s:11:"user_digest";a:4:{i:0;s:2:"50";i:1;s:3:"100";i:2;s:3:"500";i:3;s:4:"1000";}}');

#首頁熱點;
REPLACE INTO cdb_settings (variable, value) VALUES ('indexhot', '');

#浮窗改進;
DELETE FROM cdb_settings WHERE variable='allowfloatwin';
REPLACE INTO cdb_settings (variable, value) VALUES ('disallowfloat', '');

#擴展中心默認的資源提供商;
TRUNCATE TABLE cdb_addons;
INSERT INTO cdb_addons (`key`, `title`, `sitename`, `siteurl`, `description`, `contact`, `logo`, `system`) VALUES ('25z5wh0o00', 'Comsenz', 'Comsenz官方網站', 'http://www.comsenz.com', 'Comsenz官方網站推薦的論壇模板與插件', 'ts@comsenz.com', 'http://www.comsenz.com/addon/logo.gif', 1);
INSERT INTO cdb_addons (`key`, `title`, `sitename`, `siteurl`, `description`, `contact`, `logo`, `system`) VALUES ('R051uc9D1i', 'DPS', 'DPS 插件中心', 'http://bbs.7dps.com', '提供 Discuz!7.1 新核(NC)插件，享受一鍵安裝/升級/卸載帶來的快感，還提供少量風格。', 'http://bbs.7dps.com/thread-1646-1-1.html', 'http://api.7dps.com/addons/logo.gif', 0);

#刪除回復通知的計劃任務;
DELETE FROM cdb_crons WHERE filename='notify_daily.inc.php';

#發帖域名白名單;
REPLACE INTO cdb_settings (variable, value) VALUES ('domainwhitelist', '');

EOT;

$newfunc = getgpc('newfunc');
$newfunc = empty($newfunc) ? 0 : $newfunc;
$step = getgpc('step');
$step = empty($step) ? 1 : $step;
instheader();
if(!isset($cookiepre)) {
	instmsg('config_nonexistence');
} elseif(!ini_get('short_open_tag')) {
	instmsg('short_open_tag_invalid');
}

if(file_exists($lock_file)) {
	instmsg('升級被鎖定，應該是已經升級過了，如果已經恢複數據請手動刪除<br />'.str_replace(DISCUZ_ROOT, '', $lock_file).'<br />之後再來刷新頁面。');
}

if($step == 1) {

	$msg = '<div class="btnbox marginbot">
			<form method="get">
			<input type="hidden" name="step" value="check" />
				<input type="submit" style="padding: 2px;" value="開始升級" name="submit" />
			</form>
		</div>';

echo <<<EOT
		<div class="licenseblock">
		<div class="license">
	<h1>本升級程序只能從 $version[old] 升級到 $version[new]</h1>
	升級之前<b>務必備份數據庫資料</b>，否則升級失敗無法恢復<br /><br />
		正確的升級方法為:
	<ol>
		<li>關閉原有論壇，上傳 $version[new] 的全部文件和目錄（除install目錄和config.inc.php文件），覆蓋服務器上的 $version[old]
		<li>上傳升級程序到論壇目錄中。
		<li>運行本程序，直到出現升級完成的提示
		<li>如果中途失敗，請使用Discuz!工具箱（./utilities/tools.php）裡面的數據恢復工具恢復備份，去除錯誤後重新運行本程序
	</ol>
</div></div>
	$msg

EOT;

	instfooter();

} elseif($step == 'check') {

	@touch(DISCUZ_ROOT.'./forumdata/install.lock');
	@unlink(DISCUZ_ROOT.'./install/index.php');

//	echo "<h4>Discuz!程序版本檢測</h4>";

	if(!defined('UC_CONNECT')) {
		instmsg('您的config.inc.php文件被覆蓋，請恢復備份好的config.inc.php文件，之後再嘗試升級。');
	}

	include_once DISCUZ_ROOT.'./discuz_version.php';
	if(!defined('DISCUZ_VERSION') || DISCUZ_VERSION != '7.1') {
		instmsg('您還沒有上傳(或者上傳不完全)最新的Discuz!7.1的程序文件，請先上傳之後再嘗試升級。');
	}

	instmsg("Discuz!程序版本檢測通過，自動執行下一步。", '?step=2');

} elseif($step == 2) {

//	echo "<h4>新增數據表</h4>";

	dir_clear('./forumdata/cache');
	dir_clear('./forumdata/templates');

	runquery($upgrade1);

	instmsg("新增數據表處理完畢。", '?step=3');
	instfooter();

} elseif($step == 3) {

	//echo "<h4>轉移附件描述</h4>";

	upg_attach_description();

	$recommendthread = array (
		'status' => '1',
		'addtext' => '支持',
		'subtracttext' => '反對',
		'defaultshow' => '0',
		'daycount' => '0',
		'ownthread' => '1',
		'iconlevels' => '10,50,100',
	);
	$db->query("REPLACE INTO {$tablepre}settings (`variable`, `value`) VALUES ('recommendthread', '".addslashes(serialize($recommendthread))."')");

	$db->query("DELETE FROM {$tablepre}bbcodes WHERE type='1'", "SILENT");

	instmsg("轉移附件描述成功。", '?step=4');

	instfooter();

} elseif($step == 4) {

	$start = isset($_GET['start']) ? intval($_GET['start']) : 0;

	//echo "<h4></h4>";

	if(isset($upgradetable[$start]) && $upgradetable[$start][0]) {

		//echo "升級數據表 [ $start ] {$tablepre}{$upgradetable[$start][0]} {$upgradetable[$start][3]}:";
		$successed = upgradetable($upgradetable[$start]);

		if($successed === TRUE) {
			$start ++;
			if(isset($upgradetable[$start]) && $upgradetable[$start][0]) {
				instmsg("升級數據表 [ $start ] {$tablepre}{$upgradetable[$start][0]} {$upgradetable[$start][3]}:<span class='w'>OK</span>", "?step=4&start=$start");
			}
		} elseif($successed === FALSE) {
			instmsg("調整數據表結構失敗：{$tablepre}{$upgradetable[$start][0]} {$upgradetable[$start][3]}");
		} elseif($successed == 'TABLE NOT EXISTS') {
			instmsg("<span class=red>數據表：{$tablepre}{$upgradetable[$start][0]}不存在，升級無法繼續，請確認您的論壇版本是否正確!</span>");
		}
	}

	instmsg("論壇數據表結構調整完畢。", "?step=5");
	instfooter();

} elseif($step == 5) {

//	echo "<h4>更新部分數據</h4>";
	runquery($upgrade3);
	upg_newbietask();

	@include_once DISCUZ_ROOT.'./forumdata/cache/cache_settings.php';
	$timestamp = time();
	$data = array('title' => array(
		'bbname' => $_DCACHE['settings']['bbname'],
		'time' => gmdate($_DCACHE['settings']['dateformat'], $timestamp + $_DCACHE['settings']['timeoffset'] * 3600),
		'version' => $version['new'],
		)
	);
	$template = array('title' => '{bbname} 於 {time} 升級到 {version}');
	$db->query("INSERT INTO {$tablepre}feeds (type, fid, typeid, sortid, appid, uid, username, data, template, dateline)
		VALUES ('feed_announce', '0', '0', '0', '0', '0', '', '".addslashes(serialize($data))."', '".addslashes(serialize($template))."', '$timestamp')");

	instmsg("部分數據更新完畢。", "?step=6");
	instfooter();
} elseif($step == 6) {
	if(getgpc('addfounder_contact','P')) {
		$email = strip_tags(getgpc('email', 'P'));
		$msn = strip_tags(getgpc('msn', 'P'));
		$qq = strip_tags(getgpc('qq', 'P'));
		if(!preg_match("/^[\d]+$/", $qq)) $qq = '';
		if(strlen($email) < 6 || !preg_match("/^[\w\-\.]+@[\w\-\.]+(\.\w+)+$/", $email)) $email = '';
		if(strlen($msn) < 6 || !preg_match("/^[\w\-\.]+@[\w\-\.]+(\.\w+)+$/", $msn)) $msn = '';

		$contact = serialize(array('qq' => $qq, 'msn' => $msn, 'email' => $email));
		$db->query("REPLACE {$tablepre}settings (variable, value) VALUES ('founder_contact', '$contact')");
		instmsg("進入新功能提示。","?step=7");
	} else {
		$contact = array();
		$contact = unserialize($db->result_first("SELECT value FROM {$tablepre}settings WHERE variable='founder_contact'"));
		$founder_contact = str_replace(array("\n","\t"), array('<br>','&nbsp;&nbsp;&nbsp;&nbsp;'), $founder_contact);
echo <<<EOD
 		<div class="licenseblock">
		<div class="license">
	<h1>關於《康盛改善計劃》的說明</h1>
	<ol>
		<li>為了不斷改進產品質量，改善用戶體驗，Discuz!7.1版內置了統計系統。</li>
		<li>該統計系統有利於我們分析用戶在論壇的操作習慣，進而幫助我們在未來的版本中對產品進行改進，設計出更符合用戶需求的新功能。</li>
		<li>該統計系統不會收集站點敏感信息，不收集用戶資料，不存在安全風險，並且經過實際測試不會影響論壇的運行效率。</li>
		<li>您安裝使用本版本表示您同意加入《康盛改善計劃》，Discuz!運營部門會通過對站點數據的分析為您提供運營指導建議，我們將提示您如何根據站點運行情況開啟論壇功能，如何進行合理的功能配置，以及提供其他的一些運營經驗等。</li>
		<li>為了方便我們和您溝通運營策略，請您留下常用的網絡聯繫方式。</li>
	</ol>
</div></div>
<div class="desc">
	<h4>填寫聯繫方式</h4>
	<p>正確的聯繫方式有助於我們給你提供最新的信息和安全方面的報告</p>
</div>

<form action="$url_forward" method="post" id="postform">
	<table class="tb2">
		<tr>
			<th class="tbopt">QQ：</th>
			<td><input type="text" value="$contact[qq]" name="qq" size="35" class="txt" /></td>
			<td>請正確填寫QQ號碼</td>
		</tr>
		<tr>

			<th class="tbopt">MSN：</th>
			<td><input type="text" value="$contact[msn]" name="msn" size="35" class="txt" /></td>
			<td>MSN賬號</td>
		</tr>
		<tr>
			<th class="tbopt">E-mail：</th>
			<td><input type="text" value="$contact[email]" name="email" size="35" class="txt" /></td>

			<td>郵箱地址</td>
		</tr>
		<tr>
			<th class="tbopt"></th>
			<td><input type="submit" class="btn" name="addfounder_contact" value="下一步" /> &nbsp; &nbsp;<a href='?step=7'>跳過</a>
			<td></td>
		</tr>
	</table>
</form>

EOD;

	}

} elseif($step == 7) {
	if($newfunction_set[$newfunc]) {
		$newfunction_set[$newfunc] = str_replace(array("\n","\t"), array('<br>','&nbsp;&nbsp;&nbsp;&nbsp;'), $newfunction_set[$newfunc]);
$msg = $newfunction_set[$newfunc];
$nextfunc = $newfunc + 1;
$newfunction_set_count = count($newfunction_set);
echo <<<EOD
	<div class="licenseblock">
		<div class="license">
			<h1>重要新功能設置</h1>
			$msg
		</div>
	</div>
	<div class="btnbox marginbot">
		<form method="get">
			<input type="hidden" name="step" value="7" />
			<input type="hidden" name="newfunc" value="$nextfunc" />
			共【{$newfunction_set_count}】個重要新功能，第【{$nextfunc}】個。
			<input type="submit" style="padding: 2px;" value="繼續下一個功能" name="submit" />&nbsp;<a href='?step=8'>跳過</a>
		</form>
	</div>
EOD;
	} else {
		instmsg("新功能查看完畢。", "?step=8");
	}

	instfooter();
} else {

	$settings = array();
	$query = $db->query("SELECT value, variable FROM {$tablepre}settings WHERE variable IN('statid', 'statkey', 'bbname')");
	while($row = $db->fetch_array($query)) {
		$settings[$row['variable']] = $row['value'];
	}
	getstatinfo($settings['statid'], $settings['statkey']);

	dir_clear('./forumdata/cache');
	dir_clear('./forumdata/templates');
	dir_clear('./uc_client/data/cache');
	@touch($lock_file);
	if(!@unlink('upgrade12.php')) {
		$msg = '<li><b>必刪除本程序</b></li>';
	} else {
		$msg = '';
	}
echo <<<EOT
		<div class="licenseblock">
		<div class="license">
	<h1>恭喜您論壇數據升級成功</h1>
	<h3>接下來請您：</h3>
	<ol>
		$msg
		<li>使用管理員身份登錄論壇，進入後台，更新緩存</li>
		<li>進行論壇註冊、登錄、發貼等常規測試，看看運行是否正常</li>
	</ol>
</div></div>

EOT;
echo '<div class="btnbox marginbot">
			<form method="get" action="index.php">
				<b>感謝您選用我們的產品！</b><input type="submit" style="padding: 2px;" value="您現在可以訪問論壇，查看升級情況" name="submit" />
			</form>
		</div><iframe width="0" height="0" src="index.php" style="display:none;"></iframe>';
		
	instfooter();

}

function send_sql_to_uc($sql) {
	$url = UC_API.'/accept_sql.php?appid='.UC_APPID.'&uckey='.UC_KEY.'&sql='.urlencode($sql);
	return file_get_contents($url);
}

function insertconfig($s, $find, $replace) {
	if(preg_match($find, $s)) {
		$s = preg_replace($find, $replace, $s);
	} else {
		// 插入到最後一行
		$s .= "\r\n".$replace;
	}
	return $s;
}

function instheader() {
	global $charset, $version;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Discuz! 升級嚮導</title>
<style type="text/css">
/*
(C) 2001-2009 Comsenz Inc.
*/

/* common */
*{ word-wrap:break-word; }
body{ padding:5px 0; background:#FFF; text-align:center; }
body, td, input, textarea, select, button{ color:#666; font:12px Verdana, Tahoma, Arial, sans-serif; }
ul, dl, dd, p, h1, h2, h3, h4, h5, h6, form, fieldset { margin:0; padding:0; }
h1, h2, h3, h4, h5, h6{ font-size:12px; }
a{ color:#2366A8; text-decoration:none; }
	a:hover { text-decoration:underline; }
	a img{ border:none; }
em, cite, strong, th{ font-style:normal; font-weight:normal; }
table{ border-collapse:collapse; }

/* box */
.container{ overflow:hidden; margin:0 auto; width:700px; height:auto !important;text-align:left; border:1px solid #B5CFD9; }
.header{ height:71px; background:url(images/upgrade/bg_repx.gif) repeat-x; }
	.header h1{ text-indent:-9999px; width:270px; height:48px; background:url(images/upgrade/bg_repno.gif) no-repeat 26px 22px; }
	.header span { float: right; padding-right: 10px; }
.main{ padding:20px 20px 0; background:#F7FBFE url(images/upgrade/bg_repx.gif) repeat-x 0 -194px; }
	.main h3{ margin:10px auto; width:75%; color:#6CA1B4; font-weight:700; }
.desc{ margin:0 auto; width:537px; line-height:180%; clear:both; }
	.desc ul{ margin-left:20px; }
.desc1{ margin:10px 0; width:100%; }
	.desc1 ul{ margin-left:25px; }
	.desc1 li{ margin:3px 0; }
.tb2{ margin:15px 0 15px 67px; }
	.tb2 th, .tb2 td{ padding:3px 5px; }
	.tbopt{ width:120px; text-align: left; }
.btnbox{ text-align:center; }
	.btnbox input{ margin:0 2px; }
	.btnbox textarea{ margin-bottom:10px; height:150px; }
.btn{ margin-top:10px; }
.footer{ line-height:40px; text-align:center; background:url(images/upgrade/bg_footer.gif) repeat-x; font-size:11px; }

/* form */
.txt{ width:200px; }

/* file status */
.w{ margin-left: 8px; padding-left: 16px; background:url(images/upgrade/bg_repno.gif) no-repeat 0 -149px;  }
.nw{ margin-left: 8px; padding-left: 16px; background:url(images/upgrade/bg_repno.gif) no-repeat 0 -198px; }

/* space */
.marginbot{ margin-bottom:20px; }
.margintop{ margin-top:20px; }
.red{ color:red; }

.licenseblock{ margin-bottom:15px; padding:8px; border:1px solid #EEE; background:#FFF; overflow:scroll; overflow-x:hidden; }
.license{}
	.license h1{ padding-bottom:10px; font-size:14px; text-align:center; }
	.license h3{ margin:0; color:#666; }
	.license p{ line-height:150%; margin:10px 0; text-indent:25px; }
	.license li{ line-height:150%; margin:5px 0; }
.title{ margin:5px 0 -15px 58px; }
.showmessage { margin: 0 0 20px; line-height: 160%; }
	.showmessage h2 { margin-bottom: 10px;font-size: 14px; }
	.showmessage .btnbox { margin-top: 20px;}
</style>
<meta name="copyright" content="Comsenz Inc." />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<script type="text/javascript">
function redirect(url) {
	window.location=url;
}
function $(id) {
	return document.getElementById(id);
}
</script>
</head>
<div class="container">
	<div class="header">
		<h1>Discuz! 升級嚮導</h1>
		<span>從 Discuz! 7.0 升級到 7.1</span>
	</div>
	<div class="main">

<?php
}

function instfooter() {
	global $version;
?>
		<div class="footer">&copy;2001 - 2009 <a href="http://www.comsenz.com/">Comsenz</a> Inc.</div>
	</div>
</div>
</body>
</html>
<?php
}

function instmsg($message, $url_forward = '', $postdata = '') {
	global $lang, $msglang;
	$message = $msglang[$message] ? $msglang[$message] : $message;
	if($url_forward) {
		$message .= "<p><a href=\"$url_forward\">$msglang[redirect_msg]</a></p>";
		$message .= "<script>setTimeout(\"redirect('$url_forward');\", 1250);</script>";
	} elseif(strpos($message, $lang['return'])) {
		$message .= "<p><a href=\"javascript:history.go(-1);\" class=\"mediumtxt\">$lang[message_return]</a></p>";
	}

echo <<<EOD
	<div class="showmessage">
	<h2>{$lang[error_message]}</h2>
	<p>$message</p>
	<!--<div class="btnbox"><input type="button" class="btn" value="按鈕文字" /></div>-->
	</div>
EOD;
		
	instfooter();
	exit;
}

function getgpc($k, $var='G') {
	switch($var) {
		case 'G': $var = &$_GET; break;
		case 'P': $var = &$_POST; break;
		case 'C': $var = &$_COOKIE; break;
		case 'R': $var = &$_REQUEST; break;
	}
	return isset($var[$k]) ? $var[$k] : NULL;
}

function dir_clear($dir) {
	if($directory = dir($dir)) {
		while($entry = $directory->read()) {
			$filename = $dir.'/'.$entry;
			if(is_file($filename)) {
				@unlink($filename);
			}
		}
		@touch($dir.'/index.htm');
		$directory->close();
	}
}

function createtable($sql, $dbcharset) {
	$type = strtoupper(preg_replace("/^\s*CREATE TABLE\s+.+\s+\(.+?\).*(ENGINE|TYPE)\s*=\s*([a-z]+?).*$/isU", "\\2", $sql));
	$type = in_array($type, array('MYISAM', 'HEAP')) ? $type : 'MYISAM';
	return preg_replace("/^\s*(CREATE TABLE\s+.+\s+\(.+?\)).*$/isU", "\\1", $sql).
		(mysql_get_server_info() > '4.1' ? " ENGINE=$type DEFAULT CHARSET=$dbcharset" : " TYPE=$type");
}

function runquery($query) {
	global $db, $tablepre, $dbcharset;

	$query = str_replace("\r", "\n", str_replace(' cdb_', ' '.$tablepre, $query));
	$expquery = explode(";\n", $query);
	foreach($expquery as $sql) {
		$sql = trim($sql);
		if($sql == '' || $sql[0] == '#') continue;

		if(strtoupper(substr($sql, 0, 12)) == 'CREATE TABLE') {
			$db->query(createtable($sql, $dbcharset));
		} else {
			$db->query($sql);
		}
	}
}

function upgradetable($updatesql) {
	global $db, $tablepre, $dbcharset;

	$successed = TRUE;

	if(is_array($updatesql) && !empty($updatesql[0])) {

		list($table, $action, $field, $sql) = $updatesql;

		if(empty($field) && !empty($sql)) {

			$query = "ALTER TABLE {$tablepre}{$table} ";
			if($action == 'INDEX') {
				$successed = $db->query("$query $sql", "SILENT");
			} elseif ($action == 'UPDATE') {
				$successed = $db->query("UPDATE {$tablepre}{$table} SET $sql", 'SILENT');
			}

		} elseif($tableinfo = loadtable($table)) {

			$fieldexist = isset($tableinfo[$field]) ? 1 : 0;

			$query = "ALTER TABLE {$tablepre}{$table} ";

			if($action == 'MODIFY') {

				$query .= $fieldexist ? "MODIFY $field $sql" : "ADD $field $sql";
				$successed = $db->query($query, 'SILENT');

			} elseif($action == 'CHANGE') {

				$field2 = trim(substr($sql, 0, strpos($sql, ' ')));
				$field2exist = isset($tableinfo[$field2]);

				if($fieldexist && ($field == $field2 || !$field2exist)) {
					$query .= "CHANGE $field $sql";
				} elseif($fieldexist && $field2exist) {
					$db->query("ALTER TABLE {$tablepre}{$table} DROP $field2", 'SILENT');
					$query .= "CHANGE $field $sql";
				} elseif(!$fieldexist && $fieldexist2) {
					$db->query("ALTER TABLE {$tablepre}{$table} DROP $field2", 'SILENT');
					$query .= "ADD $sql";
				} elseif(!$fieldexist && !$field2exist) {
					$query .= "ADD $sql";
				}
				$successed = $db->query($query);

			} elseif($action == 'ADD') {

				$query .= $fieldexist ? "CHANGE $field $field $sql" :  "ADD $field $sql";
				$successed = $db->query($query);

			} elseif($action == 'DROP') {
				if($fieldexist) {
					$successed = $db->query("$query DROP $field", "SILENT");
				}
				$successed = TRUE;
			}

		} else {

			$successed = 'TABLE NOT EXISTS';

		}
	}
	return $successed;
}

function loadtable($table, $force = 0) {
	global $db, $tablepre, $dbcharset;
	static $tables = array();

	if(!isset($tables[$table]) || $force) {
		if($db->version() > '4.1') {
			$query = $db->query("SHOW FULL COLUMNS FROM {$tablepre}$table", 'SILENT');
		} else {
			$query = $db->query("SHOW COLUMNS FROM {$tablepre}$table", 'SILENT');
		}
		while($field = @$db->fetch_array($query)) {
			$tables[$table][$field['Field']] = $field;
		}
	}
	return $tables[$table];
}

function daddslashes($string, $force = 0) {
	!defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());
	if(!MAGIC_QUOTES_GPC || $force) {
		if(is_array($string)) {
			foreach($string as $key => $val) {
				$string[$key] = daddslashes($val, $force);
			}
		} else {
			$string = addslashes($string);
		}
	}
	return $string;
}

function get_uc_root() {
	$uc_root = '';
	$uc = parse_url(UC_API);
	if($uc['host'] == $_SERVER['HTTP_HOST']) {
		$php_self_len = strlen($_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME']);
		$uc_root = substr(__FILE__, 0, -$php_self_len).$uc['path'];
	}
	return $uc_root;
}

function random($length, $numeric = 0) {
	PHP_VERSION < '4.2.0' && mt_srand((double)microtime() * 1000000);
	if($numeric) {
		$hash = sprintf('%0'.$length.'d', mt_rand(0, pow(10, $length) - 1));
	} else {
		$hash = '';
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
		$max = strlen($chars) - 1;
		for($i = 0; $i < $length; $i++) {
			$hash .= $chars[mt_rand(0, $max)];
		}
	}
	return $hash;
}

function upg_attach_description() {
	global $db, $tablepre;
	if($db->fetch_first("SHOW TABLE STATUS LIKE '{$tablepre}attachmentfields'")) {
		return;
	}
$create_table_sql = "
CREATE TABLE cdb_attachmentfields (
  aid mediumint(8) UNSIGNED NOT NULL ,
  tid mediumint(8) UNSIGNED NOT NULL DEFAULT '0' ,
  pid int(10) UNSIGNED NOT NULL DEFAULT '0' ,
  uid mediumint(8) UNSIGNED NOT NULL DEFAULT '0' ,
  description varchar(255) NOT NULL ,
  PRIMARY KEY (`aid`),
  KEY tid (tid),
  KEY pid (pid,aid),
  KEY uid (uid)
) TYPE=MyISAM;
";
	runquery($create_table_sql);
	$db->query("INSERT INTO {$tablepre}attachmentfields (`aid`, `tid`, `pid`, `uid`, `description`) SELECT `aid`, `tid`, `pid`, `uid`, `description` FROM {$tablepre}attachments WHERE `description`<>''");
}

function getstatinfo($siteid = 0, $key = '') {
	global $db, $tablepre, $dbcharset, $settings;
	if($siteid && $key) {
		return;
	} else {
		$siteid = $key = '';
	}
	$version = '7.1';
	$onlineip = '';
	if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$onlineip = getenv('HTTP_CLIENT_IP');
	} elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$onlineip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$onlineip = getenv('REMOTE_ADDR');
	} elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$onlineip = $_SERVER['REMOTE_ADDR'];
	}
	$members = $db->result_first("SELECT COUNT(*) FROM {$tablepre}members");
	$funcurl = 'http://stat.discuz.com/stat_ins.php';
	$bbname = $settings['bbname'];
	$PHP_SELF = htmlspecialchars($_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME']);
	$url = htmlspecialchars('http://'.$_SERVER['HTTP_HOST'].preg_replace("/\/+(api|archiver|wap)?\/*$/i", '', substr($PHP_SELF, 0, strrpos($PHP_SELF, '/'))));
	$posts = $db->result($db->query("SELECT count(*) FROM {$tablepre}posts"), 0);
	$domain = $_SERVER['HTTP_HOST'];
	$hash = $bbname.$url.$mark.$version.$posts;
	$threads = $db->result($db->query("SELECT count(*) FROM {$tablepre}threads"), 0);
	$hash = md5($hash.$members.$threads.$email.$siteid.md5($key).'install');
	$q = "bbname=$bbname&url=$url&domain=$domain&mark=$mark&version=$version&posts=$posts&members=$members&threads=$threads&email=$email&siteid=$siteid&key=".md5($key)."&ip=$onlineip&time=".time()."&hash=$hash";
	$q=rawurlencode(base64_encode($q));
	$siteinfo = dfopen($funcurl."?action=install&q=$q");
	if(empty($siteinfo)) {
		$siteinfo = dfopen($funcurl."?action=install&q=$q");
	}
	if($siteinfo && preg_match("/^[a-zA-Z0-9_]+,[A-Z]+$/i", $siteinfo)) {
		$siteinfo = explode(',', $siteinfo);
		$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('statid', '$siteinfo[0]')");
		$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('statkey', '$siteinfo[1]')");
	}
}

function upg_newbietask() {
	global $db, $tablepre;

	$newbietask = array(
		1 => array(
			'name' => '回帖是一種美德',
			'task' => "1, 0, '回帖是一種美德', '學習回帖，看帖回帖是一種美德，BS看帖不回帖的', '', 0, 0, 0, 'all', 'newbie_post_reply', 0, 0, 0, 'credit', '2', 10, -1, ''",
			'vars' => array(
				"'complete', '回復指定主題', '".addslashes('設置會員只有回復該主題才能完成任務，請填寫主題的 tid(比如一個主題的地址是 http://localhost/viewthread.php?tid=8 那麼該主題的 tid 就是 8)，留空為不限制')."', 'threadid', 'text', '0', ''",
				"'setting', '', '', 'entrance', 'text', 'viewthread', ''"
			)
		),
		2 => array(
			'name' => '我的第一次',
			'task' => "1, 0, '我的第一次', '學會發主題帖，成為社區的焦點', '', 0, 0, 0, 'all', 'newbie_post_newthread', 0, 0, 0, 'credit', '2', 10, -1, ''",
			'vars' => array(
				"'complete', '在指定版塊發表新主題', '".addslashes('設置會員必須在某個版塊發表至少一篇新主題才能完成任務')."', 'forumid', 'text', '', ''",
	
				"'setting', '', '', 'entrance', 'text', 'forumdisplay', ''"
			)
		),
		3 => array(
			'name' => '與眾不同',
			'task' => "1, 0, '與眾不同', '修改個人資料，讓你和別人與眾不同', '', 0, 0, 0, 'all', 'newbie_modifyprofile', 0, 0, 0, 'credit', '2', 10, -1, ''",
			'vars' => array(
				"'complete', '完善個人資料', '".addslashes('申請任務後只要把自己的個人資料填寫完整即可完成任務')."', '', '', '', ''",
				"'setting', '', '', 'entrance', 'text', 'memcp', ''"
			)
		),
		4 => array(
			'name' => '我型我秀',
			'task' => "1, 0, '我型我秀', '上傳頭像，讓大家認識一個全新的你', '', 0, 0, 0, 'all', 'newbie_uploadavatar', 0, 0, 0, 'credit', '2', 10, -1, ''",
			'vars' => array(
				"'complete', '上傳頭像', '".addslashes('申請任務後只要成功上傳頭像即可完成任務')."', '', '', '', ''",
				"'setting', '', '', 'entrance', 'text', 'memcp', ''"
			)
		),
		5 => array(
			'name' => '聯絡感情',
			'task' => "1, 0, '聯絡感情', '給其他用戶發個發短消息，大家聯絡一下感情', '', 0, 0, 0, 'all', 'newbie_sendpm', 0, 0, 0, 'credit', '2', 10, -1, ''",
			'vars' => array(
				"'complete', '給指定會員發送短消息', '".addslashes('只有給該會員成功發送短消息才能完成任務，請填寫該會員的用戶名')."', 'authorid', 'text', '', ''",
				"'setting', '', '', 'entrance', 'text', 'space', ''"
			)
		),
		6 => array(
			'name' => '一個好漢三個幫',
			'task' => "1, 0, '一個好漢三個幫', '出來混的，沒幾個好友怎麼行，加個好友吧', '', 0, 0, 0, 'all', 'newbie_addbuddy', 0, 0, 0, 'credit', '2', 10, -1, ''",
			'vars' => array(
				"'complete', '將指定會員加為好友', '".addslashes('只有將該會員加為好友才能完成任務，請填寫該會員的用戶名')."', 'authorid', 'text', '', ''",
				"'setting', '', '', 'entrance', 'text', 'space', ''"
			)
		),
		7 => array(
			'name' => '信息時代',
			'task' => "1, 0, '信息時代', '信息時代最缺的什麼？搜索', '', 0, 0, 0, 'all', 'newbie_search', 0, 0, 0, 'credit', '2', 10, -1, ''",
			'vars' => array(
				"'complete', '學會搜索', '".addslashes('申請任務後只要成功使用論壇搜索功能即可完成任務')."', '', '', '', ''",
				"'setting', '', '', 'entrance', 'text', 'search', ''"
			)
		)
	);
	if($db->result($db->query("SELECT count(*) FROM `{$tablepre}tasks` WHERE newbietask=1"), 0)) {
		return;
	}
	foreach($newbietask as $k => $sqlarray) {
		$db->query("INSERT INTO `{$tablepre}tasks` (`newbietask`, `available`, `name`, `description`, `icon`, `applicants`, `achievers`, `tasklimits`, `applyperm`, `scriptname`, `starttime`, `endtime`, `period`, `reward`, `prize`, `bonus`, `displayorder`, `version`) VALUES ($sqlarray[task]);");
		$currentid = $db->insert_id();
		foreach($sqlarray['vars'] as $taskvars) {
			$db->query("INSERT INTO `{$tablepre}taskvars` (`taskid`, `sort`, `name`, `description`, `variable`, `type`, `value`, `extra`) VALUES ($currentid, $taskvars);");
		}
	}
}

function dfopen($url, $limit = 0, $post = '', $cookie = '', $bysocket = FALSE, $ip = '', $timeout = 15, $block = TRUE) {
	$return = '';
	$matches = parse_url($url);
	$host = $matches['host'];
	$path = $matches['path'] ? $matches['path'].($matches['query'] ? '?'.$matches['query'] : '') : '/';
	$port = !empty($matches['port']) ? $matches['port'] : 80;

	if($post) {
		$out = "POST $path HTTP/1.0\r\n";
		$out .= "Accept: */*\r\n";
		//$out .= "Referer: $boardurl\r\n";
		$out .= "Accept-Language: zh-cn\r\n";
		$out .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$out .= "User-Agent: $_SERVER[HTTP_USER_AGENT]\r\n";
		$out .= "Host: $host\r\n";
		$out .= 'Content-Length: '.strlen($post)."\r\n";
		$out .= "Connection: Close\r\n";
		$out .= "Cache-Control: no-cache\r\n";
		$out .= "Cookie: $cookie\r\n\r\n";
		$out .= $post;
	} else {
		$out = "GET $path HTTP/1.0\r\n";
		$out .= "Accept: */*\r\n";
		//$out .= "Referer: $boardurl\r\n";
		$out .= "Accept-Language: zh-cn\r\n";
		$out .= "User-Agent: $_SERVER[HTTP_USER_AGENT]\r\n";
		$out .= "Host: $host\r\n";
		$out .= "Connection: Close\r\n";
		$out .= "Cookie: $cookie\r\n\r\n";
	}
	$fp = @fsockopen(($ip ? $ip : $host), $port, $errno, $errstr, $timeout);
	if(!$fp) {
		return '';
	} else {
		stream_set_blocking($fp, $block);
		stream_set_timeout($fp, $timeout);
		@fwrite($fp, $out);
		$status = stream_get_meta_data($fp);
		if(!$status['timed_out']) {
			while (!feof($fp)) {
				if(($header = @fgets($fp)) && ($header == "\r\n" ||  $header == "\n")) {
					break;
				}
			}

			$stop = false;
			while(!feof($fp) && !$stop) {
				$data = fread($fp, ($limit == 0 || $limit > 8192 ? 8192 : $limit));
				$return .= $data;
				if($limit) {
					$limit -= strlen($data);
					$stop = $limit <= 0;
				}
			}
		}
		@fclose($fp);
		return $return;
	}
}
?>