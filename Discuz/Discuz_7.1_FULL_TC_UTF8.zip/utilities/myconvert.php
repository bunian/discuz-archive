<?php

// Upgrade Discuz! Board from 4.1.0 to 5.0.0

@set_time_limit(1000);

define('IN_DISCUZ', TRUE);
define('DISCUZ_ROOT', './');

if(@(!include("./config.inc.php")) || @(!include("./include/db_mysql.class.php"))) {
	exit("請先上傳所有新版本的程序文件後再運行本升級程序");
}

header("Content-Type: text/html; charset=$charset");

error_reporting(E_ERROR | E_WARNING | E_PARSE);
@set_magic_quotes_runtime(0);

if(empty($dbcharset) && in_array(strtolower($charset), array('gbk', 'big5', 'utf-8'))) {
	$dbcharset = str_replace('-', '', $charset);
}

if(PHP_VERSION < '4.1.0') {
	$_GET = &$HTTP_GET_VARS;
	$_POST = &$HTTP_POST_VARS;
	$_COOKIE = &$HTTP_COOKIE_VARS;
	$_SERVER = &$HTTP_SERVER_VARS;
	$_ENV = &$HTTP_ENV_VARS;
	$_FILES = &$HTTP_POST_FILES;
}

$action = ($_POST['action']) ? $_POST['action'] : $_GET['action'];
$step = $_GET['step'];
$start = $_GET['start'];

$upgrademsg = array(
	1 => '論壇升級第 1 步: 導入我的主題<br>',
	2 => '論壇升級第 2 步: 導入我的回復<br>',
	3 => '論壇升級第 3 步: 標記我的回復<br>',
	4 => '論壇升級第 4 步: 全部導入完畢<br>',
);

if(!$action) {
	echo 	"本程序用於導入 Discuz!5.0.0 我的主題功能, 請確認之前已經順利升級到 Discuz!5.0.0 <br><br>",
		"<b><font color=\"red\">本程序用於升級 Discuz!5.0.0 我的主題功能</font></b><br>",
		"<b><font color=\"red\">請確認已經上傳 Discuz!5.0.0 的全部文件和目錄並升級成功</font></b><br>",
		"<b><font color=\"red\">升級前請打開瀏覽器 JavaScript 支持,整個過程是自動完成的,不需人工點擊和干預.<br>升級之前務必備份數據庫資料,否則可能產生無法恢復的後果!</font></b><br><br>",
		"正確的升級方法為:<br><ol><li>確認論壇升級成功，關閉論壇<li>上傳本程序到您的論壇安裝目錄中<li>運行本程序,直到出現升級完成的提示</ol><br><br>",
		"<a href=\"$PHP_SELF?action=upgrade&step=1\">如果您已確認完成上面的步驟,請點這裡升級</a>";
} else {

	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
	$db->select_db($dbname);
	unset($dbhost, $dbuser, $dbpw, $dbname, $pconnect);

	$step = intval($step);
	echo $upgrademsg[$step];
	flush();

	$query = $db->query("SELECT value FROM {$tablepre}settings WHERE variable IN ('myrecorddays')");
	$myrecorddays = $db->result($query, 0);
	$converttimp = time() - $myrecorddays * 86400;

	if($step == 1) {

		$limit = 500; // 每次導入會員數
		$next = FALSE;
		$start = $start ? intval($start) : 0;

		$query = $db->query("SELECT uid FROM {$tablepre}members WHERE lastactivity>$converttimp AND posts>0 LIMIT $start, $limit");
		while($data = $db->fetch_array($query)) {
			$next = TRUE;
			$authorid[] = $data;
		}

		if(is_array($authorid)) {
			foreach($authorid as $author) {
				$query = $db->query("SELECT tid,dateline,authorid FROM {$tablepre}threads WHERE authorid=$author[uid] AND dateline>$converttimp");
				while($data = $db->fetch_array($query)) {
					$threads[] = $data;
				}
			}
		}

		if(is_array($threads)) {
			foreach($threads as $thread) {
				$db->query("REPLACE INTO {$tablepre}mythreads (uid, tid, dateline) VALUES ('$thread[authorid]', '$thread[tid]', '$thread[dateline]')", 'UNBUFFERED');
			}
		}

		if($next) {
			redirect("?action=upgrade&step=$step&start=".($start + $limit));
		} else {
			echo "第 $step 步升級成功<br><br>";
			redirect("?action=upgrade&step=".($step+1));
		}

	} elseif($step == 2) {

		$limit = 500; // 每次導入會員數
		$next = FALSE;
		$start = $start ? intval($start) : 0;

		$query = $db->query("SELECT uid FROM {$tablepre}members WHERE lastactivity>$converttimp AND posts>0 LIMIT $start, $limit");
		while($data = $db->fetch_array($query)) {
			$next = TRUE;
			$authorid[] = $data;
		}

		if(is_array($authorid)) {
			foreach($authorid as $author) {
				$query = $db->query("SELECT pid,tid,dateline,authorid FROM {$tablepre}posts WHERE authorid=$author[uid] AND dateline>$converttimp AND first!='1'");
				while($data = $db->fetch_array($query)) {
					$posts[] = $data;
				}
			}
		}

		if(is_array($posts)) {
			foreach($posts as $post) {
				$db->query("REPLACE INTO {$tablepre}myposts (uid, tid, pid, position, dateline) VALUES ('$post[authorid]', '$post[tid]', '$post[pid]', '".($thread['replies'] + 1)."', '$post[dateline]')", 'UNBUFFERED');
			}
		}

		if($next) {
			redirect("?action=upgrade&step=$step&start=".($start + $limit));
		} else {
			echo "第 $step 步升級成功<br><br>";
			redirect("?action=upgrade&step=".($step+1));
		}

	} elseif($step == 3) {

		$limit = 500; // 每次導入會員數
		$next = FALSE;
		$start = $start ? intval($start) : 0;

		$query = $db->query("SELECT tid FROM {$tablepre}myposts LIMIT $start, $limit");
		while($data = $db->fetch_array($query)) {
			$next = TRUE;
			$threadid[] = $data;
		}

		if(is_array($threadid)) {
			foreach($threadid as $thread) {
				$query = $db->query("SELECT tid,authorid,replies FROM {$tablepre}threads WHERE tid=$thread[tid]");
				while($data = $db->fetch_array($query)) {
					$threads[] = $data;
				}
			}
		}

		if(is_array($threads)) {
			foreach($threads as $thread) {
				$position = $thread['replies'] + 1;
				$db->query("UPDATE {$tablepre}myposts SET position='$position' WHERE tid='$thread[tid]' AND uid='$thread[authorid]'", 'UNBUFFERED');
			}
		}

		if($next) {
			redirect("?action=upgrade&step=$step&start=".($start + $limit));
		} else {
			echo "第 $step 步升級成功<br><br>";
			redirect("?action=upgrade&step=".($step+1));
		}

	} else {

		echo 	'<br>恭喜您論壇數據導入成功，接下來請您：必刪除本程序<br><br>'.
			'<b>感謝您選用我們的產品！</b>';
		exit;
	}
}

function redirect($url) {

	echo 	"<script>",
		"function redirect() {window.location.replace('$url');}\n",
		"setTimeout('redirect();', 500);\n",
		"</script>",
		"<br><br><a href=\"$url\">瀏覽器會自動跳轉頁面，無需人工干預。<br>除非當您的瀏覽器沒有自動跳轉時，請點擊這裡</a>";
	flush();

}

?>