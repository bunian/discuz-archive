||==========================||
||   Discuz! 工具文件說明   ||
||==========================||

+----------------------------------------------------------+
 標準版本升級程序
+----------------------------------------------------------+

upgrade1.php		CDB 3.0RC1 to Discuz! 1.0
upgrade2.php		Discuz! 1.0 到 Discuz! 2.0 升級程序
upgrade3.php		Discuz! 2.0 到 Discuz! 3.0 升級程序
upgrade4.php		Discuz! 3.0 到 Discuz! 3.1 升級程序
upgrade5.php		Discuz! 3.1.2 到 Discuz! 4.0.0 升級程序
upgrade6.php		Discuz! 4.0.0 到 Discuz! 4.1.0 升級程序
upgrade7.php		Discuz! 4.1.0 到 Discuz! 5.0.0 升級程序
upgrade8.php		Discuz! 5.0.0 到 Discuz! 5.5.0 升級程序
upgrade9.php		Discuz! 5.5.0 到 Discuz! 6.0.0 升級程序
upgrade10.php		Discuz! 6.0.0 到 Discuz! 6.1.0 升級程序
upgrade11.php		Discuz! 6.1.0 到 Discuz! 7.0.0 升級程序

+----------------------------------------------------------+
 其他版本升級程序
+----------------------------------------------------------+

d3ftod4.php		Discuz! 3.0F 到 Discuz!4.0 升級程序
rc3torc4.php		Discuz! 4.0RC3 到 Discuz! 4.0RC4 升級程序
rc4torcfinal.php	Discuz! 4.0RC4 到 Discuz! 4.0RCfinal 升級程序
d5rc1torc2.php		Discuz! 5.0RC1 到 Discuz! 5.0RC2 升級程序
d6rc1tofinal.php	Discuz! 6.0RC1 到 Discuz! 6.0.0 升級程序
d60to70.php			Discuz! 6.0.0  到 Discuz! 7.0.0 升級程序

+----------------------------------------------------------+
 相關工具程序
+----------------------------------------------------------+

myconvert.php		Discuz! 4.1.0 -> Discuz! 5.0 「我的」功能轉換程序
thumbattach.php		Discuz! 5.0.0 -> Discuz! 5.5.0 舊附件圖片縮略圖生成程序
tools.php			Discuz!工具箱程序,檢查或修複數據庫/導入數據庫備份/恢復論壇管理員帳號/測試郵件發送方式/數據庫冗餘數據清理 
checks.php			搜索未知文件