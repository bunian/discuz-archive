<?php

// Upgrade Discuz! Board from 6.0.0RC1 to 6.0.0 final

error_reporting(E_ERROR | E_WARNING | E_PARSE);
@set_magic_quotes_runtime(0);

@set_time_limit(1000);

define('IN_DISCUZ', TRUE);
define('DISCUZ_ROOT', './');

$version_old = 'Discuz! 6.0.0 RC1';
$version_new = 'Discuz! 6.0.0 正式版';
$timestamp = time();

@include(DISCUZ_ROOT."./config.inc.php");
@include(DISCUZ_ROOT."./include/db_mysql.class.php");

header("Content-Type: text/html; charset=$charset");
showheader();

if(empty($dbcharset) && in_array(strtolower($charset), array('gbk', 'big5', 'utf-8'))) {
	$dbcharset = str_replace('-', '', $charset);
}

if(PHP_VERSION < '4.1.0') {
	$_GET = &$HTTP_GET_VARS;
	$_POST = &$HTTP_POST_VARS;
	$_COOKIE = &$HTTP_COOKIE_VARS;
	$_SERVER = &$HTTP_SERVER_VARS;
	$_ENV = &$HTTP_ENV_VARS;
	$_FILES = &$HTTP_POST_FILES;
}

$action = ($_POST['action']) ? $_POST['action'] : $_GET['action'];
$step = $_GET['step'];
$start = isset($_GET['start']) ? intval($_GET['start']) : 0;

$upgrade1 = <<<EOT

REPLACE INTO cdb_settings (variable, value) VALUES ('baidusitemap', '1');
REPLACE INTO cdb_settings (variable, value) VALUES ('baidusitemap_life', '12');
REPLACE INTO cdb_settings (variable, value) VALUES ('google', '');

UPDATE cdb_stylevars SET variable='stypeid', substitute='1' WHERE variable='smdir';

CREATE TABLE IF NOT EXISTS cdb_videotags (
  tagname char(10) NOT NULL DEFAULT '',
  vid char(16) NOT NULL DEFAULT '',
  tid mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY tagname (tagname,vid),
  KEY tid (tid)
) TYPE=MyISAM;

EOT;

$upgradetable = array(

	array('typevars', 'ADD', 'required', "TINYINT( 1 ) NOT NULL DEFAULT '0' AFTER available"),
	array('typevars', 'ADD', 'unchangeable', " TINYINT( 1 ) NOT NULL DEFAULT '0' AFTER required"),
	array('typevars', 'ADD', 'search', " TINYINT( 1 ) NOT NULL DEFAULT '0' AFTER `unchangeable`"),

	array('threadtypes', 'ADD', 'modelid', "SMALLINT( 6 ) UNSIGNED NOT NULL DEFAULT '0' DEFAULT '0' AFTER `special`"),
	array('threadtypes', 'ADD', 'expiration', "TINYINT( 1 ) NOT NULL DEFAULT '0' AFTER modelid"),

	array('typeoptionvars', 'ADD', 'expiration', "INT( 10 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `optionid`"),

	array('searchindex', 'ADD', 'threadtypeid', "SMALLINT( 6 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `threads`"),
	array('searchindex', 'MODIFY', 'searchstring', "searchstring TEXT  NOT NULL"),

	array('forumfields', 'ADD', 'tradetypes', "TEXT NOT NULL"),
	array('forumfields', 'ADD', 'typemodels', "MEDIUMTEXT NOT NULL"),

	array('promotions', 'MODIFY', 'uid', "uid MEDIUMINT( 8 ) UNSIGNED NOT NULL DEFAULT '0'"),
	array('smilies', 'MODIFY', 'displayorder', "displayorder TINYINT( 3 ) NOT NULL DEFAULT '0'"),
	array('smilies', 'ADD', 'typeid', "SMALLINT( 6 ) UNSIGNED NOT NULL AFTER id"),

	array('caches', 'MODIFY', 'data', "data MEDIUMTEXT NOT NULL"),
	array('usergroups', 'ADD', 'allowpostvideo', "TINYINT (1) DEFAULT '0' NOT NULL  AFTER allowpostactivity"),
	array('usergroups', 'MODIFY', 'tradestick', "TINYINT(1) UNSIGNED NOT NULL DEFAULT '0'"),

	array('videos', 'MODIFY', 'vid', "VARCHAR(16)  NOT NULL DEFAULT ''"),
	array('videotags', 'ADD', 'tid', "MEDIUMINT(8) UNSIGNED  DEFAULT '0' NOT NULL  AFTER vid"),
	array('videotags', 'INDEX', '', "ADD INDEX tid (tid)"),

        array('tradelog', 'MODIFY', 'orderid', "varchar(32) NOT NULL"),
        array('tradelog', 'MODIFY', 'tradeno', "varchar(32) NOT NULL"),
        array('tradelog', 'MODIFY', 'subject', "varchar(100) NOT NULL"),
        array('tradelog', 'MODIFY', 'locus', "varchar(100) NOT NULL"),
        array('tradelog', 'MODIFY', 'seller', "varchar(15) NOT NULL"),
        array('tradelog', 'MODIFY', 'selleraccount', "varchar(50) NOT NULL"),
        array('tradelog', 'MODIFY', 'buyer', "varchar(15) NOT NULL"),
        array('tradelog', 'MODIFY', 'buyercontact', "varchar(50) NOT NULL"),
        array('tradelog', 'MODIFY', 'buyermsg', "varchar(200) default NULL"),
        array('tradelog', 'MODIFY', 'buyername', "varchar(50) NOT NULL"),
        array('tradelog', 'MODIFY', 'buyerzip', " varchar(10) NOT NULL"),
        array('tradelog', 'MODIFY', 'buyerphone', "varchar(20) NOT NULL"),
        array('tradelog', 'MODIFY', 'buyermobile', "varchar(20) NOT NULL"),
        array('tradelog', 'ADD', 'message', "text NOT NULL"),

	array('forums', 'MODIFY', 'allowpostspecial', "SMALLINT( 6 ) UNSIGNED NOT NULL DEFAULT '0'"),

);

$upgrade3 = <<<EOT

DROP TABLE IF EXISTS cdb_typemodels;
CREATE TABLE cdb_typemodels (
  id smallint(6) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  displayorder tinyint(3) NOT NULL default '0',
  `type` tinyint(1) NOT NULL default '0',
  options mediumtext NOT NULL,
  customoptions mediumtext NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

INSERT INTO cdb_typemodels (id, name, displayorder, type, options, customoptions) VALUES (1, '房屋交易信息', 0, 1, '7	10	13	65	66	68', '');
INSERT INTO cdb_typemodels (id, name, displayorder, type, options, customoptions) VALUES (2, '車票交易信息', 0, 1, '55	56	58	67	7	13	68', '');
INSERT INTO cdb_typemodels (id, name, displayorder, type, options, customoptions) VALUES (3, '興趣交友信息', 0, 1, '8	9	31', '');
INSERT INTO cdb_typemodels (id, name, displayorder, type, options, customoptions) VALUES (4, '公司招聘信息', 0, 1, '34	48	54	51	47	46	44	45	52	53', '');

ALTER TABLE cdb_typemodels AUTO_INCREMENT=101;

REPLACE INTO cdb_typeoptions VALUES (7, 1, 0, '姓名', '', 'name', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (9, 1, 0, '年齡', '', 'age', 'number', '');
REPLACE INTO cdb_typeoptions VALUES (10, 1, 0, '地址', '', 'address', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (11, 1, 0, 'QQ', '', 'qq', 'number', '');
REPLACE INTO cdb_typeoptions VALUES (12, 1, 0, '郵箱', '', 'mail', 'email', '');
REPLACE INTO cdb_typeoptions VALUES (13, 1, 0, '電話', '', 'phone', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (14, 5, 0, '培訓費用', '', 'teach_pay', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (15, 5, 0, '培訓時間', '', 'teach_time', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (20, 2, 0, '樓層', '', 'floor', 'number', '');
REPLACE INTO cdb_typeoptions VALUES (21, 2, 0, '交通狀況', '', 'traf', 'textarea', '');
REPLACE INTO cdb_typeoptions VALUES (22, 2, 0, '地圖', '', 'images', 'image', '');
REPLACE INTO cdb_typeoptions VALUES (24, 2, 0, '價格', '', 'price', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (26, 5, 0, '培訓名稱', '', 'teach_name', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (28, 3, 0, '身高', '', 'heighth', 'number', '');
REPLACE INTO cdb_typeoptions VALUES (29, 3, 0, '體重', '', 'weighth', 'number', '');
REPLACE INTO cdb_typeoptions VALUES (33, 1, 0, '照片', '', 'photo', 'image', '');
REPLACE INTO cdb_typeoptions VALUES (35, 5, 0, '服務方式', '', 'service_type', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (36, 5, 0, '服務時間', '', 'service_time', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (37, 5, 0, '服務費用', '', 'service_pay', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (39, 6, 0, '網址', '', 'site_url', 'url', '');
REPLACE INTO cdb_typeoptions VALUES (40, 6, 0, '電子郵件', '', 'site_mail', 'email', '');
REPLACE INTO cdb_typeoptions VALUES (42, 6, 0, '網站名稱', '', 'site_name', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (46, 4, 0, '職位', '', 'recr_intend', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (47, 4, 0, '工作地點', '', 'recr_palce', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (49, 4, 0, '有效期至', '', 'recr_end', 'calendar', '');
REPLACE INTO cdb_typeoptions VALUES (51, 4, 0, '公司名稱', '', 'recr_com', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (52, 4, 0, '年齡要求', '', 'recr_age', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (54, 4, 0, '專業', '', 'recr_abli', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (55, 5, 0, '始發', '', 'leaves', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (56, 5, 0, '終點', '', 'boundfor', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (57, 6, 0, 'Alexa排名', '', 'site_top', 'number', '');
REPLACE INTO cdb_typeoptions VALUES (58, 5, 0, '車次/航班', '', 'train_no', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (59, 5, 0, '數量', '', 'trade_num', 'number', '');
REPLACE INTO cdb_typeoptions VALUES (60, 5, 0, '價格', '', 'trade_price', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (61, 5, 0, '有效期至', '', 'trade_end', 'calendar', '');
REPLACE INTO cdb_typeoptions VALUES (63, 1, 0, '詳細描述', '', 'detail_content', 'textarea', '');
REPLACE INTO cdb_typeoptions VALUES (64, 1, 0, '籍貫', '', 'born_place', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (65, 2, 0, '租金', '', 'money', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (66, 2, 0, '面積', '', 'acreage', 'text', '');
REPLACE INTO cdb_typeoptions VALUES (67, 5, 0, '發車時間', '', 'time', 'calendar', 'N;');
REPLACE INTO cdb_typeoptions VALUES (68, 1, 0, '所在地', '', 'now_place', 'text', '');

DROP TABLE IF EXISTS cdb_imagetypes;
CREATE TABLE cdb_imagetypes (
  typeid smallint(6) unsigned NOT NULL auto_increment,
  name char(20) NOT NULL,
  type enum('smiley', 'icon', 'avatar') NOT NULL DEFAULT 'smiley',
  displayorder tinyint(3) NOT NULL default '0',
  directory char(100) NOT NULL,
  PRIMARY KEY  (typeid)
) TYPE=MyISAM;
INSERT INTO cdb_imagetypes VALUES (1, '默認表情', 'smiley', 1, 'default');
UPDATE cdb_smilies SET typeid=1 WHERE type='smiley';

EOT;

$upgrade4 = <<<EOT

EOT;

$upgrade6 = <<<EOT

EOT;

$upgrade7 = <<<EOT

INSERT INTO cdb_bbcodes VALUES ({bbcodeid,1}, '0', 'sup', 'bb_sup.gif', '<sup>{1}</sup>', 'X[sup]2[/sup]', '上標', 1, '請輸入上標文字：', '1');
INSERT INTO cdb_bbcodes VALUES ({bbcodeid,2}, '0', 'sub', 'bb_sub.gif', '<sub>{1}</sub>', 'X[sub]2[/sub]', '下標', 1, '請輸入下標文字：', '1');

INSERT INTO cdb_templates (templateid, name, directory, copyright) VALUES ({templateid,1}, '喝彩奧運', './templates/Beijing2008', '康盛創想（北京）科技有限公司');
INSERT INTO cdb_templates (templateid, name, directory, copyright) VALUES ({templateid,2}, '深邃永恆', './templates/Overcast', '康盛創想（北京）科技有限公司');
INSERT INTO cdb_templates (templateid, name, directory, copyright) VALUES ({templateid,3}, '粉妝精靈', './templates/PinkDresser', '康盛創想（北京）科技有限公司');

INSERT INTO cdb_styles (styleid, name, available, templateid) VALUES ({styleid,1}, '喝彩奧運', 1, {templateid,1});
INSERT INTO cdb_stylevars (styleid, variable, substitute) VALUES
  ({styleid,1}, 'available', ''),
  ({styleid,1}, 'bgcolor', '#FFF'),
  ({styleid,1}, 'altbg1', '#FFF'),
  ({styleid,1}, 'altbg2', '#F7F7F3'),
  ({styleid,1}, 'link', '#262626'),
  ({styleid,1}, 'bordercolor', '#C1C1C1'),
  ({styleid,1}, 'headercolor', '#FFF forumbox_head.gif'),
  ({styleid,1}, 'headertext', '#D00'),
  ({styleid,1}, 'catcolor', '#F90 cat_bg.gif'),
  ({styleid,1}, 'tabletext', '#535353'),
  ({styleid,1}, 'text', '#535353'),
  ({styleid,1}, 'borderwidth', '1px'),
  ({styleid,1}, 'tablespace', '1px'),
  ({styleid,1}, 'fontsize', '12px'),
  ({styleid,1}, 'msgfontsize', '14px'),
  ({styleid,1}, 'msgbigsize', '16px'),
  ({styleid,1}, 'msgsmallsize', '12px'),
  ({styleid,1}, 'font', 'Arial,Helvetica,sans-serif'),
  ({styleid,1}, 'smfontsize', '11px'),
  ({styleid,1}, 'smfont', 'Arial,Helvetica,sans-serif'),
  ({styleid,1}, 'boardimg', 'logo.gif'),
  ({styleid,1}, 'imgdir', './images/Beijing2008'),
  ({styleid,1}, 'maintablewidth', '98%'),
  ({styleid,1}, 'bgborder', '#C1C1C1'),
  ({styleid,1}, 'catborder', '#E2E2E2'),
  ({styleid,1}, 'inputborder', '#D7D7D7'),
  ({styleid,1}, 'lighttext', '#535353'),
  ({styleid,1}, 'headermenu', '#FFF menu_bg.gif'),
  ({styleid,1}, 'headermenutext', '#54564C'),
  ({styleid,1}, 'framebgcolor', ''),
  ({styleid,1}, 'noticebg', ''),
  ({styleid,1}, 'commonboxborder', '#F0F0ED'),
  ({styleid,1}, 'tablebg', '#FFF'),
  ({styleid,1}, 'highlightlink', '#535353'),
  ({styleid,1}, 'commonboxbg', '#F5F5F0'),
  ({styleid,1}, 'boxspace', '8px'),
  ({styleid,1}, 'portalboxbgcode', '#FFF portalbox_bg.gif'),
  ({styleid,1}, 'noticeborder', ''),
  ({styleid,1}, 'noticetext', '#DD0000'),
  ({styleid,1}, 'stypeid', '1');

INSERT INTO cdb_styles (styleid, name, available, templateid) VALUES ({styleid,2}, '深邃永恆', 1, {templateid,2});
INSERT INTO cdb_stylevars (styleid, variable, substitute) VALUES
  ({styleid,2}, 'available', ''),
  ({styleid,2}, 'bgcolor', '#222D2D'),
  ({styleid,2}, 'altbg1', '#3E4F4F'),
  ({styleid,2}, 'altbg2', '#384747'),
  ({styleid,2}, 'link', '#CEEBEB'),
  ({styleid,2}, 'bordercolor', '#1B2424'),
  ({styleid,2}, 'headercolor', '#1B2424'),
  ({styleid,2}, 'headertext', '#94B3C5'),
  ({styleid,2}, 'catcolor', '#293838'),
  ({styleid,2}, 'tabletext', '#CEEBEB'),
  ({styleid,2}, 'text', '#999'),
  ({styleid,2}, 'borderwidth', '6px'),
  ({styleid,2}, 'tablespace', '0'),
  ({styleid,2}, 'fontsize', '12px'),
  ({styleid,2}, 'msgfontsize', '14px'),
  ({styleid,2}, 'msgbigsize', '16px'),
  ({styleid,2}, 'msgsmallsize', '12px'),
  ({styleid,2}, 'font', 'Arial'),
  ({styleid,2}, 'smfontsize', '11px'),
  ({styleid,2}, 'smfont', 'Arial,sans-serif'),
  ({styleid,2}, 'boardimg', 'logo.gif'),
  ({styleid,2}, 'imgdir', './images/Overcast'),
  ({styleid,2}, 'maintablewidth', '98%'),
  ({styleid,2}, 'bgborder', '#384747'),
  ({styleid,2}, 'catborder', '#1B2424'),
  ({styleid,2}, 'inputborder', '#EEE'),
  ({styleid,2}, 'lighttext', '#74898E'),
  ({styleid,2}, 'headermenu', '#3E4F4F'),
  ({styleid,2}, 'headermenutext', '#CEEBEB'),
  ({styleid,2}, 'framebgcolor', '#222D2D'),
  ({styleid,2}, 'noticebg', '#3E4F4F'),
  ({styleid,2}, 'commonboxborder', '#384747'),
  ({styleid,2}, 'tablebg', '#3E4F4F'),
  ({styleid,2}, 'highlightlink', '#9CB2A0'),
  ({styleid,2}, 'commonboxbg', '#384747'),
  ({styleid,2}, 'boxspace', '6px'),
  ({styleid,2}, 'portalboxbgcode', '#293838'),
  ({styleid,2}, 'noticeborder', '#384747'),
  ({styleid,2}, 'noticetext', '#C7E001'),
  ({styleid,2}, 'stypeid', '1');

INSERT INTO cdb_styles (styleid, name, available, templateid) VALUES ({styleid,3}, '粉妝精靈', 1, {templateid,3});
INSERT INTO cdb_stylevars (styleid, variable, substitute) VALUES
  ({styleid,3}, 'noticetext', '#C44D4D'),
  ({styleid,3}, 'noticeborder', '#D6D6D6'),
  ({styleid,3}, 'portalboxbgcode', '#FFF portalbox_bg.gif'),
  ({styleid,3}, 'boxspace', '6px'),
  ({styleid,3}, 'commonboxbg', '#FAFAFA'),
  ({styleid,3}, 'highlightlink', '#C44D4D'),
  ({styleid,3}, 'tablebg', '#FFF'),
  ({styleid,3}, 'commonboxborder', '#DEDEDE'),
  ({styleid,3}, 'noticebg', '#FAFAFA'),
  ({styleid,3}, 'framebgcolor', '#FFECF9'),
  ({styleid,3}, 'headermenu', 'transparent'),
  ({styleid,3}, 'headermenutext', ''),
  ({styleid,3}, 'lighttext', '#999'),
  ({styleid,3}, 'catborder', '#D7D7D7'),
  ({styleid,3}, 'inputborder', ''),
  ({styleid,3}, 'bgborder', '#CECECE'),
  ({styleid,3}, 'stypeid', '1'),
  ({styleid,3}, 'maintablewidth', '920px'),
  ({styleid,3}, 'imgdir', 'images/PinkDresser'),
  ({styleid,3}, 'boardimg', 'logo.gif'),
  ({styleid,3}, 'smfont', 'Arial,Helvetica,sans-serif'),
  ({styleid,3}, 'smfontsize', '12px'),
  ({styleid,3}, 'font', 'Arial,Helvetica,sans-serif'),
  ({styleid,3}, 'msgsmallsize', '12px'),
  ({styleid,3}, 'msgbigsize', '16px'),
  ({styleid,3}, 'msgfontsize', '14px'),
  ({styleid,3}, 'fontsize', '12px'),
  ({styleid,3}, 'tablespace', '0'),
  ({styleid,3}, 'borderwidth', '1px'),
  ({styleid,3}, 'text', '#666'),
  ({styleid,3}, 'tabletext', '#666'),
  ({styleid,3}, 'catcolor', '#FAFAFA category_bg.gif'),
  ({styleid,3}, 'headertext', '#FFF'),
  ({styleid,3}, 'headercolor', '#E7BFC9 forumbox_head.gif'),
  ({styleid,3}, 'bordercolor', '#D88E9D'),
  ({styleid,3}, 'link', '#C44D4D'),
  ({styleid,3}, 'altbg2', '#F1F1F1'),
  ({styleid,3}, 'available', ''),
  ({styleid,3}, 'altbg1', '#FBFBFB'),
  ({styleid,3}, 'bgcolor', '#FBF4F5 bg.gif');

INSERT INTO cdb_styles (styleid, name, available, templateid) VALUES ({styleid,4}, '詩意田園', 1, 1);
INSERT INTO cdb_stylevars (styleid, variable, substitute) VALUES
  ({styleid,4}, 'available', ''),
  ({styleid,4}, 'bgcolor', '#FFF'),
  ({styleid,4}, 'altbg1', '#FFFBF8'),
  ({styleid,4}, 'altbg2', '#FBF6F1'),
  ({styleid,4}, 'link', '#54564C'),
  ({styleid,4}, 'bordercolor', '#D7B094'),
  ({styleid,4}, 'headercolor', '#BE6A2D forumbox_head.gif'),
  ({styleid,4}, 'headertext', '#FFF'),
  ({styleid,4}, 'catcolor', '#E9E9E9 cat_bg.gif'),
  ({styleid,4}, 'tabletext', '#7B7D72'),
  ({styleid,4}, 'text', '#535353'),
  ({styleid,4}, 'borderwidth', '1px'),
  ({styleid,4}, 'tablespace', '1px'),
  ({styleid,4}, 'fontsize', '12px'),
  ({styleid,4}, 'msgfontsize', '14px'),
  ({styleid,4}, 'msgbigsize', '16px'),
  ({styleid,4}, 'msgsmallsize', '12px'),
  ({styleid,4}, 'font', 'Arial, sans-serif'),
  ({styleid,4}, 'smfontsize', '11px'),
  ({styleid,4}, 'smfont', 'Arial, sans-serif'),
  ({styleid,4}, 'boardimg', 'logo.gif'),
  ({styleid,4}, 'imgdir', './images/Picnicker'),
  ({styleid,4}, 'maintablewidth', '98%'),
  ({styleid,4}, 'bgborder', '#E8C9B7'),
  ({styleid,4}, 'catborder', '#E6E6E2'),
  ({styleid,4}, 'inputborder', ''),
  ({styleid,4}, 'lighttext', '#878787'),
  ({styleid,4}, 'headermenu', '#FFF menu_bg.gif'),
  ({styleid,4}, 'headermenutext', '#54564C'),
  ({styleid,4}, 'framebgcolor', 'frame_bg.gif'),
  ({styleid,4}, 'noticebg', '#FAFAF7'),
  ({styleid,4}, 'commonboxborder', '#E6E6E2'),
  ({styleid,4}, 'tablebg', '#FFF'),
  ({styleid,4}, 'highlightlink', ''),
  ({styleid,4}, 'commonboxbg', '#F5F5F0'),
  ({styleid,4}, 'boxspace', '6px'),
  ({styleid,4}, 'portalboxbgcode', '#FFF portalbox_bg.gif'),
  ({styleid,4}, 'noticeborder', '#E6E6E2'),
  ({styleid,4}, 'noticetext', '#FF3A00'),
  ({styleid,4}, 'stypeid', '1');

INSERT INTO cdb_styles (styleid, name, available, templateid) VALUES ({styleid,5}, '春意盎然', 1, 1);
INSERT INTO cdb_stylevars (styleid, variable, substitute) VALUES
  ({styleid,5}, 'available', ''),
  ({styleid,5}, 'bgcolor', '#FFF'),
  ({styleid,5}, 'altbg1', '#F5F5F0'),
  ({styleid,5}, 'altbg2', '#F9F9F9'),
  ({styleid,5}, 'link', '#54564C'),
  ({styleid,5}, 'bordercolor', '#D9D9D4'),
  ({styleid,5}, 'headercolor', '#80A400 forumbox_head.gif'),
  ({styleid,5}, 'headertext', '#FFF'),
  ({styleid,5}, 'catcolor', '#F5F5F0 cat_bg.gif'),
  ({styleid,5}, 'tabletext', '#7B7D72'),
  ({styleid,5}, 'text', '#535353'),
  ({styleid,5}, 'borderwidth', '1px'),
  ({styleid,5}, 'tablespace', '1px'),
  ({styleid,5}, 'fontsize', '12px'),
  ({styleid,5}, 'msgfontsize', '14px'),
  ({styleid,5}, 'msgbigsize', '16px'),
  ({styleid,5}, 'msgsmallsize', '12px'),
  ({styleid,5}, 'font', 'Arial,sans-serif'),
  ({styleid,5}, 'smfontsize', '11px'),
  ({styleid,5}, 'smfont', 'Arial,sans-serif'),
  ({styleid,5}, 'boardimg', 'logo.gif'),
  ({styleid,5}, 'imgdir', './images/GreenPark'),
  ({styleid,5}, 'maintablewidth', '98%'),
  ({styleid,5}, 'bgborder', '#D9D9D4'),
  ({styleid,5}, 'catborder', '#D9D9D4'),
  ({styleid,5}, 'inputborder', '#D9D9D4'),
  ({styleid,5}, 'lighttext', '#878787'),
  ({styleid,5}, 'headermenu', '#FFF menu_bg.gif'),
  ({styleid,5}, 'headermenutext', '#262626'),
  ({styleid,5}, 'framebgcolor', ''),
  ({styleid,5}, 'noticebg', '#FAFAF7'),
  ({styleid,5}, 'commonboxborder', '#E6E6E2'),
  ({styleid,5}, 'tablebg', '#FFF'),
  ({styleid,5}, 'highlightlink', '#535353'),
  ({styleid,5}, 'commonboxbg', '#F9F9F9'),
  ({styleid,5}, 'boxspace', '6px'),
  ({styleid,5}, 'portalboxbgcode', '#FFF portalbox_bg.gif'),
  ({styleid,5}, 'noticeborder', '#E6E6E2'),
  ({styleid,5}, 'noticetext', '#FF3A00'),
  ({styleid,5}, 'stypeid', '1');

EOT;

$insenz_upgrade = <<<EOT


EOT;

$upgrademsg = array(

	1 => '論壇升級第 1 步: 增加基本設置<br /><br />',
	2 => '論壇升級第 2 步: 調整論壇數據表結構<br /><br />',
	3 => '論壇升級第 3 步: 新增數據表<br /><br />',

	4 => '論壇升級第 4 步: 更新部分數據<br /><br />',
	5 => '論壇升級第 5 步: 升級郵件設置<br /><br />',
	6 => '論壇升級第 6 步: 升級電子商務設置<br /><br />',
	7 => '論壇升級第 7 步: 升級論壇風格<br /><br />',

	8 => '論壇升級第 8 步: Insenz相關數據升級<br /><br />',
	9 => '論壇升級第 9 步: 其他相關數據升級<br /><br />',
	10 => '論壇升級第 10 步: 升級全部完畢<br /><br />',
);

$errormsg = '';
if(!isset($dbhost)) {
	showerror("<span class=error>沒有找到 config.inc.php 文件!</span><br />請確認您已經上傳了所有 $version_new 文件");
} elseif(!isset($cookiepre)) {
	showerror("<span class=error>config.inc.php 版本錯誤!</span><br />請上傳 $version_new 的 config.inc.php，並調整好數據庫設置然後重新進行升級");
} elseif(!$dblink = @mysql_connect($dbhost, $dbuser, $dbpw)) {
	showerror("<span class=error>config.inc.php 配置錯誤!</span><br />請修改 config.inc.php 當中關於數據庫的設置，然後上傳到論壇目錄，重新開始升級");
}

@mysql_close($dblink);
$db = new dbstuff;
$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);

if(!$action) {

	if(!$tableinfo = loadtable('threads')) {
		showerror("<span class=error>無法找到 Discuz! 論壇數據表!</span><br />請修改 config.inc.php 當中關於數據庫的設置，然後上傳到論壇目錄，重新開始升級");
	} elseif($db->version() > '4.1') {
		$old_dbcharset = substr($tableinfo['subject']['Collation'], 0, strpos($tableinfo['subject']['Collation'], '_'));
		if($old_dbcharset <> $dbcharset) {
			showerror("<span class=error>config.inc.php 數據庫字符集設置錯誤!</span><br />".
				"<li>原來的字符集設置為：$old_dbcharset".
				"<li>當前使用的字符集為：$dbcharset".
				"<li>建議：修改 config.inc.php， 將其中的 <b>\$dbcharset = ''</b> 或者 <b>\$dbcharset = '$dbcharset'</b> 修改為： <b>\$dbcharset = '$old_dbcharset'</b>".
				"<li>修改完畢後上傳 config.inc.php，然後重新進行升級"
			);
		}
	}

	echo <<< EOT
<span class="red">
升級前請打開瀏覽器 JavaScript 支持,整個過程是自動完成的,不需人工點擊和干預.<br />
升級之前務必備份數據庫資料，否則升級失敗無法恢復<br /></span><br />
正確的升級方法為:
<ol>
	<li>關閉原有論壇,上傳 $version_new 的全部文件和目錄, 覆蓋服務器上的 $version_old
	<li>上傳升級程序到論壇目錄中，<b>重新配置好 config.inc.php</b>
	<li>運行本程序,直到出現升級完成的提示
	<li>如果中途失敗，請使用Discuz!工具箱（./utilities/tools.php）裡面的數據恢復工具恢復備份, 去除錯誤後重新運行本程序
</ol>
<a href="$PHP_SELF?action=upgrade&step=1"><font size="2" color="red"><b>&gt;&gt;&nbsp;如果您已確認完成上面的步驟,請點這裡升級</b></font></a>
<br /><br />
EOT;
	showfooter();

} else {

	$step = intval($step);
	echo '&gt;&gt;'.$upgrademsg[$step];
	flush();

	if($step == 1) {

		dir_clear('./forumdata/cache');
		dir_clear('./forumdata/templates');

		runquery($upgrade1);

		$authkey = substr(md5($_SERVER['SERVER_ADDR'].$_SERVER['HTTP_USER_AGENT'].$dbhost.$dbuser.$dbpw.$dbname.$username.$password.$pconnect.substr($timestamp, 0, 6)), 8, 6).random(10);

		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
		$siteuniqueid = $chars[date('y')%60].$chars[date('n')].$chars[date('j')].$chars[date('G')].$chars[date('i')].$chars[date('s')].substr(md5($onlineip.$timestamp), 0, 4).random(6);

		$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('authkey', '$authkey')");
		$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('siteuniqueid', '$siteuniqueid')");

		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 2) {

		if(isset($upgradetable[$start]) && $upgradetable[$start][0]) {

			echo "升級數據表 [ $start ] {$tablepre}{$upgradetable[$start][0]} {$upgradetable[$start][3]}:";
			$successed = upgradetable($upgradetable[$start]);

			if($successed === TRUE) {
				echo ' <font color=green>OK</font><br />';
			} elseif($successed === FALSE) {
				//echo ' <font color=red>ERROR</font><br />';
			} elseif($successed == 'TABLE NOT EXISTS') {
				showerror('<span class=red>數據表不存在</span>升級無法繼續，請確認您的論壇版本是否正確!</font><br />');
			}
		}

		$start ++;
		if(isset($upgradetable[$start]) && $upgradetable[$start][0]) {
			redirect("?action=upgrade&step=$step&start=$start");
		}

		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 3) {

		runquery($upgrade3);

		$optionlist = array (
			  8 => array (
			    	'classid' => '1',
			   	'displayorder' => '2',
			    	'title' => '性別',
			    	'identifier' => 'gender',
			    	'type' => 'radio',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=男\r\n2=女",
			    		),
			  	),
			  16 => array (
			    	'classid' => '2',
			    	'displayorder' => '0',
			    	'title' => '房屋類型',
			    	'identifier' => 'property',
			    	'type' => 'select',
			    	'rules' => array (
			      			'choices' => "1=寫字樓\r\n2=公寓\r\n3=小區\r\n4=平房\r\n5=別墅\r\n6=地下室",
			    		),
			  	),
			  17 => array (
			    	'classid' => '2',
			    	'displayorder' => '0',
			    	'title' => '座向',
			    	'identifier' => 'face',
			    	'type' => 'radio',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=南向\r\n2=北向\r\n3=西向\r\n4=東向",
			    		),
			  	),
			  18 => array (
			    	'classid' => '2',
			    	'displayorder' => '0',
			    	'title' => '裝修情況',
			    	'identifier' => 'makes',
			    	'type' => 'radio',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=無裝修\r\n2=簡單裝修\r\n3=精裝修",
			    		),
			  	),
			  19 => array (
			    	'classid' => '2',
			    	'displayorder' => '0',
			    	'title' => '居室',
			    	'identifier' => 'mode',
			    	'type' => 'select',
			    	'rules' => array (
			      			'choices' => "1=獨居\r\n2=兩居室\r\n3=三居室\r\n4=四居室\r\n5=別墅",
			    		),
			  	),
			  23 => array (
			    	'classid' => '2',
			    	'displayorder' => '0',
			    	'title' => '屋內設施',
			    	'identifier' => 'equipment',
			    	'type' => 'checkbox',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=水電\r\n2=寬帶\r\n3=管道氣\r\n4=有線電視\r\n5=電梯\r\n6=電話\r\n7=冰箱\r\n8=洗衣機\r\n9=熱水器\r\n10=空調\r\n11=暖氣\r\n12=微波爐\r\n13=油煙機\r\n14=飲水機",
			   		),
			  	),
			  25 => array (
			    	'classid' => '2',
			    	'displayorder' => '0',
			    	'title' => '是否中介',
			    	'identifier' => 'bool',
			    	'type' => 'radio',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=是\r\n2=否",
			    		),
			  	),
			  27 => array (
			    	'classid' => '3',
			   	'displayorder' => '0',
			    	'title' => '星座',
			    	'identifier' => 'Horoscope',
			    	'type' => 'select',
			    	'rules' => array (
			      			'choices' => "1=白羊座\r\n2=金牛座\r\n3=雙子座\r\n4=巨蟹座\r\n5=獅子座\r\n6=處女座\r\n7=天秤座\r\n8=天蠍座\r\n9=射手座\r\n10=摩羯座\r\n11=水瓶座\r\n12=雙魚座",
			    		),
			  	),
			  30 => array (
			    	'classid' => '3',
			    	'displayorder' => '0',
			    	'title' => '婚姻狀況',
			    	'identifier' => 'marrige',
			    	'type' => 'radio',
			    	'rules' => array (
			      			'choices' => "1=已婚\r\n2=未婚",
			    		),
			  	),
			  31 => array (
			    	'classid' => '3',
			    	'displayorder' => '0',
			    	'title' => '愛好',
			    	'identifier' => 'hobby',
			    	'type' => 'checkbox',
			    	'rules' => array (
			      			'choices' => "1=美食\r\n2=唱歌\r\n3=跳舞\r\n4=電影\r\n5=音樂\r\n6=戲劇\r\n7=聊天\r\n8=拍托\r\n9=電腦\r\n10=網絡\r\n11=遊戲\r\n12=繪畫\r\n13=書法\r\n14=雕塑\r\n15=異性\r\n16=閱讀\r\n17=運動\r\n18=旅遊\r\n19=八卦\r\n20=購物\r\n21=賺錢\r\n22=汽車\r\n23=攝影",
			    		),
			  	),
			  32 => array (
			    	'classid' => '3',
			    	'displayorder' => '0',
			    	'title' => '收入範圍',
			    	'identifier' => 'salary',
			    	'type' => 'select',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=保密\r\n2=800元以上\r\n3=1500元以上\r\n4=2000元以上\r\n5=3000元以上\r\n6=5000元以上\r\n7=8000元以上",
			    		),
			  	),
			  34 => array (
			    	'classid' => '1',
			    	'displayorder' => '0',
			    	'title' => '學歷',
			    	'identifier' => 'education',
			    	'type' => 'radio',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=文盲\r\n2=小學\r\n3=初中\r\n4=高中\r\n5=中專\r\n6=大專\r\n7=本科\r\n8=研究生\r\n9=博士",
			    		),
			  	),
			  38 => array (
			    	'classid' => '5',
			    	'displayorder' => '0',
			    	'title' => '席別',
			    	'identifier' => 'seats',
			    	'type' => 'select',
			    	'rules' => array (
			      			'choices' => "1=站票\r\n2=硬座\r\n3=軟座\r\n4=硬臥\r\n5=軟臥",
			    		),
			  	),
			  44 => array (
			    	'classid' => '4',
			    	'displayorder' => '0',
			    	'title' => '是否應屆',
			    	'identifier' => 'recr_term',
			    	'type' => 'radio',
			    	'rules' => array (
					      	'required' => '0',
					      	'unchangeable' => '0',
					      	'choices' => "1=應屆\r\n2=非應屆",
			    		),
			  	),
			  48 => array (
			    	'classid' => '4',
			    	'displayorder' => '0',
			    	'title' => '薪金',
			    	'identifier' => 'recr_salary',
			    	'type' => 'select',
			    	'rules' => array (
			      			'choices' => "1=面議\r\n2=1000以下\r\n3=1000~1500\r\n4=1500~2000\r\n5=2000~3000\r\n6=3000~4000\r\n7=4000~6000\r\n8=6000~8000\r\n9=8000以上",
			    		),
			  	),
			  50 => array (
			    	'classid' => '4',
			    	'displayorder' => '0',
			    	'title' => '工作性質',
			    	'identifier' => 'recr_work',
			    	'type' => 'radio',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=全職\r\n2=兼職",
			    		),
			  	),
			  53 => array (
			    	'classid' => '4',
			    	'displayorder' => '0',
			    	'title' => '性別要求',
			    	'identifier' => 'recr_sex',
			    	'type' => 'checkbox',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=男\r\n2=女",
			    		),
			  	),
			  62 => array (
			    	'classid' => '5',
			    	'displayorder' => '0',
			    	'title' => '付款方式',
			    	'identifier' => 'pay_type',
			    	'type' => 'checkbox',
			    	'rules' => array (
			      			'required' => '0',
			      			'unchangeable' => '0',
			      			'choices' => "1=電匯\r\n2=支付寶\r\n3=現金\r\n4=其他",
			    		),
			  	),
			);

		foreach($optionlist as $optionid => $option) {
			$db->query("REPLACE INTO {$tablepre}typeoptions VALUES ('$optionid', '$option[classid]', '$option[displayorder]', '$option[title]', '', '$option[identifier]', '$option[type]', '".addslashes(serialize($option['rules']))."');");
		}

		$db->query("ALTER TABLE {$tablepre}typeoptions AUTO_INCREMENT=3001");

		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 4) {

		runquery($upgrade4);

		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 5) {
		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 6) {

		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 7) {

		$lastid = $db->result($db->query("SELECT id FROM {$tablepre}bbcodes ORDER BY id DESC"), 0);
		$upgrade7 = preg_replace('/\{bbcodeid,(\d)\}/e', "\$lastid + \\1", $upgrade7);
		$lastid = $db->result($db->query("SELECT templateid FROM {$tablepre}templates ORDER BY templateid DESC"), 0);
		$upgrade7 = preg_replace('/\{templateid,(\d)\}/e', "\$lastid + \\1", $upgrade7);
		$lastid = $db->result($db->query("SELECT styleid FROM {$tablepre}styles ORDER BY styleid DESC"), 0);
		$upgrade7 = preg_replace('/\{styleid,(\d)\}/e', "\$lastid + \\1", $upgrade7);
		runquery($upgrade7);
		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 8) {

		$query = $db->query("SELECT value FROM {$tablepre}settings WHERE variable='insenz'");
		$insenz = ($insenz = $db->result($query, 0)) ? unserialize($insenz) : array();

		if(is_array($insenz['member_masks'])) {
			foreach($insenz['member_masks'] AS $uid => $username) {
				$db->query("UPDATE {$tablepre}members m, {$tablepre}usergroups u SET m.adminid=0, m.groupid=u.groupid WHERE m.uid='$uid' AND m.groupid='$insenz[groupid]' AND m.credits>u.creditshigher AND m.credits <=u.creditslower");
			}
		}

		$db->query("DELETE FROM {$tablepre}usergroups WHERE groupid='$insenz[groupid]' AND type='special'");

		unset($insenz['groupid'], $insenz['lastmodified'], $insenz['forums']);

		$insenz['jsurl'] = !empty($insenz['jsurl']) ? preg_replace("/http:\/\/a0(\d{1})\.insenz\.com\/adv\?sid=(\d+)/e", "'http://a0'.('\\2' % 8 + 1).'.insenz.com/adv?sid=\\2'", $insenz['jsurl']) : '';

		$insenz['topicstatus'] = 1;

		$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('insenz', '".addslashes(serialize($insenz))."')");

		$query = $db->query("SELECT value FROM {$tablepre}settings WHERE variable='videoinfo'");
		$settings = unserialize($db->result($query, 0));
		$settings['vpassword'] = $settings['vsitecode'];
		$settings['vkey'] = $settings['vauthcode'];
		$settings['sitetype'] = "新聞\t軍事\t音樂\t影視\t動漫\t遊戲\t美女\t娛樂\t交友\t教育\t藝術\t學術\t技術\t動物\t旅遊\t生活\t時尚\t電腦\t汽車\t手機\t攝影\t戲曲\t外語\t公益\t校園\t數碼\t電腦\t歷史\t天文\t地理\t財經\t地區\t人物\t體育\t健康\t綜合";
		$settings['vclasses'] = array (
			22 => '新聞',
			15 => '體育',
			27 => '教育',
			28 => '明星',
			26 => '美色',
			1 => '搞笑',
			29 => '另類',
			18 => '影視',
			12 => '音樂',
			8 => '動漫',
			7 => '遊戲',
			24 => '綜藝',
			11 => '廣告',
			19 => '藝術',
			5 => '時尚',
			21 => '居家',
			23 => '旅遊',
			25 => '動物',
			14 => '汽車',
			30 => '軍事',
			16 => '科技',
			31 => '其它'
		);
		$settings['vclassesable'] = array (22, 15, 27, 28, 26, 1, 29, 18, 12, 8, 7, 24, 11, 19, 5, 21, 23, 25, 14, 30, 16, 31);
		unset($settings['vsitecode']);
		unset($settings['vauthcode']);
		$settings = addslashes(serialize($settings));
		$db->query("UPDATE {$tablepre}settings SET value='$settings' WHERE variable='videoinfo'");

		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 9) {

		echo "第 $step 步升級成功<br /><br />";
		redirect("?action=upgrade&step=".($step+1));

	} else {

		dir_clear('./forumdata/cache');
		dir_clear('./forumdata/templates');

		$qihoo_items = "'qihoo_adminemail', 'qihoo_jammer', 'qihoo_keywords', 'qihoo_location', 'qihoo_maxtopics', 'qihoo_relatedthreads', 'qihoo_relatedsort', 'qihoo_searchbox', 'qihoo_status', 'qihoo_summary', 'qihoo_topics', 'qihoo_validity'";
		$qihoo = $settings = array();
		$query = $db->query("SELECT variable, value FROM {$tablepre}settings WHERE variable IN ($qihoo_items)");
		while($setting = $db->fetch_array($query)) {
			$settings[$setting['variable']] = $setting['value'];
		}
		$settings['qihoo_topics'] = !empty($settings['qihoo_topics']) ? unserialize($settings['qihoo_topics']) : array();
		$settings['qihoo_relatedthreads'] = !empty($settings['qihoo_relatedthreads']) ? unserialize($settings['qihoo_relatedthreads']) : array();
		foreach($settings AS $variable => $value) {
			$qihoo[substr($variable, 6)] = $value;
		}
		unset($qihoo['validity']);
		$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('qihoo', '".addslashes(serialize($qihoo))."')");
		$db->query("DELETE FROM {$tablepre}settings WHERE variable IN ($qihoo_items)");

		$query = $db->query("SELECT value FROM {$tablepre}settings WHERE variable='insenz'");
		$insenz = unserialize($db->result($query, 0));

		$insenz_message = '';
		if(empty($insenz['authkey'])) {
			$insenz_message = '<li><font color="red">'.$version_new.' 為您提供了 Insenz 社區營銷服務，幫助站長創造收益，提升社區價值，登錄論壇後台點擊「社區營銷」菜單即可註冊</font>';
		} elseif($insenz['softadstatus'] != 2) {
			$insenz_message = '<li><font color="red">您的社區營銷尚未開啟自動接受活動功能，為了保障您的利益，更快更多的接到廣告活動，並且得到更高的廣告費用，建議您立即登錄論壇後台，在「社區營銷 -- 營銷設置 -- 基本設置」中設置自動接受活動</font>';
		}

		echo '<br />恭喜您論壇數據升級成功，接下來請您：<ol><li><b>必刪除本程序</b>'.$insenz_message.
		'<li>使用管理員身份登錄論壇，進入後台，更新緩存'.
		'<li>進行論壇註冊、登錄、發貼等常規測試，看看運行是否正常'.
		'<li>如果您希望啟用 <b>'.$version_new.'</b> 提供的新功能，你還需要對於論壇基本設置、欄目、會員組等等進行重新設置</ol><br />'.
		'<b>感謝您選用我們的產品！</b><a href="index.php" target="_blank">您現在可以訪問論壇，查看升級情況</a><iframe width="0" height="0" src="index.php"></iframe>';
		showfooter();
	}
}

instfooter();

function createtable($sql, $dbcharset) {
	$type = strtoupper(preg_replace("/^\s*CREATE TABLE\s+.+\s+\(.+?\).*(ENGINE|TYPE)\s*=\s*([a-z]+?).*$/isU", "\\2", $sql));
	$type = in_array($type, array('MYISAM', 'HEAP')) ? $type : 'MYISAM';
	return preg_replace("/^\s*(CREATE TABLE\s+.+\s+\(.+?\)).*$/isU", "\\1", $sql).
	(mysql_get_server_info() > '4.1' ? " ENGINE=$type default CHARSET=$dbcharset" : " TYPE=$type");
}

function dir_clear($dir) {
	$directory = dir($dir);
	while($entry = $directory->read()) {
		$filename = $dir.'/'.$entry;
		if(is_file($filename)) {
			@unlink($filename);
		}
	}
	@touch($dir.'/index.htm');
	$directory->close();
}

function dir_writeable($dir) {
	if(!is_dir($dir)) {
		@mkdir($dir, 0777);
	}
	if(is_dir($dir)) {
		if($fp = @fopen("$dir/test.txt", 'w')) {
			@fclose($fp);
			@unlink("$dir/test.txt");
			$writeable = 1;
		} else {
			$writeable = 0;
		}
	}
	return $writeable;
}

function daddslashes($string) {
	if(is_array($string)) {
		foreach($string as $key => $val) {
			$string[$key] = daddslashes($val, $force);
		}
	} else {
		$string = addslashes($string);
	}
	return $string;
}

function instfooter() {
	echo '</table></body></html>';
}

function random($length, $numeric = 0) {
	PHP_VERSION < '4.2.0' && mt_srand((double)microtime() * 1000000);
	if($numeric) {
		$hash = sprintf('%0'.$length.'d', mt_rand(0, pow(10, $length) - 1));
	} else {
		$hash = '';
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
		$max = strlen($chars) - 1;
		for($i = 0; $i < $length; $i++) {
			$hash .= $chars[mt_rand(0, $max)];
		}
	}
	return $hash;
}

function runquery($query) {
	global $db, $tablepre, $dbcharset;

	$query = str_replace("\r", "\n", str_replace(' cdb_', ' '.$tablepre, $query));
	$expquery = explode(";\n", $query);
	foreach($expquery as $sql) {
		$sql = trim($sql);
		if($sql == '' || $sql[0] == '#') continue;

		if(strtoupper(substr($sql, 0, 12)) == 'CREATE TABLE') {
			$db->query(createtable($sql, $dbcharset));
		} else {
			$db->query($sql);
		}
	}
}

function loadtable($table, $force = 0) {
	global $db, $tablepre, $dbcharset;
	static $tables = array();

	if(!isset($tables[$table]) || $force) {
		if($db->version() > '4.1') {
			$query = $db->query("SHOW FULL COLUMNS FROM {$tablepre}$table", 'SILENT');
		} else {
			$query = $db->query("SHOW COLUMNS FROM {$tablepre}$table", 'SILENT');
		}
		while($field = @$db->fetch_array($query)) {
			$tables[$table][$field['Field']] = $field;
		}
	}
	return $tables[$table];
}

function upgradetable($updatesql) {
	global $db, $tablepre, $dbcharset;

	$successed = TRUE;

	if(is_array($updatesql) && !empty($updatesql[0])) {

		list($table, $action, $field, $sql) = $updatesql;

		if(empty($field) && !empty($sql)) {

			$query = "ALTER TABLE {$tablepre}{$table} ";
			if($action == 'INDEX') {
				$successed = $db->query("$query $sql", "SILENT");
			} elseif ($action == 'UPDATE') {
				$successed = $db->query("UPDATE {$tablepre}{$table} SET $sql", 'SILENT');
			}

		} elseif($tableinfo = loadtable($table)) {

			$fieldexist = isset($tableinfo[$field]) ? 1 : 0;

			$query = "ALTER TABLE {$tablepre}{$table} ";

			if($action == 'MODIFY') {

				$query .= $fieldexist ? "MODIFY $field $sql" : "ADD $field $sql";
				$successed = $db->query($query, 'SILENT');

			} elseif($action == 'CHANGE') {

				$field2 = trim(substr($sql, 0, strpos($sql, ' ')));
				$field2exist = isset($tableinfo[$field2]);

				if($fieldexist && ($field == $field2 || !$field2exist)) {
					$query .= "CHANGE $field $sql";
				} elseif($fieldexist && $field2exist) {
					$db->query("ALTER TABLE {$tablepre}{$table} DROP $field2", 'SILENT');
					$query .= "CHANGE $field $sql";
				} elseif(!$fieldexist && $fieldexist2) {
					$db->query("ALTER TABLE {$tablepre}{$table} DROP $field2", 'SILENT');
					$query .= "ADD $sql";
				} elseif(!$fieldexist && !$field2exist) {
					$query .= "ADD $sql";
				}
				$successed = $db->query($query);

			} elseif($action == 'ADD') {

				$query .= $fieldexist ? "CHANGE $field $field $sql" :  "ADD $field $sql";
				$successed = $db->query($query);

			} elseif($action == 'DROP') {
				if($fieldexist) {
					$successed = $db->query("$query DROP $field", "SILENT");
				}
				$successed = TRUE;
			}

		} else {

			$successed = 'TABLE NOT EXISTS';

		}
	}
	return $successed;
}

function showheader() {
	global $version_old, $version_new;

	print <<< EOT
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Discuz! 升級程序( $version_old &gt;&gt; $version_new)</title>
<meta name="MSSmartTagsPreventParsing" content="TRUE">
<meta http-equiv="MSThemeCompatible" content="Yes">
<style>
a:visited	{color: #FF0000; text-decoration: none}
a:link		{color: #FF0000; text-decoration: none}
a:hover		{color: #FF0000; text-decoration: underline}
body,table,td	{color: #3a4273; font-family: Tahoma, verdana, arial; font-size: 12px; line-height: 20px; scrollbar-base-color: #e3e3ea; scrollbar-arrow-color: #5c5c8d}
input		{color: #085878; font-family: Tahoma, verdana, arial; font-size: 12px; background-color: #3a4273; color: #ffffff; scrollbar-base-color: #e3e3ea; scrollbar-arrow-color: #5c5c8d}
.install	{font-family: Arial, Verdana; font-size: 14px; font-weight: bold; color: #000000}
.header		{font: 12px Tahoma, Verdana; font-weight: bold; background-color: #3a4273 }
.header	td	{color: #ffffff}
.red		{color: red; font-weight: bold}
.bg1		{background-color: #e3e3ea}
.bg2		{background-color: #eeeef6}
</style>
</head>

<body bgcolor="#3A4273" text="#000000">
<table width="95%" height="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center">
<tr>
<td>
<table width="98%" border="0" cellspacing="0" cellpadding="0" align="center">
<tr>
<td class="install" height="30" valign="bottom"><font color="#FF0000">&gt;&gt;</font>
Discuz! 升級程序( $version_old &gt;&gt; $version_new)</td>
</tr>
<tr>
<td>
<hr noshade align="center" width="100%" size="1">
</td>
</tr>
<tr>
<td align="center">
<b>本升級程序只能從 $version_old 升級到 $version_new ，運行之前，請確認已經上傳所有文件，並做好數據備份<br />
升級當中有任何問題請訪問技術支持站點 <a href="http://www.discuz.net" target="_blank">http://www.discuz.net</a></b>
</td>
</tr>
<tr>
<td>
<hr noshade align="center" width="100%" size="1">
</td>
</tr>
<tr><td>
EOT;
}

function showfooter() {
	echo <<< EOT
</td></tr></table></td></tr>
<tr><td height="100%">&nbsp;</td></tr>
</table>
</body>
</html>
EOT;
	exit();
}

function showerror($message, $break = 1) {
	echo '<br /><br />'.$message.'<br /><br />';
	if($break) showfooter();
}

function redirect($url) {

	echo <<< EOT
<hr size=1>
<script language="JavaScript">
	function redirect() {
		window.location.replace('$url');
	}
	setTimeout('redirect();', 1000);
</script>
<br /><br />
&gt;&gt;<a href="$url">瀏覽器會自動跳轉頁面，無需人工干預。除非當您的瀏覽器長時間沒有自動跳轉時，請點擊這裡</a>
<br /><br />
EOT;
	showfooter();
}



?>