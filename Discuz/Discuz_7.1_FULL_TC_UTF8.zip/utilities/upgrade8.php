<?php

// Upgrade Discuz! Board from 5.0.0 to 5.5.0
error_reporting(E_ERROR | E_WARNING | E_PARSE);
@set_magic_quotes_runtime(0);

@set_time_limit(1000);

define('IN_DISCUZ', TRUE);
define('DISCUZ_ROOT', './');

$version_old = 'Discuz! 5.0.0';
$version_new = 'Discuz! 5.5.0';
$timestamp = time();

@include("./config.inc.php");
@include("./include/db_mysql.class.php");

header("Content-Type: text/html; charset=$charset");
showheader();

if(empty($dbcharset) && in_array(strtolower($charset), array('gbk', 'big5', 'utf-8'))) {
	$dbcharset = str_replace('-', '', $charset);
}

if(PHP_VERSION < '4.1.0') {
	$_GET = &$HTTP_GET_VARS;
	$_POST = &$HTTP_POST_VARS;
	$_COOKIE = &$HTTP_COOKIE_VARS;
	$_SERVER = &$HTTP_SERVER_VARS;
	$_ENV = &$HTTP_ENV_VARS;
	$_FILES = &$HTTP_POST_FILES;
}

$action = ($_POST['action']) ? $_POST['action'] : $_GET['action'];
$step = $_GET['step'];
$start = $_GET['start'];

$upgrade1 = <<<EOT

REPLACE INTO cdb_settings (variable, value) VALUES ('spacecachelife', 1800);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacelimitmythreads', 5);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacelimitmyreplies', 5);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacelimitmyrewards', 0);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacelimitmytrades', 0);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacelimitmyblogs', 8);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacelimitmyfriends', 0);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacelimitmyfavforums', 5);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacelimitmyfavthreads', 0);
REPLACE INTO cdb_settings (variable, value) VALUES ('spacetextlength', 300);
REPLACE INTO cdb_settings (variable, value) VALUES ('thumbstatus', 0);
REPLACE INTO cdb_settings (variable, value) VALUES ('thumbwidth', 400);
REPLACE INTO cdb_settings (variable, value) VALUES ('thumbheight', 300);
REPLACE INTO cdb_settings (variable, value) VALUES ('forumlinkstatus', 1);
REPLACE INTO cdb_settings (variable, value) VALUES ('pluginjsmenu', '插件');
REPLACE INTO cdb_settings (variable, value) VALUES ('magicstatus', '1');
REPLACE INTO cdb_settings (variable, value) VALUES ('magicmarket', '1');
REPLACE INTO cdb_settings (variable, value) VALUES ('maxmagicprice', '50');
REPLACE INTO cdb_settings (variable, value) VALUES ('jswizard', '');
REPLACE INTO cdb_settings (variable, value) VALUES ('passport_shopex', 0);
REPLACE INTO cdb_settings (variable, value) VALUES ('seccodeanimator', 1);
REPLACE INTO cdb_settings (variable, value) VALUES ('welcomemsgtitle', '{username}，您好，感謝您的註冊，請閱讀以下內容。');
REPLACE INTO cdb_settings (variable, value) VALUES ('welcomemsgtxt', '尊敬的{username}，您已經註冊成為{sitename}的會員，請您在發表言論時，遵守當地法律法規。\r\n如果您有什麼疑問可以聯繫管理員，Email: {adminemail}。\r\n\r\n\r\n{bbname}\r\n{time}');
REPLACE INTO cdb_settings (variable, value) values ('cacheindexlife', '0');
REPLACE INTO cdb_settings (variable, value) values ('cachethreadlife', '0');
REPLACE INTO cdb_settings (variable, value) values ('cachethreaddir', 'forumdata/threadcaches');
REPLACE INTO cdb_settings (variable, value) values ('jsdateformat', '');
REPLACE INTO cdb_settings (variable, value) VALUES ('seccodedata', '');
REPLACE INTO cdb_settings (variable, value) values ('frameon', '0');
REPLACE INTO cdb_settings (variable, value) values ('framewidth', '180');
REPLACE INTO cdb_settings (variable, value) VALUES ('smrows', '4');
REPLACE INTO cdb_settings (variable, value) VALUES ('watermarktype', '0');
REPLACE INTO cdb_settings (variable, value) VALUES ('spacestatus', 1);
REPLACE INTO cdb_settings (variable, value) VALUES ('whosonline_contract', 0);
REPLACE INTO cdb_settings (variable, value) VALUES ('attachdir', './attachments');
REPLACE INTO cdb_settings (variable, value) VALUES ('attachurl', 'attachments');
REPLACE INTO cdb_settings (variable, value) VALUES ('onlinehold', '15');
REPLACE INTO cdb_settings (variable, value) VALUES ('wapregister', '0');
REPLACE INTO cdb_settings (variable, value) VALUES ('msgforward', 'a:3:{s:11:\"refreshtime\";i:1;s:5:\"quick\";i:1;s:8:\"messages\";a:13:{i:0;s:19:\"thread_poll_succeed\";i:1;s:19:\"thread_rate_succeed\";i:2;s:23:\"usergroups_join_succeed\";i:3;s:23:\"usergroups_exit_succeed\";i:4;s:25:\"usergroups_update_succeed\";i:5;s:20:\"buddy_update_succeed\";i:6;s:17:\"post_edit_succeed\";i:7;s:18:\"post_reply_succeed\";i:8;s:24:\"post_edit_delete_succeed\";i:9;s:22:\"post_newthread_succeed\";i:10;s:13:\"admin_succeed\";i:11;s:17:\"pm_delete_succeed\";i:12;s:15:\"search_redirect\";}}');
REPLACE INTO cdb_settings (variable, value) VALUES ('forumjump','0');
REPLACE INTO cdb_settings (variable, value) VALUES ('ftp', 'a:10:{s:2:\"on\";s:1:\"0\";s:3:\"ssl\";s:1:\"0\";s:4:\"host\";s:0:\"\";s:4:\"port\";s:2:\"21\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"attachdir\";s:1:\".\";s:9:\"attachurl\";s:0:\"\";s:7:\"hideurl\";s:1:\"0\";s:7:\"timeout\";s:1:\"0\";}');
REPLACE INTO cdb_settings (variable, value) VALUES ('secqaa', 'a:2:{s:8:\"minposts\";s:1:\"1\";s:6:\"status\";i:0;}');
REPLACE INTO cdb_settings (variable, value) values ('smthumb','20');

DELETE FROM cdb_settings WHERE variable IN ('qihoo_searchboxtxt', 'qihoo_ustyle', 'qihoo_allsearch');
DELETE FROM cdb_settings WHERE variable='avatarshowwidth';
DELETE FROM cdb_settings WHERE variable='avatarshowstatus';
DELETE FROM cdb_settings WHERE variable='avatarshowpos';
DELETE FROM cdb_settings WHERE variable='avatarshowlink';
DELETE FROM cdb_settings WHERE variable='avatarshowheight';
DELETE FROM cdb_settings WHERE variable='avatarshowdefault';

EOT;

$upgradetable = array(

	array('usergroups', 'CHANGE', 'minrewardprice', "minrewardprice smallint(6) NOT NULL default '1'"),
	array('usergroups', 'CHANGE', 'maxrewardprice', "maxrewardprice smallint(6) NOT NULL default '0'"),
	array('usergroups', 'ADD', 'magicsdiscount', "tinyint(1) NOT NULL default '0'"),
	array('usergroups', 'ADD', 'allowmagics', "tinyint(1) unsigned NOT NULL default '1'"),
	array('usergroups', 'ADD', 'maxmagicsweight', "smallint(6) unsigned NOT NULL default '100'"),
	array('usergroups', 'ADD', 'allowbiobbcode', "tinyint(1) unsigned NOT NULL default '0'"),
	array('usergroups', 'ADD', 'allowbioimgcode', "tinyint(1) unsigned NOT NULL default '0'"),
	array('usergroups', 'ADD', 'maxbiosize', "smallint(6) unsigned NOT NULL default '0'"),

	array('forums', 'ADD', 'alloweditpost', "tinyint(1) unsigned NOT NULL default '1'"),
	array('forums', 'ADD', 'simple', "tinyint(1) unsigned NOT NULL default '0'"),
	array('forums', 'ADD', 'allowspecialonly', "tinyint(1) unsigned NOT NULL default '0' AFTER allowpostspecial"),

	array('attachments', 'ADD', 'thumb', "tinyint(1) unsigned NOT NULL default '0'"),
	array('attachments', 'ADD', 'price', "smallint(6) unsigned not NULL default '0' AFTER readperm"),
	array('attachments', 'ADD', 'remote', "tinyint(1) unsigned NOT NULL default '0'"),

	array('threadsmod', 'ADD', 'magicid', "smallint(6) unsigned NOT NULL"),
	array('threadsmod', 'CHANGE', 'action', "action CHAR(5) NOT NULL"),

	array('announcements', 'CHANGE', 'redirect', "type tinyint(1) NOT NULL default '0'"),
	array('announcements', 'ADD', 'groups', "text NOT NULL"),

	array('activityapplies', 'ADD', 'contact', "CHAR(200) NOT NULL"),

	array('forumlinks', 'CHANGE', 'note', "description mediumtext NOT NULL"),

	array('sessions', 'CHANGE', 'seccode', "seccode mediumint(6) unsigned NOT NULL default '0'"),

	array('bbcodes', 'ADD', 'prompt', "TEXT NOT NULL AFTER params"),

	array('memberfields', 'ADD', 'spacename', "varchar(40) NOT NULL"),
	array('memberfields', 'DROP', 'signature', ""),

	array('members', 'DROP', 'avatarshowid', ""),

	array('pms', 'ADD', 'delstatus', "tinyint(1) unsigned NOT NULL default '0'"),

);

$upgrade2 = <<<EOT

UPDATE cdb_forums SET alloweditpost=1;
UPDATE cdb_usergroups SET maxmagicsweight=100 WHERE groupid<4 OR groupid>9;

UPDATE cdb_bbcodes SET prompt = '請輸入滾動顯示的文字:' WHERE `tag` ='fly';
UPDATE cdb_bbcodes SET prompt = '請輸入 Flash 動畫的 URL:' WHERE `tag` ='flash';
UPDATE cdb_bbcodes SET prompt = '請輸入顯示在線狀態 QQ 號碼:' WHERE `tag` ='qq';
UPDATE cdb_bbcodes SET prompt = '請輸入 Real 音頻的 URL:' WHERE `tag` ='ra';
UPDATE cdb_bbcodes SET prompt = '請輸入 Real 音頻或視頻的 URL:' WHERE `tag` ='rm';
UPDATE cdb_bbcodes SET prompt = '請輸入 Windows media 音頻的 URL:' WHERE `tag` ='wma';
UPDATE cdb_bbcodes SET prompt = '請輸入 Windows media 音頻或視頻的 URL:' WHERE `tag` ='wmv';
UPDATE cdb_bbcodes SET replacement='<object classid="clsid:CFCDAA03-8BE4-11CF-B84B-0020AFBBCCFA" width="400" height="30"><param name="src" value="{1}" /><param name="controls" value="controlpanel" /><param name="console" value="{RANDOM}" /><embed src="{1}" type="audio/x-pn-realaudio-plugin" console="{RANDOM}" controls="ControlPanel" width="400" height="30"></embed></object>' WHERE tag='ra';
UPDATE cdb_bbcodes SET replacement='<br /><object classid="clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA" width="480" height="360"><param name="src" value="{1}" /><param name="controls" value="imagewindow" /><param name="console" value="{MD5}" /><embed src="{1}" type="audio/x-pn-realaudio-plugin" controls="IMAGEWINDOW" console="{MD5}" width="480" height="360"></embed></object><br /><object classid="CLSID:CFCDAA03-8BE4-11CF-B84B-0020AFBBCCFA" width="480" height="32"><param name="src" value="{1}" /><param name="controls" value="controlpanel" /><param name="console" value="{MD5}" /><embed src="{1}" type="audio/x-pn-realaudio-plugin" controls="ControlPanel" console="{MD5}" width="480" height="32"></embed></object><br />'  WHERE tag='rm';
UPDATE cdb_bbcodes SET replacement='<object classid="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" width="260" height="64"><param name="autostart" value="0" /><param name="url" value="{1}" /><embed src="{1}" autostart="0" type="video/x-ms-wmv" width="260" height="42"></embed></object>'  WHERE tag='wma';
UPDATE cdb_bbcodes SET replacement='<object classid="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" width="500" height="400"><param name="autostart" value="0" /><param name="url" value="{1}" /><embed src="{1}" autostart="0" type="video/x-ms-wmv" width="500" height="400"></embed></object>'  WHERE tag='wmv';
UPDATE cdb_crons SET filename = 'threadexpiries_hourly.inc.php' WHERE filename = 'threadexpiries_daily.inc.php';

EOT;

$upgrade4 = <<<EOT

UPDATE cdb_posts SET invisible='-2' WHERE invisible='2';

EOT;

$upgrade6 = <<<EOT

DROP TABLE IF EXISTS cdb_spacecaches;
CREATE TABLE cdb_spacecaches (
  uid mediumint(8) unsigned NOT NULL default '0',
  variable varchar(20) NOT NULL,
  value text NOT NULL,
  expiration int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (uid, variable)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_memberspaces;
CREATE TABLE cdb_memberspaces (
  uid mediumint(8) unsigned NOT NULL default '0',
  style char(20) NOT NULL,
  description char(100) NOT NULL,
  layout char(200) NOT NULL,
  side tinyint(1) NOT NULL default '0',
  PRIMARY KEY (uid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_attachpaymentlog;
CREATE TABLE cdb_attachpaymentlog (
  uid mediumint(8) unsigned NOT NULL default '0',
  aid mediumint(8) unsigned NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  amount int(10) unsigned NOT NULL default '0',
  netamount int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (aid,uid),
  KEY uid (uid),
  KEY authorid (authorid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_magics;
CREATE TABLE cdb_magics (
  magicid smallint(6) unsigned NOT NULL auto_increment,
  available tinyint(1) NOT NULL default '0',
  type tinyint(3) NOT NULL default '0',
  name varchar(50) NOT NULL,
  identifier varchar(40) NOT NULL,
  description varchar(255) NOT NULL,
  displayorder tinyint(3) NOT NULL default '0',
  price mediumint(8) unsigned NOT NULL default '0',
  num smallint(6) unsigned NOT NULL default '0',
  salevolume smallint(6) unsigned NOT NULL default '0',
  supplytype tinyint(1) NOT NULL default '0',
  supplynum smallint(6) unsigned NOT NULL default '0',
  weight tinyint(3) unsigned NOT NULL default '1',
  filename varchar(50) NOT NULL,
  magicperm text NOT NULL,
  PRIMARY KEY  (magicid),
  UNIQUE KEY identifier (identifier),
  KEY displayorder (available,displayorder)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_magiclog;
CREATE TABLE cdb_magiclog (
  uid mediumint(8) unsigned NOT NULL default '0',
  magicid smallint(6) unsigned NOT NULL default '0',
  action tinyint(1) NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  amount smallint(6) unsigned NOT NULL default '0',
  price mediumint(8) unsigned NOT NULL default '0',
  targettid mediumint(8) unsigned NOT NULL default '0',
  targetpid int(10) unsigned NOT NULL default '0',
  targetuid mediumint(8) unsigned NOT NULL default '0',
  KEY uid (uid,dateline),
  KEY targetuid (targetuid,dateline)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_magicmarket;
CREATE TABLE cdb_magicmarket (
  mid smallint(6) unsigned NOT NULL auto_increment,
  magicid smallint(6) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL,
  price mediumint(8) unsigned NOT NULL default '0',
  num smallint(6) unsigned NOT NULL default '0',
  PRIMARY KEY (mid),
  KEY num (magicid,num),
  KEY price (magicid,price),
  KEY uid (uid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_membermagics;
CREATE TABLE cdb_membermagics (
  uid mediumint(8) unsigned NOT NULL default '0',
  magicid smallint(6) unsigned NOT NULL default '0',
  num smallint(6) unsigned NOT NULL default '0',
  KEY uid (uid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_projects;
CREATE TABLE cdb_projects (
  id smallint(6) unsigned NOT NULL auto_increment auto_increment,
  name varchar(50) NOT NULL,
  type varchar(10) NOT NULL,
  description varchar(255) NOT NULL,
  value mediumtext NOT NULL,
  PRIMARY KEY (id),
  KEY type (type)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_itempool;
CREATE TABLE cdb_itempool (
  id smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  type tinyint(1) unsigned NOT NULL,
  question text NOT NULL,
  answer varchar(50) NOT NULL,
  PRIMARY KEY (id)
) TYPE=MyISAM;

DROP TABLE IF EXISTS cdb_faqs;
CREATE TABLE cdb_faqs (
  id smallint(6) NOT NULL auto_increment,
  fpid smallint(6) unsigned NOT NULL default '0',
  displayorder tinyint(3) NOT NULL default '0',
  identifier varchar(20) NOT NULL,
  keyword varchar(50) NOT NULL,
  title varchar(50) NOT NULL,
  message text NOT NULL,
  PRIMARY KEY (id),
  KEY displayplay (displayorder)
) TYPE=MyISAM  AUTO_INCREMENT=35;

EOT;

$upgrade7 = <<<EOT

INSERT INTO cdb_magics (magicid, available, type, name, identifier, description, displayorder, price, num, salevolume, supplytype, supplynum, weight, filename, magicperm) VALUES
	('1','1','1','變色卡','CCK','可以變換主題的顏色,並保存24小時','0','10','999','0','0','0','30','magic_color.inc.php',''),
	('2','1','3','金錢卡','MOK','可以隨機獲得一些金幣','0','10','999','0','0','0','30','magic_money.inc.php',''),
	('3','1','1','IP卡','SEK','可以查看帖子作者的IP','0','15','999','0','0','0','30','magic_see.inc.php',''),
	('4','1','1','提升卡','UPK','可以提升某個主題','0','10','999','0','0','0','30','magic_up.inc.php',''),
	('5','1','1','置頂卡','TOK','可以將主題置頂24小時','0','20','999','0','0','0','40','magic_top.inc.php',''),
	('6','1','1','悔悟卡','REK','可以刪除自己的帖子','0','10','999','0','0','0','30','magic_del.inc.php',''),
	('7','1','2','狗仔卡','RTK','查看某個用戶是否在線','0','15','999','0','0','0','30','magic_reporter.inc.php',''),
	('8','1','1','沉默卡','CLK','24小時內不能回復','0','15','999','0','0','0','30','magic_close.inc.php',''),
	('9','1','1','喧囂卡','OPK','使貼子可以回復','0','15','999','0','0','0','30','magic_open.inc.php',''),
	('10','1','1','隱身卡','YSK','可以將自己的帖子匿名','0','20','999','0','0','0','30','magic_hidden.inc.php',''),
	('11','1','1','恢復卡','CBK','將匿名恢復為正常顯示的用戶名,匿名終結者','0','15','999','0','0','0','20','magic_renew.inc.php',''),
	('12','1','1','移動卡','MVK','可將自已的帖子移動到其他版面（隱含、特殊限定版面除外）','0','50','989','0','0','0','50','magic_move.inc.php','');

INSERT INTO cdb_projects (name, type, description, value) VALUES
	('技術性論壇', 'extcredit', '如果您不希望會員通過灌水、頁面訪問等方式得到積分，而是需要發佈一些技術性的帖子獲得積分。', 'a:4:{s:10:\"savemethod\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:14:\"creditsformula\";s:49:\"posts*0.5+digestposts*5+extcredits1*2+extcredits2\";s:13:\"creditspolicy\";s:299:\"a:12:{s:4:\"post\";a:0:{}s:5:\"reply\";a:0:{}s:6:\"digest\";a:1:{i:1;i:10;}s:10:\"postattach\";a:0:{}s:9:\"getattach\";a:0:{}s:2:\"pm\";a:0:{}s:6:\"search\";a:0:{}s:15:\"promotion_visit\";a:1:{i:3;i:2;}s:18:\"promotion_register\";a:1:{i:3;i:2;}s:13:\"tradefinished\";a:0:{}s:8:\"votepoll\";a:0:{}s:10:\"lowerlimit\";a:0:{}}\";s:10:\"extcredits\";s:1444:\"a:8:{i:1;a:8:{s:5:\"title\";s:4:\"威望\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:2;a:8:{s:5:\"title\";s:4:\"金錢\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:3;a:8:{s:5:\"title\";s:4:\"貢獻\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:4;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:5;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:6;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:7;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:8;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}}\";}'),
  	('娛樂性論壇', 'extcredit', '此類型論壇的會員可以通過發佈一些評論、回復等獲得積分，同時擴大論壇的訪問量。更重要的是希望會員發佈一些有價值的娛樂新聞等。', 'a:4:{s:10:\"savemethod\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:14:\"creditsformula\";s:81:\"posts+digestposts*5+oltime*5+pageviews/1000+extcredits1*2+extcredits2+extcredits3\";s:13:\"creditspolicy\";s:315:\"a:12:{s:4:\"post\";a:1:{i:1;i:1;}s:5:\"reply\";a:1:{i:2;i:1;}s:6:\"digest\";a:1:{i:1;i:10;}s:10:\"postattach\";a:0:{}s:9:\"getattach\";a:0:{}s:2:\"pm\";a:0:{}s:6:\"search\";a:0:{}s:15:\"promotion_visit\";a:1:{i:3;i:2;}s:18:\"promotion_register\";a:1:{i:3;i:2;}s:13:\"tradefinished\";a:0:{}s:8:\"votepoll\";a:0:{}s:10:\"lowerlimit\";a:0:{}}\";s:10:\"extcredits\";s:1036:\"a:8:{i:1;a:6:{s:5:\"title\";s:4:\"威望\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;}i:2;a:6:{s:5:\"title\";s:4:\"金錢\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;}i:3;a:6:{s:5:\"title\";s:4:\"貢獻\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;}i:4;a:6:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;}i:5;a:6:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;}i:6;a:6:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;}i:7;a:6:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;}i:8;a:6:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;}}\";}'),
  	('動漫、攝影類論壇', 'extcredit', '此類型論壇需要更多的圖片附件發佈給廣大會員，因此增加一項擴展積分：魅力。', 'a:4:{s:10:\"savemethod\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:14:\"creditsformula\";s:86:\"posts+digestposts*2+pageviews/2000+extcredits1*2+extcredits2+extcredits3+extcredits4*3\";s:13:\"creditspolicy\";s:324:\"a:12:{s:4:\"post\";a:1:{i:2;i:1;}s:5:\"reply\";a:0:{}s:6:\"digest\";a:1:{i:1;i:10;}s:10:\"postattach\";a:1:{i:4;i:3;}s:9:\"getattach\";a:1:{i:2;i:-2;}s:2:\"pm\";a:0:{}s:6:\"search\";a:0:{}s:15:\"promotion_visit\";a:1:{i:3;i:2;}s:18:\"promotion_register\";a:1:{i:3;i:2;}s:13:\"tradefinished\";a:0:{}s:8:\"votepoll\";a:0:{}s:10:\"lowerlimit\";a:0:{}}\";s:10:\"extcredits\";s:1454:\"a:8:{i:1;a:8:{s:5:\"title\";s:4:\"威望\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:2;a:8:{s:5:\"title\";s:4:\"金錢\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:3;a:8:{s:5:\"title\";s:4:\"貢獻\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:4;a:8:{s:5:\"title\";s:4:\"魅力\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:5;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:6;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:7;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:8;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}}\";}'),
 	('文章、小說類論壇', 'extcredit', '此類型的論壇更重視會員的原創文章或者是轉發的文章，因此增加一項擴展積分：文采。', 'a:4:{s:10:\"savemethod\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:14:\"creditsformula\";s:57:\"posts+digestposts*8+extcredits2+extcredits3+extcredits4*2\";s:13:\"creditspolicy\";s:307:\"a:12:{s:4:\"post\";a:1:{i:2;i:1;}s:5:\"reply\";a:0:{}s:6:\"digest\";a:1:{i:4;i:10;}s:10:\"postattach\";a:0:{}s:9:\"getattach\";a:0:{}s:2:\"pm\";a:0:{}s:6:\"search\";a:0:{}s:15:\"promotion_visit\";a:1:{i:3;i:2;}s:18:\"promotion_register\";a:1:{i:3;i:2;}s:13:\"tradefinished\";a:0:{}s:8:\"votepoll\";a:0:{}s:10:\"lowerlimit\";a:0:{}}\";s:10:\"extcredits\";s:1454:\"a:8:{i:1;a:8:{s:5:\"title\";s:4:\"威望\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:2;a:8:{s:5:\"title\";s:4:\"金錢\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:3;a:8:{s:5:\"title\";s:4:\"貢獻\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:4;a:8:{s:5:\"title\";s:4:\"文采\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:5;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:6;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:7;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:8;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}}\";}'),
	('調研性論壇', 'extcredit', '此類型論壇更期望的是得到會員的建議和意見，主要是通過投票的方式體現會員的建議，因此增加一項積分策略為：參加投票，增加一項擴展積分為：積極性。', 'a:4:{s:10:\"savemethod\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:14:\"creditsformula\";s:63:\"posts*0.5+digestposts*2+extcredits1*2+extcredits3+extcredits4*2\";s:13:\"creditspolicy\";s:306:\"a:12:{s:4:\"post\";a:0:{}s:5:\"reply\";a:0:{}s:6:\"digest\";a:1:{i:1;i:8;}s:10:\"postattach\";a:0:{}s:9:\"getattach\";a:0:{}s:2:\"pm\";a:0:{}s:6:\"search\";a:0:{}s:15:\"promotion_visit\";a:1:{i:3;i:2;}s:18:\"promotion_register\";a:1:{i:3;i:2;}s:13:\"tradefinished\";a:0:{}s:8:\"votepoll\";a:1:{i:4;i:5;}s:10:\"lowerlimit\";a:0:{}}\";s:10:\"extcredits\";s:1456:\"a:8:{i:1;a:8:{s:5:\"title\";s:4:\"威望\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:2;a:8:{s:5:\"title\";s:4:\"金錢\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:3;a:8:{s:5:\"title\";s:4:\"貢獻\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:4;a:8:{s:5:\"title\";s:6:\"積極性\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:5;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:6;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:7;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:8;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}}\";}'),
	('貿易性論壇', 'extcredit', '此類型論壇更注重的是會員之間的交易，因此使用積分策略：交易成功，增加一項擴展積分：誠信度。', 'a:4:{s:10:\"savemethod\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:14:\"creditsformula\";s:55:\"posts+digestposts+extcredits1*2+extcredits3+extcredits4\";s:13:\"creditspolicy\";s:306:\"a:12:{s:4:\"post\";a:0:{}s:5:\"reply\";a:0:{}s:6:\"digest\";a:1:{i:1;i:5;}s:10:\"postattach\";a:0:{}s:9:\"getattach\";a:0:{}s:2:\"pm\";a:0:{}s:6:\"search\";a:0:{}s:15:\"promotion_visit\";a:1:{i:3;i:2;}s:18:\"promotion_register\";a:1:{i:3;i:2;}s:13:\"tradefinished\";a:1:{i:4;i:6;}s:8:\"votepoll\";a:0:{}s:10:\"lowerlimit\";a:0:{}}\";s:10:\"extcredits\";s:1456:\"a:8:{i:1;a:8:{s:5:\"title\";s:4:\"威望\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:2;a:8:{s:5:\"title\";s:4:\"金錢\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:3;a:8:{s:5:\"title\";s:4:\"貢獻\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:4;a:8:{s:5:\"title\";s:6:\"誠信度\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";s:1:\"1\";s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:5;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:6;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:7;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}i:8;a:8:{s:5:\"title\";s:0:\"\";s:4:\"unit\";s:0:\"\";s:5:\"ratio\";i:0;s:9:\"available\";N;s:10:\"lowerlimit\";i:0;s:12:\"showinthread\";N;s:15:\"allowexchangein\";N;s:16:\"allowexchangeout\";N;}}\";}'),
	('壇內事務類版塊', 'forum', '該板塊設置了不允許其他模塊共享，以及設置了需要很高的權限才能瀏覽該版塊。也適合於保密性高版塊。', 'a:33:{s:7:\"styleid\";s:1:\"0\";s:12:\"allowsmilies\";s:1:\"1\";s:9:\"allowhtml\";s:1:\"0\";s:11:\"allowbbcode\";s:1:\"1\";s:12:\"allowimgcode\";s:1:\"1\";s:14:\"allowanonymous\";s:1:\"0\";s:10:\"allowshare\";s:1:\"0\";s:16:\"allowpostspecial\";s:1:\"0\";s:14:\"alloweditrules\";s:1:\"1\";s:10:\"recyclebin\";s:1:\"1\";s:11:\"modnewposts\";s:1:\"0\";s:6:\"jammer\";s:1:\"0\";s:16:\"disablewatermark\";s:1:\"0\";s:12:\"inheritedmod\";s:1:\"0\";s:9:\"autoclose\";s:1:\"0\";s:12:\"forumcolumns\";s:1:\"0\";s:12:\"threadcaches\";s:2:\"40\";s:16:\"allowpaytoauthor\";s:1:\"0\";s:13:\"alloweditpost\";s:1:\"1\";s:6:\"simple\";s:1:\"0\";s:11:\"postcredits\";s:0:\"\";s:12:\"replycredits\";s:0:\"\";s:16:\"getattachcredits\";s:0:\"\";s:17:\"postattachcredits\";s:0:\"\";s:13:\"digestcredits\";s:0:\"\";s:16:\"attachextensions\";s:0:\"\";s:11:\"threadtypes\";s:0:\"\";s:8:\"viewperm\";s:7:\"	1	2	3	\";s:8:\"postperm\";s:7:\"	1	2	3	\";s:9:\"replyperm\";s:7:\"	1	2	3	\";s:13:\"getattachperm\";s:7:\"	1	2	3	\";s:14:\"postattachperm\";s:7:\"	1	2	3	\";s:16:\"supe_pushsetting\";s:0:\"\";}'),
	('技術交流類版塊', 'forum', '該設置開啟了主題緩存係數。其他的權限設置級別較低。', 'a:33:{s:7:\"styleid\";s:1:\"0\";s:12:\"allowsmilies\";s:1:\"1\";s:9:\"allowhtml\";s:1:\"0\";s:11:\"allowbbcode\";s:1:\"1\";s:12:\"allowimgcode\";s:1:\"1\";s:14:\"allowanonymous\";s:1:\"0\";s:10:\"allowshare\";s:1:\"1\";s:16:\"allowpostspecial\";s:1:\"5\";s:14:\"alloweditrules\";s:1:\"0\";s:10:\"recyclebin\";s:1:\"1\";s:11:\"modnewposts\";s:1:\"0\";s:6:\"jammer\";s:1:\"0\";s:16:\"disablewatermark\";s:1:\"0\";s:12:\"inheritedmod\";s:1:\"0\";s:9:\"autoclose\";s:1:\"0\";s:12:\"forumcolumns\";s:1:\"0\";s:12:\"threadcaches\";s:2:\"40\";s:16:\"allowpaytoauthor\";s:1:\"1\";s:13:\"alloweditpost\";s:1:\"1\";s:6:\"simple\";s:1:\"0\";s:11:\"postcredits\";s:0:\"\";s:12:\"replycredits\";s:0:\"\";s:16:\"getattachcredits\";s:0:\"\";s:17:\"postattachcredits\";s:0:\"\";s:13:\"digestcredits\";s:0:\"\";s:16:\"attachextensions\";s:0:\"\";s:11:\"threadtypes\";s:0:\"\";s:8:\"viewperm\";s:0:\"\";s:8:\"postperm\";s:0:\"\";s:9:\"replyperm\";s:0:\"\";s:13:\"getattachperm\";s:0:\"\";s:14:\"postattachperm\";s:0:\"\";s:16:\"supe_pushsetting\";s:0:\"\";}'),
	('發佈公告類版塊', 'forum', '該設置開啟了發帖審核，限制了允許發帖的用戶組。', 'a:33:{s:7:\"styleid\";s:1:\"0\";s:12:\"allowsmilies\";s:1:\"1\";s:9:\"allowhtml\";s:1:\"0\";s:11:\"allowbbcode\";s:1:\"1\";s:12:\"allowimgcode\";s:1:\"1\";s:14:\"allowanonymous\";s:1:\"0\";s:10:\"allowshare\";s:1:\"1\";s:16:\"allowpostspecial\";s:1:\"1\";s:14:\"alloweditrules\";s:1:\"0\";s:10:\"recyclebin\";s:1:\"1\";s:11:\"modnewposts\";s:1:\"1\";s:6:\"jammer\";s:1:\"1\";s:16:\"disablewatermark\";s:1:\"0\";s:12:\"inheritedmod\";s:1:\"0\";s:9:\"autoclose\";s:1:\"0\";s:12:\"forumcolumns\";s:1:\"0\";s:12:\"threadcaches\";s:1:\"0\";s:16:\"allowpaytoauthor\";s:1:\"1\";s:13:\"alloweditpost\";s:1:\"0\";s:6:\"simple\";s:1:\"0\";s:11:\"postcredits\";s:0:\"\";s:12:\"replycredits\";s:0:\"\";s:16:\"getattachcredits\";s:0:\"\";s:17:\"postattachcredits\";s:0:\"\";s:13:\"digestcredits\";s:0:\"\";s:16:\"attachextensions\";s:0:\"\";s:11:\"threadtypes\";s:0:\"\";s:8:\"viewperm\";s:0:\"\";s:8:\"postperm\";s:7:\"	1	2	3	\";s:9:\"replyperm\";s:0:\"\";s:13:\"getattachperm\";s:0:\"\";s:14:\"postattachperm\";s:0:\"\";s:16:\"supe_pushsetting\";s:0:\"\";}'),
	('發起活動類版塊', 'forum', '該類型設置裡發起主題一個月之後會自動關閉主題。', 'a:33:{s:7:\"styleid\";s:1:\"0\";s:12:\"allowsmilies\";s:1:\"1\";s:9:\"allowhtml\";s:1:\"0\";s:11:\"allowbbcode\";s:1:\"1\";s:12:\"allowimgcode\";s:1:\"1\";s:14:\"allowanonymous\";s:1:\"0\";s:10:\"allowshare\";s:1:\"1\";s:16:\"allowpostspecial\";s:1:\"9\";s:14:\"alloweditrules\";s:1:\"0\";s:10:\"recyclebin\";s:1:\"1\";s:11:\"modnewposts\";s:1:\"0\";s:6:\"jammer\";s:1:\"0\";s:16:\"disablewatermark\";s:1:\"0\";s:12:\"inheritedmod\";s:1:\"1\";s:9:\"autoclose\";s:2:\"30\";s:12:\"forumcolumns\";s:1:\"0\";s:12:\"threadcaches\";s:2:\"40\";s:16:\"allowpaytoauthor\";s:1:\"1\";s:13:\"alloweditpost\";s:1:\"1\";s:6:\"simple\";s:1:\"0\";s:11:\"postcredits\";s:0:\"\";s:12:\"replycredits\";s:0:\"\";s:16:\"getattachcredits\";s:0:\"\";s:17:\"postattachcredits\";s:0:\"\";s:13:\"digestcredits\";s:0:\"\";s:16:\"attachextensions\";s:0:\"\";s:8:\"viewperm\";s:0:\"\";s:8:\"postperm\";s:22:\"	1	2	3	11	12	13	14	15	\";s:9:\"replyperm\";s:0:\"\";s:13:\"getattachperm\";s:0:\"\";s:14:\"postattachperm\";s:0:\"\";s:16:\"supe_pushsetting\";s:0:\"\";}'),
	('娛樂灌水類版塊', 'forum', '該設置了主題緩存係數，開啟了所有的特殊主題按鈕。', 'a:33:{s:7:\"styleid\";s:1:\"0\";s:12:\"allowsmilies\";s:1:\"1\";s:9:\"allowhtml\";s:1:\"0\";s:11:\"allowbbcode\";s:1:\"1\";s:12:\"allowimgcode\";s:1:\"1\";s:14:\"allowanonymous\";s:1:\"0\";s:10:\"allowshare\";s:1:\"1\";s:16:\"allowpostspecial\";s:2:\"15\";s:14:\"alloweditrules\";s:1:\"0\";s:10:\"recyclebin\";s:1:\"1\";s:11:\"modnewposts\";s:1:\"0\";s:6:\"jammer\";s:1:\"0\";s:16:\"disablewatermark\";s:1:\"0\";s:12:\"inheritedmod\";s:1:\"0\";s:9:\"autoclose\";s:1:\"0\";s:12:\"forumcolumns\";s:1:\"0\";s:12:\"threadcaches\";s:2:\"40\";s:16:\"allowpaytoauthor\";s:1:\"1\";s:13:\"alloweditpost\";s:1:\"1\";s:6:\"simple\";s:1:\"0\";s:11:\"postcredits\";s:0:\"\";s:12:\"replycredits\";s:0:\"\";s:16:\"getattachcredits\";s:0:\"\";s:17:\"postattachcredits\";s:0:\"\";s:13:\"digestcredits\";s:0:\"\";s:16:\"attachextensions\";s:0:\"\";s:11:\"threadtypes\";s:0:\"\";s:8:\"viewperm\";s:0:\"\";s:8:\"postperm\";s:0:\"\";s:9:\"replyperm\";s:0:\"\";s:13:\"getattachperm\";s:0:\"\";s:14:\"postattachperm\";s:0:\"\";s:16:\"supe_pushsetting\";s:0:\"\";}');

INSERT INTO cdb_faqs (id, fpid, displayorder, identifier, keyword, title, message) VALUES
	('1', '0', '1', '', '', '用戶須知', ''),
	('2', '1', '1', '', '', '我必須要註冊嗎？', '這取決於管理員如何設置 Discuz! 論壇的用戶組權限選項，您甚至有可能必須在註冊成正式用戶後後才能瀏覽帖子。當然，在通常情況下，您至少應該是正式用戶才能發新帖和回復已有帖子。請 <a href="register.php" target="_blank">點擊這裡</a> 免費註冊成為我們的新用戶！\r\n<br><br>強烈建議您註冊，這樣會得到很多以遊客身份無法實現的功能。'),
	('3', '1', '2', 'login', '登錄幫助', '我如何登錄論壇？', '如果您已經註冊成為該論壇的會員，哪麼您只要通過訪問頁面右上的<a href="logging.php?action=login" target="_blank">登錄</a>，進入登陸界面填寫正確的用戶名和密碼（如果您設有安全提問，請選擇正確的安全提問並輸入對應的答案），點擊「提交」即可完成登陸如果您還未註冊請點擊這裡。<br><br>\r\n如果需要保持登錄，請選擇相應的 Cookie 時間，在此時間範圍內您可以不必輸入密碼而保持上次的登錄狀態。'),
	('4', '1', '3', '', '', '忘記我的登錄密碼，怎麼辦？', '當您忘記了用戶登錄的密碼，您可以通過註冊時填寫的電子郵箱重新設置一個新的密碼。點擊登錄頁面中的 <a href="member.php?action=lostpasswd" target="_blank">取回密碼</a>，按照要求填寫您的個人信息，系統將自動發送重置密碼的郵件到您註冊時填寫的 Email 信箱中。如果您的 Email 已失效或無法收到信件，請與論壇管理員聯繫。'),
	('5', '0', '2', '', '', '帖子相關操作', ''),
	('6', '0', '3', '', '', '基本功能操作', ''),
	('7', '0', '4', '', '', '其他相關問題', ''),
	('8', '1', '4', '', '', '我如何使用個性化頭像', '在<a href="memcp.php" target="_blank">控制面板</a>中的「編輯個人資料」，有一個「頭像」的選項，可以使用論壇自帶的頭像或者自定義的頭像。'),
	('9', '1', '5', '', '', '我如何修改登錄密碼', '在<a href="memcp.php" target="_blank">控制面板</a>中的「編輯個人資料」，填寫「原密碼」，「新密碼」，「確認新密碼」。點擊「提交」，即可修改。'),
	('10', '1', '6', '', '', '我如何使用個性化簽名和暱稱', '在<a href="memcp.php" target="_blank">控制面板</a>中的「編輯個人資料」，有一個「暱稱」和「個人簽名」的選項，可以在此設置。'),
	('11', '5', '1', '', '', '我如何發表新主題', '在論壇版塊中，點「新帖」，如果有權限，您可以看到有「投票，懸賞，活動，交易」，點擊即可進入功能齊全的發帖界面。\r\n<br><br>注意：一般論壇都設置為高級別的用戶組才能發佈這四類特殊主題。如發佈普通主題，直接點擊「新帖」，當然您也可以使用版塊下面的「快速發帖」發表新帖(如果此選項打開)。一般論壇都設置為需要登錄後才能發帖。'),
	('12', '5', '2', '', '', '我如何發表回復', '回復有分三種：第一、貼子最下方的快速回復； 第二、在您想回復的樓層點擊右下方「回復」； 第三、完整回復頁面，點擊本頁「新帖」旁邊的「回復」。'),
	('13', '5', '3', '', '', '我如何編輯自己的帖子', '在帖子的右下角，有編輯，回復，報告等選項，點擊編輯，就可以對帖子進行編輯。'),
	('14', '5', '4', '', '', '我如何出售購買主題', '<li>出售主題：\r\n當您進入發貼界面後，如果您所在的用戶組有發買賣貼的權限，在「售價(金錢)」後面填寫主題的價格，這樣其他用戶在查看這個帖子的時候就需要進入交費的過程才可以查看帖子。</li>\r\n<li>購買主題：\r\n瀏覽你準備購買的帖子，在帖子的相關信息的下面有[查看付款記錄] [購買主題] [返回上一頁] \r\n等鏈接，點擊「購買主題」進行購買。</li>'),
	('15', '5', '5', '', '', '我如何出售購買附件', '<li>上傳附件一欄有個售價的輸入框，填入出售價格即可實現需要支付才可下載附件的功能。</li>\r\n<li>點擊帖子中[購買附件]按鈕或點擊附件的下載鏈接會跳轉至附件購買頁面，確認付款的相關信息後點提交按鈕，即可得到附件的下載權限。只需購買一次，就有該附件的永遠下載權限。</li>'),
	('16', '5', '6', '', '', '我如何上傳附件', '<li>發表新主題的時候上傳附件，步驟為：寫完帖子標題和內容後點上傳附件右方的瀏覽，然後在本地選擇要上傳附件的具體文件名，最後點擊發表話題。</li>\r\n<li>發表回復的時候上傳附件，步驟為：寫完回復樓主的內容，然後點上傳附件右方的瀏覽，找到需要上傳的附件，點擊發表回復。</li>'),
	('17', '5', '7', '', '', '我如何實現發帖時圖文混排效果', '<li>先把文章寫在帖子裡，然後把相關的圖片以附件的形式上傳。</li>\r\n<li>編輯帖子，找到帖子下方的附件信息，點擊aid欄目所對應的數字，論壇會自動把附件的內容以[attach]xx[/attach]的形式插入到當前光標所在的位置。</li>'),
	('18', '5', '8', 'discuzcode', 'Discuz!代碼', '我如何使用Discuz!代碼', '<table width="100%" cellpadding="2" cellspacing="2">\r\n  <tr>\r\n    <th width="50%">Discuz!代碼</th>\r\n    <th width="402">效果</th>\r\n  </tr>\r\n  <tr>\r\n    <td>[b]粗體文字 Abc[/b]</td>\r\n    <td><strong>粗體文字 Abc</strong></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[i]斜體文字 Abc[/i]</td>\r\n    <td><em>斜體文字 Abc</em></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[u]下劃線文字 Abc[/u]</td>\r\n    <td><u>下劃線文字 Abc</u></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[color=red]紅顏色[/color]</td>\r\n    <td><font color="red">紅顏色</font></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[size=3]文字大小為 3[/size] </td>\r\n    <td><font size="3">文字大小為 3</font></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[font=仿宋]字體為仿宋[/font] </td>\r\n    <td><font face"仿宋">字體為仿宋</font></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[align=Center]內容居中[/align] </td>\r\n    <td><div align="center">內容居中</div></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[url]http://www.comsenz.com[/url]</td>\r\n    <td><a href="http://www.comsenz.com" target="_blank">http://www.comsenz.com</a>（超級鏈接）</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[url=http://www.Discuz.net]Discuz! 論壇[/url]</td>\r\n    <td><a href="http://www.Discuz.net" target="_blank">Discuz! 論壇</a>（超級鏈接）</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[email]myname@mydomain.com[/email]</td>\r\n    <td><a href="mailto:myname@mydomain.com">myname@mydomain.com</a>（E-mail鏈接）</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[email=support@discuz.net]Discuz! 技術支持[/email]</td>\r\n    <td><a href="mailto:support@discuz.net">Discuz! 技術支持（E-mail鏈接）</a></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[quote]Discuz! Board 是由康盛創想（北京）科技有限公司開發的論壇軟件[/quote] </td>\r\n    <td><div style="font-size: 12px"><br><br><div class="msgheader">QUOTE:</div><div class="msgborder">原帖由 <i>admin</i> 於 2006-12-26 08:45 發表<br>Discuz! Board 是由康盛創想（北京）科技有限公司開發的論壇軟件</div></td>\r\n  </tr>\r\n   <tr>\r\n    <td>[code]Discuz! Board 是由康盛創想（北京）科技有限公司開發的論壇軟件[/code] </td>\r\n    <td><div style="font-size: 12px"><br><br><div class="msgheader">CODE:</div><div class="msgborder">Discuz! Board 是由康盛創想（北京）科技有限公司開發的論壇軟件</div></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[hide]隱藏內容 Abc[/hide]</td>\r\n    <td>效果:只有當瀏覽者回復本帖時，才顯示其中的內容，否則顯示為「<b>**** 隱藏信息 跟帖後才能顯示 *****</b>」</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[hide=20]隱藏內容 Abc[/hide]</td>\r\n    <td>效果:只有當瀏覽者積分高於 20 點時，才顯示其中的內容，否則顯示為「<b>**** 隱藏信息 積分高於 20 點才能顯示 ****</b>」</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[list][*]列表項 #1[*]列表項 #2[*]列表項 #3[/list]</td>\r\n    <td><ul>\r\n      <li>列表項 ＃1</li>\r\n      <li>列表項 ＃2</li>\r\n      <li>列表項 ＃3 </li>\r\n    </ul></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[fly]飛行的效果[/fly]</td>\r\n    <td><marquee scrollamount="3" behavior="alternate" width="90%">飛行的效果</marquee></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[flash]Flash網頁地址 [/flash] </td>\r\n    <td>帖子內嵌入 Flash 動畫</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[qq]123456789[/qq]</td>\r\n    <td>在帖子內顯示 QQ 在線狀態，點這個圖標可以和他（她）聊天</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[ra]ra網頁地址[/ra]</td>\r\n    <td>帖子內嵌入 Real 音頻</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[rm]rm網頁地址[/rm] </td>\r\n    <td>帖子內嵌入 Real 音頻或視頻</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[wma]wma網頁地址[/wma] </td>\r\n    <td>帖子內嵌入 Windows media 音頻</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[wmv]wmv網頁地址[/wmv]</td>\r\n    <td>帖子內嵌入 Windows media 音頻或視頻</td>\r\n  </tr>\r\n  <tr>\r\n    <td>[img]http://www.discuz.net/images/default/logo.gif[/img] </td>\r\n    <td>帖子內顯示為：<img src="http://www.discuz.net/images/default/logo.gif"></td>\r\n  </tr>\r\n  <tr>\r\n    <td>[img=88,31]http://www.discuz.net/images/logo.gif[/img] </td>\r\n    <td>帖子內顯示為：<img src="http://www.discuz.net/images/logo.gif"></td>\r\n  </tr>\r\n</table>'),
	('19', '6', '1', '', '', '我如何使用短消息功能', '您登錄後，點擊導航欄上的短消息按鈕，即可進入短消息管理。\r\n點擊[發送短消息]按鈕，在"發送到"後輸入收信人的用戶名，填寫完標題和內容，點提交(或按 Ctrl+Enter 發送)即可發出短消息。\r\n<br><br>如果要保存到發件箱，以在提交前勾選"保存到發件箱中"前的復選框。\r\n<ul>\r\n<li>點擊收件箱可打開您的收件箱查看收到的短消息。</li>\r\n<li>點擊發件箱可查看保存在發件箱裡的短消息。 </li>\r\n<li>點擊消息跟蹤來查看對方是否已經閱讀您的短消息。 </li>\r\n<li>點擊搜索短消息就可通過關鍵字，發信人，收信人，搜索範圍，排序類型等一系列條件設定來找到您需要查找的短消息。 </li>\r\n<li>點擊導出短消息可以將自己的短消息導出htm文件保存在自己的電腦裡。 </li>\r\n<li>點擊忽略列表可以設定忽略人員，當這些被添加的忽略用戶給您發送短消息時將不予接收。</li>\r\n</ul>'),
	('20', '6', '2', '', '', '我如何向好友群發短消息', '登錄論壇後，點擊短消息，然後點發送短消息，如果有好友的話，好友群發後麵點擊全選，可以給所有的好友群發短消息。'),
	('21', '6', '3', '', '', '我如何查看論壇會員數據', '點擊導航欄上面的會員，然後顯示的是此論壇的會員數據。註：需要論壇管理員開啟允許你查看會員資料才可看到。'),
	('22', '6', '4', '', '', '我如何使用搜索', '點擊導航欄上面的搜索，輸入搜索的關鍵字並選擇一個範圍，就可以檢索到您有權限訪問論壇中的相關的帖子。'),
	('23', '6', '5', '', '', '我如何使用「我的」功能', '<li>會員必須首先<a href="logging.php?action=login" target="_blank">登錄</a>，沒有用戶名的請先<a href="register.php" target="_blank">註冊</a>；</li>\r\n<li>登錄之後在論壇的左上方會出現一個「我的」的超級鏈接，點擊這個鏈接之後就可進入到有關於您的信息。</li>'),
	('24', '7', '1', '', '', '我如何向管理員報告帖子', '打開一個帖子，在帖子的右下角可以看到：「編輯」、「引用」、「報告」、「評分」、「回復」等等幾個按鈕，點擊其中的「報告」按鈕進入報告頁面，填寫好「我的意見」，單擊「報告」按鈕即可完成報告某個帖子的操作。'),
	('25', '7', '2', '', '', '我如何「打印」，「推薦」，「訂閱」，「收藏」帖子', '當你瀏覽一個帖子時，在它的右上角可以看到：「打印」、「推薦」、「訂閱」、「收藏」，點擊相對應的文字連接即可完成相關的操作。'),
	('26', '7', '3', '', '', '我如何設置論壇好友', '設置論壇好友有3種簡單的方法。\r\n<ul>\r\n<li>當您瀏覽帖子的時候可以點擊「發表時間」右側的「加為好友」設置論壇好友。</li>\r\n<li>當您瀏覽某用戶的個人資料時，可以點擊頭像下方的「加為好友」設置論壇好友。</li>\r\n<li>您也可以在控制面板中的好友列表增加您的論壇好友。</li>\r\n<ul>'),
	('27', '7', '4', '', '', '我如何使用RSS訂閱', '在論壇的首頁和進入版塊的頁面的右上角就會出現一個rss訂閱的小圖標<img src="images/common/xml.gif" border="0">，鼠標點擊之後將出現本站點的rss地址，你可以將此rss地址放入到你的rss閱讀器中進行訂閱。'),
	('28', '7', '5', '', '', '我如何清除Cookies', 'cookie是由瀏覽器保存在系統內的，在論壇的右下角提供有"清除 Cookies"的功能，點擊後即可幫您清除系統內存儲的Cookies。 <br><br>\r\n以下介紹3種常用瀏覽器的Cookies清除方法(註：此方法為清除全部的Cookies,請謹慎使用)\r\n<ul>\r\n<li>Internet Explorer: 工具（選項）內的Internet選項→常規選項卡內，IE6直接可以看到刪除Cookies的按鈕點擊即可，IE7為「瀏 覽歷史記錄」選項內的刪除點擊即可清空Cookies。對於Maxthon,騰訊TT等IE核心瀏覽器一樣適用。 </li>\r\n<li>FireFox:工具→選項→隱私→Cookies→顯示Cookie裡可以對Cookie進行對應的刪除操作。 </li>\r\n<li>Opera:工具→首選項→高級→Cookies→管理Cookies即可對Cookies進行刪除的操作。</li>\r\n</ul>'),
	('29', '7', '6', '', '', '我如何聯繫管理員', '您可以通過論壇底部右下角的「聯繫我們」鏈接快速的發送郵件與我們聯繫。也可以通過管理團隊中的用戶資料發送短消息給我們。'),
	('30', '7', '7', '', '', '我如何開通個人空間', '如果您有權限開通「我的個人空間」，當用戶登錄論壇以後在論壇首頁，用戶名的右方點擊開通我的個人空間，進入個人空間的申請頁面。'),
	('31', '7', '8', '', '', '我如何將自己的主題加入個人空間', '如果您有權限開通「我的個人空間」，在您發表的主題上方點擊「加入個人空間」，您發表的主題以及回復都會加入到您空間的日誌裡。'),
	('32', '5', '9', 'smilies', 'Smilies', '我如何使用Smilies代碼', 'Smilies是一些用字符表示的表情符號，如果打開 Smilies 功能，Discuz! 會把一些符號轉換成小圖像，顯示在帖子中，更加美觀明瞭。目前支持下面這些 Smilies：<br><br>\r\n<table cellspacing="0" cellpadding="4" width="30%" align="center">\r\n<tr><th width="25%" align="center">表情符號</td>\r\n<th width="75%" align="center">對應圖像</td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:)</td>\r\n<td width="75%" align="center"><img src="images/smilies/smile.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:(</td>\r\n<td width="75%" align="center"><img src="images/smilies/sad.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:D</td>\r\n<td width="75%" align="center"><img src="images/smilies/biggrin.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:\'(</td>\r\n<td width="75%" align="center"><img src="images/smilies/cry.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:@</td>\r\n<td width="75%" align="center"><img src="images/smilies/huffy.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:o</td>\r\n<td width="75%" align="center"><img src="images/smilies/shocked.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:P</td>\r\n<td width="75%" align="center"><img src="images/smilies/tongue.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:$</td>\r\n<td width="75%" align="center"><img src="images/smilies/shy.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">；P</td>\r\n<td width="75%" align="center"><img src="images/smilies/titter.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:L</td>\r\n<td width="75%" align="center"><img src="images/smilies/sweat.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:Q</td>\r\n<td width="75%" align="center"><img src="images/smilies/mad.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:lol</td>\r\n<td width="75%" align="center"><img src="images/smilies/lol.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:hug:</td>\r\n<td width="75%" align="center"><img src="images/smilies/hug.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:victory:</td>\r\n<td width="75%" align="center"><img src="images/smilies/victory.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:time:</td>\r\n<td width="75%" align="center"><img src="images/smilies/time.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:kiss:</td>\r\n<td width="75%" align="center"><img src="images/smilies/kiss.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:handshake</td>\r\n<td width="75%" align="center"><img src="images/smilies/handshake.gif" alt=""></td>\r\n</tr>\r\n<tr>\r\n<td width="25%" align="center">:call:</td>\r\n<td width="75%" align="center"><img src="images/smilies/call.gif" alt=""></td>\r\n</tr>\r\n</table>\r\n</div></div>\r\n<br>'),
	('33','0','5','','','論壇高級功能使用',''),
	('34','33','0','forwardmessagelist','','論壇快速跳轉關鍵字列表','Discuz! 支持自定義快速跳轉頁面，當某些操作完成後，可以不顯示提示信息，直接跳轉到新的頁面，從而方便用戶進行下一步操作，避免等待。 在實際使用當中，您根據需要，把關鍵字添加到快速跳轉設置裡面(後台 -- 基本設置 --  界面與顯示方式 -- [<a href=\"admincp.php?action=settings&do=styles&frames=yes\" target=\"_blank\">提示信息跳轉設置</a> ])，讓某些信息不顯示而實現快速跳轉。以下是 Discuz! 當中的一些常用信息的關鍵字:\r\n</br></br>\r\n\r\n<table width=\"400\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\" class=\"msgborder\" align=\"center\">\r\n  <tr class=\"msgheader\">\r\n    <td width=\"50%\">關鍵字</td>\r\n    <td width=\"50%\">提示信息頁面或者作用</td>\r\n  </tr>\r\n  <tr>\r\n    <td>login_succeed</td>\r\n    <td>登錄成功</td>\r\n  </tr>\r\n  <tr>\r\n    <td>logout_succeed</td>\r\n    <td>退出登錄成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>thread_poll_succeed</td>\r\n    <td>投票成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>thread_rate_succeed</td>\r\n    <td>評分成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>register_succeed</td>\r\n    <td>註冊成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>usergroups_join_succeed</td>\r\n    <td>加入擴展組成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td height=\"22\">usergroups_exit_succeed</td>\r\n    <td>退出擴展組成功</td>\r\n  </tr>\r\n  <tr>\r\n    <td>usergroups_update_succeed</td>\r\n    <td>更新擴展組成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>buddy_update_succeed</td>\r\n    <td>好友更新成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>post_edit_succeed</td>\r\n    <td>編輯帖子成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>post_edit_delete_succeed</td>\r\n    <td>刪除帖子成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>post_reply_succeed</td>\r\n    <td>回復成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>post_newthread_succeed</td>\r\n    <td>發表新主題成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>post_reply_blog_succeed</td>\r\n    <td>文集評論發表成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>post_newthread_blog_succeed</td>\r\n    <td>blog 發表成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>&nbsp;profile_avatar_succeed</td>\r\n    <td>頭像設置成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>&nbsp;profile_succeed</td>\r\n    <td>個人資料更新成功</td>\r\n  </tr>\r\n    <tr>\r\n    <td>pm_send_succeed</td>\r\n    <td>短消息發送成功</td>\r\n  </tr>\r\n  </tr>\r\n    <tr>\r\n    <td>pm_delete_succeed</td>\r\n    <td>短消息刪除成功</td>\r\n  </tr>\r\n  </tr>\r\n    <tr>\r\n    <td>pm_ignore_succeed</td>\r\n    <td>短消息忽略列表更新</td>\r\n  </tr>\r\n    <tr>\r\n    <td>admin_succeed</td>\r\n    <td>管理操作成功〔注意：設置此關鍵字後，所有管理操作完畢都將直接跳轉〕</td>\r\n  </tr>\r\n    <tr>\r\n    <td>admin_succeed_next&nbsp;</td>\r\n    <td>管理成功並將跳轉到下一個管理動作</td>\r\n  </tr> \r\n    <tr>\r\n    <td>search_redirect</td>\r\n    <td>搜索完成，進入搜索結果列表</td>\r\n  </tr>\r\n</table>');

EOT;

$upgrademsg = array(
	1 => '論壇升級第 1 步: 增加基本設置<br><br>',
	2 => '論壇升級第 2 步: 調整論壇數據表結構<br><br>',
	3 => '論壇升級第 3 步: 更新部分數據<br><br>',
	4 => '論壇升級第 4 步: 調整審核信息<br><br>',
	5 => '論壇升級第 5 步: 調整部分數據<br><br>',
	6 => '論壇升級第 6 步: 新增數據表<br><br>',
	7 => '論壇升級第 7 步: 插入論壇相關數據<br><br>',
	8 => '論壇升級第 8 步: SupeSite相關數據升級<br><br>',
	9 => '論壇升級第 9 步: 其他相關數據升級<br><br>',
	10 => '論壇升級第 10 步: 升級全部完畢<br><br>',
);

$errormsg = '';
if(!isset($dbhost)) {
	showerror("<span class=error>沒有找到 config.inc.php 文件!</span><br>請確認您已經上傳了所有 $version_new 文件");
} elseif(!isset($cookiepre)) {
	showerror("<span class=error>config.inc.php 版本錯誤!</span><br>請上傳 $version_new 的 config.inc.php，並調整好數據庫設置然後重新進行升級");
} elseif(!$dblink = @mysql_connect($dbhost, $dbuser, $dbpw)) {
	showerror("<span class=error>config.inc.php 配置錯誤!</span><br>請修改 config.inc.php 當中關於數據庫的設置，然後上傳到論壇目錄，重新開始升級");
}

@mysql_close($dblink);
$db = new dbstuff;
$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);

if(!$action) {

	if(!$tableinfo = loadtable('threads')) {
		showerror("<span class=error>無法找到 Discuz! 論壇數據表!</span><br>請修改 config.inc.php 當中關於數據庫的設置，然後上傳到論壇目錄，重新開始升級");
	} elseif($db->version() > '4.1') {
		$old_dbcharset = substr($tableinfo['subject']['Collation'], 0, strpos($tableinfo['subject']['Collation'], '_'));
		if($old_dbcharset <> $dbcharset) {
			showerror("<span class=error>config.inc.php 數據庫字符集設置錯誤!</span><br>".
				"<li>原來的字符集設置為：$old_dbcharset".
				"<li>當前使用的字符集為：$dbcharset".
				"<li>建議：修改 config.inc.php， 將其中的 <b>\$dbcharset = ''</b> 或者 <b>\$dbcharset = '$dbcharset'</b> 修改為： <b>\$dbcharset = '$old_dbcharset'</b>".
				"<li>修改完畢後上傳 config.inc.php，然後重新進行升級"
			);
		}
	}

	echo <<< EOT
<span class="red">
升級前請打開瀏覽器 JavaScript 支持,整個過程是自動完成的,不需人工點擊和干預.<br>
升級之前務必備份數據庫資料，否則升級失敗無法恢復<br></span><br>
正確的升級方法為:
<ol>
	<li>關閉原有論壇,上傳 $version_new 的全部文件和目錄, 覆蓋服務器上的 $version_old
	<li>上傳升級程序到論壇目錄中，<b>重新配置好 config.inc.php</b>
	<li>運行本程序,直到出現升級完成的提示
	<li>如果中途失敗，請使用Discuz!工具箱（./utilities/tools.php）裡面的數據恢復工具恢復備份, 去除錯誤後重新運行本程序
</ol>
<a href="$PHP_SELF?action=upgrade&step=1"><font size="2" color="red"><b>&gt;&gt;&nbsp;如果您已確認完成上面的步驟,請點這裡升級</b></font></a>
<br><br>
EOT;
	showfooter();

} else {

	$step = intval($step);
	echo '&gt;&gt;'.$upgrademsg[$step];
	flush();

	if($step == 1) {

		dir_clear('./forumdata/cache');
		dir_clear('./forumdata/templates');

		if(!dir_writeable('./forumdata/logs')) {
			showerror('升級檢測失敗，無法建立目錄 /forumdata/logs，請手工建立此目錄，然後重新運行升級程序');
		} else {
			$logfilearray = array('cplog.php', 'illegallog.php', 'ratelog.php', 'medalslog.php', 'banlog.php', 'runwizardlog.php', 'errorlog.php', 'modslog.php', 'viewcount.log', 'dberror.log');
			foreach($logfilearray as $filename) {
				@copy('./forumdata/'.$filename, './forumdata/logs/'.$filename);
				@unlink('./forumdata/'.$filename);
			}
		}

		runquery($upgrade1);

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 2) {

		$start = isset($_GET['start']) ? intval($_GET['start']) : 0;

		if(isset($upgradetable[$start]) && $upgradetable[$start][0]) {

			echo "升級數據表 [ $start ] {$tablepre}{$upgradetable[$start][0]} :";
			$successed = upgradetable($upgradetable[$start]);

			if($successed === TRUE) {
				echo ' <font color=green>OK</font><br>';
			} elseif($successed === FALSE) {
				echo ' <font color=red>ERROR</font><br>';
			} elseif($successed == 'TABLE NOT EXISTS') {
				showerror('<span class=red>數據表不存在</span>升級無法繼續，請確認您的論壇版本是否正確!</font><br>');
			}
		}

		$start ++;
		if(isset($upgradetable[$start])) {
			redirect("?action=upgrade&step=$step&start=$start");
		}

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 3) {

		runquery($upgrade2);

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 4) {

		runquery($upgrade4);

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 5) {

		$db->query("DELETE FROM {$tablepre}crons WHERE type='system' AND filename='magics_daily.inc.php'", 'SILENT');
		$db->query("INSERT INTO {$tablepre}crons (available, type, name, filename, lastrun, nextrun, weekday, day, hour, minute) VALUES (1, 'system', '道具自動補貨', 'magics_daily.inc.php', $timestamp, $timestamp, -1, -1, 0, '0')", "SILENT");
		$db->query("INSERT INTO {$tablepre}crons (available, type, name, filename, lastrun, nextrun, weekday, day, hour, minute) VALUES (1, 'system', '每日驗證問答更新', 'secqaa_daily.inc.php', 0, 0, -1, -1, 6, '0')", "SILENT");
		
		$db->query("DELETE FROM {$tablepre}stylevars WHERE variable='msgbigsize'", 'SILENT');
		$db->query("DELETE FROM {$tablepre}stylevars WHERE variable='msgsmallsize'", 'SILENT');
		$db->query("DELETE FROM {$tablepre}stylevars WHERE variable='frameswitch'", 'SILENT');
		$db->query("DELETE FROM {$tablepre}stylevars WHERE variable='framebg'", 'SILENT');
		$db->query("DELETE FROM {$tablepre}stylevars WHERE variable='framebgcolor'", 'SILENT');

		$styleids = array();
		$query = $db->query("SELECT styleid FROM {$tablepre}styles");
		while($style = $db->fetch_array($query)) {
			$styleids[] = $style['styleid'];
		}

		foreach ($styleids as $styleid) {
			$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute) VALUES ('$styleid', 'msgbigsize', '')", 'SILENT');
			$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute) VALUES ('$styleid', 'msgsmallsize', '')", 'SILENT');
			$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute) VALUES ('$styleid', 'frameswitch', 'frame_switch.gif')", 'SILENT');
			$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute) VALUES ('$styleid', 'framebg', 'frame_bg.gif')", 'SILENT');
			$db->query("INSERT INTO {$tablepre}stylevars (styleid, variable, substitute) VALUES ('$styleid', 'framebgcolor', '#E8F2F7')", 'SILENT');
		}

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 6) {

		runquery($upgrade6);

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 7) {

		runquery($upgrade7);

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 8) {

		$settings = array();
		$query = $db->query("SELECT variable, value FROM {$tablepre}settings WHERE variable LIKE 'supe_%'");
		while($setting = $db->fetch_array($query)) {
			$settings[$setting['variable']] = $setting['value'];
		}
		$supe = array(
		'dbmode' => '0',
		'dbhost' => '',
		'dbuser' => '',
		'dbpw' => '',
		'dbname' => '',
		'status' => $settings['supe_status'],
		'tablepre' => $settings['supe_tablepre'],
		'siteurl' => $settings['supe_siteurl'],
		'sitename' => $settings['supe_sitename'],
		'maxupdateusers' => $settings['supe_maxupdateusers'],
		'items' => array(
		'status' => '1',
		'rows' => '4',
		'columns' => '3',
		'orderby' => '1'
		),
		'circlestatus' => '0'
		);

		$supe = addslashes(serialize($supe));

		$db->query("DELETE FROM {$tablepre}settings WHERE `variable` = 'supe_maxupdateusers'");
		$db->query("REPLACE INTO {$tablepre}settings (variable, value) values ('supe', '$supe')");

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} elseif($step == 9) {

		$backupdir = random(6);
		@mkdir('forumdata/backup_'.$backupdir, 0777);
		$db->query("REPLACE INTO {$tablepre}settings (variable, value) values ('backupdir', '$backupdir')");
		$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('seccodedata', '".addslashes(serialize(array('loginfailedcount' => 0, 'animator' => 0, 'background' => 1, 'width' => mt_rand(70, 100), 'height' => mt_rand(25, 40))))."')");

		echo "第 $step 步升級成功<br><br>";
		redirect("?action=upgrade&step=".($step+1));

	} else {

		dir_clear('./forumdata/cache');
		dir_clear('./forumdata/templates');

		echo '<br>恭喜您論壇數據升級成功，接下來請您：<ol><li><b>必刪除本程序</b>'.
		'<li>使用管理員身份登錄論壇，進入後台，更新緩存'.
		'<li><span class="red">由於 Discuz! 5.5.0 將原 config.inc.php 當中關於附件的設置改為數據庫存儲，所以如果您的附件目錄如果不是默認設置，請進入後台－基本設置－附件設置，進行更改。否則論壇舊貼可能無法找到原有的附件</span>'.
		'<li>進行論壇註冊、登錄、發貼等常規測試，看看運行是否正常'.
		'<li><b>如果您的論壇開啟了 URL 靜態化功能，您需要閱讀《用戶使用說明書》當中的高級應用，調整服務器 rewrite 設置， 否則論壇部分頁面會出現無法訪問的錯誤。</b>'.
		'<li>如果您希望啟用 <b>'.$version_new.'</b> 提供的新功能，你還需要對於論壇基本設置、欄目、會員組等等進行重新設置</ol><br>'.
		'<b>感謝您選用我們的產品！</b><a href="index.php" target="_blank">您現在可以訪問論壇，查看升級情況</a><iframe width="0" height="0" src="index.php"></iframe>';
		showfooter();
	}
}

instfooter();

function createtable($sql, $dbcharset) {
	$type = strtoupper(preg_replace("/^\s*CREATE TABLE\s+.+\s+\(.+?\).*(ENGINE|TYPE)\s*=\s*([a-z]+?).*$/isU", "\\2", $sql));
	$type = in_array($type, array('MYISAM', 'HEAP')) ? $type : 'MYISAM';
	return preg_replace("/^\s*(CREATE TABLE\s+.+\s+\(.+?\)).*$/isU", "\\1", $sql).
	(mysql_get_server_info() > '4.1' ? " ENGINE=$type default CHARSET=$dbcharset" : " TYPE=$type");
}

function dir_clear($dir) {
	$directory = dir($dir);
	while($entry = $directory->read()) {
		$filename = $dir.'/'.$entry;
		if(is_file($filename)) {
			@unlink($filename);
		}
	}
	@touch($dir.'/index.htm');
	$directory->close();
}

function dir_writeable($dir) {
	if(!is_dir($dir)) {
		@mkdir($dir, 0777);
	}
	if(is_dir($dir)) {
		if($fp = @fopen("$dir/test.txt", 'w')) {
			@fclose($fp);
			@unlink("$dir/test.txt");
			$writeable = 1;
		} else {
			$writeable = 0;
		}
	}
	return $writeable;
}

function daddslashes($string) {
	if(is_array($string)) {
		foreach($string as $key => $val) {
			$string[$key] = daddslashes($val, $force);
		}
	} else {
		$string = addslashes($string);
	}
	return $string;
}

function instfooter() {
	echo '</table></body></html>';
}

function random($length, $numeric = 0) {
	PHP_VERSION < '4.2.0' && mt_srand((double)microtime() * 1000000);
	if($numeric) {
		$hash = sprintf('%0'.$length.'d', mt_rand(0, pow(10, $length) - 1));
	} else {
		$hash = '';
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
		$max = strlen($chars) - 1;
		for($i = 0; $i < $length; $i++) {
			$hash .= $chars[mt_rand(0, $max)];
		}
	}
	return $hash;
}

function runquery($query) {
	global $db, $tablepre, $dbcharset;

	$query = str_replace("\r", "\n", str_replace(' cdb_', ' '.$tablepre, $query));
	$expquery = explode(";\n", $query);
	foreach($expquery as $sql) {
		$sql = trim($sql);
		if($sql == '' || $sql[0] == '#') continue;

		if(strtoupper(substr($sql, 0, 12)) == 'CREATE TABLE') {
			$db->query(createtable($sql, $dbcharset));
		} else {
			$db->query($sql);
		}
	}
}

function loadtable($table, $force = 0) {
	global $db, $tablepre, $dbcharset;
	static $tables = array();

	if(!isset($tables[$table]) || $force) {
		if($db->version() > '4.1') {
			$query = $db->query("SHOW FULL COLUMNS FROM {$tablepre}$table", 'SILENT');
		} else {
			$query = $db->query("SHOW COLUMNS FROM {$tablepre}$table", 'SILENT');
		}
		while($field = @$db->fetch_array($query)) {
			$tables[$table][$field['Field']] = $field;
		}
	}
	return $tables[$table];
}

function upgradetable($updatesql) {
	global $db, $tablepre, $dbcharset;

	$successed = FALSE;

	if(is_array($updatesql) && !empty($updatesql[0])) {

		list($table, $action, $field, $sql) = $updatesql;

		if($tableinfo = loadtable($table)) {
			$fieldexist = isset($tableinfo[$field]) ? 1 : 0;

			$query = "ALTER TABLE {$tablepre}{$table} ";

			if($action == 'CHANGE') {

				$field2 = trim(substr($sql, 0, strpos($sql, ' ')));
				$field2exist = isset($tableinfo[$field2]);

				if($fieldexist && ($field == $field2 || !$field2exist)) {
					$query .= "CHANGE $field $sql";
				} elseif($fieldexist && $field2exist) {
					$db->query('ALTER TABLE {$tablepre}{$table} DROP $field2', 'SILENT');
					$query .= "CHANGE $field $sql";
				} elseif(!$fieldexist && $fieldexist2) {
					$db->query('ALTER TABLE {$tablepre}{$table} DROP $field2', 'SILENT');
					$query .= "ADD $sql";
				} elseif(!$fieldexist && !$field2exist) {
					$query .= "ADD $sql";
				}
				$successed = $db->query($query);

			} elseif($action == 'ADD') {

				$query .= $fieldexist ? "CHANGE $field $field $sql" :  "ADD $field $sql";
				if($successed = $db->query($query)) {
					$db->query("UPDATE LOW_PRIORITY IGNORE $tablepre{$table} SET $field=NULL", "UNBUFFERED");
				}

			} elseif($action == 'DROP') {
				if($fieldexist) {
					$successed = $db->query("$query DROP $field", "SILENT");
				}
				$successed = TRUE;
			}

		} else {

			$successed = 'TABLE NOT EXISTS';

		}
	}
	return $successed;
}

function showheader() {
	global $version_old, $version_new;

	print <<< EOT
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Discuz! 升級程序( $version_old &gt;&gt; $version_new)</title>
<meta name="MSSmartTagsPreventParsing" content="TRUE">
<meta http-equiv="MSThemeCompatible" content="Yes">
<style>
a:visited	{color: #FF0000; text-decoration: none}
a:link		{color: #FF0000; text-decoration: none}
a:hover		{color: #FF0000; text-decoration: underline}
body,table,td	{color: #3a4273; font-family: Tahoma, verdana, arial; font-size: 12px; line-height: 20px; scrollbar-base-color: #e3e3ea; scrollbar-arrow-color: #5c5c8d}
input		{color: #085878; font-family: Tahoma, verdana, arial; font-size: 12px; background-color: #3a4273; color: #ffffff; scrollbar-base-color: #e3e3ea; scrollbar-arrow-color: #5c5c8d}
.install	{font-family: Arial, Verdana; font-size: 14px; font-weight: bold; color: #000000}
.header		{font: 12px Tahoma, Verdana; font-weight: bold; background-color: #3a4273 }
.header	td	{color: #ffffff}
.red		{color: red; font-weight: bold}
.bg1		{background-color: #e3e3ea}
.bg2		{background-color: #eeeef6}
</style>
</head>

<body bgcolor="#3A4273" text="#000000">
<table width="95%" height="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center">
<tr>
<td>
<table width="98%" border="0" cellspacing="0" cellpadding="0" align="center">
<tr>
<td class="install" height="30" valign="bottom"><font color="#FF0000">&gt;&gt;</font>
Discuz! 升級程序( $version_old &gt;&gt; $version_new)</td>
</tr>
<tr>
<td>
<hr noshade align="center" width="100%" size="1">
</td>
</tr>
<tr>
<td align="center">
<b>本升級程序只能從 $version_old 升級到 $version_new ，運行之前，請確認已經上傳所有文件，並做好數據備份<br>
升級當中有任何問題請訪問技術支持站點 <a href="http://www.discuz.net" target="_blank">http://www.discuz.net</a></b>
</td>
</tr>
<tr>
<td>
<hr noshade align="center" width="100%" size="1">
</td>
</tr>
<tr><td>
EOT;
}

function showfooter() {
	echo <<< EOT
</td></tr></table></td></tr>
<tr><td height="100%">&nbsp;</td></tr>
</table>
</body>
</html>
EOT;
	exit();
}

function showerror($message, $break = 1) {
	echo '<br><br>'.$message.'<br><br>';
	if($break) showfooter();
}

function redirect($url) {

	echo <<< EOT
<hr size=1>
<script language="JavaScript">
	function redirect() {
		window.location.replace('$url');
	}
	setTimeout('redirect();', 1000);
</script>
<br><br>
&gt;&gt;<a href="$url">瀏覽器會自動跳轉頁面，無需人工干預。除非當您的瀏覽器長時間沒有自動跳轉時，請點擊這裡</a>
<br><br>
EOT;
	showfooter();
}
?>