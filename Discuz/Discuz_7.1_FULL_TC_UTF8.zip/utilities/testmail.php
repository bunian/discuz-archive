<?php

/*
	[DISCUZ!] utilities/testmail.php - test email sending module of Discuz!
	This is NOT a freeware, use is subject to license terms

	Version: 2.0.0
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2002/12/6 17:00
*/

error_reporting(7);
define('IN_DISCUZ', true);

define('DISCUZ_ROOT', './');
define('TPLDIR', './templates/default');

// Please modify the following 3 variables to fit your situations
$from = 'my@mydomain.com';			// mail from(發件人郵件地址)
$to1 = 'test@test.com';				// mail to(測試單一郵件發送地址)
$to2 = 'test1@test1.com, test2@test2.net';	// mail to for Bcc(測試郵件群體發送地址)

require './include/global.func.php';

$mailsend = 1;
sendmail($to1, '標準方式發送 Email(單發)', "通過 PHP 函數及 UNIX sendmail 發送\n\n單一郵件發送至 $to1\n\n來自 $from", $from);
sendmail($to2, '標準方式發送 Email(群發)', "通過 PHP 函數及 UNIX sendmail 發送\n\n群體發送郵件發送至 $to2\n\n來自 $from", $from);

$mailsend = 2;
sendmail($to1, '通過 SMTP 服務器(SOCKET)發送 Email(單發)', "通過 SOCKET 連接 SMTP 服務器發送\n\n單一郵件發送至 $to1\n\n來自 $from", $from);
sendmail($to2, '通過 SMTP 服務器(SOCKET)發送 Email(群發)', "通過 SOCKET 連接 SMTP 服務器發送\n\n群體發送郵件發送至 $to2\n\n來自 $from", $from);

$mailsend = 3;
sendmail($to1, '通過 PHP 函數 SMTP 發送 Email(單發)', "通過 PHP 函數 SMTP 發送 Email\n\n單一郵件發送至 $to1\n\n來自 $from", $from);
sendmail($to2, '通過 PHP 函數 SMTP 發送 Email(群發)', "通過 PHP 函數 SMTP 發送\n\n群體發送郵件發送至 $to2\n\n來自 $from", $from);

?>