document.write("<li><a href=\"plugins.htm\" target=\"_self\">插件相關首頁</a>");
document.write("<li><a href=\"plugins_setup.htm\" target=\"_self\">插件安裝</a>");
document.write("<li><a href=\"plugins_design.htm\" target=\"_self\">插件設計</a>");