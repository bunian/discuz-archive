document.write('</div><br /><br /><br /><div id="footer">');
document.write('<div class="wrap">');
document.write('<p id="copyright">');
document.write("版權所有 &copy;2001-2007 <a href=\"http://www.comsenz.com\" style=\"color: #888888; text-decoration: none\">");
document.write("康盛創想(北京)科技有限公司 Comsenz Inc</a>");
document.write('</p></div>');