<?php

// Space Language Pack for Discuz! Version 1.0.0
// Translated by Monkey

$spacelanguage = array
(
	'space' => '的個人空間',
	'userinfo' => '個人信息',
	'calendar' => '日曆',
	'mythreads' => '主題',
	'myreplies' => '回復',
	'myrewards' => '懸賞',
	'mytrades' => '店舖',
	'myvideos' => '視頻',
	'mytradestick' => '推薦商品',
	'mytradetypes' => '店舖欄目',
	'mycounters' => '櫃台',
	'tradeinfo' => '店舖介紹',
	'myblogs' => '文集',
	'myfriends' => '好友',
	'myfavforums' => '收藏的版塊',
	'myfavthreads' => '收藏的帖子',
	'postblog' => '發表文集',
	'hotblog' => '最熱的 5 篇文集',
	'lastpostblog' => '最新回復的 5 篇文集'
);

?>