<?php

// Misc Language Pack for Discuz! Version 1.0.0
// Translated by Crossday

$lang = array
(
	'option' => '相關選項',
	'target_tid' => '目標主題tid',
	'target_pid' => '目標帖子pid',
	'target_username' => '目標用戶名',

	'CCK_color' => '變換顏色',
	'MOK_info' => '獲得的錢幣數目規則：大於1且小於購買價格150%的隨機數',
	'MVK_target' => '要移動到的版面',
);

?>