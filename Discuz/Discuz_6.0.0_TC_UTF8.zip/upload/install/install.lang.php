<?php
define('INSTALL_LANG', 'TC_UTF8');

$lang = array
(
	'SC_GBK' => '簡體中文版',
	'TC_BIG5' => '繁體中文版',
	'SC_UTF8' => '簡體中文 UTF8 版',
	'TC_UTF8' => '繁體中文 UTF8 版',
	'EN_ISO' => 'ENGLISH ISO8859',
	'EN_UTF8' => 'ENGLIST UTF-8',

	'username' => '管理員賬號:',
	'password' => '管理員密碼:',
	'repeat_password' => '重複密碼:',
	'admin_email' => '管理員 Email:',

	'succeed' => '成功',
	'enabled' => '允許',
	'writeable' => '可寫',
	'readable' => '可讀',
	'unwriteable' => '不可寫',
	'yes' => '可',
	'no' => '不可',
	'unlimited' => '不限',
	'support' => '支持',
	'unsupport' => '<span class="redfont">不支持</span>',
	'old_step' => '上一步',
	'new_step' => '下一步',
	'tips_message' => '提示信息',
	'return' => '返回',
	'error_message' => '錯誤信息',

	'env_os' => '操作系統',
	'env_php' => 'PHP 版本',
	'env_mysql' => 'MySQL 支持',
	'env_attach' => '附件上傳',
	'env_diskspace' => '磁盤空間',
	'env_dir_writeable' => '目錄寫入',

	'init_log' => '初始化記錄',
	'clear_dir' => '清空目錄',
	'select_db' => '選擇數據庫',
	'create_table' => '建立數據表',

	'install_wizard' => '安裝嚮導',
	'current_process' => '當前狀態:',
	'show_license' => 'Discuz! 用戶許可協議',
	'agreement_yes' => '我同意',
	'agreement_no' => '我不同意',
	'check_config' => '檢查配置文件狀態',
	'check_catalog_file_name' => '目錄文件名稱',
	'check_need_status' => '所需狀態',
	'check_currently_status' => '當前狀態',
	'edit_config' => '瀏覽/編輯當前配置',
	'variable' => '設置選項',
	'value' => '當前值',
	'comment' => '註釋',
	'dbhost' => '數據庫服務器:',
	'dbhost_comment' => '數據庫服務器地址, 一般為 localhost',
	'dbuser' => '數據庫用戶名:',
	'dbuser_comment' => '數據庫賬號用戶名',
	'dbpw' => '數據庫密碼:',
	'dbpw_comment' => '數據庫賬號密碼',
	'dbname' => '數據庫名:',
	'dbname_comment' => '數據庫名稱',
	'email' => '系統 Email:',
	'email_comment' => '用於發送程序錯誤報告',
	'tablepre' => '表名前綴:',
	'tablepre_comment' => '同一數據庫安裝多論壇時可改變默認',
	'tablepre_prompt' => '除非您需要在同一數據庫安裝多個 Discuz! \n論壇,否則,強烈建議您不要修改表名前綴。',

	'recheck_config' => '重新檢查設置',
	'check_env' => '檢查當前服務器環境',
	'env_required' => 'Discuz! 所需配置',
	'env_best' => 'Discuz! 最佳配置',
	'env_current' => '當前服務器',
	'install_note' => '安裝嚮導提示',
	'add_admin' => '設置管理員賬號',
	'start_install' => '開始安裝 Discuz!',
	'dbname_invalid' => '數據庫名為空，請填寫數據庫名稱',
	'admin_username_invalid' => '用戶名空, 長度超過限制或包含非法字符。',
	'admin_password_invalid' => '兩次輸入密碼不一致。',
	'admin_email_invalid' => 'Email 地址無效',
	'admin_invalid' => '您的信息沒有填寫完整。',

	'config_comment' => '請在下面填寫您的數據庫賬號信息, 通常情況下不需要修改紅色選項內容。',
	'config_unwriteable' => '安裝嚮導無法寫入配置文件, 請核對現有信息, 如需修改, 請通過 FTP 將改好的 config.inc.php 上傳。',

	'database_errno_2003' => '無法連接數據庫，請檢查數據庫是否啟動，數據庫服務器地址是否正確',
	'database_errno_1044' => '無法創建新的數據庫，請檢查數據庫名稱填寫是否正確',
	'database_errno_1045' => '無法連接數據庫，請檢查數據庫用戶名或者密碼是否正確',

	'dbpriv_createtable' => '沒有CREATE TABLE權限，無法安裝論壇',
	'dbpriv_insert' => '沒有INSERT權限，無法安裝論壇',
	'dbpriv_select' => '沒有SELECT權限，無法安裝論壇',
	'dbpriv_update' => '沒有UPDATE權限，無法安裝論壇',
	'dbpriv_delete' => '沒有DELETE權限，無法安裝論壇',
	'dbpriv_droptable' => '沒有DROP TABLE權限，無法安裝論壇',

	'php_version_406' => '您的 PHP 版本小於 4.0.6, 無法使用 Discuz!。',
	'attach_enabled' => '允許/最大尺寸 ',
	'attach_enabled_info' => '您可以上傳附件的最大尺寸: ',
	'attach_disabled' => '不允許上傳附件',
	'attach_disabled_info' => '附件上傳或相關操作被服務器禁止。',
	'mysql_version_323' => '您的 MySQL 版本低於 3.23，安裝無法繼續進行。',
	'mysql_unsupport' => '您的服務器不支持MySql數據庫，無法安裝論壇程序',
	'template_unwriteable' => '模板目錄(./templates)屬性非 777 或無法寫入，在線編輯模板功能將無法使用。',
	'attach_unwriteable' => '附件目錄(默認是 ./attachments)屬性非 777 或無法寫入，附件上傳功能將無法使用。',
	'avatar_unwriteable' => '自定義頭像目錄(./customavatars)屬性非 777 或無法寫入，上傳頭像功能將無法使用。',
	'forumdata_unwriteable' => '數據目錄(./forumdata)屬性非 777 或無法寫入，論壇運行記錄和備份到數據庫功能將無法使用。',
	'femplate_unwriteable' => '編譯模板目錄(./forumdata/templates)屬性非 777 或無法寫入，安裝無法繼續進行。',
	'cache_unwriteable' => '數據緩存目錄(./forumdata/cache)屬性非 777 或無法寫入，安裝無法繼續進行。',
	'threadcache_unwriteable' => '數據緩存目錄(./forumdata/threadcaches)屬性非 777 或無法寫入，安裝無法繼續進行。',
	'log_unwriteable' => '數據緩存目錄(./forumdata/threadcaches)屬性非 777 或無法寫入，安裝無法繼續進行。',
	'cache_unwriteable' => '數據緩存目錄(./forumdata/cache)屬性非 777 或無法寫入，安裝無法繼續進行。',
	'tablepre_invalid' => '您指定的數據表前綴包含點字符(".")，請返回修改。',
	'db_invalid' => '指定的數據庫不存在, 系統也無法自動建立, 無法安裝 Discuz!。',
	'db_auto_created' => '指定的數據庫不存在, 但系統已成功建立, 可以繼續安裝。',
	'db_not_null' => '數據庫中已經安裝過 Discuz!, 繼續安裝會清空原有數據。',
	'db_drop_table_confirm' => '繼續安裝會清空全部原有數據，您確定要繼續嗎?',
	'install_in_processed' => '正在安裝...',
	'install_succeed' => '恭喜您論壇安裝成功，點擊進入論壇首頁',

	'init_credits_karma' => '威望',
	'init_credits_money' => '金錢',

	'init_group_0' => '會員',
	'init_group_1' => '管理員',
	'init_group_2' => '超級版主',
	'init_group_3' => '版主',
	'init_group_4' => '禁止發言',
	'init_group_5' => '禁止訪問',
	'init_group_6' => '禁止 IP',
	'init_group_7' => '遊客',
	'init_group_8' => '等待驗證會員',
	'init_group_9' => '乞丐',
	'init_group_10' => '新手上路',
	'init_group_11' => '註冊會員',
	'init_group_12' => '中級會員',
	'init_group_13' => '高級會員',
	'init_group_14' => '金牌會員',
	'init_group_15' => '論壇元老',

	'init_rank_1' => '新生入學',
	'init_rank_2' => '小試牛刀',
	'init_rank_3' => '實習記者',
	'init_rank_4' => '自由撰稿人',
	'init_rank_5' => '特聘作家',

	'init_cron_1' => '清空今日發帖數',
	'init_cron_2' => '清空本月在線時間',
	'init_cron_3' => '每日數據清理',
	'init_cron_4' => '生日統計與郵件祝福',
	'init_cron_5' => '主題回復通知',
	'init_cron_6' => '每日公告清理',
	'init_cron_7' => '限時操作清理',
	'init_cron_8' => '論壇推廣清理',
	'init_cron_9' => '每月主題清理',
	'init_cron_10' => '每日 X-Space更新用戶',
	'init_cron_11' => '每週主題更新',

	'init_bbcode_1' => '使內容橫向滾動，這個效果類似 HTML 的 marquee 標籤，注意：這個效果只在 Internet Explorer 瀏覽器下有效。',
	'init_bbcode_2' => '嵌入 Flash 動畫',
	'init_bbcode_3' => '顯示 QQ 在線狀態，點這個圖標可以和他（她）聊天',
	'init_bbcode_4' => '嵌入 Real 音頻',
	'init_bbcode_5' => '嵌入 Real 音頻或視頻',
	'init_bbcode_6' => '嵌入 Windows media 音頻',
	'init_bbcode_7' => '嵌入 Windows media 音頻或視頻',

	'init_qihoo_searchboxtxt' =>'輸入關鍵詞,快速搜索本論壇',
	'init_threadsticky' =>'全局置頂,分類置頂,本版置頂',

	'init_default_style' => '默認風格',
	'init_default_forum' => '默認版塊',
	'init_default_template' => '默認模板套系',
	'init_default_template_copyright' => '康盛創想（北京）科技有限公司',

	'init_dataformat' => 'Y-n-j',
	'init_modreasons' => '廣告/SPAM\r\n惡意灌水\r\n違規內容\r\n文不對題\r\n重複發帖\r\n\r\n我很贊同\r\n精品文章\r\n原創內容',
	'init_link' => 'Discuz! 官方論壇',
	'init_link_note' => '提供最新 Discuz! 產品新聞、軟件下載與技術交流',

	'license' => '<p class="subtitle">中文版授權協議 適用於中文用戶

<p>版權所有 (c) 2001-2007，康盛創想（北京）科技有限公司<br />
保留所有權利。

<p>感謝您選擇 Discuz! 論壇產品。希望我們的努力能為您提供一個高效快速和強大的社區論壇解決方案。

<p>Discuz! 英文全稱為 Crossday Discuz! Board，中文全稱為 Discuz! 論壇，以下簡稱 Discuz!。

<p>康盛創想（北京）科技有限公司為 Discuz! 產品的開發商，依法獨立擁有 Discuz! 產品著作權（中國國家版權局
著作權登記號 2006SR11895）。康盛創想（北京）科技有限公司網址為 http://www.comsenz.com，Discuz! 官方網站網址為 http://www.discuz.com，
Discuz! 官方討論區網址為 http://www.discuz.net。

<p>Discuz! 著作權已在中華人民共和國國家版權局註冊，著作權受到法律和國際公約保護。使用者：無論個人或組織、盈利與否、用途如何
（包括以學習和研究為目的），均需仔細閱讀本協議，在理解、同意、並遵守本協議的全部條款後，方可開始使用 Discuz! 軟件。

<p>本授權協議適用且僅適用於 Discuz! 6.x.x 版本，康盛創想（北京）科技有限公司擁有對本授權協議的最終解釋權。

<ul type="I">
<p><li><b>協議許可的權利</b>
<ul type="1">
<li>您可以在完全遵守本最終用戶授權協議的基礎上，將本軟件應用於非商業用途，而不必支付軟件版權授權費用。
<li>您可以在協議規定的約束和限制範圍內修改 Discuz! 源代碼(如果被提供的話)或界面風格以適應您的網站要求。
<li>您擁有使用本軟件構建的論壇中全部會員資料、文章及相關信息的所有權，並獨立承擔與文章內容的相關法律義務。
<li>獲得商業授權之後，您可以將本軟件應用於商業用途，同時依據所購買的授權類型中確定的技術支持期限、技術支持方式和技術支持內容，
自購買時刻起，在技術支持期限內擁有通過指定的方式獲得指定範圍內的技術支持服務。商業授權用戶享有反映和提出意見的權力，相關意見
將被作為首要考慮，但沒有一定被採納的承諾或保證。
</ul>

<p><li><b>協議規定的約束和限制</b>
<ul type="1">
<li>未獲商業授權之前，不得將本軟件用於商業用途（包括但不限於企業網站、經營性網站、以營利為目或實現盈利的網站）。購買商業授權請登陸http://www.discuz.com參考相關說明，也可以致電8610-51657885瞭解詳情。
<li>不得對本軟件或與之關聯的商業授權進行出租、出售、抵押或發放子許可證。
<li>無論如何，即無論用途如何、是否經過修改或美化、修改程度如何，只要使用 Discuz! 的整體或任何部分，未經書面許可，論壇頁面頁腳處
的 Discuz! 名稱和康盛創想（北京）科技有限公司下屬網站（http://www.comsenz.com、http://www.discuz.com 或 http://www.discuz.net） 的
鏈接都必須保留，而不能清除或修改。
<li>禁止在 Discuz! 的整體或任何部分基礎上以發展任何派生版本、修改版本或第三方版本用於重新分發。
<li>如果您未能遵守本協議的條款，您的授權將被終止，所被許可的權利將被收回，並承擔相應法律責任。
</ul>

<p><li><b>有限擔保和免責聲明</b>
<ul type="1">
<li>本軟件及所附帶的文件是作為不提供任何明確的或隱含的賠償或擔保的形式提供的。
<li>用戶出於自願而使用本軟件，您必須瞭解使用本軟件的風險，在尚未購買產品技術服務之前，我們不承諾提供任何形式的技術支持、使用擔保，
也不承擔任何因使用本軟件而產生問題的相關責任。
<li>康盛創想（北京）科技有限公司不對使用本軟件構建的論壇中的文章或信息承擔責任。
</ul>
</ul>

<p>有關 Discuz! 最終用戶授權協議、商業授權與技術服務的詳細內容，均由 Discuz! 官方網站獨家提供。康盛創想（北京）科技有限公司擁有在不
事先通知的情況下，修改授權協議和服務價目表的權力，修改後的協議或價目表對自改變之日起的新授權用戶生效。

<p>電子文本形式的授權協議如同雙方書面簽署的協議一樣，具有完全的和等同的法律效力。您一旦開始安裝 Discuz!，即被視為完全理解並接受
本協議的各項條款，在享有上述條款授予的權力的同時，受到相關的約束和限制。協議許可範圍以外的行為，將直接違反本授權協議並構成侵權，
我們有權隨時終止授權，責令停止損害，並保留追究相關責任的權力。',

	'preparation' => '<li>將壓縮包中 Discuz! 目錄下全部文件和目錄上傳到服務器。</li><li>如果您使用非 WINNT 系統請修改以下屬性：<br />&nbsp; &nbsp; <b>./templates</b> 目錄 777;&nbsp; &nbsp; <b>./attachments</b> 目錄 777;&nbsp; &nbsp; <b>./customavatars</b> 目錄 777;&nbsp; &nbsp; <b>./forumdata</b> 目錄 777;<br /><b>&nbsp; &nbsp; ./forumdata/cache</b> 目錄 777;&nbsp; &nbsp; <b>./forumdata/templates</b> 目錄 777;&nbsp; &nbsp; <b>./forumdata/threadcaches</b> 目錄 777;<br />&nbsp; &nbsp; <b>./forumdata/logs</b> 目錄 777;&nbsp; &nbsp; <br /></li><li>確認 URL 中 /attachments 可以訪問服務器目錄 ./attachments 內容。</li><li>如果config.inc.php文件不可寫，請自行修改該文件上傳到論壇根目錄下。</li>',

);

$msglang = array(

	'lock_exists' => '您已經安裝過論壇，為了保證論壇數據安全，請手動刪除 install.php 文件 和 ./install 文件夾下的所有文件，如果您想重新安裝論壇，請刪除 forumdata/install.lock 文件，再次運行安裝文件。',
	'short_open_tag_invalid' => '對不起，請將 php.ini 中的 short_open_tag 設置為 On，否則無法繼續安裝論壇。',
	'database_nonexistence' => '您的 ./include/db_'.$database.'.class.php 不存在, 無法繼續安裝, 請用 FTP 將該文件上傳後再試。',
	'config_nonexistence' => '您的 config.inc.php 不存在, 無法繼續安裝, 請用 FTP 將該文件上傳後再試。',

);

$videoinfo = array(
	'open' => 0,
	'vtype' => "新聞\t軍事\t音樂\t影視\t動漫",
	'bbname' => '',
	'url' => '',
	'email' => '',
	'logo' => '',
	'sitetype' => "新聞\t軍事\t音樂\t影視\t動漫\t遊戲\t美女\t娛樂\t交友\t教育\t藝術\t學術\t技術\t動物\t旅遊\t生活\t時尚\t電腦\t汽車\t手機\t攝影\t戲曲\t外語\t公益\t校園\t數碼\t電腦\t歷史\t天文\t地理\t財經\t地區\t人物\t體育\t健康\t綜合",
	'vsiteid' => '',
	'vpassword' => '',
	'vkey' => '',
	'vclasses' => array (
		22 => '新聞',
		15 => '體育',
		27 => '教育',
		28 => '明星',
		26 => '美色',
		1 => '搞笑',
		29 => '另類',
		18 => '影視',
		12 => '音樂',
		8 => '動漫',
		7 => '遊戲',
		24 => '綜藝',
		11 => '廣告',
		19 => '藝術',
		5 => '時尚',
		21 => '居家',
		23 => '旅遊',
		25 => '動物',
		14 => '汽車',
		30 => '軍事',
		16 => '科技',
		31 => '其它'
	),
	'vclassesable' => array (22, 15, 27, 28, 26, 1, 29, 18, 12, 8, 7, 24, 11, 19, 5, 21, 23, 25, 14, 30, 16, 31)
);



$optionlist = array (
	8 => array (
		'classid' => '1',
		'displayorder' => '2',
		'title' => '性別',
		'identifier' => 'gender',
		'type' => 'radio',
		'rules' => array (
			      'required' => '0',
			      'unchangeable' => '0',
			      'choices' => "1=男\\r\n2=女",
			   ),
		),
	16 => array (
		'classid' => '2',
		'displayorder' => '0',
		'title' => '房屋類型',
		'identifier' => 'property',
		'type' => 'select',
		'rules' => array (
			      'choices' => "1=寫字樓\\r\n2=公寓\r\n3=小區\r\n4=平房\r\n5=別墅\r\n6=地下室",
			   ),
		),
	17 => array (
		'classid' => '2',
		'displayorder' => '0',
		'title' => '座向',
		'identifier' => 'face',
		'type' => 'radio',
	    	'rules' => array (
	      			'required' => '0',
	      			'unchangeable' => '0',
	      			'choices' => "1=南向\r\n2=北向\r\n3=西向\r\n4=東向",
	    		),
	  	),
      18 => array (
        	'classid' => '2',
        	'displayorder' => '0',
        	'title' => '裝修情況',
        	'identifier' => 'makes',
        	'type' => 'radio',
        	'rules' => array (
          			'required' => '0',
          			'unchangeable' => '0',
          			'choices' => "1=無裝修\\r\n2=簡單裝修\r\n3=精裝修",
        		),
      	),
      19 => array (
        	'classid' => '2',
        	'displayorder' => '0',
        	'title' => '居室',
        	'identifier' => 'mode',
        	'type' => 'select',
        	'rules' => array (
          			'choices' => "1=獨居\r\n2=兩居室\\r\n3=三居室\\r\n4=四居室\\r\n5=別墅",
        		),
      	),
      23 => array (
        	'classid' => '2',
        	'displayorder' => '0',
        	'title' => '屋內設施',
        	'identifier' => 'equipment',
        	'type' => 'checkbox',
        	'rules' => array (
          			'required' => '0',
          			'unchangeable' => '0',
          			'choices' => "1=水電\r\n2=寬帶\r\n3=管道氣\\r\n4=有線電視\r\n5=電梯\r\n6=電話\r\n7=冰箱\r\n8=洗衣機\\r\n9=熱水器\\r\n10=空調\r\n11=暖氣\r\n12=微波爐\\r\n13=油煙機\\r\n14=飲水機",
       		),
      	),
      25 => array (
        	'classid' => '2',
        	'displayorder' => '0',
        	'title' => '是否中介',
        	'identifier' => 'bool',
        	'type' => 'radio',
        	'rules' => array (
          			'required' => '0',
          			'unchangeable' => '0',
          			'choices' => "1=是\\r\n2=否",
        		),
      	),
      27 => array (
        	'classid' => '3',
       	'displayorder' => '0',
        	'title' => '星座',
        	'identifier' => 'Horoscope',
        	'type' => 'select',
        	'rules' => array (
          			'choices' => "1=白羊座\\r\n2=金牛座\\r\n3=雙子座\\r\n4=巨蟹座\\r\n5=獅子座\\r\n6=處女座\\r\n7=天秤座\\r\n8=天蠍座\\r\n9=射手座\\r\n10=摩羯座\\r\n11=水瓶座\\r\n12=雙魚座",
        		),
      	),
      30 => array (
        	'classid' => '3',
        	'displayorder' => '0',
        	'title' => '婚姻狀況',
        	'identifier' => 'marrige',
        	'type' => 'radio',
        	'rules' => array (
          			'choices' => "1=已婚\r\n2=未婚",
        		),
      	),
      31 => array (
        	'classid' => '3',
        	'displayorder' => '0',
        	'title' => '愛好',
        	'identifier' => 'hobby',
        	'type' => 'checkbox',
        	'rules' => array (
          			'choices' => "1=美食\r\n2=唱歌\r\n3=跳舞\r\n4=電影\r\n5=音樂\r\n6=戲劇\r\n7=聊天\r\n8=拍托\r\n9=電腦\r\n10=網絡\r\n11=遊戲\r\n12=繪畫\r\n13=書法\r\n14=雕塑\r\n15=異性\r\n16=閱讀\r\n17=運動\r\n18=旅遊\r\n19=八卦\r\n20=購物\r\n21=賺錢\r\n22=汽車\r\n23=攝影",
        		),
      	),
      32 => array (
        	'classid' => '3',
        	'displayorder' => '0',
        	'title' => '收入範圍',
        	'identifier' => 'salary',
        	'type' => 'select',
        	'rules' => array (
          			'required' => '0',
          			'unchangeable' => '0',
          			'choices' => "1=保密\r\n2=800元以上\\r\n3=1500元以上\\r\n4=2000元以上\\r\n5=3000元以上\\r\n6=5000元以上\\r\n7=8000元以上",
        		),
      	),
      34 => array (
        	'classid' => '1',
        	'displayorder' => '0',
        	'title' => '學歷',
        	'identifier' => 'education',
        	'type' => 'radio',
        	'rules' => array (
          			'required' => '0',
          			'unchangeable' => '0',
          			'choices' => "1=文盲\r\n2=小學\r\n3=初中\r\n4=高中\r\n5=中專\r\n6=大專\r\n7=本科\r\n8=研究生\\r\n9=博士",
        		),
      	),
      38 => array (
        	'classid' => '5',
        	'displayorder' => '0',
        	'title' => '席別',
        	'identifier' => 'seats',
        	'type' => 'select',
        	'rules' => array (
          			'choices' => "1=站票\r\n2=硬座\r\n3=軟座\r\n4=硬臥\r\n5=軟臥",
        		),
      	),
      44 => array (
        	'classid' => '4',
        	'displayorder' => '0',
        	'title' => '是否應屆',
        	'identifier' => 'recr_term',
        	'type' => 'radio',
        	'rules' => array (
    		      	'required' => '0',
    		      	'unchangeable' => '0',
    		      	'choices' => "1=應屆\r\n2=非應屆",
        		),
      	),
      48 => array (
        	'classid' => '4',
        	'displayorder' => '0',
        	'title' => '薪金',
        	'identifier' => 'recr_salary',
        	'type' => 'select',
        	'rules' => array (
          			'choices' => "1=面議\r\n2=1000以下\r\n3=1000~1500\r\n4=1500~2000\r\n5=2000~3000\r\n6=3000~4000\r\n7=4000~6000\r\n8=6000~8000\r\n9=8000以上",
        		),
      	),
      50 => array (
        	'classid' => '4',
        	'displayorder' => '0',
        	'title' => '工作性質',
        	'identifier' => 'recr_work',
        	'type' => 'radio',
        	'rules' => array (
          			'required' => '0',
          			'unchangeable' => '0',
          			'choices' => "1=全職\r\n2=兼職",
        		),
      	),
      53 => array (
        	'classid' => '4',
        	'displayorder' => '0',
        	'title' => '性別要求',
        	'identifier' => 'recr_sex',
        	'type' => 'checkbox',
        	'rules' => array (
          			'required' => '0',
          			'unchangeable' => '0',
          			'choices' => "1=男\\r\n2=女",
        		),
      	),
      62 => array (
        	'classid' => '5',
        	'displayorder' => '0',
        	'title' => '付款方式',
        	'identifier' => 'pay_type',
        	'type' => 'checkbox',
        	'rules' => array (
          			'required' => '0',
          			'unchangeable' => '0',
          			'choices' => "1=電匯\r\n2=支付寶\\r\n3=現金\r\n4=其他",
        		),
      	),
);

?>