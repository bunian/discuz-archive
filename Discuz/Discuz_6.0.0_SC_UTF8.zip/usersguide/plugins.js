document.write("<li><a href=\"plugins.htm\" target=\"_self\">插件相关首页</a>");
document.write("<li><a href=\"plugins_setup.htm\" target=\"_self\">插件安装</a>");
document.write("<li><a href=\"plugins_design.htm\" target=\"_self\">插件设计</a>");