document.write("<li><a href=\"intro.htm\" target=\"_self\">Discuz! 产品概况首页</a>");
document.write("<li><a href=\"intro_features.htm\" target=\"_self\">Discuz! 产品特色</a>");
document.write("<li><a href=\"intro_tech.htm\" target=\"_self\">Discuz! 新技术概述</a>");
document.write("<li><a href=\"intro_history.htm\" target=\"_self\">Discuz! 产品发展历程</a>");
document.write("<li><a href=\"intro_corp.htm\" target=\"_self\">康盛创想（北京）科技有限公司简介</a>");