<?php  if(!defined('IN_ADMINCP')) exit('Access Denied'); ?>

<table cellspacing="0" cellpadding="0" border="0" width="95%" align="center">
	<tr><td bgcolor="<?=BORDERCOLOR?>">
	<table border="0" cellspacing="<?=BORDERWIDTH?>" cellpadding="<?=TABLESPACE?>" width="100%">
		<tr class="header"><td><?=$lang['tips']?></td></tr>
		<tr bgcolor="<?=ALTBG1?>"><td>
		<br><?=$lang['admingroup_tips']?>
		</td></tr>
	</table>
	</td></tr>
</table>

<form method="post" action="admincp.php?action=admingroups">
<input type="hidden" name="formhash" value="<?=FORMHASH?>">
<table cellspacing="0" cellpadding="0" border="0" width="95%" align="center">
<tr><td bgcolor="<?=BORDERCOLOR?>">
<table border="0" cellspacing="<?=BORDERWIDTH?>" cellpadding="<?=TABLESPACE?>" width="100%">
<tr class="header" align="center"><td width="45">ID</td>
<td><?=$lang['admingroup_title']?></td><td><?=$lang['admingroup_global']?></td><td><?=$lang['admingroup_edit']?></tr>
<?=$admingroups?>
<tr height="1" bgcolor="<?=ALTBG2?>"><td colspan="4"></td></tr>
<tr align="center" bgcolor="<?=ALTBG1?>"><td><?=$lang['add_new']?></td>
<td ><input type="text" size="20" name="newadmintitle"></td>
<td></td>
<td></td>
</tr></table></tr></td></table><br>
<center><input type="submit" name="newtitlesubmit" value="<?=$lang['submit']?>"></center></form>
