<?php  if(!defined('IN_ADMINCP')) exit('Access Denied'); ?>
<br><br><br><br><hr size="0" noshade color="<?=BORDERCOLOR?>" width="80%">
<center><font style="font-size: 11px; font-family: Tahoma, Verdana, Arial">Powered by <a href="http://www.discuz.net" target="_blank" style="color: <?=TEXT?>"><b>Discuz!</b> <?=$version?></a> &nbsp;&copy; 2001-2005, <b>
<a href="http://www.discuz.com" target="_blank" style="color: <?=TEXT?>">�_�ʱd���@����ަ������q</a></b></font>
</body>
</html>
