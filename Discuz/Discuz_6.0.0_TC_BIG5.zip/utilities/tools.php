<?php

/*
	[Discuz!] Tools (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: tools.php 377 2007-05-31 06:33:51Z kimi $
*/

foreach(array('_COOKIE', '_POST', '_GET') as $_request) {
	foreach($$_request as $_key => $_value) {
		$_key{0} != '_' && $$_key = $_value;
	}
}

$tool_password = ''; //�бz�]�m�@�Ӥu��]�����j�ױK�X�A���ର�šI
$lockfile = 'forumdata/tool.lock';

define('DISCUZ_ROOT', dirname(__FILE__).'/');
define('VERSION', '1.300');
error_reporting(E_ERROR | E_WARNING | E_PARSE);
@set_time_limit(0);


if(file_exists($lockfile)) {
	errorpage("�u��c�w�����A�p�ݨϥνгq�LFTP�}�ҡI");
} elseif ($tool_password == ''){
	errorpage('�K�X���ର�šA�Эק糧���$tool_password�]�m�K�X�I');
}

if($_POST['action'] == 'login') {
	setcookie('toolpassword', $_POST['toolpassword'], 0);
	echo '<meta http-equiv="refresh" content="2 url=?">';
	errorpage("�еy���A�{�ǵn�����I");
}

if(isset($_COOKIE['toolpassword'])) {
	if($_COOKIE['toolpassword'] != $tool_password) {
		errorpage("login");
	}
} else {
		errorpage("login");
}

$action = $_GET['action'];

if($action == 'repair') {
	$check = $_GET['check'];
	$nohtml = $_GET['nohtml'];
	$iterations = $_GET['iterations'];
	$simple = $_GET['simple'];

	if(@!include("./config.inc.php")) {
		if(@!include("./config.php")) {
			exit("�Х��W��config���H�O�ұz���ƾڮw�ॿ�`�챵�I");
		}
	}
	mysql_connect($dbhost, $dbuser, $dbpw);
	mysql_select_db($dbname);
	$counttables = $oktables = $errortables = $rapirtables = 0;

	if($check) {

	$tables=mysql_query("SHOW TABLES");

	if(!$nohtml) {
		echo "<HTML><HEAD></HEAD><BODY><table border=1 cellspacing=0 cellpadding=4 STYLE=\"font-family: Tahoma, Verdana; font-size: 11px\">";
	}

	if($iterations) {
		$iterations --;
	}
	while($table=mysql_fetch_row($tables)) {
		if(substr($table[0], -8) != 'sessions') {
			$counttables += 1;
			$answer=checktable($table[0],$iterations);
			if(!$nohtml) {
			echo "<tr><td colspan=4>&nbsp;</td></tr>";
			} elseif (!$simple) {
			flush();
			}
		}
	}

	if(!$nohtml) {
		echo "</table></BODY></HTML>";
	}

	if($simple) {
	htmlheader();
	echo '<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tr><td>
		<p class="subtitle">Discuz! �ˬd�׽Ƽƾڮw <ul>
		<center><p class="subtitle">�ˬd���G
		<div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;">
			<table width="100%" cellpadding="6" cellspacing="0" border="0">
				<tr align="center" class="header"><td width="25%">�ˬd��(�i)</td><td width="25%">���`��(�i)</td><td width="25%">���~��(�i)</td><td width="25%">���~��(��)</td></tr>
				<tr align="center"><td width="25%"><?=$counttables?></td><td width="25%"><?=$oktables?></td><td width="25%"><?=$rapirtables?></td><td width="25%"><?=$errortables?></td></tr>
			</table>
		</div><br>�ˬd���G�S�����~��Ъ�^�u��c�����Ϥ��h�~��״_<p><b><a href="?action=repair">�~��״_</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?">��^����</a></b></center>

		<br><br>
		<p><font color="red">�`�N�G
		<br><p style="text-indent: 3em; margin: 0;">��ƾڮw�ާ@�i��|�X�{�N�~�{�H���o�ͤί}�a�A�ҥH�Х��ƥ��n�ƾڮw�A�i��W�z�ާ@�I�t�~�бz��ܪA�Ⱦ����O����p���ɭԶi��@���u�ƾާ@�C
		<br><p style="text-indent: 3em; margin: 0;">���z�ϥΧ���Discuz! �t�κ��@�u��c��A���I����w�u��c�H�T�O�t�Ϊ��w���I�U���ϥΫe�u�ݭn�b/forumdata�ؿ��U�R��tool.lock���Y�i�}�l�ϥΡC</p></font>
		</td></tr></table>';
	}
	} else {
		htmlheader();
		echo '<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<tr><td>
				<p class="subtitle">Discuz! �ˬd�׽Ƽƾڮw <ul>
				<p class="subtitle">�����G<p style="text-indent: 3em; margin: 0;">�z�i�H�q�L�U�����覡�״_�w�g�l�a���ƾڮw�C�I����Э@�ߵ��ݭ״_���G�I
				<p style="text-indent: 3em; margin: 0;">���{�ǥi�H�״_�`�����ƾڮw���~�A���L�k�O�ҥi�H�״_�Ҧ����ƾڮw���~�C(�ݭn MySQL 3.23+)
				<br><br>
				<ul>
				<li> <a href="?action=repair&check=1&nohtml=1&simple=1">�ˬd�ù��խ׽Ƽƾڮw1��</a>
				<li> <a href="?action=repair&check=1&iterations=5&nohtml=1&simple=1">�ˬd�ù��խ׽Ƽƾڮw5��</a> (�]���ƾڮwŪ�g���Y�i�঳�ɻݭn�h�״_�X���~�৹���״_���\\)
				</ul>
				<p><font color="red">�`�N�G
				<br><p style="text-indent: 3em; margin: 0;">��ƾڮw�ާ@�i��|�X�{�N�~�{�H���o�ͤί}�a�A�ҥH�Х��ƥ��n�ƾڮw�A�i��W�z�ާ@�I�t�~�бz��ܪA�Ⱦ����O����p���ɭԶi��@���u�ƾާ@�C
				<br><p style="text-indent: 3em; margin: 0;">���z�ϥΧ���Discuz! �t�κ��@�u��c��A���I����w�u��c�H�T�O�t�Ϊ��w���I�U���ϥΫe�u�ݭn�b/forumdata�ؿ��U�R��tool.lock���Y�i�}�l�ϥΡC</p></font>
				</td></tr></table>';
	}
	htmlfooter();
} elseif ($action == 'check') {
	htmlheader();
	//6.�������ҬO�_���DZ/SS�A�d�ݼƾڮw�M�����r�Ŷ��A�ӷP�H��    charset,dbcharset, php,mysql,zend,php�u�аO
	if(@!include("./config.inc.php")) {
		if(@!include("./config.php")) {
			exit("�Х��W��config���H�O�ұz���ƾڮw�ॿ�`�챵�I");
		}
	}
	$curr_os = PHP_OS;

	if(!function_exists('mysql_connect')) {
		$curr_mysql = '�����';
		$msg .= "<li>�z���A�Ⱦ������MySql�ƾڮw�A�L�k�w�˽׾µ{��</li>";
		$quit = TRUE;
	} else {
		if(@mysql_connect($dbhost, $dbuser, $dbpw)) {
			$curr_mysql =  mysql_get_server_info();
		} else {
			$curr_mysql = '���';
		}
	}

	$curr_php_version = PHP_VERSION;
	if($curr_php_version < '4.0.6') {
		$msg .= "<li>�z�� PHP �����p�� 4.0.6, �L�k�ϥ� Discuz! / SuperSite�C</li>";
	}
	if(!ini_get('short_open_tag')) {
		$curr_short_tag = '����';
		$msg .='<li>�бN php.ini ���� short_open_tag �]�m�� On�A�_�h�L�k�ϥν׾¡C</li>';
	} else {
		$curr_short_tag = '�}��';
	}
	if(@ini_get(file_uploads)) {
		$max_size = @ini_get(upload_max_filesize);
		$curr_upload_status = '�z�i�H�W�Ǫ��󪺳̤j�ؤo: '.$max_size;
	} else {
		$msg .= "<li>����W�ǩά����ާ@�Q�A�Ⱦ��T��C</li>";
	}

	if(OPTIMIZER_VERSION < 3.0) {
		$msg .="<li>�z��ZEND�����C��3.x,�N�L�k�ϥ�SuperSite.</li>";
	}
	

	$curr_disk_space = intval(diskfreespace('.') / (1024 * 1024)).'M';
	?>
	<div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;float:center;">
	<table width="100%" border="0" cellpadding="6" cellspacing="0" align="center">
	<tr class="header"><td></td><td>Discuz! / SuperSite �һݰt�m</td><td>���e�A�Ⱦ�</td>
	</tr><tr class="option">
	<td class="altbg2">�ާ@�t��</td>
	<td class="altbg1">����</td>
	<td class="altbg2"><?=$curr_os?></td>
	</tr><tr class="option">
	<td class="altbg2">PHP ����</td>
	<td class="altbg1">4.0.6+</td>
	<td class="altbg2"><?=$curr_php_version?></td>
	</tr>
	<tr class="option">
	<td class="altbg2">�u�аO���A</td>
	<td class="altbg1">�}��</td>
	<td class="altbg2"><?=$curr_short_tag?></td></tr>
	<tr class="option">
	<td class="altbg2">MySQL ���</td>
	<td class="altbg1">���</td>
	<td class="altbg2"><?=$curr_mysql?></td></tr>
	<tr class="option">
	<td class="altbg2">ZEND ���</td>
	<td class="altbg1">���</td>
	<td class="altbg2"><?=OPTIMIZER_VERSION?></td>
	
	</tr><tr class="option">
	<td class="altbg2">�ϽL�Ŷ�</td>
	<td class="altbg1">10M+</td>
	<td class="altbg2"><?=$curr_disk_space?></td>
	</tr><tr class="option">
	<td class="altbg2">����W��</td>
	<td class="altbg1">����</td>
	<td class="altbg2"><?=$curr_upload_status?></td>
	</tr>
	<?
	echo '<tr class="option"><td colspan="3" class="altbg2">';
	$msg == '' && $msg = '�����ˬd����,�S���o�{���D.';
	echo '<br>&nbsp;&nbsp;<font color="red">'.$msg.'</font></td></tr>';
	?>
	
	</table></div>
	<?
	htmlfooter();
} elseif ($action == 'filecheck') {
	require_once './include/common.inc.php';

	@set_time_limit(0);

	$do = isset($do) ? $do : 'advance';

	$lang = array(
		'filecheck_fullcheck' => '�j���������',
		'filecheck_fullcheck_select' => '�j��������� - ��ܻݭn�j�����ؿ�',
		'filecheck_fullcheck_selectall' => '[�j�������ؿ�]',
		'filecheck_fullcheck_start' => '�}�l�ɶ�:',
		'filecheck_fullcheck_current' => '���e�ɶ�:',
		'filecheck_fullcheck_end' => '�����ɶ�:',
		'filecheck_fullcheck_file' => '���e���:',
		'filecheck_fullcheck_foundfile' => '�o�{��������: ',
		'filecheck_fullcheck_nofound' => '�S���o�{���󥼪����'
	);

	if(!$discuzfiles = @file('admin/discuzfiles.md5')) {
		cpmsg('filecheck_nofound_md5file');
	}
	htmlheader();
	if($do == 'advance') {
		$dirlist = array();
		$starttime = date('Y-m-d H:i:s');
		$cachelist = $templatelist = array();
		if(empty($checkdir)) {
			checkdirs('./');
		} elseif($checkdir == 'all') {
			echo "\n<script>var dirlist = ['./'];var runcount = 0;var foundfile = 0</script>";
		} else {
			$checkdir = str_replace('..', '', $checkdir);
			$checkdir = $checkdir{0} == '/' ? '.'.$checkdir : $checkdir;
			checkdirs($checkdir.'/');
			echo "\n<script>var dirlist = ['$checkdir/'];var runcount = 0;var foundfile = 0</script>";
		}

		echo '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td>
			<p class="subtitle">�j���������<ul>
			<center><div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;float:center;">
			<table width="100%" border="0" cellpadding="6" cellspacing="0">
			<tr><th colspan="2" class="header">'.(empty($checkdir) ? '<a href="tools.php?action=filecheck&do=advance&start=yes&checkdir=all">'.$lang['filecheck_fullcheck_selectall'].'</a>' : $lang['filecheck_fullcheck'].($checkdir != 'all' ? ' - '.$checkdir : '')).'</th></tr>
			<script language="JavaScript" src="include/javascript/common.js"></script>';
		if(empty($checkdir)) {
			echo '<tr><td class="altbg1"><br><ul>';
			foreach($dirlist as $dir) {
				$subcount = count(explode('/', $dir));
				echo '<li>'.str_repeat('-', ($subcount - 2) * 4);
				echo '<a href="tools.php?action=filecheck&do=advance&start=yes&checkdir='.rawurlencode($dir).'">'.basename($dir).'</a></li>';
			}
			echo '</ul></td></tr></table>';
		} else {
			echo '<tr><td class="altbg1">'.$lang['filecheck_fullcheck_start'].' '.$starttime.'<br><span id="msg"></span></td></tr><tr><td class="altbg2"><div id="checkresult"></div></td></tr></table>
				<iframe name="checkiframe" id="checkiframe" style="display: none"></iframe>';
			echo "<script>checkiframe.location = 'tools.php?action=filecheck&do=advancenext&start=yes&dir=' + dirlist[runcount];</script>";
		}
		htmlfooter();
		exit;
	} elseif($do == 'advancenext') {
		$nopass = 0;
		foreach($discuzfiles as $line) {
			$md5files[] = trim(substr($line, 34));
		}
		$foundfile = checkfullfiles($dir);

		echo "<script>";
		if($foundfile) {
			echo "parent.foundfile += $foundfile;";
		}
		echo "parent.runcount++;
		if(parent.dirlist.length > parent.runcount) {
			parent.checkiframe.location = 'tools.php?action=filecheck&do=advancenext&start=yes&dir=' + parent.dirlist[parent.runcount];
		} else {
			var msg = '';
			msg = '$lang[filecheck_fullcheck_end] ".addslashes(date('Y-m-d H:i:s'))."';
			if(parent.foundfile) {
				msg += '<br>$lang[filecheck_fullcheck_foundfile] ' + parent.foundfile;
			} else {
				msg += '<br>$lang[filecheck_fullcheck_nofound]';
			}
			parent.$('msg').innerHTML = msg;
		}</script>";
		exit;
	}
} elseif ($action == 'logout') {
	setcookie('toolpassword', '', -86400 * 365);
	errorpage("�h�X���\\�I");
} elseif ($action == 'mysqlclear') {
	ob_implicit_flush();

	define('IN_DISCUZ', TRUE);

	require './config.inc.php';
	require './include/db_'.$database.'.class.php';

	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
	$db->select_db($dbname);

	if(!get_cfg_var('register_globals')) {
		@extract($_GET, EXTR_SKIP);
	}

	$rpp			=	"1000"; //�C���B�z�h�ֱ��ƾ�
	$totalrows		=	isset($totalrows) ? $totalrows : 0;
	$convertedrows	=	isset($convertedrows) ? $convertedrows : 0;
	$start			=	isset($start) && $start > 0 ? $start : 0;
	$sqlstart		=	isset($start) && $start > $convertedrows ? $start - $convertedrows : 0;
	$end			=	$start + $rpp - 1;
	$stay			=	isset($stay) ? $stay : 0;
	$converted		=	0;
	$step			=	isset($step) ? $step : 0;
	$info			=	isset($info) ? $info : '';
	$action			=	array(
						'1'=>'���E�^�Ƽƾھ�z',
						'2'=>'���E����ƾھ�z',
						'3'=>'���E�|���ƾھ�z',
						'4'=>'���E�O���ƾھ�z',
						'5'=>'���E�u�H�ƾھ�z',
						'6'=>'�D�D�H����z',
						'7'=>'�����ƾڤ��E��z'
					);
	$steps			=	count($action);
	$actionnow		=	isset($action[$step]) ? $action[$step] : '����';
	$maxid			=	isset($maxid) ? $maxid : 0;
	$tableid		=	isset($tableid) ? $tableid : 1;

	htmlheader();
	if($step==0){
	?>
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr><td>
	<p class="subtitle">�ƾڮw���l�ƾھ�z <ul>
	<center><div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;float:center;">
	<table width="100%" border="0" cellpadding="6" cellspacing="0">
	<tr class="header"><td colspan="9">�ƾڮw���l�ƾھ�z���ظԲӫH��</td></tr>
	<tr align="center" style="background: #FFFFD9;">
	<td>Posts������z</td><td>Attachments������z</td>
	<td>Members������z</td><td>Forums������z</td>
	<td>Pms������z</td><td>Threads������z</td><td>�Ҧ�������z</td></tr><tr align="center">
	<td class="altbg2">[<a href="?action=mysqlclear&step=1&stay=1">��B��z</a>]</td>
	<td class="altbg1">[<a href="?action=mysqlclear&step=2&stay=1">��B��z</a>]</td>
	<td class="altbg2">[<a href="?action=mysqlclear&step=3&stay=1">��B��z</a>]</td>
	<td class="altbg1">[<a href="?action=mysqlclear&step=4&stay=1">��B��z</a>]</td>
	<td class="altbg2">[<a href="?action=mysqlclear&step=5&stay=1">��B��z</a>]</td>
	<td class="altbg2">[<a href="?action=mysqlclear&step=6&stay=1">��B��z</a>]</td>
	<td class="altbg1">[<a href="?action=mysqlclear&step=1&stay=0">������z</a>]</td>
	</tr>
	</center></table></div>
	<p><font color="red">�`�N�G
	<br><p style="text-indent: 3em; margin: 0;">��ƾڮw�ާ@�i��|�X�{�N�~�{�H���o�ͤί}�a�A�ҥH�Х��ƥ��n�ƾڮw�A�i��W�z�ާ@�I�t�~�бz��ܪA�Ⱦ����O����p���ɭԶi��@���u�ƾާ@�C
	<br><p style="text-indent: 3em; margin: 0;">���z�ϥΧ���Discuz! �t�κ��@�u��c��A���I����w�u��c�H�T�O�t�Ϊ��w���I�U���ϥΫe�u�ݭn�b/forumdata�ؿ��U�R��tool.lock���Y�i�}�l�ϥΡC</p></font>
	</td></tr></table>
	<?php
	} elseif ($step=='1'){

		$query = "SELECT pid,tid FROM {$tablepre}posts LIMIT ".$sqlstart.", $rpp";
		$posts=$db->query($query);
			while ($post = $db->fetch_array($posts)){
				$query = $db->query("SELECT tid FROM {$tablepre}threads WHERE tid='".$post['tid']."'");
				if ($db->result($query, 0)) {
					} else {
						$convertedrows ++;
						$db->query("DELETE FROM {$tablepre}posts WHERE pid='".$post['pid']."'");
					}
				$converted = 1;
				$totalrows ++;
		}
			if($converted || $end < $maxid) {
				continue_redirect();
			} else {
				stay_redirect();
			}

	} elseif ($step=='2'){

		$query = "SELECT aid,pid,attachment FROM {$tablepre}attachments LIMIT ".$sqlstart.", $rpp";
		$posts=$db->query($query);
			while ($post = $db->fetch_array($posts)){
				$query = $db->query("SELECT pid FROM {$tablepre}posts WHERE pid='".$post['pid']."'");
				if ($db->result($query, 0)) {
					} else {
						$convertedrows ++;
						$db->query("DELETE FROM {$tablepre}attachments WHERE aid='".$post['aid']."'");
						$attachmentdir = DISCUZ_ROOT.'./attachments/';
						@unlink($attachmentdir.$post['attachment']);
					}
				$converted = 1;
				$totalrows ++;
		}
			if($converted || $end < $maxid) {
				continue_redirect();
			} else {
				stay_redirect();
			}

	} elseif ($step=='3'){

		$query = "SELECT uid FROM {$tablepre}memberfields LIMIT ".$sqlstart.", $rpp";
		$posts=$db->query($query);
			while ($post = $db->fetch_array($posts)){
				$query = $db->query("SELECT uid FROM {$tablepre}members WHERE uid='".$post['uid']."'");
				if ($db->result($query, 0)) {
					} else {
						$convertedrows ++;
						$db->query("DELETE FROM {$tablepre}memberfields WHERE uid='".$post['uid']."'");
					}
				$converted = 1;
				$totalrows ++;
		}
			if($converted || $end < $maxid) {
				continue_redirect();
			} else {
				stay_redirect();
			}

	} elseif ($step=='4'){

		$query = "SELECT fid FROM {$tablepre}forumfields LIMIT ".$sqlstart.", $rpp";
		$posts=$db->query($query);
			while ($post = $db->fetch_array($posts)){
				$query = $db->query("SELECT fid FROM {$tablepre}forums WHERE fid='".$post['fid']."'");
				if ($db->result($query, 0)) {
					} else {
						$convertedrows ++;
						$db->query("DELETE FROM {$tablepre}forumfields WHERE fid='".$post['fid']."'");
					}
				$converted = 1;
				$totalrows ++;
		}
			if($converted || $end < $maxid) {
				continue_redirect();
			} else {
				stay_redirect();
			}

	} elseif ($step=='5'){

		$query = "SELECT msgfromid,msgtoid FROM {$tablepre}pms LIMIT ".$sqlstart.", $rpp";
		$posts=$db->query($query);
			while ($post = $db->fetch_array($posts)){
				$query = $db->query("SELECT uid FROM {$tablepre}members WHERE uid='".$post['msgtoid']."'");
				if ($db->result($query, 0)) {
					} else {
						$convertedrows ++;
						$db->query("DELETE FROM {$tablepre}pms WHERE msgtoid='".$post['msgtoid']."'");
					}
				$converted = 1;
				$totalrows ++;
		}
			if($converted || $end < $maxid) {
				continue_redirect();
			} else {
				stay_redirect();
			}

	} elseif ($step=='6'){

		$query = "SELECT tid FROM {$tablepre}threads LIMIT ".$sqlstart.", $rpp";
		$posts=$db->query($query);
			while ($threads = $db->fetch_array($posts)){
				$query = $db->query("SELECT COUNT(*) FROM {$tablepre}posts WHERE tid='".$threads['tid']."' AND invisible='0'");
				$replynum = $db->result($query, 0) - 1;
				if ($replynum < 0) {
					$db->query("DELETE FROM {$tablepre}threads WHERE tid='".$threads['tid']."'");
				} else {
					$query = $db->query("SELECT a.aid FROM {$tablepre}posts p, {$tablepre}attachments a WHERE a.tid='".$threads['tid']."' AND a.pid=p.pid AND p.invisible='0' LIMIT 1");
					$attachment = $db->num_rows($query) ? 1 : 0;//�״_����
					$query  = $db->query("SELECT pid, subject, rate FROM {$tablepre}posts WHERE tid='".$threads['tid']."' AND invisible='0' ORDER BY dateline LIMIT 1");
					$firstpost = $db->fetch_array($query);
					$firstpost['subject'] = addslashes($firstpost['subject']);
					@$firstpost['rate'] = $firstpost['rate'] / abs($firstpost['rate']);//�״_�o��
					$query  = $db->query("SELECT author, dateline FROM {$tablepre}posts WHERE tid='".$threads['tid']."' AND invisible='0' ORDER BY dateline DESC LIMIT 1");
					$lastpost = $db->fetch_array($query);//�״_�̫�o��
					$db->query("UPDATE {$tablepre}threads SET subject='".$firstpost['subject']."', replies='$replynum', lastpost='".$lastpost['dateline']."', lastposter='".addslashes($lastpost['author'])."', rate='".$firstpost['rate']."', attachment='$attachment' WHERE tid='".$threads['tid']."'", 'UNBUFFERED');
					$db->query("UPDATE {$tablepre}posts SET first='1', subject='".$firstpost['subject']."' WHERE pid='".$firstpost['pid']."'", 'UNBUFFERED');
					$db->query("UPDATE {$tablepre}posts SET first='0' WHERE tid='".$threads['tid']."' AND pid<>'".$firstpost['pid']."'", 'UNBUFFERED');
				}
				$converted = 1;
				$totalrows ++;
			}
			if($converted || $end < $maxid) {
				continue_redirect();
			} else {
				stay_redirect();
			}

	} elseif ($step=='7'){

		echo '<div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;float:center;">
	<table width="100%" border="0" cellpadding="6" cellspacing="0">
	<tr class="header"><td colspan="9">�������l�ƾھ�z</td></tr><tr align="center" class="category">
	<td>�Ҧ��ƾھ�z�ާ@����.<br><br><font color="red">�b�z���ϥΥ��{�Ǫ��ɭ�,�Ъ`�N��w�ΧR�������!</font><br></td></tr></table></div>';

	}
	htmlfooter();
} elseif ($action == 'repair_auto') {
	if(@!include("./config.inc.php")) {
		if(@!include("./config.php")) {
			exit("�Х��W��config���H�O�ұz���ƾڮw�ॿ�`�챵�I");
		}
	}
	mysql_connect($dbhost, $dbuser, $dbpw);
	mysql_select_db($dbname);
	@set_time_limit(0);
	$querysql = array(
		'activityapplies' => 'applyid',
		'adminnotes' => 'id',
		'advertisements' => 'advid',
		'announcements' => 'id',
		'attachments' => 'aid',
		'attachtypes' => 'id',
		'banned' => 'id',
		'bbcodes' => 'id',
		'crons' => 'cronid',
		'faqs' => 'id',
		'forumlinks' => 'id',
		'forums' => 'fid',
		'itempool' => 'id',
		'magicmarket' => 'mid',
		'magics' => 'magicid',
		'medals' => 'medalid',
		'members' => 'uid',
		'pluginhooks' => 'pluginhookid',
		'plugins' => 'pluginid',
		'pluginvars' => 'pluginvarid',
		'pms' => 'pmid',
		'pmsearchindex' => 'searchid',
		'polloptions' => 'polloptionid',
		'posts' => 'pid',
		'profilefields' => 'fieldid',
		'projects' => 'id',
		'ranks' => 'rankid',
		'searchindex' => 'searchid',
		'smilies' => 'id',
		'styles' => 'styleid',
		'stylevars' => 'stylevarid',
		'templates' => 'templateid',
		'threads' => 'tid',
		'threadtypes' => 'typeid',
		'tradecomments' => 'id',
		'typeoptions' => 'optionid',
		'words' => 'id'
	);

	htmlheader();
	echo '<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tr><td>
		<p class="subtitle">Discuz! �ۼW���r�q�״_ <ul>
		<center><p class="subtitle">�ˬd���G
		<div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;">
		<table width="100%" cellpadding="6" cellspacing="0" border="0">
		<tr align="center" class="header"><td width="25%">�ƾڪ��W</td><td width="25%">�r�q�W</td><td width="25%">�O�_���`</td><td width="25%">�ۼW�����A</td></tr>';
	foreach($querysql as $key => $keyfield) {
		echo '<tr align="center"><td width="25%"  class="altbg2" align="left">'.$tablepre.$key.'</td><td width="25%" class="altbg1">'.$keyfield.'</td>';
		if($query = @mysql_query("Describe $tablepre$key $keyfield")) {
			$istableexist = '�s�b';
			$field = @mysql_fetch_array($query);
			if(empty($field[5]) &&  $field[0] == $keyfield) {
				mysql_query("ALTER TABLE $tablepre$key CHANGE $keyfield $keyfield $field[1] NOT NULL AUTO_INCREMENT");
				$tablestate = '<font color="red">�w�g�״_</font>';
			} else {
				$tablestate = '���`';
			}
		} else {
			$istableexist = '���s�b';
			$tablestate = '----';
		}
		echo '<td width="25%" class="altbg2">'.$istableexist.'</td><td width="25%" class="altbg1">'.$tablestate.'</td></tr>';
	}
	echo '</table>
		</div><br></center>

		<br><br>
		<p><font color="red">�`�N�G
		<br><p style="text-indent: 3em; margin: 0;">��ƾڮw�ާ@�i��|�X�{�N�~�{�H���o�ͤί}�a�A�ҥH�Х��ƥ��n�ƾڮw�A�i��W�z�ާ@�I�t�~�бz��ܪA�Ⱦ����O����p���ɭԶi��@���u�ƾާ@�C
		<br><p style="text-indent: 3em; margin: 0;">���z�ϥΧ���Discuz! �t�κ��@�u��c��A���I����w�u��c�H�T�O�t�Ϊ��w���I�U���ϥΫe�u�ݭn�b/forumdata�ؿ��U�R��tool.lock���Y�i�}�l�ϥΡC</p></font>
		</td></tr></table>';
	htmlfooter();
} elseif ($action == 'restore') {
	ob_implicit_flush();

	define('IN_DISCUZ', TRUE);

	if(@(!include("./config.inc.php")) || @(!include('./include/db_'.$database.'.class.php'))) {
		if(@(!include("./config.php")) || @(!include('./include/db_'.$database.'.class.php'))) {
			exit("�Х��W�ǩҦ��s�������{�Ǥ���A�B�楻�ɯŵ{�ǡI");
		}
	}

	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
	$db->select_db($dbname);

	if(!get_cfg_var('register_globals')) {
		@extract($HTTP_GET_VARS);
	}

	$sqldump = '';
	htmlheader();
	?>
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr><td>
	<p class="subtitle">�ƾڮw��_��Τu�� <ul>

	<?php
	echo "���{�ǥΩ��_�� Discuz! �ƥ����ƾڤ��,�� Discuz! �X�{���D�L�k�B��M��Ƽƾ�,<br>".
		"�� phpMyAdmin �S�����_�j����,�i���ըϥΦ��u��.<br><br>".
		"�`�N:<ul>".
		"<li>�u���_�s��b�A�Ⱦ�(���{�Υ��a)�W���ƾڤ��,�p�G�z���ƾڤ��b�A�Ⱦ��W,�Х� FTP �W��</li>".
		"<li>�ƾڤ�󥲶��� Discuz! �ɥX�榡,�ó]�m�����ݩʨ� PHP ���Ū��</li>".
		"<li>�кɶq��ܪA�Ⱦ��Ŷ��ɬq�ާ@,�H�קK�W��.�p�{�Ǫ��[(�W�L 10 ����)������,�Ш�s</b></li></ul>";

	if($file) {
		if(strtolower(substr($file, 0, 7)) == "http://") {
			echo "�q���{�ƾڮw��Ƽƾ� - Ū�����{�ƾ�:<br><br>";
			echo "�q���{�A�Ⱦ�Ū����� ... ";

			$sqldump = @fread($fp, 99999999);
			@fclose($fp);
			if($sqldump) {
				echo "���\\<br><br>";
			} elseif (!$multivol) {
				cexit("����<br><br><b>�L�k��Ƽƾ�</b>");
			}
		} else {
			echo "�q���a��Ƽƾ� - �ˬd�ƾڤ��:<br><br>";
			if(file_exists($file)) {
				echo "�ƾڤ�� $file �s�b�ˬd ... ���\\<br><br>";
			} elseif (!$multivol) {
				cexit("�ƾڤ�� $file �s�b�ˬd ... ����<br><br><br><b>�L�k��Ƽƾ�</b>");
			}

			if(is_readable($file)) {
				echo "�ƾڤ�� $file �iŪ�ˬd ... ���\\<br><br>";
				@$fp = fopen($file, "r");
				@flock($fp, 3);
				$sqldump = @fread($fp, filesize($file));
				@fclose($fp);
				echo "�q���aŪ���ƾ� ... ���\\<br><br>";
			} elseif (!$multivol) {
				cexit("�ƾڤ�� $file �iŪ�ˬd ... ����<br><br><br><b>�L�k��Ƽƾ�</b>");
			}
		}

		if($multivol && !$sqldump) {
			cexit("�����ƥ��d���ˬd ... ���\\<br><br><b>���߱z,�ƾڤw�g�������\\��_!�w���_��,�аȥ��R�����{��.</b>");
		}

		echo "�ƾڤ�� $file �榡�ˬd ... ";
		@list(,,,$method, $volume) = explode(',', base64_decode(preg_replace("/^# Identify:\s*(\w+).*/s", "\\1", preg_replace("/^(.+)/", "\\1", substr($sqldump, 0, 256)))));
		if($method == 'multivol' && is_numeric($volume)) {
			echo "���\\<br><br>";
		} else {
			cexit("����<br><br><b>�ƾګD Discuz! �����ƥ��榡,�L�k��_</b>");
		}

		if($onlysave == "yes") {
			echo "�N�ƾڤ��O�s�쥻�a�A�Ⱦ� ... ";
			$filename = DISCUZ_ROOT.'./forumdata'.strrchr($file, "/");
			@$filehandle = fopen($filename, "w");
			@flock($filehandle, 3);
			if(@fwrite($filehandle, $sqldump)) {
				@fclose($filehandle);
				echo "���\\<br><br>";
			} else {
				@fclose($filehandle);
				die("����<br><br><b>�L�k�O�s�ƾ�</b>");
			}
			echo "���\\<br><br><b>���߱z,�ƾڤw�g���\\�O�s�쥻�a�A�Ⱦ� <a href=\"".strstr($filename, "/")."\">$filename</a>.�w���_��,�аȥ��R�����{��.</b>";
		} else {
			$sqlquery = splitsql($sqldump);
			echo "����ާ@�y�y ... ���\\<br><br>";
			unset($sqldump);

			echo "���b��Ƽƾ�,�е��� ... <br><br>";
			foreach($sqlquery as $sql) {
				if(trim($sql)) {
					$db->query($sql);
					//echo "$sql<br>";
				}
			}
		if($auto == 'off'){
			$nextfile = str_replace("-$volume.sql", '-'.($volume + 1).'.sql', $file);
			cexit("�ƾڤ�� <b>$volume#</b> ��_���\\,�p�G���ݭn���~���_��L���ƾڤ��<br>���I��<b><a href=\"?action=restore&file=$nextfile&multivol=yes\">������_</a></b>	�γ\\��W��_�U�@�Ӽƾڤ��<b><a href=\"?action=restore&file=$nextfile&multivol=yes&auto=off\">��W��_�U�@�ƾڤ��</a></b>");
		} else {
			$nextfile = str_replace("-$volume.sql", '-'.($volume + 1).'.sql', $file);
			echo "�ƾڤ�� <b>$volume#</b> ��_���\\,�{�b�N�۰ʾɤJ��L�����ƥ��ƾ�.<br><b>�Ф������s�����Τ��_���{�ǹB��</b>";
			redirect("?action=restore&file=$nextfile&multivol=yes");
		}
		}
	} else {
			$exportlog = array();
			if(is_dir(DISCUZ_ROOT.'./forumdata')) {
				$dir = dir(DISCUZ_ROOT.'./forumdata');
				while($entry = $dir->read()) {
					$entry = "./forumdata/$entry";
					if(is_file($entry) && preg_match("/\.sql/i", $entry)) {
						$filesize = filesize($entry);
						$fp = fopen($entry, 'rb');
						$identify = explode(',', base64_decode(preg_replace("/^# Identify:\s*(\w+).*/s", "\\1", fgets($fp, 256))));
						fclose ($fp);
							if(preg_match("/\-1.sql/i", $entry) || $identify[3] == 'shell'){
								$exportlog[$identify[0]] = array(	'version' => $identify[1],
													'type' => $identify[2],
													'method' => $identify[3],
													'volume' => $identify[4],
													'filename' => $entry,
													'size' => $filesize);
							}
					} elseif (is_dir($entry) && preg_match("/backup\_/i", $entry)) {
						$bakdir = dir($entry);
							while($bakentry = $bakdir->read()) {
								$bakentry = "$entry/$bakentry";
								if(is_file($bakentry)){
									$fp = fopen($bakentry, 'rb');
									$bakidentify = explode(',', base64_decode(preg_replace("/^# Identify:\s*(\w+).*/s", "\\1", fgets($fp, 256))));
									fclose ($fp);
									if(preg_match("/\-1\.sql/i", $bakentry) || $bakidentify[3] == 'shell') {
										$identify['bakentry'] = $bakentry;
									}
								}
							}
							if(preg_match("/backup\_/i", $entry)){
								$exportlog[filemtime($entry)] = array(	'version' => $bakidentify[1],
													'type' => $bakidentify[2],
													'method' => $bakidentify[3],
													'volume' => $bakidentify[4],
													'bakentry' => $identify['bakentry'],
													'filename' => $entry);
							}
					}
				}
				$dir->close();
			} else {
				echo 'error';
			}
			krsort($exportlog);
			reset($exportlog);

			$exportinfo = '<br><center><div style="margin-top: 4px; border-top: 1px solid #7AC4EA; border-right: 1px solid #7AC4EA; border-left: 1px solid #7AC4EA; width: 80%;float:center;"><table width="100%" border="0" cellpadding="6" cellspacing="0">
	<tr class="header"><td colspan="9">�h���ƾڳƥ��O���ԲӫH��</td></tr>
	<tr align="center" style="background: #FFFFD9;">
	<td>�ƥ�����</td><td>����</td>
	<td>�ɶ�</td><td>����</td>
	<td>�d��</td><td>�ާ@</td></tr>';
			foreach($exportlog as $dateline => $info) {
				$info['dateline'] = is_int($dateline) ? gmdate("Y-m-d H:i", $dateline + 8*3600) : '����';
					switch($info['type']) {
						case 'full':
							$info['type'] = '�����ƥ�';
							break;
						case 'standard':
							$info['type'] = '�зǳƥ�(����)';
							break;
						case 'mini':
							$info['type'] = '�̤p�ƥ�';
							break;
						case 'custom':
							$info['type'] = '�۩w�q�ƥ�';
							break;
					}
				//$info['size'] = sizecount($info['size']);
				$info['volume'] = $info['method'] == 'multivol' ? $info['volume'] : '';
				$info['method'] = $info['method'] == 'multivol' ? '�h��' : 'shell';
				$info['url'] = str_replace(".sql", '', str_replace("-$info[volume].sql", '', substr(strrchr($info['filename'], "/"), 1)));
				$exportinfo .= "<tr align=\"center\">\n".
					"<td class=\"altbg2\" align=\"left\">".$info['url']."</td>\n".
					"<td class=\"altbg1\">$info[version]</td>\n".
					"<td class=\"altbg2\">$info[dateline]</td>\n".
					"<td class=\"altbg1\">$info[type]</td>\n";
				if($info['bakentry']){
				$exportinfo .= "<td class=\"altbg2\"><a href=\"?action=restore&bakdirname=".$info['url']."\">�d��</a></td>\n".
					"<td class=\"altbg1\"><a href=\"?action=restore&file=$info[bakentry]&importsubmit=yes\">[�����ɤJ]</a></td>\n</tr>\n";
				} else {
				$exportinfo .= "<td class=\"altbg2\"><a href=\"?action=restore&filedirname=".$info['url']."\">�d��</a></td>\n".
					"<td class=\"altbg1\"><a href=\"?action=restore&file=$info[filename]&importsubmit=yes\">[�����ɤJ]</a></td>\n</tr>\n";
				}
			}
		$exportinfo .= '</center></table></div>';
		echo $exportinfo;
		unset($exportlog);
		unset($exportinfo);
		echo "<br>";
	//�H�e�����ƥ��Ψ쪺�ƥ����p
	if(!empty($filedirname)){
			$exportlog = array();
			if(is_dir(DISCUZ_ROOT.'./forumdata')) {
					$dir = dir(DISCUZ_ROOT.'./forumdata');
					while($entry = $dir->read()) {
						$entry = "./forumdata/$entry";
						if(is_file($entry) && preg_match("/\.sql/i", $entry) && preg_match("/$filedirname/i", $entry)) {
							$filesize = filesize($entry);
							$fp = fopen($entry, 'rb');
							$identify = explode(',', base64_decode(preg_replace("/^# Identify:\s*(\w+).*/s", "\\1", fgets($fp, 256))));
							fclose ($fp);

							$exportlog[$identify[0]] = array(	'version' => $identify[1],
												'type' => $identify[2],
												'method' => $identify[3],
												'volume' => $identify[4],
												'filename' => $entry,
												'size' => $filesize);
						}
					}
					$dir->close();
				} else {
				}
				krsort($exportlog);
				reset($exportlog);

				$exportinfo = '<br><center><div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;float:center;"><table	width="100%" border="0" cellpadding="6" cellspacing="0">
								<tr class="header"><td colspan="9">�ƾڳƥ��O��</td></tr>
								<tr align="center" class="category">
								<td>���W</td><td>����</td>
								<td>�ɶ�</td><td>����</td>
								<td>�j�p</td><td>�覡</td>
								<td>����</td><td>�ާ@</td></tr>';
				foreach($exportlog as $dateline => $info) {
					$info['dateline'] = is_int($dateline) ? gmdate("Y-m-d H:i", $dateline + 8*3600) : '����';
						switch($info['type']) {
							case 'full':
								$info['type'] = '�����ƥ�';
								break;
							case 'standard':
								$info['type'] = '�зǳƥ�(����)';
								break;
							case 'mini':
								$info['type'] = '�̤p�ƥ�';
								break;
							case 'custom':
								$info['type'] = '�۩w�q�ƥ�';
								break;
						}
					//$info['size'] = sizecount($info['size']);
					$info['volume'] = $info['method'] == 'multivol' ? $info['volume'] : '';
					$info['method'] = $info['method'] == 'multivol' ? '�h��' : 'shell';
					$exportinfo .= "<tr align=\"center\">\n".
						"<td class=\"altbg2\" align=\"left\"><a href=\"$info[filename]\" name=\"".substr(strrchr($info['filename'], "/"), 1)."\">".substr(strrchr($info['filename'], "/"), 1)."</a></td>\n".
						"<td class=\"altbg1\">$info[version]</td>\n".
						"<td class=\"altbg2\">$info[dateline]</td>\n".
						"<td class=\"altbg1\">$info[type]</td>\n".
						"<td class=\"altbg2\">".get_real_size($info[size])."</td>\n".
						"<td class=\"altbg1\">$info[method]</td>\n".
						"<td class=\"altbg2\">$info[volume]</td>\n".
						"<td class=\"altbg1\"><a href=\"?action=restore&file=$info[filename]&importsubmit=yes&auto=off\">[�ɤJ]</a></td>\n</tr>\n";
				}
			$exportinfo .= '</center></table></div>';
			echo $exportinfo;
		}
	// 5.5�����Ψ쪺�Բӳƥ����p
	if(!empty($bakdirname)){
			$exportlog = array();
			$filedirname = DISCUZ_ROOT.'./forumdata/'.$bakdirname;
			if(is_dir($filedirname)) {
					$dir = dir($filedirname);
					while($entry = $dir->read()) {
						$entry = $filedirname.'/'.$entry;
						if(is_file($entry) && preg_match("/\.sql/i", $entry)) {
							$filesize = filesize($entry);
							$fp = fopen($entry, 'rb');
							$identify = explode(',', base64_decode(preg_replace("/^# Identify:\s*(\w+).*/s", "\\1", fgets($fp, 256))));
							fclose ($fp);

							$exportlog[$identify[0]] = array(	'version' => $identify[1],
												'type' => $identify[2],
												'method' => $identify[3],
												'volume' => $identify[4],
												'filename' => $entry,
												'size' => $filesize);
						}
					}
					$dir->close();
			} else {
				}
			krsort($exportlog);
			reset($exportlog);

			$exportinfo = '<br><center><div style="margin-top: 4px; border-top: 1px solid #7AC4EA; border-right: 1px solid #7AC4EA; border-left: 1px solid #7AC4EA; width: 80%;float:center;"><table width="100%" border="0" cellpadding="6" cellspacing="0">
					<tr class="header"><td colspan="9">�ƾڳƥ��O��</td></tr>
					<tr align="center" style="background: #FFFFD9;">
					<td>���W</td><td>����</td>
					<td>�ɶ�</td><td>����</td>
					<td>�j�p</td><td>�覡</td>
					<td>����</td><td>�ާ@</td></tr>';
			foreach($exportlog as $dateline => $info) {
				$info['dateline'] = is_int($dateline) ? gmdate("Y-m-d H:i", $dateline + 8*3600) : '����';
				switch($info['type']) {
					case 'full':
						$info['type'] = '�����ƥ�';
						break;
					case 'standard':
						$info['type'] = '�зǳƥ�(����)';
						break;
					case 'mini':
						$info['type'] = '�̤p�ƥ�';
						break;
					case 'custom':
						$info['type'] = '�۩w�q�ƥ�';
						break;
				}
				//$info['size'] = sizecount($info['size']);
				$info['volume'] = $info['method'] == 'multivol' ? $info['volume'] : '';
				$info['method'] = $info['method'] == 'multivol' ? '�h��' : 'shell';
				$exportinfo .= "<tr align=\"center\">\n".
						"<td class=\"altbg2\" align=\"left\"><a href=\"$info[filename]\" name=\"".substr(strrchr($info['filename'], "/"), 1)."\">".substr(strrchr($info['filename'], "/"), 1)."</a></td>\n".
						"<td class=\"altbg1\">$info[version]</td>\n".
						"<td class=\"altbg2\">$info[dateline]</td>\n".
						"<td class=\"altbg1\">$info[type]</td>\n".
						"<td class=\"altbg2\">".get_real_size($info[size])."</td>\n".
						"<td class=\"altbg1\">$info[method]</td>\n".
						"<td class=\"altbg2\">$info[volume]</td>\n".
						"<td class=\"altbg1\"><a href=\"?action=restore&file=$info[filename]&importsubmit=yes&auto=off\">[�ɤJ]</a></td>\n</tr>\n";
			}
			$exportinfo .= '</center></table></div>';
			echo $exportinfo;
		}
		echo "<br>";
		cexit("");
	}
} elseif ($action == 'replace') {
	htmlheader();
	$rpp			=	"500"; //�C���B�z�h�ֱ��ƾ�
	$totalrows		=	isset($totalrows) ? $totalrows : 0;
	$convertedrows	=	isset($convertedrows) ? $convertedrows : 0;
	$start			=	isset($start) && $start > 0 ? $start : 0;
	$end			=	$start + $rpp - 1;
	$converted		=	0;
	$maxid			=	isset($maxid) ? $maxid : 0;
	$threads_mod	=	isset($threads_mod) ? $threads_mod : 0;
	$threads_banned =	isset($threads_banned) ? $threads_banned : 0;
	$posts_mod		=	isset($posts_mod) ? $posts_mod : 0;
	ob_implicit_flush();
	define('IN_DISCUZ', TRUE);
	if(@!include("./config.inc.php")) {
		if(@!include("./config.php")) {
			exit("�Х��W��config���H�O�ұz���ƾڮw�ॿ�`�챵�I");
		}
	}
	require './include/db_'.$database.'.class.php';
	$db = new dbstuff;
	$db->connect($dbhost, $dbuser, $dbpw, $dbname, $pconnect);
	$db->select_db($dbname);
	if(isset($replacesubmit) || $start > 0) {
		$array_find = $array_replace = $array_findmod = $array_findbanned = array();
		$query = $db->query("SELECT find,replacement from {$tablepre}words");//��o�{���W�h{BANNED}��^���� {MOD}��i�f�֦C��
		while($row = $db->fetch_array($query)) {
			$find = $row['find'];
			$replacement = $row['replacement'];
			if($replacement == '{BANNED}') {
				$array_findbanned[] = $find;
			} elseif($replacement == '{MOD}') {
				$array_findmod[] = $find;
			} else {
				$array_find[] = $find;
				$array_replace[] = $replacement;
			}

		}
		function topattern_array($source_array) { //�N�Ʋե��h��
			$source_array = preg_replace("/\{(\d+)\}/",".{0,\\1}",$source_array);
			foreach($source_array as $key => $value) {
				$source_array[$key] = '/'.$value.'/i';
			}
			return $source_array;
		}
		$array_find = topattern_array($array_find);
		$array_findmod = topattern_array($array_findmod);
		$array_findbanned = topattern_array($array_findbanned);

		//�d��posts���ǳƴ���
		$sql = "SELECT pid, tid, first, subject, message from {$tablepre}posts where pid > $start and pid < $end";
		$query = $db->query($sql);
		while($row = $db->fetch_array($query)) {
			$pid = $row['pid'];
			$tid = $row['tid'];
			$subject = $row['subject'];
			$message = $row['message'];
			$first = $row['first'];
			$displayorder = 0;//  -2�f�� -1�^����
			if(count($array_findmod) > 0) {
				foreach($array_findmod as $value){
					if(preg_match($value,$subject.$message)){
						$displayorder = '-2';
						break;
					}
				}
			} 
			if(count($array_findbanned) > 0) {
				foreach($array_findbanned as $value){
					if(preg_match($value,$subject.$message)){
						$displayorder = '-1';
						break;
					}
				}
			}
			if($displayorder < 0) {
				if($displayorder == '-2' && $first == 0) {//�p���ߴN����f�֦^�_
					$posts_mod ++;
					$db->query("UPDATE {$tablepre}posts SET invisible = '$displayorder' WHERE pid = $pid");
				} else {
					if($db->affected_rows($db->query("UPDATE {$tablepre}threads SET displayorder = '$displayorder' WHERE tid = $tid and displayorder >= 0")) > 0) {
						$displayorder == '-2' && $threads_mod ++;
						$displayorder == '-1' && $threads_banned ++;
					}
				}
			}

			$subject = preg_replace($array_find,$array_replace,addslashes($subject));
			$message = preg_replace($array_find,$array_replace,addslashes($message));
			if($subject != addslashes($row['subject']) || $message != addslashes($row['message'])) {
				if($db->query("UPDATE {$tablepre}posts SET subject = '$subject', message = '$message' WHERE pid = $pid")) {
					$convertedrows ++;
				}
			}
			
			$converted = 1;
		}
		if($converted) {
			continue_redirect('replace',"&replacesubmit=1&threads_banned=$threads_banned&threads_mod=$threads_mod&posts_mod=$posts_mod");
		} else {
			echo "	<table width=\"80%\" cellspacing=\"1\" bgcolor=\"#000000\" border=\"0\" align=\"center\">
						<tr class=\"header\">
							<td>��q��������</td>
						</tr>";
			$threads_banned > 0 && print("<tr class=\"altbg1\"><td><br><li><font color=\"red\">".$threads_banned."</font>�ӥD�D�Q��J�^����.</li><center><br></td></tr>");
			$threads_mod > 0 && print("<tr class=\"altbg1\"><td><br><li><font color=\"red\">".$threads_mod."</font>�ӥD�D�Q��J�f�֦C��.</li><br></td></tr>");
			$posts_mod > 0 && print("<tr class=\"altbg1\"><td><br><li><font color=\"red\">".$posts_mod."</font>�Ӧ^�_�Q��J�f�֦C��.</li><br></td></tr>");
			echo "<tr class=\"altbg1\"><td><br><li>�����F<font color=\"red\">".$convertedrows."</font>�ӶK�l</li><br></td></tr>";
			echo "</table>";
		}
	} else {
		$query = $db->query("select * from {$tablepre}words");
		$i = 1;
		if($db->num_rows($query) < 1) {
			echo "<center><br><br><font color=\"red\">�藍�_,�{�b�٨S���L�o�W�h,�жi�J�׾«�x�]�m.</font><br><br></center>";
			htmlfooter();
			exit;
		}
	?>
		<form method="post" action="tools.php?action=replace">
				<div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 60%;float:center;">
				<table width="100%" border="0" cellpadding="6" cellspacing="0" align="center">
					<tr class="header"><td colspan="3">��q�����K�l���e</td></tr>
					<tr align="center" style="background: #FFFFD9;">
						<td align="center" width="30">�Ǹ�</td>
						<td align="center">���}���y</td>
						<td align="center">������</td></tr>
					<?
						while($row = $db->fetch_array($query)) {
					?>
					<tr>
						<td align="center" class="altbg2"><?=$i++?></td>
						<td align="center" class="altbg1"><?=$row['find']?></td>
						<td align="center" class="altbg2"><?=$row['replacement']?></td>
					</tr>
					<?}?>
				</table></div><br><br>
				<center><input type="submit" name=replacesubmit value="�}�l����"></center><br>
		</form>
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr><td>
	<p><font color="red">�`�N�G
	<br><p style="text-indent: 3em; margin: 0;">���{�Ƿ|���ӽ׾²{���L�o�W�h�ާ@�Ҧ��K�l���e.�p�ݭק�жi�׾«�x�C
	<br><p style="text-indent: 3em; margin: 0;">�W���C�X�F�z�׾·��e���L�o���y.</p></font>
	</td></tr></table>
	<?
	}
	htmlfooter();
} elseif ($action == 'runquery') {
	define('IN_DISCUZ',TRUE);
	if(@!include("./config.inc.php")) {
		if(@!include("./config.php")) {
			exit("�Х��W��config���H�O�ұz���ƾڮw�ॿ�`�챵�I");
		}
	}
	if($admincp['runquery'] != 1) {
		errorpage('�ϥΦ��\\��ݭn�N config.inc.php ������ $admincp[\'runquery\'] �]�m�קאּ 1�C');
	} else {
		if(!empty($_POST['sqlsubmit']) && $_POST['queries']) {
			mysql_connect($dbhost, $dbuser, $dbpw);
			mysql_select_db($dbname);
			if(mysql_query(stripslashes($_POST[queries]))) {
				errorpage("�ƾڮw�ɯŦ��\\,�v�T�C�� &nbsp;".mysql_affected_rows());
				if(strpos($_POST[queries],'settings')) {
					require_once './include/common.inc.php';
					require_once './include/cache.func.php';
					updatecache('settings');
				}
			} else {
				errorpage("�ƾڮw�ɯť���,mysql���~����:.<br />".mysql_error().'<br><br><br><a href="javascript:history.go(-1);" >[ �I���o�̪�^�W�@�� ]</a>');
			}
		}
		htmlheader();
		echo "<form method=\"post\" action=\"tools.php?action=runquery\">
		<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr class=\"header\"><td colspan=2>Discuz! �ƾڮw�ɯ� - �бN�ƾڮw�ɯŻy�y�߶K�b�U��</td></tr>
		<tr class=\"altbg1\">
		<td valign=\"top\">
		<div align=\"center\">
		<br /><select name=\"queryselect\" style=\"width:35%\" onChange=\"queries.value = this.value\">
			<option value = ''>�i���TOOLS���m�ɯŻy�y</option>
			<option value = \"REPLACE INTO ".$tablepre."settings (variable, value) VALUES ('seccodestatus', '0')\">�����Ҧ����ҽX�\\��</option>
			<option value = \"REPLACE INTO ".$tablepre."settings (variable, value) VALUES ('supe_status', '1')\">�����׾¤���supersite�\\��</option>
		</select>
		<br />
		<br /><textarea cols=\"85\" rows=\"10\" name=\"queries\">$queries</textarea><br />
		<br /></div>
		<br /><center><input class=\"button\" type=\"submit\" name=\"sqlsubmit\" value=\"����\"></center><br>
		</td></tr></table>
		</form>";	
	}
	htmlfooter();
} elseif ($action == 'setadmin') {
	$info = "�п�J�n�]�m���޲z�����Τ�W";
	htmlheader();
	?>
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr><td>
	<p class="subtitle">Discuz! admin�Τ�K�X��^�M���m <ul>

	<?php

	if(!empty($_POST['loginsubmit'])){
		require './config.inc.php';
		mysql_connect($dbhost, $dbuser, $dbpw);
		mysql_select_db($dbname);
		$passwordsql = empty($_POST['password']) ? '' : ', password = \''.md5($_POST['password']).'\'';
		$passwordsql .= empty($_POST['issecques']) ? '' : ', secques = \'\'';
		$passwordinfo = empty($_POST['password']) ? '�K�X�O������' : '�ñN�K�X�קאּ'.$_POST['password'].'';
		$query = "UPDATE {$tablepre}members SET adminid='1', groupid='1' $passwordsql WHERE $_POST[loginfield] = '$_POST[username]' limit 1";
			if(mysql_query($query)){
				$mysql_affected_rows = mysql_affected_rows();
				if($mysql_affected_rows == 0){
				$info = '<font color="red">�L���Τ�I���ˬd�Τ�W�O�_���T<br><br>�Ϊ̭��s���U�A�Ϊ�</font><a href="?action=setadmin">���s��J</a>';
				} elseif ($mysql_affected_rows > 0){
				$info = "�N$_POST[loginfield]��$_POST[username]���Τ�w�g�]�m���޲z���A$passwordinfo";
				}
			} else {
			$info = '<font color="red">���ѽ��ˬdMysql�]�mconfig.inc.php</font>';
			}
	?>
	<center><p class="subtitle">
	<div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;">
	<form action="?action=setadmin" method="post"><input type="hidden" name="action" value="login" />
		<table width="100%" cellpadding="6" cellspacing="0" border="0">
			<tr align="left" class="header"><td><center>���ܫH��</center></td></tr>
			<tr align="center"><td><br><?=$info?></td></tr>
		</table>
	</form>
	<?php
	} else {?>
	<center><p class="subtitle"><?=$info?>
	<div style="margin-top: 4px; width: 80%;">
	<form action="?action=setadmin" method="post">
		<table width="100%" cellpadding="6" cellspacing="0" border="0" style="border: 1px solid #7AC4EA;">
			<tr colspan="1" class="header"><td width="30%">�H��</td><td width="70%">��g</td></tr>
			<tr align="left"><td class="altbg1" width="30%"><span class="bold">	<input type="radio" name="loginfield" value="username" checked class="radio">�Τ�W<input type="radio" name="loginfield" value="uid" class="radio">UID</span></td><td class="altbg2" width="70%"><input type="text" name="username" size="25" maxlength="40"></td></tr>
			<tr align="left"><td class="altbg1" width="30%"><div style="padding-left: 5px;">�п�J�K�X</div></td><td class="altbg2" width="70%"><input type="text" name="password" size="25"></td></tr>
			<tr align="left"><td class="altbg1" width="30%"><div style="padding-left: 5px;">�O�_�M���w������</div></td><td class="altbg2" width="70%"><span class="bold"><input type="radio" name="issecques" value="1" checked class="radio">�O<input type="radio" name="issecques" value="" class="radio">�_</span></td></tr>
			<th colspan="2" class="altbg1" align="center"><input type="submit" name="loginsubmit" value="�� &nbsp; ��"></th>
		</table>
	</form>
	<?php
	}?>
	</div></center>
	<br><br>
	<p><font color="red">�`�N�G
	<br><p style="text-indent: 3em; margin: 0;">��ƾڮw�ާ@�i��|�X�{�N�~�{�H���o�ͤί}�a�A�ҥH�Х��ƥ��n�ƾڮw�A�i��W�z�ާ@�I�t�~�бz��ܪA�Ⱦ����O����p���ɭԶi��@���u�ƾާ@�C
	<br><p style="text-indent: 3em; margin: 0;">���z�ϥΧ���Discuz! �t�κ��@�u��c��A���I����w�u��c�H�T�O�t�Ϊ��w���I�U���ϥΫe�u�ݭn�b/forumdata�ؿ��U�R��tool.lock���Y�i�}�l�ϥΡC</p></font>
	</td></tr></table>
	<?php
	htmlfooter();
} elseif ($action == 'setlock') {
	touch($lockfile);
	if(file_exists($lockfile)) {
		echo '<meta http-equiv="refresh" content="3 url=?">';
		errorpage("���\\�����u��c�I<br>�j�P��ĳ�z�b���ݭn���{�Ǫ��ɭԤήɶi��R��");
	} else {
		errorpage('�`�N�z���ؿ��S���g�J�v���A�ڭ̵L�k���z���Ѧw���O�١A�ЧR���׾®ڥؿ��U��tool.php���I');
	}
} elseif ($action == 'testmail') {
	$msg = '';

	if($_POST['action'] == 'save') {

		if(is_writeable('./mail_config.inc.php')) {

			$_POST['sendmail_silent_new'] = intval($_POST['sendmail_silent_new']);
			$_POST['mailsend_new'] = intval($_POST['mailsend_new']);
			$_POST['maildelimiter_new'] = intval($_POST['maildelimiter_new']);
			$_POST['mailusername_new'] = intval($_POST['mailusername_new']);
			$_POST['mailcfg_new']['server'] = addslashes($_POST['mailcfg_new']['server']);
			$_POST['mailcfg_new']['port'] = intval($_POST['mailcfg_new']['port']);
			$_POST['mailcfg_new']['auth'] = intval($_POST['mailcfg_new']['auth']);
			$_POST['mailcfg_new']['from'] = addslashes($_POST['mailcfg_new']['from']);
			$_POST['mailcfg_new']['auth_username'] = addslashes($_POST['mailcfg_new']['auth_username']);
			$_POST['mailcfg_new']['auth_password'] = addslashes($_POST['mailcfg_new']['auth_password']);

	$savedata = <<<EOF
	<?php

	\$sendmail_silent = $_POST[sendmail_silent_new];
	\$maildelimiter = $_POST[maildelimiter_new];
	\$mailusername = $_POST[mailusername_new];
	\$mailsend = $_POST[mailsend_new];

EOF;

			if($_POST['mailsend_new'] == 2) {

	$savedata .= <<<EOF

	\$mailcfg['server'] = '{$_POST[mailcfg_new][server]}';
	\$mailcfg['port'] = {$_POST[mailcfg_new][port]};
	\$mailcfg['auth'] = {$_POST[mailcfg_new][auth]};
	\$mailcfg['from'] = '{$_POST[mailcfg_new][from]}';
	\$mailcfg['auth_username'] = '{$_POST[mailcfg_new][auth_username]}';
	\$mailcfg['auth_password'] = '{$_POST[mailcfg_new][auth_password]}';

EOF;

			} elseif ($_POST['mailsend_new'] == 3) {

	$savedata .= <<<EOF

	\$mailcfg['server'] = '{$_POST[mailcfg_new][server]}';
	\$mailcfg['port'] = '{$_POST[mailcfg_new][port]}';

EOF;

			}

			setcookie('mail_cfg', base64_encode(serialize($_POST['mailcfg_new'])), time() + 86400);

	$savedata .= <<<EOF

	?>
EOF;

			$fp = fopen('./mail_config.inc.php', 'w');
			fwrite($fp, $savedata);
			fclose($fp);

			$msg = '�]�m�O�s�����I';

			if($_POST['sendtest']) {

				define('IN_DISCUZ', true);

				define('DISCUZ_ROOT', './');
				define('TPLDIR', './templates/default');
				require './include/global.func.php';

				$test_tos = explode(',', $_POST['mailcfg_new']['test_to']);
				$date = date('Y-m-d H:i:s');

				switch($_POST['mailsend_new']) {
					case 1:
						$title = '�зǤ覡�o�e Email';
						$message = "�q�L PHP ��Ƥ� UNIX sendmail �o�e\n\n�Ӧ� {$_POST['mailcfg_new']['test_from']}\n\n�o�e�ɶ� ".$date;
						break;
					case 2:
						$title = '�q�L SMTP �A�Ⱦ�(SOCKET)�o�e Email';
						$message = "�q�L SOCKET �s�� SMTP �A�Ⱦ��o�e\n\n�Ӧ� {$_POST['mailcfg_new']['test_from']}\n\n�o�e�ɶ� ".$date;
						break;
					case 3:
						$title = '�q�L PHP ��� SMTP �o�e Email';
						$message = "�q�L PHP ��� SMTP �o�e Email\n\n�Ӧ� {$_POST['mailcfg_new']['test_from']}\n\n�o�e�ɶ� ".$date;
						break;
				}

				$bbname = '�l���o����';
				sendmail($test_tos[0], $title.' @ '.$date, "$bbname\n\n\n$message", $_POST['mailcfg_new']['test_from']);
				$bbname = '�l��s�o����';
				sendmail($_POST['mailcfg_new']['test_to'], $title.' @ '.$date, "$bbname\n\n\n$message", $_POST['mailcfg_new']['test_from']);

				$msg = '�]�m�O�s�����I<br>���D���u'.$title.' @ '.$date.'�v�����նl��w�g�o�X�I';

			}

		} else {

			$msg = '�L�k�g�J�l��t�m��� ./mail_config.inc.php�A�n�ϥΥ��u��г]�m����󪺥i�g�J�v���C';

		}

	}

	define('IN_DISCUZ', TRUE);
	htmlheader();
	
	if(@include("./discuz_version.php")) {
		if(substr(DISCUZ_VERSION, 0, 1) >= 6) {
			echo '<br>���\\��w�g���ʦ�Disuz!�׾«�x�޲z�����l��t�m';
			htmlfooter();
			exit;
		}
	}

	@include './mail_config.inc.php';
	?>
	<script>
	function $(id) {
		return document.getElementById(id);
	}
	</script>
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr><td>
	<p class="subtitle">Discuz! �l��t�m/���դu��<ul>
	<center><p class="subtitle">

	<?

	if($msg) {
		echo '<font color="#FF0000">'.$msg.'</font>';
	}

	?><div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;">
	<table width="100%" cellpadding="6" cellspacing="0" border="0">
	<form method="post">
	<input type="hidden" name="action" value="save"><input type="hidden" name="sendtest" value="0">
	<tr><th colspan="2" class="header">�l��t�m/���դu��</th></tr>
	<?

	$saved_mailcfg = empty($_COOKIE['mail_cfg']) ? array(
		'server' => 'smtp.21cn.com',
		'port' => '25',
		'auth' => 1,
		'from' => 'Discuz <username@21cn.com>',
		'auth_username' => 'username@21cn.com',
		'auth_password' => '2678hn',
		'test_from' => 'user <my@mydomain.com>',
		'test_to' => 'user1 <test1@test1.com>, user2 <test2@test2.net>'
	) : unserialize(base64_decode($_COOKIE['mail_cfg']));

	echo '<tr><td width="30%" class="altbg1">�̽��l��o�e�����������~����</td><td class="altbg2">';
	echo ' <input class="checkbox" type="checkbox" name="sendmail_silent_new" value="1"'.($sendmail_silent ? ' checked' : '').'><br>';
	echo '</tr>';
	echo '<tr><td class="altbg1">�l���Y�����j��</td><td class="altbg2">';
	echo ' <input class="radio" type="radio" name="maildelimiter_new" value="1"'.($maildelimiter ? ' checked' : '').'> �ϥ� CRLF �@�����j��<br>';
	echo ' <input class="radio" type="radio" name="maildelimiter_new" value="0"'.(!$maildelimiter ? ' checked' : '').'> �ϥ� LF �@�����j��<br>';
	echo '</tr>';
	echo '<tr><td class="altbg1">����H���]�t�Τ�W</td><td class="altbg2">';
	echo ' <input class="checkbox" type="checkbox" name="mailusername_new" value="1"'.($mailusername ? ' checked' : '').'><br>';
	echo '</tr>';

	echo '<tr><td class="altbg1">�l��o�e�覡</td><td class="altbg2">';
	echo ' <input class="radio" type="radio" name="mailsend_new" value="1"'.($mailsend == 1 ? ' checked' : '').' onclick="$(\'hidden1\').style.display=\'none\';$(\'hidden2\').style.display=\'none\'"> �q�L PHP ��Ƥ� UNIX sendmail �o�e(���˦��覡)<br>';
	echo ' <input class="radio" type="radio" name="mailsend_new" value="2"'.($mailsend == 2 ? ' checked' : '').' onclick="$(\'hidden1\').style.display=\'\';$(\'hidden2\').style.display=\'\'"> �q�L SOCKET �s�� SMTP �A�Ⱦ��o�e(��� ESMTP ����)<br>';
	echo ' <input class="radio" type="radio" name="mailsend_new" value="3"'.($mailsend == 3 ? ' checked' : '').' onclick="$(\'hidden1\').style.display=\'\';$(\'hidden2\').style.display=\'none\'"> �q�L PHP ��� SMTP �o�e Email(�� win32 �U����, ����� ESMTP)<br>';
	echo '</tr>';

	$mailcfg['server'] = $mailcfg['server'] == '' ? $saved_mailcfg['server'] : $mailcfg['server'];
	$mailcfg['port'] = $mailcfg['port'] == '' ? $saved_mailcfg['port'] : $mailcfg['port'];
	$mailcfg['auth'] = $mailcfg['auth'] == '' ? $saved_mailcfg['auth'] : $mailcfg['auth'];
	$mailcfg['from'] = $mailcfg['from'] == '' ? $saved_mailcfg['from'] : $mailcfg['from'];
	$mailcfg['auth_username'] = $mailcfg['auth_username'] == '' ? $saved_mailcfg['auth_username'] : $mailcfg['auth_username'];
	$mailcfg['auth_password'] = $mailcfg['auth_password'] == '' ? $saved_mailcfg['auth_password'] : $mailcfg['auth_password'];

	echo '<tbody id="hidden1" style="display:'.($mailsend == 1 ? ' none' : '').'">';
	echo '<tr><td class="altbg1">SMTP �A�Ⱦ�</td><td class="altbg2">';
	echo ' <input class="text" type="text" name="mailcfg_new[server]" value="'.$mailcfg['server'].'"><br>';
	echo '</tr>';
	echo '<tr><td class="altbg1">SMTP �ݤf, �q�{���ݭק�</td><td class="altbg2">';
	echo ' <input class="text" type="text" name="mailcfg_new[port]" value="'.$mailcfg['port'].'"><br>';
	echo '</tr>';
	echo '</tbody>';
	echo '<tbody id="hidden2" style="display:'.($mailsend != 2 ? ' none' : '').'">';
	echo '<tr><td class="altbg1">�O�_�ݭn AUTH LOGIN ����</td><td class="altbg2">';
	echo ' <input class="checkbox" type="checkbox" name="mailcfg_new[auth]" value="1"'.($mailcfg['auth'] ? ' checked' : '').'><br>';
	echo '</tr>';
	echo '<tr><td class="altbg1">�o�H�H�a�} (�p�G�ݭn����,���������A�Ⱦ��a�})</td><td class="altbg2">';
	echo ' <input class="text" type="text" name="mailcfg_new[from]" value="'.$mailcfg['from'].'"><br>';
	echo '</tr>';
	echo '<tr><td class="altbg1">���ҥΤ�W</td><td class="altbg2">';
	echo ' <input class="text" type="text" name="mailcfg_new[auth_username]" value="'.$mailcfg['auth_username'].'"><br>';
	echo '</tr>';
	echo '<tr><td class="altbg1">���ұK�X</td><td class="altbg2">';
	echo ' <input class="text" type="text" name="mailcfg_new[auth_password]" value="'.$mailcfg['auth_password'].'"><br>';
	echo '</tr>';
	echo '</tbody>';

	?>
	<tr><td colspan="2" align="center" class="altbg2">
	<input class="button" type="submit" name="submit" value="�O�s�]�m">
	</td></tr>
	<?

	echo '<tr><td class="altbg1">���յo��H</td><td class="altbg2">';
	echo ' <input class="text" type="text" name="mailcfg_new[test_from]" value="'.$saved_mailcfg['test_from'].'" size="30"><br>';
	echo '</tr>';
	echo '<tr><td class="altbg1">���զ���H</td><td class="altbg2">';
	echo ' <input class="text" type="text" name="mailcfg_new[test_to]" value="'.$saved_mailcfg['test_to'].'" size="45"><br>';
	echo '</tr>';

	?>
	<tr><td colspan="2" align="center" class="altbg2">
	<input class="button" type="submit" name="submit" onclick="this.form.sendtest.value = 1" value="�O�s�]�m�ô��յo�e">
	</td></tr>
	</form>
	</table></div>
	<?php
	htmlfooter();
} else {
	htmlheader();
	?>

	<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr><td class="title">�w��z�ϥ� Discuz! �t�κ��@�u��c<?=VERSION?></td></tr>
	<tr><td><br>

	<p class="subtitle">Discuz! �t�κ��@�u��c�\\�श��<ul>
	<p><ul>
	<li>�ˬd�έ״_Discuz!�ƾڮw
	<li>�u�ƾ�zDiscuz!�ƾڮw�ϽL�H��
	<li>�ɤJDiscuz!�ƾڮw�ƥ����ܷ��e�A�Ⱦ�
	<li>��_�׾º޲z���v��
	<li>�ƾڮw���l�ƾڲM�z
	<li>���նl��o�e�覡
	</ul>
	<p><font color="red">�`�N�G
	<br><p style="text-indent: 3em; margin: 0;">��ƾڮw�ާ@�i��|�X�{�N�~�{�H���o�ͤί}�a�A�ҥH�Х��ƥ��n�ƾڮw�A�i��W�z�ާ@�I�t�~�бz��ܪA�Ⱦ����O����p���ɭԶi��@���u�ƾާ@�C
	<br><p style="text-indent: 3em; margin: 0;">���z�ϥΧ���Discuz! �t�κ��@�u��c��A���I����w�u��c�H�T�O�t�Ϊ��w���I�U���ϥΫe�u�ݭn�b/forumdata�ؿ��U�R��tool.lock���Y�i�}�l�ϥΡC</p></font>
	</td></tr></table>
	<?
	htmlfooter();}

function cexit($message){
	echo $message;
	echo '<br><br>
			<p><font color="red">�`�N�G
			<br><p style="text-indent: 3em; margin: 0;">��ƾڮw�ާ@�i��|�X�{�N�~�{�H���o�ͤί}�a�A�ҥH�Х��ƥ��n�ƾڮw�A�i��W�z�ާ@�I�t�~�бz��ܪA�Ⱦ����O����p���ɭԶi��@���u�ƾާ@�C
			<br><p style="text-indent: 3em; margin: 0;">���z�ϥΧ���Discuz! �t�κ��@�u��c��A���I����w�u��c�H�T�O�t�Ϊ��w���I�U���ϥΫe�u�ݭn�b/forumdata�ؿ��U�R��tool.lock���Y�i�}�l�ϥΡC</p></font>
			</td></tr></table>';
	htmlfooter();
	exit();
}

function checktable($table, $loops = 0) {
	global $db, $nohtml, $simple, $counttables, $oktables, $errortables, $rapirtables;

	$result = mysql_query("CHECK TABLE $table");
	if(!$nohtml) {
		echo "<tr bgcolor='#CCCCCC'><td colspan=4 align='center'>�ˬd�ƾڪ� Checking table $table</td></tr>";
		echo "<tr><td>Table</td><td>Operation</td><td>Type</td><td>Text</td></tr>";
	} else {
	if(!$simple) {
		echo "\n>>>>>>>>>>>>>Checking Table $table\n";
		echo "---------------------------------<br>\n";
	}
	}
	$error = 0;
	while($r = mysql_fetch_row($result)) {
	if($r[2] == 'error') {
		if($r[3] == "The handler for the table doesn't support check/repair") {
		$r[2] = 'status';
		$r[3] = 'This table does not support check/repair/optimize';
		unset($bgcolor);
		$nooptimize = 1;
		} else {
		$error = 1;
		$bgcolor = 'red';
		unset($nooptimize);
		}
		$view = '���~';
		$errortables += 1;
	} else {
		unset($bgcolor);
		unset($nooptimize);
		$view = '���`';
		if($r[3] == 'OK') {
		$oktables += 1;
		}
	}
	if(!$nohtml) {
		echo "<tr><td>$r[0]</td><td>$r[1]</td><td bgcolor='$bgcolor'>$r[2]</td><td>$r[3] / $view </td></tr>";
	} else {
		if(!$simple) {
		echo "$r[0] | $r[1] | $r[2] | $r[3]<br>\n";
		}
	}
	}

	if($error) {
	if(!$nohtml) {
		echo "<tr><td colspan=4 align='center'>���b�״_�� / Repairing table $table</td></tr>";
	} else {
		if(!$simple) {
		echo ">>>>>>>>���b�״_�� / Repairing Table $table<br>\n";
		}
	}
	$result2=mysql_query("REPAIR TABLE $table");
	while($r2 = mysql_fetch_row($result2)) {
	if($r2[3] == 'OK') {
		$bgcolor='blue';
		$rapirtables += 1;
	} else {
		unset($bgcolor);
	}
	if(!$nohtml) {
		echo "<tr><td>$r2[0]</td><td>$r2[1]</td><td>$r2[2]</td><td bgcolor='$bgcolor'>$r2[3]</td></tr>";
	} else {
		if(!$simple) {
			echo "$r2[0] | $r2[1] | $r2[2] | $r2[3]<br>\n";
		}
	}
	}
	}
	if(($result2[3]=='OK'||!$error)&&!$nooptimize) {
	if(!$nohtml) {
		echo "<tr><td colspan=4 align='center'>�u�Ƽƾڪ� Optimizing table $table</td></tr>";
	} else {
		if(!$simple) {
		echo ">>>>>>>>>>>>>Optimizing Table $table<br>\n";
		}
	}
	$result3=mysql_query("OPTIMIZE TABLE $table");
	$error=0;
	while($r3=mysql_fetch_row($result3)) {
		if($r3[2]=='error') {
		$error=1;
		$bgcolor='red';
		} else {
		unset($bgcolor);
		}
		if(!$nohtml) {
		echo "<tr><td>$r3[0]</td><td>$r3[1]</td><td bgcolor='$bgcolor'>$r3[2]</td><td>$r3[3]</td></tr>";
		} else {
		if(!$simple) {
			echo "$r3[0] | $r3[1] | $r3[2] | $r3[3]<br><br>\n";
		}
		}
	}
	}
	if($error && $loops) {
		checktable($table,($loops-1));
	}
}


function checkfullfiles($currentdir) {
	global $db, $tablepre, $md5files, $cachelist, $templatelist, $lang, $nopass;
	$dir = @opendir(DISCUZ_ROOT.$currentdir);

	while($entry = @readdir($dir)) {
		$file = $currentdir.$entry;
		$file = $currentdir != './' ? preg_replace('/^\.\//', '', $file) : $file;
		$mainsubdir = substr($file, 0, strpos($file, '/'));
		if($entry != '.' && $entry != '..') {
			echo "<script>parent.$('msg').innerHTML = '$lang[filecheck_fullcheck_current] ".addslashes(date('Y-m-d H:i:s')."<br>$lang[filecheck_fullcheck_file] $file")."';</script>\r\n";
			if(is_dir($file)) {
    				checkfullfiles($file.'/');
			} elseif(is_file($file) && !in_array($file, $md5files)) {
				$pass = FALSE;
				if(in_array($file, array('./favicon.ico', './config.inc.php', './mail_config.inc.php', './robots.txt'))) {
					$pass = TRUE;
				}
				if($entry == 'index.htm' && filesize($file) < 5) {
					$pass = TRUE;
				}

				switch($mainsubdir) {
					case 'attachments' :
						if(!preg_match('/\.(php|phtml|php3|php4|jsp|exe|dll|asp|cer|asa|shtml|shtm|aspx|asax|cgi|fcgi|pl)$/i', $entry)) {
							$pass = TRUE;
						}
					break;
					case 'images' :
						if(preg_match('/\.(gif|jpg|jpeg|png|ttf|wav|css)$/i', $entry)) {
							$pass = TRUE;
						}
					case 'customavatars' :
						if(preg_match('/\.(gif|jpg|jpeg|png)$/i', $entry)) {
							$pass = TRUE;
						}
					break;
					case 'mspace' :
						if(preg_match('/\.(gif|jpg|jpeg|png|css|ini)$/i', $entry)) {
							$pass = TRUE;
						}
					break;
					case 'forumdata' :
						$forumdatasubdir = str_replace('forumdata', '', dirname($file));
						if(substr($forumdatasubdir, 0, 8) == '/backup_') {
							if(preg_match('/\.(zip|sql)$/i', $entry)) {
								$pass = TRUE;
							}
						} else {
							switch ($forumdatasubdir) {
								case '' :
									if(in_array($entry, array('dberror.log', 'install.lock'))) {
										$pass = TRUE;
									}
								break;
								case '/templates':
									if(empty($templatelist)) {
										$query = $db->query("SELECT templateid, directory FROM {$tablepre}templates");
										while($template = $db->fetch_array($query)) {
											$templatelist[$template['templateid']] = $template['directory'];
										}
									}
									$tmp = array();
									$entry = preg_replace('/(\d+)\_(\w+)\.tpl\.php/ie', '$tmp = array(\1,"\2");', $entry);
									if(!empty($tmp) && file_exists($templatelist[$tmp[0]].'/'.$tmp[1].'.htm')) {
										$pass = TRUE;
									}

								break;
								case '/logs':
									if(preg_match('/(runwizardlog|\_cplog|\_errorlog|\_banlog|\_illegallog|\_modslog|\_ratelog|\_medalslog)\.php$/i', $entry)) {
										$pass = TRUE;
									}
								break;
								case '/cache':
									if(preg_match('/\.php$/i', $entry)) {
										if(empty($cachelist)) {
											$cachelist = checkcachefiles('forumdata/cache/');
											foreach($cachelist[1] as $nopassfile => $value) {
												$nopass++;
												echo "<script>parent.$('checkresult').innerHTML += '$nopassfile<br>';</script>\r\n";
											}
										}
										$pass = TRUE;
									} elseif(preg_match('/\.(css|log)$/i', $entry)) {
										$pass = TRUE;
									}
								break;
								case '/threadcaches':
									if(preg_match('/\.htm$/i', $entry)) {
										$pass = TRUE;
									}
								break;
							}
						}

					break;
					case 'templates' :
						if(preg_match('/\.(lang\.php|htm)$/i', $entry)) {
							$pass = TRUE;
						}
					break;
					case 'include' :
						if(preg_match('/\.table$/i', $entry)) {
							$pass = TRUE;
						}
					break;
					case 'ipdata' :
						if($entry == 'wry.dat' || preg_match('/\.txt$/i', $entry)) {
							$pass = TRUE;
						}
					break;
					case 'admin' :
						if(preg_match('/\.md5$/i', $entry)) {
							$pass = TRUE;
						}
					break;
				}

				if(!$pass) {
					$nopass++;
					echo "<script>parent.$('checkresult').innerHTML += '$file<br>';</script>\r\n";
				}
			}
			ob_flush();
    			flush();
		}
	}
	return $nopass;
}

function checkdirs($currentdir) {
	global $dirlist;
	$dir = @opendir(DISCUZ_ROOT.$currentdir);

	while($entry = @readdir($dir)) {
		$file = $currentdir.$entry;
		if($entry != '.' && $entry != '..') {
			if(is_dir($file)) {
				$dirlist[] = $file;
				checkdirs($file.'/');
			}
		}
	}
}

function checkcachefiles($currentdir) {
	global $authkey;
	$dir = opendir($currentdir);
	$exts = '/\.php$/i';
	$showlist = $modifylist = $addlist = array();
	while($entry = readdir($dir)) {
		$file = $currentdir.$entry;
		if($entry != '.' && $entry != '..' && preg_match($exts, $entry)) {
			$fp = fopen($file, "rb");
			$cachedata = fread($fp, filesize($file));
			fclose($fp);

			if(preg_match("/^<\?php\n\/\/Discuz! cache file, DO NOT modify me!\n\/\/Created: [\w\s,:]+\n\/\/Identify: (\w{32})\n\n(.+?)\?>$/s", $cachedata, $match)) {
				$showlist[$file] = $md5 = $match[1];
				$cachedata = $match[2];

				if(md5($entry.$cachedata.$authkey) != $md5) {
					$modifylist[$file] = $md5;
				}
			} else {
				$showlist[$file] = $addlist[$file] = '';
			}
		}

	}

	return array($showlist, $modifylist, $addlist);
}

function continue_redirect($action = 'mysqlclear', $extra = '') {
	global $scriptname, $step, $actionnow, $start, $end, $stay, $convertedrows, $totalrows, $maxid;
	$url = "?action=$action&step=".$step."&start=".($end + 1)."&stay=$stay&totalrows=$totalrows&convertedrows=$convertedrows&maxid=$maxid".$extra;
	$timeout = $GLOBALS['debug'] ? 5000 : 2000;
	echo "<script>\r\n";
	echo "<!--\r\n";
	echo "function redirect() {\r\n";
	echo "	window.location.replace('".$url."');\r\n";
	echo "}\r\n";
	echo "setTimeout('redirect();', $timeout);\r\n";
	echo "-->\r\n";
	echo "</script>\r\n";
	echo '<div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;float:center;">
		<table width="100%" border="0" cellpadding="6" cellspacing="0">
		<tr class="header"><td colspan="9">���b�i��'.$actionnow.'</td></tr><tr align="center" class="category"><td>';
	echo "���b�ˬd $start ---- $end �� <div style=\"float: right;\">[<a href='?action=mysqlclear' style='color:red'>����B��</a>]</div>";
	echo "<br><br><a href=\"".$url."\">�p�G�z���s�������ɶ��S���۰ʸ���A���I���o�̡I</a>";
	echo '</td></tr></table></div>';
}

function dirsize($dir) {
	$dh = @opendir($dir);
	$size = 0;
	while($file = @readdir($dh)) {
		if ($file != '.' && $file != '..') {
			$path = $dir.'/'.$file;
			if (@is_dir($path)) {
				$size += dirsize($path);
			} else {
				$size += @filesize($path);
			}
		}
	}
	@closedir($dh);
	return $size;
}

function get_real_size($size) {

	$kb = 1024;
	$mb = 1024 * $kb;
	$gb = 1024 * $mb;
	$tb = 1024 * $gb;

	if($size < $kb) {
		return $size.' Byte';
	} else if($size < $mb) {
		return round($size/$kb,2).' KB';
	} else if($size < $gb) {
		return round($size/$mb,2).' MB';
	} else if($size < $tb) {
		return round($size/$gb,2).' GB';
	} else {
		return round($size/$tb,2).' TB';
	}
}

function htmlheader(){
	echo '<html>
		<head>
		<meta http-equiv="Content-Type" content="text/html; charset=big5">
		<title>Discuz! �t�κ��@�u��c</title>
		<style type="text/css">
		<!--
		body {
			margin: 0px;
			scrollbar-base-color: #F5FBFF;
			scrollbar-arrow-color: #7AC4EA;
			font: 12px Tahoma, Verdana;
			background-color: #FFFFFF;
			color: #333333;
		}
		td {
			font: 12px Tahoma, Verdana;
		}
		a {
			text-decoration: none;
			color: #154BA0;
		}
		a:hover {
			text-decoration: underline;
		}
		.header {
			font: 12px Arial, Tahoma !important;
			font-weight: bold !important;
			font: 11px Arial, Tahoma;
			font-weight: bold;
			color: #154BA0;
			background: #C0E4F7;
			height: 30px;
			padding-left: 10px;
		}
		.header td {
			padding-left: 10px;
		}
		.header a {
			color: #154BA0;
		}
		.mainborder {
			clear: both;
			height: 8px;
			font-size: 0px;
			line-height: 0px;
			padding: 0px;
			background-color: #154BA0;
		}
		.headerline {
			font-size: 0px;
			line-height: 0px;
			padding: 0px;
			background: #F5FBFF;
		}
		.footerline div {
			background-color: #FFFFFF;
			position: relative;
			float: right;
			right: 40px;
		}

		.spaceborder {
			width: 100%;
			border: 1px solid #7AC4EA;
			padding: 1px;
			clear: both;
		}
		.maintable{
			width: 95%;
			font: 12px Tahoma, Verdana;
		}
		ul {
			font-size: 12px;
			color: #666666;
			margin-left: 12px;
		}
		li {
			margin-left: 22px;
		}
		pre {
			font-size: 12px;
			font-family: Courier, Courier New;
			font-weight: normal;
			color:#000000;
		}
		.code {
			background: #EFEFEF;
			border: 1px solid #CCCCCC;
		}
		.title {
			font-size: 16px;
			border-bottom: 1px dashed #999999;
			font-weight:bold; color:#333399;
		}
		.subtitle {
			font-size: 14px;
			font-weight: bold;
			color: #000000;
		}
		input, select, textarea {
		font: 12px Tahoma, Verdana;
		color: #333333;
		font-weight: normal;
		background-color: #F5FBFF;
		border: 1px solid #7AC4EA;
		}
		.checkbox, .radio {
		border: 0px;
		background: none;
		vertical-align: middle;
		height: 16px;
		}
		input {
		height: 21px;
		}
		.submitbutton {
		margin-top: 8px !important;
		margin-top: 6px;
		margin-bottom: 5px;
		text-align: left;
		}
		.bold {
		font-weight: bold;
		}
		.altbg1	{
		background: #F5FBFF;
		font: 12px Tahoma, Verdana;
		}
		td.altbg1 {
		border-bottom: 1px solid #BBE9FF;
		}
		.altbg2 {
		background: #FFFFFF;
		font: 12px Tahoma, Verdana;
		}
		td.altbg2 {
		border-bottom: 1px solid #BBE9FF;
		}
		-->
		</style>
		</head>

		<body leftmargin="0" rightmargin="0" topmargin="0">
		<div class="mainborder"></div>
		<div class="headerline" style="height: 6px"></div>
		<center><div class="maintable">
		<br><div class="spaceborder"><table cellspacing="0" cellpadding="4" width="100%" align="center">
		<tr><td class="header" colspan="2">Discuz! �t�κ��@�u��c</td></tr><tr><td bgcolor="#F8F8F8" align="left">
		[ <b><a href="?" target="_self">�u��c����</a></b> ]
		[ <b><a href="?action=setlock" target="_self"><font color="red">��w�u��c</font></a></b> ] &nbsp; &raquo; &nbsp;
		</td><td bgcolor="#F8F8F8" align="center">
		[ <b><a href="?action=repair" target="_self">�ˬd�έ׽Ƽƾڮw</a></b> ]
		[ <b><a href="?action=restore" target="_self">�ɤJ�ƾڮw�ƥ�</a></b> ]
		[ <b><a href="?action=setadmin" target="_self">���m�޲z���b��</a></b> ]
		[ <b><a href="?action=testmail" target="_self">�l��t�m����</a></b> ]
		[ <b><a href="?action=mysqlclear" target="_self">�ƾڮw���l�ƾڲM�z</a></b> ]
		<br>
		[ <b><a href="?action=filecheck" target="_self">Discuz!��������˯�</a></b> ]
		[ <b><a href="?action=runquery" target="_self">Mysql�ɯżƾڮw</a></b> ]
		[ <b><a href="?action=replace" target="_self">�K�l���e��q����</a></b> ]
		[ <b><a href="?action=check" target="_self">�t�������ˬd</a></b> ]
		[ <b><a href="tools.php?action=repair_auto">�r�q�ۼW���״_</a></b> ]
		[ <b><a href="?action=logout" target="_self">�h�X</a></b> ]
		</td></tr></table></div><br><br>';
}

function htmlfooter(){
	echo '
		</div></center><br><br><br><br></td></tr><tr><td colspan="3" style="padding: 1">
		<table cellspacing="0" cellpadding="4" width="100%"><tr bgcolor="#F5FBFF">
		<td align="center" class="smalltxt"><font color="#666666">Discuz! Board �t�κ��@�u��c &nbsp;
		���v�Ҧ� &copy;2001-2007 <a href="http://www.comsenz.com" style="color: #888888; text-decoration: none">
		�d���зQ(�_��)��ަ������q Comsenz Inc</a>.</font></td></tr><tr style="font-size: 0px; line-height: 0px; spacing: 0px; padding: 0px; background-color: #698CC3">
		</table></td></tr></table><div class="mainborder" style="height: 6px"></div>
		</body>
		</html>';
}

function errorpage($message){
	htmlheader();
	if($message == 'login'){
		$message ='�п�JDisucz!�u��]���n���K�X�I<div style="margin-top: 4px; width: 80%;">
				<form action="?" method="post">
					<input type="password" name="toolpassword"></input>
					<input type="submit" value="submit"></input>
					<input type="hidden" name="action" value="login">
				</form>
				</div>';
	}
	echo "<br><br><br><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
		<tr><td>
		<center><p class=\"subtitle\"><font color=\"red\">$message</font></center>
		</td></tr></table>";
	htmlfooter();
	exit();
}

function redirect($url) {
	echo "<script>";
	echo "function redirect() {window.location.replace('$url');}\n";
	echo "setTimeout('redirect();', 2000);\n";
	echo "</script>";
	echo "<br><br><a href=\"$url\">�p�G�z���s�����S���۰ʸ���A���I���o��</a>";
	cexit("");
}

function splitsql($sql){
	$ret = array();
	$num = 0;
	$queriesarray = explode(";\n", trim($sql));
	unset($sql);
	foreach($queriesarray as $query) {
		$queries = explode("\n", trim($query));
		foreach($queries as $query) {
			$ret[$num] .= $query[0] == "#" ? NULL : $query;
		}
		$num++;
	}
	return($ret);
}

function stay_redirect() {
	global $action, $actionnow, $step, $stay;
	$nextstep = $step + 1;
	echo '<div style="margin-top: 4px; border: 1px solid #7AC4EA; width: 80%;float:center;">
			<table width="100%" border="0" cellpadding="6" cellspacing="0">
			<tr class="header"><td colspan="9">���b�i��'.$actionnow.'</td></tr><tr align="center" class="category">
			<td>';
	if($stay) {
		$actions = isset($action[$nextstep]) ? $action[$nextstep] : '����';
		echo "$actionnow �ާ@����.".($stay == 1 ? "&nbsp;&nbsp;&nbsp;&nbsp;" : '').'<br><br>';
		echo "<a href='?action=mysqlclear&step=".$nextstep."&stay=1'>�p�G�~��U�@�B�ާ@( $actions )�A���I���o�̡I</a><br>";
	} else {
		if(isset($action[$nextstep])) {
			echo '�Y�N�i�J�G'.$action[$nextstep].'......';
		}
		$timeout = $GLOBALS['debug'] ? 5000 : 2000;
		echo "<script>\r\n";
		echo "<!--\r\n";
		echo "function redirect() {\r\n";
		echo "	window.location.replace('?action=mysqlclear&step=".$nextstep."');\r\n";
		echo "}\r\n";
		echo "setTimeout('redirect();', $timeout);\r\n";
		echo "-->\r\n";
		echo "</script>\r\n";
		echo "<div style=\"float: right;\">[<a href='?action=mysqlclear' style='color:red'>����B��</a>]</div><br><br><a href=\"".$scriptname."?step=".$nextstep."\">�p�G�z���s�������ɶ��S���۰ʸ���A���I���o�̡I</a>";
	}

	echo '</td></tr></table></div>';
}
?>