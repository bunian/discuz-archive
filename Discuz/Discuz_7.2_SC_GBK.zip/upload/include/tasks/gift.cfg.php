<?php

/*
	[Discuz!] (C)2001-2009 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: gift.cfg.php 16697 2008-11-14 07:36:51Z monkey $
*/

	$task_name = $tasklang['gift_name'];

	$task_description = $tasklang['gift_desc'];

	$task_icon = 'gift.gif';

	$task_period = '';

	$task_conditions = array(
		array('sort' => '', 'name' => '', 'description' => '', 'variable' => '', 'value' => '', 'type' => '', 'extra' => ''),
	);

	$task_version = '1.0';

	$task_copyright = $tasklang['gift_copyright'];

?>