<?php

// P.M. Pack for Discuz! Version 1.0
// Translated by Crossday

// ATTENTION: Please add slashes(\) before (') and (")

$language = array
(

	'reason_moderate_subject' => '[Discuz!] 您发表的主题被执行管理操作',
	'reason_moderate_message' => '这是由论坛系统自动发送的通知短消息。

[b]以下您所发表的主题被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 执行 {$modaction} 操作。[/b]

[b]主题:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]发表时间:[/b] {$thread[dateline]}
[b]所在论坛:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]操作理由:[/b] {$reason}

如果您对本管理操作有异议，请与我取得联系。',

	'reason_merge_subject' => '[Discuz!] 您发表的主题被执行合并操作',
	'reason_merge_message' => '这是由论坛系统自动发送的通知短消息。

[b]以下您所发表的主题被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 执行 {$modaction} 操作。[/b]

[b]主题:[/b] {$thread[subject]}
[b]发表时间:[/b] {$thread[dateline]}
[b]所在论坛:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]合并后的主题:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$other[subject]}[/url]

[b]操作理由:[/b] {$reason}

如果您对本管理操作有异议，请与我取得联系。',
	'reason_delete_post_subject' => '[Discuz!] 您发表的回复被执行管理操作',
	'reason_delete_post_message' => '这是由论坛系统自动发送的通知短消息。

[b]以下您所发表的回复被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 执行 删除 操作。[/b]
[quote]{$post[message]}[/quote]

[b]发表时间:[/b] {$post[dateline]}
[b]所在论坛:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]操作理由:[/b] {$reason}

如果您对本管理操作有异议，请与我取得联系。',

	'reason_move_subject' => '[Discuz!] 您发表的主题被执行管理操作',
	'reason_move_message' => '这是由论坛系统自动发送的通知短消息。

[b]以下您所发表的主题被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 执行 移动 操作。[/b]

[b]主题:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]发表时间:[/b] {$thread[dateline]}
[b]原论坛:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]
[b]目标论坛:[/b] [url={$boardurl}forumdisplay.php?fid={$toforum[fid]}]{$toforum[name]}[/url]

[b]操作理由:[/b] {$reason}

如果您对本管理操作有异议，请与我取得联系。',

	'rate_reason_subject' => '[Discuz!] 您发表的帖子被评分',
	'rate_reason_message' => '这是由论坛系统自动发送的通知短消息。

[b]以下您所发表的帖子被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 评分。[/b]
[quote]{$post[message]}[/quote]

[b]发表时间:[/b] {$post[dateline]}
[b]所在论坛:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]
[b]所在主题:[/b] [url={$boardurl}viewthread.php?tid={$tid}&page={$page}#pid{$pid}]{$thread[subject]}[/url]

[b]评分分数:[/b] {$ratescore}
[b]操作理由:[/b] {$reason}',

	'transfer_subject' => '[Discuz!] 您收到一笔积分转账',
	'transfer_message' => '这是由论坛系统自动发送的通知短消息。

[b]您收到一笔来自他人的积分转账。[/b]

[b]来自:[/b] [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url]
[b]时间:[/b] {$transfertime}
[b]积分:[/b] {$extcredits[$creditstrans][title]} {$amount} {$extcredits[$creditstrans][unit]}
[b]净收入:[/b] {$extcredits[$creditstrans][title]} {$netamount} {$extcredits[$creditstrans][unit]}

[b]附言:[/b] {$transfermessage}

详情请[url={$boardurl}memcp.php?action=credits&operation=creditslog]点击这里[/url]访问您的积分转账与兑换记录。',

	'reportpost_subject'	=> '[Discuz!] $discuz_user 向您报告一篇帖子',
	'reportpost_message'	=> '[i]{$discuz_user}[/i] 向您报告以下的帖子，详细内容请访问:
[url]{$posturl}[/url]

他/她的报告理由是: {$reason}',

	'addfunds_subject' => '[Discuz!] 积分充值成功完成',
	'addfunds_message' => '这是由论坛系统自动发送的通知短消息。

[b]您提交的积分充值请求已成功完成，相应数额的积分已经存入您的积分账户。[/b]

[b]订单号:[/b] {$order[orderid]}
[b]提交时间:[/b] {$submitdate}
[b]确认时间:[/b] {$confirmdate}

[b]支出:[/b] 人民币 {$order[price]} 元
[b]收入:[/b] {$extcredits[$creditstrans][title]} {$order[amount]} {$extcredits[$creditstrans][unit]}

详情请[url={$boardurl}memcp.php?action=credits&operation=creditslog]点击这里[/url]访问您的积分转账与兑换记录。',

	'trade_seller_send_subject' => '[Discuz!] 有买家购买您的商品',
	'trade_seller_send_message' => '这是由论坛系统自动发送的通知短消息。

买家 {$user} 购买您的商品 {$itemsubject}

买家已付款，等待您发货，请[url={$boardurl}trade.php?orderid={$orderid}]点击这里[/url]查看详情。',

	'trade_buyer_confirm_subject' => '[Discuz!] 您购买的商品已经发货',
	'trade_buyer_confirm_message' => '这是由论坛系统自动发送的通知短消息。

您购买的商品 {$itemsubject}

卖家 {$user} 已发货，等待您的确认，请[url={$boardurl}trade.php?orderid={$orderid}]点击这里[/url]查看详情。',

	'trade_fefund_success_subject' => '[Discuz!] 您购买的商品已成功退款',
	'trade_fefund_success_message' => '这是由论坛系统自动发送的通知短消息。

您购买的 {$user} 的商品 {$itemsubject}

已退款成功，请[url={$boardurl}trade.php?orderid={$orderid}]点击这里[/url]查看详情。',

	'trade_success_subject' => '[Discuz!] 商品交易已成功完成',
	'trade_success_message' => '这是由论坛系统自动发送的通知短消息。

买家 {$user} 已收到商品 {$itemsubject}

商品已交易成功，请[url={$boardurl}trade.php?orderid={$orderid}]点击这里[/url]查看详情。',

	'activity_apply_subject' => '[Discuz!] 活动的申请已通过批准',
	'activity_apply_message' => '这是由论坛系统自动发送的通知短消息。

活动 [b]{$activity_subject}[/b] 的发起者已批准您参加此活动，请[url={$boardurl}viewthread.php?tid={$tid}]点击这里[/url]查看详情。',

	'reward_question_subject' => '[Discuz!] 您发表的悬赏被设置了最佳答案',
	'reward_question_message' => '这是由论坛系统自动发送的通知短消息。

[b]您发表的悬赏被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 设置了 最佳答案。[/b]

[b]悬赏:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]发表时间:[/b] {$thread[dateline]}
[b]所在论坛:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forum[name]}[/url]

如果您对本操作有异议，请与作者取得联系。',

	'reward_bestanswer_subject' => '[Discuz!] 您发表的回复被选为最佳答案',
	'reward_bestanswer_message' => '这是由论坛系统自动发送的通知短消息。

[b]您的回复被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 选为悬赏最佳答案。[/b]

[b]悬赏:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]发表时间:[/b] {$thread[dateline]}
[b]所在论坛:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forum[name]}[/url]

如果您对本操作有异议，请与作者取得联系。'
);

?>