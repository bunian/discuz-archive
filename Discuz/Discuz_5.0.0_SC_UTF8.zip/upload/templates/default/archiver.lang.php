<?php

// Message Pack for Discuz! Archiver Version 1.0.0
// Created by Crossday

$lang = array
(

	'page' => '页',
	'replies' => '篇回复',
	'anonymous' => '匿名',
	'full_version' => '查看完整版本',
	'forum_nonexistence' => '您没有权限访问这个论坛的存档或该论坛不存在。',
	'thread_nonexistence' => '您没有权限察看这个话题或该话题不存在。',

);

?>