<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: supesite.inc.php,v $
	$Revision: 1.15 $
	$Date: 2006/08/29 03:15:13 $
*/

if(!defined('IN_DISCUZ') || !isset($PHP_SELF) || !preg_match("/[\/\\\\]admincp\.php$/", $PHP_SELF)) {
        exit('Access Denied');
}

cpheader();

if(!$supe_siteurl) {

	shownav('supe_settings');
	showtips('supe_tips_unstalled');

} else {

	$query = $db->query("SELECT * FROM {$tablepre}settings");
	while($setting = $db->fetch_array($query)) {
		$settings[$setting['variable']] = $setting['value'];
	}

	if(!submitcheck('settingsubmit')) {

		shownav('supe_settings');
		showtips('supe_tips_installed');

		echo '<form method="post" name="settings" action="admincp.php?action=xspace">';
		echo '<input type="hidden" name="formhash" value="'.FORMHASH.'">';

		showtype('supe_settings', 'top');
		showsetting('supe_status', 'settingsnew[supe_status]', $settings['supe_status'], 'radio');
		showsetting('supe_siteurl', 'settingsnew[supe_siteurl]', $settings['supe_siteurl'], 'text');
		showsetting('supe_sitename', 'settingsnew[supe_sitename]', $settings['supe_sitename'], 'text');
		showsetting('supe_tablepre', 'settingsnew[supe_tablepre]', $settings['supe_tablepre'], 'text');
		showsetting('supe_last_newuser', 'settingsnew[supe_maxupdateusers]', $settings['supe_maxupdateusers'], 'text');
		showtype('', 'bottom');

?>
<br><center><input class="button" type="submit" name="settingsubmit" value="<?=$lang['submit']?>"></center>
</form>
<?

	} else {

		$settingsnew['supe_maxupdateusers']= intval($settingsnew['supe_maxupdateusers']);

		foreach($settingsnew as $key => $val) {
			if(isset($settings[$key]) && $settings[$key] != $val) {
				$$key = $val;
				$db->query("REPLACE INTO {$tablepre}settings (variable, value)
					VALUES ('$key', '$val')");
			}
		}

		updatecache('settings');
		cpmsg('supe_update_succeed');

	}
}

?>