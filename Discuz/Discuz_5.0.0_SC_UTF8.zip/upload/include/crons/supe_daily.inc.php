<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: supe_daily.inc.php,v $
	$Revision: 1.5.6.1 $
	$Date: 2006/09/01 06:15:01 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($supe_status && $supe_maxupdateusers) {
	require_once DISCUZ_ROOT.'./include/cache.func.php';
	updatecache('supe_updateusers');
}

?>