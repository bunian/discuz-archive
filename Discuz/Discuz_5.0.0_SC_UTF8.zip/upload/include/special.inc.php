<?php

/*
[Discuz!] (C)2001-2006 Comsenz Inc.
This is NOT a freeware, use is subject to license terms

$RCSfile: special.inc.php,v $
$Revision: 1.2.2.1 $
$Date: 2006/09/01 06:15:01 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($thread['special'] == 1) {
	$polloptions = array();
	$votersuid = '';
	$query = $db->query("SELECT MAX(votes) AS max, SUM(votes) AS total FROM {$tablepre}polloptions WHERE tid = '$tid' GROUP BY tid");
	if($count = $db->fetch_array($query)) {

		$query = $db->query("SELECT multiple, visible, maxchoices, expiration FROM {$tablepre}polls WHERE tid='$tid'");
		$options = $db->fetch_array($query);
		$multiple = $options['multiple'];
		$visible = $options['visible'];
		$maxchoices = $options['maxchoices'];
		$expiration = $options['expiration'];

		$query = $db->query("SELECT polloptionid, votes, polloption, voterids FROM {$tablepre}polloptions WHERE tid='$tid' ORDER BY displayorder");
		$voterids = '';
		while($options = $db->fetch_array($query)) {
			$viewvoteruid[] = $options['voterids'];
			$voterids .= "\t".$options['voterids'];
			$polloptions[] = array
			(
			'polloptionid'	=> $options['polloptionid'],
			'polloption'	=> $options['polloption'],
			'votes'		=> $options['votes'],
			'width'		=> @round($options['votes'] * 300 / $count['max']) + 2,
			'percent'	=> @sprintf("%01.2f", $options['votes'] * 100 / $count['total'])
			);
		}

		$voterids = explode("\t", $voterids);
		$voters = array_unique($voterids);
		array_shift($voters);

		if($showvoters) {
			$voterids = implode('\',\'', $voters);
			$svquery = $db->query("SELECT uid, username FROM {$tablepre}members WHERE uid IN ('$voterids')");
			while($voter = $db->fetch_array($svquery)) {
				$options['uid'][] = $voter['uid'];
				$options['voters'][] = $voter['username'];
			}
			$options['voters'] = is_array($options['voters']) ? array_map('stripslashes', $options['voters']) : array();
			if($adminid == 1 && $voters) {
				foreach($viewvoteruid as $key => $value) {
					$viewvoteruid[$key] = explode("\t", $value);
					foreach($options['uid'] as $optuidkey => $optuidvalue) {
						if(in_array($optuidvalue, $viewvoteruid[$key])) {
							$options['viewvoters'][$key][] = $options['voters'][$optuidkey];
						}
					}
				}
			}
		}

		if(!$expiration) {
			$expirations = $timestamp + 86400;
		} else {
			$expirations = $expiration;
			$expiration = gmdate("$dateformat $timeformat", $expiration + $timeoffset * 3600);
		}

		$allowvote = $allowvote && (empty($thread['closed']) || $alloweditpoll) && !in_array(($discuz_uid ? $discuz_uid : $onlineip), $voters) && $timestamp < $expirations && $expirations > 0;
		$optiontype = $multiple ? 'checkbox' : 'radio';
		$visiblepoll = 0;

		if(!($visible || in_array(($discuz_uid ? $discuz_uid : $onlineip), $voters) || in_array($adminid, array(1, 2)) || $ismoderator) && $expirations > $timestamp) {
			$visiblepoll = 1;
		}
	} else {
		$db->query("UPDATE {$tablepre}threads SET special='0' WHERE tid='$tid'", 'UNBUFFERED');
	}

} elseif($thread['special'] == 2) {
	$query = $db->query("SELECT * FROM {$tablepre}trades WHERE tid='$tid'");
	$trade = $db->fetch_array($query);

} elseif($thread['special'] == 3) {
	$rewardprice = abs($thread['price']);

} elseif($thread['special'] == 4) {
	$query = $db->query("SELECT * FROM {$tablepre}activities WHERE tid='$tid'");
	$activity = $db->fetch_array($query);
	$activityclose = $activity['expiration'] ? $activity['expiration'] > $timestamp - date('Z') ? 1 : 0 : 1;
	$activity['starttimefrom'] = date("$dateformat $timeformat", $activity['starttimefrom'] + $timeoffset * 3600);
	$activity['starttimeto'] = $activity['starttimeto'] ? date("$dateformat $timeformat", $activity['starttimeto'] + $timeoffset * 3600) : 0;
	$activity['expiration'] = $activity['expiration'] ? date("$dateformat $timeformat", $activity['expiration'] + $timeoffset * 3600) : 0;

	$isverified = $applied = 0;
	if($discuz_uid) {
		$query = $db->query("SELECT verified FROM {$tablepre}activityapplies WHERE tid='$tid' AND uid='$discuz_uid'");
		if($db->num_rows($query)) {
			$isverified = $db->result($query, 0);
			$applied = 1;
		}
	}

	$sqlverified = $thread['authorid'] == $discuz_uid ? '' : 'AND verified=1';

	$query = $db->query("SELECT username, uid, message, verified, dateline, payment FROM {$tablepre}activityapplies WHERE tid='$tid' $sqlverified ORDER BY dateline DESC LIMIT 5 ");
	while($activityapplies = $db->fetch_array($query)) {
		$activityapplies['dateline'] = gmdate("$dateformat $timeformat", $activityapplies['dateline'] + $timeoffset * 3600);
		$applylist[] = $activityapplies;
	}
	$query = $db->query("SELECT COUNT(*) FROM {$tablepre}activityapplies WHERE tid='$tid' AND verified=1");
	$applynumbers = $db->result($query, 0);
}

?>