document.write("<li><a href=\"upgrade.htm\" target=\"_self\">升级指南首页</a>");
document.write("<li><a href=\"upgrade_changelog.htm\" target=\"_self\">版本更新记录</a>");