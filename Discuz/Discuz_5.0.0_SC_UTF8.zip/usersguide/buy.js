document.write("<li><a href=\"buy_standard.htm\" target=\"_self\">Discuz! 标准型服务</a>");
document.write("<li><a href=\"buy_vip.htm\" target=\"_self\">Discuz! VIP型服务</a>");
document.write("<li><a href=\"buy_enterprise.htm\" target=\"_self\">Discuz! 企业型服务</a>");
document.write("<li><a href=\"buy_assure.htm\" target=\"_self\">有限担保与免责</a>");