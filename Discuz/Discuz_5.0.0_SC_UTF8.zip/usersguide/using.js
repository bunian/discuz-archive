document.write("<li><a href=\"using.htm\" target=\"_self\">使用常见问题首页</a>");
document.write("<li><a href=\"using_config.htm\" target=\"_self\">config.inc.php 配置问题</a>");
document.write("<li><a href=\"using_general.htm\" target=\"_self\">日常使用</a>");
document.write("<li><a href=\"using_styles.htm\" target=\"_self\">风格与模板</a>");
document.write("<li><a href=\"using_permissions.htm\" target=\"_self\">用户权限设定</a>");
document.write("<li><a href=\"using_server.htm\" target=\"_self\">服务器相关</a>");
document.write("<li><a href=\"using_tips.htm\" target=\"_self\">经验技巧</a>");