<?php

// Misc Language Pack for Discuz! Version 1.0.0
// Translated by Crossday

$lang = array
(
	'option' => '相关选项',
	'target_tid' => '目标主题tid',
	'target_pid' => '目标帖子pid',
	'target_username' => '目标用户名',
	'magics_type_1' => '帖子类',
	'magics_type_2' => '会员类',
	'magics_type_3' => '其他类',

	'CCK_color' => '颜色',
	'MOK_info' => '获得的钱币数目规则：大于1且小于购买价格150%的随机数',
	'CODE_info' => '获得Discuz!测试邀请码一个',
	'MVK_target' => '要移动到的版面',
	'SOFA_message' => '一道闪电划破湛蓝的天空，随着一声巨响，沙发被我抢了！哈哈！',
);

?>