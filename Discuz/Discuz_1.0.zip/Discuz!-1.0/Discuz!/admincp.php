<?php
//-----------------------------------------------------------------------------
//    Discuz! Board 1.0 Standard - Discuz! ������̳ (PHP & MySQL) 1.0 ��׼��
//-----------------------------------------------------------------------------
//    Copyright(C) Dai Zhikang, Crossday Studio, 2002. All rights reserved
//
//    Crossday ������ www.crossday.com    *Discuz! ����֧�� www.Discuz.net
//-----------------------------------------------------------------------------
//  ����ϸ�Ķ� Discuz! ��ȨЭ��,�鿴��ʹ�� Discuz! ���κβ�����ζ����ȫͬ��
//  Э���е�ȫ������,�����֮��֧�ֹ���������ҵ,�Ͻ�һ��Υ��Э�����Ȩ��Ϊ.
//-----------------------------------------------------------------------------
// Discuz! רע���ṩ��Чǿ�����̳�������,��������ҵ��;,�����빺��ʹ����Ȩ!
//-----------------------------------------------------------------------------


if(file_exists("install.php")) {
	@unlink("install.php");
	if(file_exists("install.php")) {
		die("���İ�װ���� install.php �Դ����ڷ������ϣ���ͨ�� FTP ɾ������ܽ���ϵͳ���á�<br>Please delete install.php via FTP!");
	}
}

require "./admin/global.php";

$css = <<<EOT
<style type="text/css">
a:link,a:visited	{ text-decoration: none; color: $link }
select			{ font-family: ����; font-size: $fontsize; font-weight: normal; background-color: $altbg1; color: $tabletext }
body			{ scrollbar-base-color: $altbg1; scrollbar-arrow-color: $bordercolor; font-size: $fontsize; $bgcode }
table			{ font-family: $font; color: $tabletext; font-size: $fontsize }
textarea,input,object	{ font-family: $font; font-size: $fontsize; font-weight: normal; background-color: $altbg1; color: $tabletext }
.bold			{ font-weight: $bold }
.subject		{ font-size: $fontsize; color: $tabletext; font-family: $font; font-weight: $bold }
.post			{ font-size: $font3; font-weight: normal; font-family: $font }
.header			{ color: $headertext; font-family: $font; font-weight: $bold; font-size: $fontsize; $headerbgcode }
.category		{ font-family: $font; color: $cattext; font-size: $fontsize; $catbgcode }
.nav			{ font-family: $font; font-weight: $bold; font-size: $fontsize }
.smalltxt		{ font-size: 12px; color: $tabletext; font-family: Tohoma, Arial, Verdana }
.mediumtxt		{ font-size: $fontsize; font-family: $font; font-weight: normal; color: $text }
.navtd			{ font-size: $fontsize; font-family: $font; color: $headertext; text-decoration: none }
.multi			{ font-family: $font; color: $link; font-size: $fontsize }
</style>
EOT;

$navigation = "&raquo; ϵͳ����";
$navtitle .= " - ϵͳ����";

if(!$action || $action == "header" || $action == "menu") {
	if(!$action) {

?>
<html>
<head>
<title>Discuz! ϵͳ�������</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$charset?>">
</head>

<frameset cols="160,*" frameborder="no" border="0" framespacing="0" rows="*"> 
<frame name="menu" noresize scrolling="yes" src="admincp.php?action=menu&sid=<?=$sid?>">
<frameset rows="20,*" frameborder="no" border="0" framespacing="0" cols="*"> 
<frame name="header" noresize scrolling="no" src="admincp.php?action=header&sid=<?=$sid?>">
<frame name="main" noresize scrolling="yes" src="admincp.php?action=main&sid=<?=$sid?>">
</frameset></frameset></html>
<?

	} elseif($action == "header") {

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$charset?>">
<?=$css?>
</head>

<body leftmargin="0" topmargin="0">
<table cellspacing="0" cellpadding="2" border="0" width="100%" height="100%" bgcolor="<?=$altbg2?>">
<tr valign="middle">
<td width="33%"><a href="http://www.crossday.com" target="_blank">Discuz! <?=$version?> ϵͳ�������</a></td>
<td width="33%" align="center"><a href="http://www.Discuz.net" target="_blank">Discuz! �û�����</a></td>
<td width="34%" align="right"><a href="index.php" target="_blank">��̳��ҳ</a></TD>
</tr>
</table>
</body></html>
<?

	} elseif($action == "menu") {

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$charset?>">
<?=$css?>
</head>

<body leftmargin="3" topmargin="3">

<br><table cellspacing="0" cellpadding="0" border="0" width="100%" align="center" style="table-layout: fixed">
<tr><td bgcolor="<?=$bordercolor?>">
<table width="100%" border="0" cellspacing="2" cellpadding="0">
<tr><td style="<?=$bgcode?>">
<table width="100%" border="0" cellspacing="3" cellpadding="<?=$tablespace?>">
<tr><td bgcolor="<?=$altbg1?>" align="center"><a href="admincp.php?action=menu&expand=1_2_3_4_5_6_7_8_9_10">[չ��]</a> &nbsp; <a href="admincp.php?action=menu">[����]</a></td></tr>
<?

		if(preg_match("/(^|_)$change($|_)/is", $expand)) {
			$expandlist = explode("_", $expand);
			$expand = $underline = "";
			foreach($expandlist as $count) {
				if($count != $change) {
					$expand .= "$underline$count";
					$underline = "_";
				}
			}
		} else {
			$expand .= $expand ? "_$change" : $change;
		}
				
		$pluginsarray = array();
		if(is_array($plugins)) {
			foreach($plugins as $plugin) {
				if($plugin[name] && $plugarray[cpurl]) {
					$pluginsarray[] = array("name" => $plugin[name], "url" => $plugin[cpurl]);
				}
			}
		}

		$menucount = 0;
		showmenu("�����ҳ", "admincp.php?action=main");
		showmenu("����ѡ��", "admincp.php?action=settings");
		showmenu("��̳����", array(	array("name" => "������̳", "url" => "admincp.php?action=forumadd"),
						array("name" => "��̳�༭", "url" => "admincp.php?action=forumsedit"),
						array("name" => "��̳�ϲ�", "url" => "admincp.php?action=forumsmerge")));
		showmenu("�û�����", array(	array("name" => "�û��༭", "url" => "admincp.php?action=members"),
						array("name" => "�û���༭", "url" => "admincp.php?action=usergroups"),
						array("name" => "IP ��ֹ", "url" => "admincp.php?action=ipban")));
		showmenu("���Ź���", array(	array("name" => "��̳����", "url" => "admincp.php?action=announcements"),
						array("name" => "��ҳ����", "url" => "admincp.php?action=news")));
		showmenu("��������", array(	array("name" => "���淽��", "url" => "admincp.php?action=themes"),
						array("name" => "������̳", "url" => "admincp.php?action=forumlinks"),
						array("name" => "�������", "url" => "admincp.php?action=censor"),
						array("name" => "Smilies �༭", "url" => "admincp.php?action=smilies")));
		showmenu("���ݹ���", array(	array("name" => "���ݱ���", "url" => "admincp.php?action=export"),
						array("name" => "���ݻָ�", "url" => "admincp.php?action=import"),
						array("name" => "���ݿ�����", "url" => "admincp.php?action=runquery"),
						array("name" => "���ݱ��Ż�", "url" => "admincp.php?action=optimize")));
		showmenu("��̳ά��", array(	array("name" => "�����༭", "url" => "admincp.php?action=attachments"),
						array("name" => "����ɾ��", "url" => "admincp.php?action=prune"),
						array("name" => "����Ϣ����", "url" => "admincp.php?action=u2uprune")));
		showmenu("ϵͳ����", array(	array("name" => "��̳֪ͨ", "url" => "admincp.php?action=newsletter"),
						array("name" => "ģ��༭", "url" => "admincp.php?action=templates"),
						array("name" => "���»���", "url" => "admincp.php?action=flush"),
						array("name" => "�ؽ�ͳ������", "url" => "admincp.php?action=chooser")));
		showmenu("������¼", array(	array("name" => "��������¼", "url" => "admincp.php?action=illegallog"),
						array("name" => "����������¼", "url" => "admincp.php?action=modslog"),
						array("name" => "ϵͳ������¼", "url" => "admincp.php?action=cplog")));
		showmenu("�������", $pluginsarray);
		showmenu("�˳����", "./member.php?action=logout&referer=admincp.php%3Faction%3Dmain");

?>
</table></td></tr></table></td></tr></table>

</body>
</html>
<?

	}

} else {

	if(!$isadmin) {
		cpheader();
		cpmsg("ֻ�й���Ա���ܽ���ϵͳ���ã�");
	}

	if ($action=="main") {
		$serverinfo = PHP_OS." / PHP v".PHP_VERSION;
		$serverinfo .= @ini_get("safe_mode") ? " ��ȫģʽ" : NULL;
		$dbversion = $db->result($db->query("SELECT VERSION()"), 0);

		if(@ini_get("file_uploads")) {
			$fileupload = "���� - �ļ� ".ini_get("upload_max_filesize")." - ������".ini_get("post_max_size");
		} else {
			$fileupload = "<font color=\"red\">��ֹ</font>";
		}

		$forumselect = $groupselect = "";
		$query = $db->query("SELECT groupid, grouptitle FROM $table_usergroups ORDER BY status, creditslower");
		while($group = $db->fetch_array($query)) {
			$groupselect .= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
		}
		$query = $db->query("SELECT fid, name FROM $table_forums WHERE type='forum' OR type='sub'");
		while($forum = $db->fetch_array($query)) {
			$forumselect .= "<option value=\"$forum[fid]\">$forum[name]</option>\n";
		}

		$dbsize = 0;
		$query = $db->query("SHOW TABLE STATUS LIKE '$tablepre%'", 1);
		while($table = $db->fetch_array($query)) {
			$dbsize += $table[Data_length] + $table[Index_length];
		}
		$dbsize = $dbsize ? sizecount($dbsize) : "δ֪";

		$attachsize = dirsize("./$attachdir");
		$attachsize = $attachsize ? sizecount($attachsize) : "δ֪";

		cpheader();

?>
<font class="mediumtxt">
<b>��ӭ���� <a href="http://www.Discuz.net" target="_blank">Discuz! <?=$version?></a> ϵͳ�������</b><br>
��Ȩ����&copy; <a href="http://www.crossday.com" target="_blank">Crossday Studio</a>, 2002.

<br><br><br><table cellspacing="0" cellpadding="0" border="0" width="85%" align="center">
<tr><td bgcolor="<?=$bordercolor?>">
<table border="0" cellspacing="<?=$borderwidth?>" cellpadding="0" width="100%">
<tr><td>
<table border="0" cellspacing="0" cellpadding="<?=$tablespace?>" width="100%">
<tr class="header"><td colspan="3">�� �� �� ʽ</td></tr>

<form method="post" action="admincp.php?action=forumdetail"><tr bgcolor="<?=$altbg2?>"><td>�༭��̳</td>
<td><select name="fid"><?=$forumselect?></select></td><td><input type="submit" value="�� ��"></td></tr></form>

<form method="post" action="admincp.php?action=usergroups&type=detail"><tr bgcolor="<?=$altbg1?>"><td>�༭�û���Ȩ��</td>
<td><select name="id"><?=$groupselect?></td><td><input type="submit" value="�� ��"></td></tr></form>

<form method="post" action="admincp.php?action=members"><tr bgcolor="<?=$altbg2?>"><td>�༭�û�</td>
<td><input type="text" size="25" name="username"></td><td><input type="submit" name="searchsubmit" value="�� ��"></td></tr></form>

<form method="post" action="admincp.php?action=export&type=standard&saveto=server"><tr bgcolor="<?=$altbg1?>"><td>��׼���ݵ�������</td>
<td><input type="text" size="25" name="filename" value="./datatemp/cdb_<?=date("md")."_".random(5)?>.sql"></td><td><input type="submit" name="exportsubmit" value="�� ��"></td></tr></form>

</table></td></tr></table></td></tr></table><br><br>

<table cellspacing="0" cellpadding="0" border="0" width="85%" align="center">
<tr><td bgcolor="<?=$bordercolor?>">
<table border="0" cellspacing="<?=$borderwidth?>" cellpadding="0" width="100%">
<tr><td>
<table border="0" cellspacing="0" cellpadding="<?=$tablespace?>" width="100%">
<tr class="header"><td colspan="2">ϵ ͳ �� Ϣ</td></tr>
<tr bgcolor="<?=$altbg2?>"><td width="50%">����������</td><td><?=$serverinfo?></td></tr>
<tr bgcolor="<?=$altbg1?>"><td>MySQL �汾</td><td><?=$dbversion?></td></tr>
<tr bgcolor="<?=$altbg2?>"><td>�����ϴ�����</td><td><?=$fileupload?></td></tr>
<tr bgcolor="<?=$altbg1?>"><td>���ݿ�ռ��</td><td><?=$dbsize?></td></tr>
<tr bgcolor="<?=$altbg2?>"><td>�����ļ�ռ��</td><td><?=$attachsize?></td></tr>
</table></td></tr></table></td></tr></table><br><br>

<table cellspacing="0" cellpadding="0" border="0" width="85%" align="center">
<tr><td bgcolor="<?=$bordercolor?>">
<table border="0" cellspacing="<?=$borderwidth?>" cellpadding="0" width="100%">
<tr><td>
<table border="0" cellspacing="0" cellpadding="<?=$tablespace?>" width="100%">
<tr class="header"><td colspan="2">�� �� �� ��</td></tr>
<tr bgcolor="<?=$altbg2?>"><td width="50%">�������</td><td><a href="http://www.crossdasy.com" target="_blank">Crossday</a></td></tr>
<tr bgcolor="<?=$altbg1?>"><td>�������</td><td><a href="http://www.nucpp.com">KnightE</a>, <a href="http://www.zc18.com/" target="_blank">feixin</a>, <a href="http://truehome.net" target="_blank">�ϱ��ư�</a></td></tr>
<tr bgcolor="<?=$altbg2?>"><td>����֧��</td><td><a href="http://www.crossdasy.com" target="_blank">Crossday</a>, <a href="http://tyc.udi.com.tw/cdb" target="_blank">Tyc</a>, <a href="http://smice.net/~youran/cdb/index.php" target="_blank">��ʴ</a>, <a href="http://www.cnmaya.org" target="_blank">�����Ϳ</a></td></tr>
<tr bgcolor="<?=$altbg1?>"><td>����֧��</td><td><a href="mailto:cdb@crossday.com">cdb@crossday.com</a></td></tr>
</table></td></tr></table></td></tr></table>
<?

	} elseif($action == "settings") {
		include "./admin/settings.php";
	} elseif($action == "forumadd" || $action == "forumsedit" || $action == "forumsmerge" || $action == "forumdetail" || $action == "forumdelete") {
		include "./admin/forums.php";
	} elseif($action == "members" || $action == "memberprofile" || $action == "usergroups" || $action == "ipban") {
		include "./admin/members.php";
	} elseif($action == "announcements" || $action == "news") {
		include "./admin/announcements.php";
	} elseif($action == "themes" || $action == "forumlinks" || $action == "censor" || $action == "smilies" || $action == "flush") {
		include "./admin/misc.php";
	} elseif($action == "export" || $action == "import" || $action == "runquery" || $action == "optimize") {
		include "./admin/database.php";
	} elseif($action == "attachments") {
		include "./admin/attachments.php";
	} elseif($action == "chooser") {
		include "./admin/chooser.php";
	} elseif($action == "prune" || $action == "u2uprune") {
		include "./admin/prune.php";
	} elseif($action == "newsletter") {
		include "./admin/newsletter.php";
	} elseif($action == "templates" || $action == "tpladd" || $action == "tplresetall" || $action == "tpldownload" || $action == "tpledit" || $action == "tpldelete" || $action == "tplreset") {
		include "./admin/templates.php";
	} elseif($action == "illegallog" || $action == "modslog" || $action == "cplog") {
		include "./admin/logs.php";
	}

	if(!$nofooter) {
		cpfooter();
	}

}

cdb_output();

?>