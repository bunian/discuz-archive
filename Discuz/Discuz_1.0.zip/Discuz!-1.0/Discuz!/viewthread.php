<?php
//-----------------------------------------------------------------------------
//    Discuz! Board 1.0 Standard - Discuz! ������̳ (PHP & MySQL) 1.0 ��׼��
//-----------------------------------------------------------------------------
//    Copyright(C) Dai Zhikang, Crossday Studio, 2002. All rights reserved
//
//    Crossday ������ www.crossday.com    *Discuz! ����֧�� www.Discuz.net
//-----------------------------------------------------------------------------
//  ����ϸ�Ķ� Discuz! ��ȨЭ��,�鿴��ʹ�� Discuz! ���κβ�����ζ����ȫͬ��
//  Э���е�ȫ������,�����֮��֧�ֹ���������ҵ,�Ͻ�һ��Υ��Э�����Ȩ��Ϊ.
//-----------------------------------------------------------------------------
// Discuz! רע���ṩ��Чǿ�����̳�������,��������ҵ��;,�����빺��ʹ����Ȩ!
//-----------------------------------------------------------------------------


require "./header.php";
$ismoderator = modcheck($cdbuser);

if($action == "attachment" && $aid) {
	$query = $db->query("SELECT a.*, t.fid FROM $table_attachments a LEFT JOIN $table_threads t ON a.tid=t.tid WHERE aid='$aid'");
	$attach = $db->fetch_array($query);
	if($allowgetattach && $attach[creditsrequire] && $attach[creditsrequire] > $credit && !$ismoderator) {
		showmessage("�Բ��𣬱�����Ҫ��{$credittitle}���� $attach[creditsrequire] {$creditunit}�ſ����أ��뷵�ء�");
	}
	$query = $db->query("SELECT * FROM $table_forums WHERE fid='$attach[fid]'");
	$forum = $db->fetch_array($query);
	if(!$forum[getattachperm] && !$allowgetattach) {
		showmessage("�Բ������ļ���{$grouptitle}���޷����ظ�����");
	} elseif($forum[getattachperm] && !strstr($forum[getattachperm], "\t$groupid\t")) {
		showmessage("�Բ���ֻ���ض��û��������ر���̳�ĸ������뷵�ء�");
	}

	$db->query("UPDATE $table_attachments SET downloads=downloads+1 WHERE aid='$aid'");
	$filename = "$attachdir/$attach[attachment]";
	$filesize = filesize($filename);
	if(is_readable($filename) && $attach[attachment]) {
		header("Content-Disposition: filename=$attach[filename]");
		header("Content-Length: $filesize");
		header("Content-Type: $attach[filetype]");
		header("Pragma: no-cache");
		header("Expires: 0");
		@$fp = fopen($filename, "rb");
		@flock($fp, 3);
		$attachment = @fread($fp, $filesize);
		@fclose($fp);
		echo $attachment;
		ob_end_flush();
	} else {
		showmessage("�����ļ������ڻ��޷����룬�������Ա��ϵ��");
	}
	cdbexit();
}

if($goto == "lastpost") {
	if($highlight) {
		$highlight = "&highlight=".rawurlencode($highlight);
	}
	if($tid) {
		$query = $db->query("SELECT p.pid, p.dateline, t.tid, t.replies FROM $table_threads t, $table_posts p WHERE p.tid=t.tid AND t.tid='$tid' ORDER BY p.dateline DESC LIMIT 0,1");
		if($post = $db->fetch_array($query)) {
			if(($post[replies] + 1) > $ppp) {
				$page = "&page=".ceil(($post[replies] + 1) / $ppp);
			}
			header("Location: {$boardurl}viewthread.php?tid=$post[tid]&pid=$post[pid]$page&sid=$sid#pid$post[pid]$highlight");
			cdbexit();
		}
	}
	if($fid) {
		$query = $db->query("SELECT p.pid, p.dateline, t.tid, t.replies FROM $table_threads t, $table_posts p WHERE p.tid=t.tid AND t.fid='$fid' ORDER BY p.dateline DESC LIMIT 0,1");
		if($post = $db->fetch_array($query)) {
			if(($post[replies] + 1) > $ppp) {
				$page = "&page=".ceil(($post[replies] + 1) / $ppp);
			}
			header("Location: {$boardurl}viewthread.php?tid=$post[tid]&pid=$post[pid]$page&sid=$sid#pid$post[pid]");
			cdbexit();
		}
	}
} elseif($goto == "nextnewset") {
	if($fid && $tid) {
		$query = $db->query("SELECT lastpost FROM $table_threads WHERE tid='$tid'");
		$this_lastpost = $db->result($query, 0);
		$query = $db->query("SELECT tid FROM $table_threads WHERE fid='$fid' AND lastpost>'$this_lastpost' ORDER BY lastpost ASC LIMIT 0, 1");
		if($next = $db->fetch_array($query)) {
			header("Location: {$boardurl}viewthread.php?tid=$next[tid]&sid=$sid");
			cdbexit();
		} else {
			showmessage("û�бȵ�ǰ���µ����⣬�뷵�ء�");
		}
	} else {
		showmessage("��û��ָ����ǰ���⼰���� id���޷�ת����һ���⡣");
	}
} elseif($goto == "nextoldset") {
	if($fid && $tid) {
		$query = $db->query("SELECT lastpost FROM $table_threads WHERE tid='$tid'");
		$this_lastpost = $db->result($query, 0);
		$query = $db->query("SELECT tid FROM $table_threads WHERE fid='$fid' AND lastpost<'$this_lastpost' ORDER BY lastpost DESC LIMIT 0, 1");
		if($last = $db->fetch_array($query)) {
			header("Location: {$boardurl}viewthread.php?tid=$last[tid]&sid=$sid");
			cdbexit();
		} else {
			showmessage("û�бȵ�ǰ��������⣬�뷵�ء�");
		}
	} else {
		showmessage("��û��ָ����ǰ���⼰���� id���޷�ת����һ���⡣");
	}
}

$codecount = 0;
$oldtopics = $HTTP_COOKIE_VARS[oldtopics];
if(!strstr($oldtopics, "\t$tid\t")) {
	$oldtopics .= $oldtopics ? "$tid\t" : "\t$tid\t";
	setcookie("oldtopics", $oldtopics, $timestamp + 86400, $cookiepath, $cookiedomain);
}

$query = $db->query("SELECT * FROM $table_threads WHERE tid='$tid'");
if(!$thread = $db->fetch_array($query)) {
	showmessage("ָ�������ⲻ���ڻ��ѱ�ɾ�����뷵�ء�");
}
$thread[subject] = censor($thread[subject]);

$useraction = "������ӡ�$thread[subject]��";
if($forum[type] == "forum") {
	$navigation .= "&raquo; <a href=\"forumdisplay.php?fid=$fid\"> $forum[name]</a> &raquo; $thread[subject]";
	$navtitle .= " - $forum[name] - $thread[subject]";
} else {
	$query = $db->query("SELECT fid, name FROM $table_forums WHERE fid='$forum[fup]'");
	$fup = $db->fetch_array($query);
	$navigation .= "&raquo; <a href=\"forumdisplay.php?fid=$fup[fid]\">$fup[name]</a> &raquo; <a href=\"forumdisplay.php?fid=$fid\"> $forum[name]</a> &raquo; $thread[subject]";
	$navtitle .= " - $fup[name] - $forum[name] - $thread[subject]";
}

if(!$forum[viewperm] && !$allowview) {
	showmessage("�Բ������ļ���{$grouptitle}���޷�������ӡ�");
} elseif($forum[viewperm] && !strstr($forum[viewperm], "\t$groupid\t")) {
	showmessage("�Բ��𣬱���ֻ̳���ض��û�����������뷵�ء�");
} elseif($thread[creditsrequire] && $thread[creditsrequire] > $credit && !$ismoderator) {
	showmessage("�Բ��𣬱���Ҫ��{$credittitle}���� $thread[creditsrequire] {$creditunit}�ſ�������뷵�ء�");
}

if($forum[password] != $HTTP_COOKIE_VARS["fidpw$fid"] && $forum[password] != $CDB_SESSION_VARS["fidpw$fid"] && $forum[password]) {
	header("Location: {$boardurl}forumdisplay.php?fid=$fid&sid=$sid");
	cdbexit();
}

if(!$action && $tid) {

	$tplnames = "css,header,footer,viewthread_post,viewthread_modoptions,viewthread_post_sig,viewthread_forumjump,viewthread";
	preloader($fastpost ? ",viewthread_fastpost" : NULL);

	$newpolllink = $allowpostpoll ? "&nbsp;<a href=\"post.php?action=newthread&fid=$fid&poll=yes\"><img src=\"$imgdir/poll.gif\" border=\"0\"></a>" : NULL;
	$replylink = "&nbsp;<a href=\"post.php?action=reply&fid=$fid&tid=$tid\"><img src=\"$imgdir/reply.gif\" border=\"0\"></a>";
	$nohllink = str_replace("+", "", $highlight) ? "<a href=\"viewthread.php?tid=$tid&page=$page\" style=\"color: $headertext;font-weight: normal\">ȡ������</a> " : NULL;
	$setdigist = $thread[digist] ? "ȡ������" : "���뾫��";
	$topuntop = $thread[topped] ? "����ö�" : "�����ö�";

	if($thread[closed]) {
		if(!$ismoderator) {
			$replylink = "";
		}
		$closeopen = "������";
	} else {
		$closeopen = "�ر�����";
	}

	if($allowkarma && $maxkarmavote) {
		$offset = ceil($maxkarmavote / 6);
		$karmabox = "&nbsp;<select name=\\\"fid\\\" id=\\\"fid\\\" onchange=\\\"if(this.options[this.selectedIndex].value != '') {\n"
			."window.location=('topicadmin.php?action=karma&tid=\$tid&username=\$encodename&score='+this.options[this.selectedIndex].value+'&sid=$sid') }\\\" align=\\\"absmiddle\\\">\n"
			."<option value=\\\"\\\">����</option>\n"
			."<option value=\\\"\\\">----</option>\n";
		for($vote = - $maxkarmavote + $offset; $vote <= $maxkarmavote; $vote += $offset) {
			$votenum = $vote > 0 ? "+$vote" : $vote;
			$karmabox .= $vote ? "<option value=\\\"$vote\\\">$votenum</option>\n" : NULL;
		}
		$karmabox .= "</select>\n";
	}

	if($page) {
		$start_limit = ($page-1) * $ppp;
	} else {
		$start_limit = 0;
		$page = 1;
	}

	$db->query("UPDATE $table_threads SET views=views+1 WHERE tid='$tid'");
	$num = $thread[replies] + 1;

	$mpurl = "viewthread.php?tid=$tid&highlight=".rawurlencode($highlight);
	$multipage = multi($num, $ppp, $page, $mpurl);
	$creditsrequire = $thread[creditsrequire] ? " &nbsp; ���������{$credittitle} <span class=\"bold\">$thread[creditsrequire]</span> $creditunit" : NULL;

	if($thread[pollopts]) {
		loadtemplates("viewthread_poll_options_view,viewthread_poll_options,viewthread_poll_submitbutton,viewthread_poll");
		$thread[pollopts] = stripslashes(censor($thread[pollopts]));
		$thread[pollopts] = str_replace("\n", "", $thread[pollopts]);
		$pollops = explode("#|#", $thread[pollopts]);

		if(strstr($thread[pollopts]." ", " $cdbuser ")) {
			for($pnum = 0; $pnum < 10; $pnum++) {
				if($pollops[$pnum] != "" && substr($pollops[$pnum],0,1)!=" ") {
					$thispollnum = eregi_replace(".*\|\|~\|~\|\| ", "", $pollops[$pnum]);
					$totpollvotes += $thispollnum;
				}
			}
			for($pnum = 0; $pnum < 10; $pnum++) {
				if($pollops[$pnum] != "" && substr($pollops[$pnum], 0, 1) != " ") {
					$thispoll = explode("||~|~|| ", $pollops[$pnum]);

					if($totpollvotes != 0) {
						$thisnum = $thispoll[1] * 100 / $totpollvotes;
					} else {
						$thisnum = "0";
					}

					if($thisnum != "0") {
						$thisnum = round($thisnum, 2);
						$pollimgnum = round($thisnum) / 3;
						for($num = 0; $num < $pollimgnum; $num++) {
							$pollbar .= "<img src=\"$imgdir/pollbar.gif\">";
						}
					}

					$thisnum .= "%";

					if($thisnum == "0%") {
						$pollbar = "";
					}
					eval("\$pollhtml .= \"".template("viewthread_poll_options_view")."\";");
					$pollbar = "";
				}
			}
		} else {
			$checked = "checked";
			for($pnum = 0; $pnum < 10; $pnum++) {
				if($pollops[$pnum] != "" && substr($pollops[$pnum], 0, 1)!=" ") {
					$thispoll = explode("||~|~|| ", $pollops[$pnum]);
					eval("\$pollhtml .= \"".template("viewthread_poll_options")."\";");
					$checked = "";
				}
			}
		}

		if(strstr($thread[pollopts]." ", " $cdbuser ")) {
			$buttoncode = "";
		} else {
			$buttoncode = "<br><center><input type=\"submit\" value=\"�ύͶƱ\"></center>";
		}
		eval("\$poll = \"".template("viewthread_poll")."\";");
	}

	$thisbg = $altbg2;
	$attachments = $comma = "";
	$querypost = $db->query("SELECT p.*, m.* FROM $table_posts p LEFT JOIN $table_members m ON m.username=p.author WHERE p.tid='$tid' ORDER BY dateline LIMIT $start_limit, $ppp");
	while($post = $db->fetch_array($querypost)) {
		$poston = gmdate("$dateformat $timeformat", $post[dateline] + ($timeoffset * 3600));
		$post[icon] = $post[icon] ? "<img src=\"$smdir/$post[icon]\" align=\"absmiddle\">" : "<img src=\"$imgdir/lastpost.gif\" align=\"absmiddle\">";
		if($post[author] != "�ο�" && $post[username]) {
			$email = $post[showemail] ? "<a href=\"mailto:$post[email]\"><img src=\"$imgdir/email.gif\" border=\"0\" alt=\"�����ʼ�\"></a>&nbsp;" : "";
			$personstatus = $vtonlinestatus ? $timestamp - $post[lastvisit] <= $onlinehold ? "״̬ <b>Online</b><br>" : "״̬ Offline<br>" : "";
			if($post[site] == "") {
				$site = "";
			} else {
				$post[site] = "http://".str_replace("http://", "", $post[site]);
				$site = "<a href=\"$post[site]\" target=\"_blank\"><img src=\"$imgdir/site.gif\" border=\"0\" alt=\"������ҳ\"></a>&nbsp;";
			}
			$encodename = rawurlencode($post[author]);

			$icq = $post[icq] ? "<a href=http://wwp.icq.com/scripts/search.dll?to=$post[icq]><img src=\"http://web.icq.com/whitepages/online?icq=$post[icq]&img=5\" alt=\"$post[author] �� ICQ ״̬\" border=\"0\"></a>&nbsp;" : "";
			$oicq = $post[oicq] ? "<a href=http://search.tencent.com/cgi-bin/friend/user_show_info?ln=$post[oicq]><img src=\"$imgdir/oicq.gif\" alt=\"$post[author] �� OICQ\" border=\"0\"></a>&nbsp;" : "";
			$yahoo = $post[yahoo] ? "<a href=http://edit.yahoo.com/config/send_webmesg?.target=$post[yahoo]&.src=pg><img src=\"$imgdir/yahoo.gif\" alt=\"$post[author] �� Yahoo\" border=\"0\"></a>&nbsp;" : "";

			$search = "<a href=\"misc.php?action=search&srchuname=$encodename&srchfid=all&srchfrom=0&searchsubmit=yes\"><img src=\"$imgdir/find.gif\" border=\"0\" alt=\"�������û���ȫ������\"></a>&nbsp;";
			$profile = "<a href=\"member.php?action=viewpro&username=$encodename\"><img src=\"$imgdir/profile.gif\" border=\"0\" alt=\"�鿴����\"></a>&nbsp;";
			$u2u = "<a href=\"###\" onclick=\"Popup('u2u.php?action=send&username=$encodename&sid=$sid', 'Window', 600, 500);\"><img src=\"$imgdir/u2u.gif\" border=\"0\" alt=\"������Ϣ\"></a>&nbsp;";

			unset($groupinfo, $groupstars, $stars);
			foreach($CDB_CACHE_VARS[usergroups] as $usergroup) {
				if((stristr($usergroup[specifiedusers], "\t".addslashes($post[author])."\t") || ($post[status] == $usergroup[status] && $usergroup[status] != "��ʽ��Ա")) && !$usergroup[creditshigher] && !$usergroup[creditslower]) {
					if($groupstars < $usergroup[stars]) {
						$groupstars = $usergroup[stars];
					}
					$groupinfo = $usergroup;
				} elseif($post[credit] >= $usergroup[creditshigher] && $post[credit] < $usergroup[creditslower]) {
					if($post[status] == $usergroup[status] && !$groupinfo) {
						$groupstars = $usergroup[stars];
						$groupinfo = $usergroup;
					} elseif($groupstars < $usergroup[stars]) {
						$groupstars = $usergroup[stars];
					}
					if($groupinfo) {
						break;
					}
				}
			}

			$showtitle = $post[customstatus] ? $post[customstatus] : $groupinfo[grouptitle];
			for($i = 0; $i < $groupstars; $i++) {
				$stars .= "<img src=\"$imgdir/star.gif\">";
			}

			$tharegdate = gmdate("$dateformat", $post[regdate] + ($timeoffset * 3600));
			$stars .= "<br>";

			$avatar = "<br>";
			if($groupinfo[allowavatar]) {
				if($groupinfo[groupavatar]) {
					$avatar = $avatar = "<table width=\"95%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"table-layout: fixed\">\n<tr><td align=\"center\">".image($groupinfo[groupavatar])."</td></tr></table>";
				} elseif($post[avatar]) {
					$avatar = "<table width=\"95%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"table-layout: fixed\">\n<tr><td align=\"center\">".image($post[avatar])."</td></tr></table>";
				}
			}

			$location = $post[location] ? "<br>���� $post[location]" : "";
		} else {
			if($post[author] == "�ο�") {
				$showtitle = "δע��<br>";
			} elseif(!$post[username]) {
				$showtitle = "���û��ѱ�ɾ��";
			}
			$post[postnum] = $post[credit] = $tharegdate = "N/A";
			$personstatus = $stars = $avatar = $email = $site = $icq
				= $oicq = $yahoo = $profile = $search = $u2u = $location = "";
		}

		if($ismoderator) {
			$ip = "<a href=\"topicadmin.php?action=getip&fid=$fid&tid=$tid&pid=$post[pid]\"><img src=\"$imgdir/ip.gif\" border=\"0\" align=\"right\" alt=\"��ȡ IP\"></a>";
			$delete = "<input type=\"checkbox\" name=\"delete[]\" value=\"$post[pid]\">";
		} else {
			$ip = $delete = "";
		}

		$repquote = !$thread[closed] || $ismoderator ? "&nbsp;<a href=\"post.php?action=reply&fid=$fid&tid=$tid&repquote=$post[pid]\"><img src=\"$imgdir/quote.gif\" border=\"0\" alt=\"���ûظ�\"></a>" : "";
		$reportlink = ($cdbuser && $reportpost) ? "&nbsp;<a href=\"topicadmin.php?action=report&fid=$fid&tid=$tid&pid=$post[pid]\"><img src=\"$imgdir/report.gif\" border=\"0\" alt=\"�������Ӧ�������\"></a>" : "";
		$edit = "&nbsp;<a href=\"post.php?action=edit&fid=$fid&tid=$tid&pid=$post[pid]&page=$page\"><img src=\"$imgdir/edit.gif\" border=\"0\" alt=\"�༭����\"></a>";

		if($allowkarma && $maxkarmavote) {
			eval("\$karma = \"$karmabox\";");
		}

		if($post[subject]) {
			$post[subject] = "$post[subject]<br><br>";
		}

		$post[subject] = censor($post[subject]);
		$post[message] = postify($post[message], $post[smileyoff], $post[bbcodeoff], $post[parseurloff], $forum[allowsmilies], $forum[allowhtml], $forum[allowbbcode], $forum[allowimgcode]);

		if($post[aid]) {
			$post[message] .= "\tCDB_ATTACHMENT_LACK_$post[aid]\t";
			$attachments .= "$comma'$post[aid]'";
			$comma = ", ";
		}

		if($thisbg == $altbg2) {
			$thisbg = $altbg1;
			$sigline = $altbg2;
		} else {
			$thisbg = $altbg2;
			$sigline = $altbg1;
		}

		if($post[usesig] && $post[signature]) {
			$post[signature] = postify($post[signature], "", "", "", 0, 0, $groupinfo[allowsigbbcode], $groupinfo[allowsigimgcode]);
			eval("\$post[message] .= \"".template("viewthread_post_sig")."\";");
		}

		eval("\$posts .= \"".template("viewthread_post")."\";");
	}

	if($attachments) {
		loadtemplates("viewthread_post_attachmentimage,viewthread_post_attachmentswf,viewthread_post_attachment");
		$query = $db->query("SELECT * FROM $table_attachments WHERE aid IN ($attachments)");
		while($postattach = $db->fetch_array($query)) {
			$extension = strtolower(substr(strrchr($postattach[filename],"."),1));
			$attachicon = attachicon(substr(strrchr($postattach[attachment], "."), 1)."\t".$postattach[filetype]);
			if($attachimgpost && ($extension == "jpg" || $extension == "jpeg" || $extension == "jpe" || $extension == "gif" || $extension == "png" || $extension == "bmp")) {
				eval("\$attacharray[$postattach[aid]] = \"".template("viewthread_post_attachmentimage")."\";");
			} elseif($attachimgpost && $extension == "swf") {
				eval("\$attacharray[$postattach[aid]] = \"".template("viewthread_post_attachmentswf")."\";");
			} else {
				$attachsize = sizecount($postattach[filesize]);
				$downloadcount = $postattach[downloads];
				$creditrequire = $postattach[creditsrequire] ? "��������$credittitle $postattach[creditsrequire] $creditunit" : NULL;
				eval("\$attacharray[$postattach[aid]] = \"".template("viewthread_post_attachment")."\";");
			}
		}
		if(is_array($attacharray)) {
			foreach($attacharray as $aid => $attachment) {
				$posts = str_replace("\tCDB_ATTACHMENT_LACK_".$aid."\t", $attachment, $posts);
			}
		}		
	}

	if($ismoderator) {
		eval("\$modoptions = \"".template("viewthread_modoptions")."\";");
	} else {
		$modoptions = "";
	}

	$forumselect = forumselect();
	eval("\$forumjump = \"".template("viewthread_forumjump")."\";");

	if($fastpost && (!$thread[closed] || $ismoderator) && ((!$forum[postperm] && $allowpost) || ($forum[postperm] && strstr($forum[postperm], "\t$groupid\t")))) {
		$usesigcheck = $signature ? "checked" : NULL;
		eval("\$fastpost_viewthread = \"".template("viewthread_fastpost")."\";");
	}
	eval("\$viewthread = \"".template("viewthread")."\";");
	echo $viewthread;

	gettotaltime();
	eval("\$footer = \"".template("footer")."\";");
	echo $footer;

} elseif($action == "printable" && $tid) {

	loadtemplates("viewthread_printable_attachmentimage,viewthread_printable_attachment,viewthread_printable_row,viewthread_printable");
	$querypost = $db->query("SELECT * FROM $table_posts WHERE fid='$fid' AND tid='$tid' ORDER BY dateline");
	while($post = $db->fetch_array($querypost)) {

		$poston = gmdate("$dateformat $timeformat", $post[dateline] + ($timeoffset * 3600));

		$thisbg = "#FFFFFF";
		$post[subject] = censor($post[subject]);
		$post[message] = postify($post[message], $post[smileyoff], $post[bbcodeoff], $post[parseurloff], $forum[allowsmilies], $forum[allowhtml], $forum[allowbbcode], $forum[allowimgcode]);

		if($post[aid]) {
			$query = $db->query("SELECT * FROM $table_attachments WHERE aid='$post[aid]'");
			$postattach = $db->fetch_array($query);
			$extension = strtolower(substr(strrchr($postattach[filename],"."),1));
			if($attachimgpost && ($extension == "jpg" || $extension == "jpeg" || $extension == "jpe" || $extension == "gif" || $extension == "png" || $extension == "bmp")) {
				$attachicon = attachicon(substr(strrchr($postattach[attachment], "."), 1)."\t".$postattach[filetype]);
				eval("\$post[message] .= \"".template("viewthread_printable_attachmentimage")."\";");
			} else {
				$attachsize = sizecount($postattach[filesize]);
				$attachicon = attachicon(substr(strrchr($postattach[attachment], "."), 1)."\t".$postattach[filetype]);
				$creditsrequire = $postattach[creditsrequire] ? " / $credittitle $postattach[creditsrequire] $creditunit" : NULL;
				eval("\$post[message] .= \"".template("viewthread_printable_attachment")."\";");
			}
		}

		eval("\$posts .= \"".template("viewthread_printable_row")."\";");
	}
	eval("\$printable = \"".template("viewthread_printable")."\";");
	echo $printable;

} else {

	showmessage("δ����������뷵�ء�");

}
cdb_output();
?>