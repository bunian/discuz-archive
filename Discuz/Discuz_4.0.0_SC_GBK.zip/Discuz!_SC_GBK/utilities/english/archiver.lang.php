<?php

// Message Pack for Discuz! Archiver Version 1.0.0
// Created by Crossday

$lang = array
(

	'page' => 'Page',
	'replies' => 'replies',
	'full_version' => 'View full version',
	'forum_nonexistence' => 'Specified forum was not found or you have no permission to access.',
	'thread_nonexistence' => 'Specified thread was not found or you have no permission to view.',

);

?>