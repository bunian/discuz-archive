<?

/*
        [DISCUZ!] /plugins.php - Crossday Discuz! Board plugin interface
        This is NOT a freeware, use is subject to license terms

        Version: 4.0.0
        Author: Crossday
        Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
        Last Modified: 2005/10/15 17:18
*/

require_once './include/common.inc.php';

$pluginmodule = isset($plugins['links'][$identifier][$module]) ? $plugins['links'][$identifier][$module] : '';

if(empty($identifier) || empty($module) || !preg_match("/^[a-z0-9_\-]+$/i", $module) || !$pluginmodule) {
	showmessage('undefined_action');
} elseif($pluginmodule['adminid'] && $adminid > 0 && $pluginmodule['adminid'] < $adminid) {
	showmessage('plugin_nopermission');
} elseif(@!file_exists(DISCUZ_ROOT.($modfile = './plugins/'.$pluginmodule['directory'].$module.'.inc.php'))) {
	showmessage('plugin_module_nonexistence');
}

include DISCUZ_ROOT.$modfile;

?>