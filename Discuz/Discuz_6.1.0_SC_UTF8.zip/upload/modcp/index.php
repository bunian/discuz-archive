<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: index.php 12294 2008-01-24 07:58:55Z cnteacher $
*/

header('Location: ../modcp.php');

?>