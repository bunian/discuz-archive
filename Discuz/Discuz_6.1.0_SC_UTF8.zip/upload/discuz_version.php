<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('DISCUZ_VERSION', '6.1.0');
define('DISCUZ_RELEASE', '20090818');

?>