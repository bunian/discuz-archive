<?php

/*
	[DISCUZ!] admincp.php - administrator's control panel
	This is NOT a freeware, use is subject to license terms

	Version: 2.0.1
	Author: Crossday (info@discuz.net)
	Copyright: Crossday Studio (www.crossday.com)
	Last Modified: 2002/12/23 17:00
*/

require './include/common.php';
require $discuz_root.'./include/cache.php';
require $discuz_root.'./admin/global.php';

$discuz_action = 161;

if(@file_exists($discuz_root.'./install.php')) {
	@unlink($discuz_root.'./install.php');
	if(@file_exists($discuz_root.'./install.php')) {
		discuz_exit('Please delete install.php via FTP!');
	}
}

if(empty($action) || !empty($direct)) {

	$action = empty($action) ? 'main' : $action;
?>
<html>
<head>
<title>Discuz! ϵͳ�������</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?=CHARSET?>">
</head>

<frameset cols="160,*" frameborder="no" border="0" framespacing="0" rows="*"> 
<frame name="menu" noresize scrolling="yes" src="admincp.php?action=menu&sid=<?=$sid?>">
<frameset rows="20,*" frameborder="no" border="0" framespacing="0" cols="*"> 
<frame name="header" noresize scrolling="no" src="admincp.php?action=header&sid=<?=$sid?>">
<frame name="main" noresize scrolling="yes" src="admincp.php?action=<?=$action?>&extr=<?=$extr?>&sid=<?=$sid?>">
</frameset></frameset><noframes></noframes></html>
<?

} elseif($action == 'header') {

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=CHARSET?>">
<? include template('css'); ?>
</head>

<body leftmargin="0" topmargin="0">
<table cellspacing="0" cellpadding="2" border="0" width="100%" height="100%" bgcolor="<?=ALTBG2?>">
<tr valign="middle">
<td width="33%"><a href="http://www.comsenz.com" target="_blank">Discuz! <?=$version?> ϵͳ�������</a></td>
<td width="33%" align="center"><a href="http://www.Discuz.net" target="_blank">Discuz! �û�����</a></td>
<td width="34%" align="right"><a href="index.php" target="_blank">��̳��ҳ</a></TD>
</tr>
</table>
</body></html>
<?

} elseif($action == 'menu') {

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=CHARSET?>">
<? include template('css'); ?>
</head>

<body leftmargin="3" topmargin="3">

<br><table cellspacing="0" cellpadding="0" border="0" width="100%" align="center" style="table-layout: fixed">
<tr><td bgcolor="<?=BORDERCOLOR?>">
<table width="100%" border="0" cellspacing="1" cellpadding="0">
<tr><td bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="3" cellpadding="<?=TABLESPACE?>">
<tr><td bgcolor="<?=ALTBG1?>" align="center"><a href="admincp.php?action=menu&expand=1_2_3_4_5_6_7_8_9_10">[չ��]</a> &nbsp; <a href="admincp.php?action=menu&expand=0">[����]</a></td></tr>
<?

		if(preg_match("/(^|_)$change($|_)/is", $expand)) {
			$expandlist = explode('_', $expand);
			$expand = $underline = '';
			foreach($expandlist as $count) {
				if($count != $change) {
					$expand .= $underline.$count;
					$underline = '_';
				}
			}
		} else {
			$expand .= isset($expand) ? '_'.$change : $change;
		}

		if($expand || $expand == '0') {
			setcookie('expand_menu', $expand, $timestamp + 2592000, $cookiepath, $cookiedomain);
		} else {
			$expand = $HTTP_COOKIE_VARS['expand_menu'];
		}

		$pluginsarray = array();
		if(is_array($plugins)) {
			foreach($plugins as $plugin) {
				if($plugin[name] && $plugin[cpurl]) {
					$pluginsarray[] = array('name' => $plugin['name'], 'url' => $plugin['cpurl']);
				}
			}
		}

		$menucount = 0;
		showmenu('�����ҳ', 'admincp.php?action=main');
		showmenu('����ѡ��', 'admincp.php?action=settings');
		showmenu('��̳����', array(	array('name' => '������̳', 'url' => 'admincp.php?action=forumadd'),
						array('name' => '��̳�༭', 'url' => 'admincp.php?action=forumsedit'),
						array('name' => '��̳�ϲ�', 'url' => 'admincp.php?action=forumsmerge')));
		showmenu('�û�����', array(	array('name' => '�����û�', 'url' => 'admincp.php?action=addmember'),
						array('name' => '�û��༭', 'url' => 'admincp.php?action=members'),
						array('name' => '�û���༭', 'url' => 'admincp.php?action=usergroups'),
						array('name' => 'IP ��ֹ', 'url' => 'admincp.php?action=ipban')));
		showmenu('������', array(	array('name' => '��񷽰�', 'url' => 'admincp.php?action=styles'),
						array('name' => 'ģ����ϵ', 'url' => 'admincp.php?action=templates')));
		showmenu('��������', array(	array('name' => '��̳����', 'url' => 'admincp.php?action=announcements'),
						array('name' => '������̳', 'url' => 'admincp.php?action=forumlinks'),
						array('name' => '�������', 'url' => 'admincp.php?action=censor'),
						array('name' => 'Smilies �༭', 'url' => 'admincp.php?action=smilies')));
		showmenu('���ݹ���', array(	array('name' => '���ݱ���', 'url' => 'admincp.php?action=export'),
						array('name' => '���ݻָ�', 'url' => 'admincp.php?action=import'),
						array('name' => '���ݿ�����', 'url' => 'admincp.php?action=runquery'),
						array('name' => '���ݱ��Ż�', 'url' => 'admincp.php?action=optimize')));
		showmenu('��̳ά��', array(	array('name' => '�����༭', 'url' => 'admincp.php?action=attachments'),
						array('name' => '����ɾ��', 'url' => 'admincp.php?action=prune'),
						array('name' => '����Ϣ����', 'url' => 'admincp.php?action=pmprune')));
		showmenu('ϵͳ����', array(	array('name' => '��̳֪ͨ', 'url' => 'admincp.php?action=newsletter'),
						array('name' => '���»���', 'url' => 'admincp.php?action=updatecache'),
						array('name' => '�ؽ�ͳ������', 'url' => 'admincp.php?action=counter')));
		showmenu('���м�¼', array(	array('name' => '��������¼', 'url' => 'admincp.php?action=illegallog'),
						array('name' => '�û����ּ�¼', 'url' => 'admincp.php?action=karmalog'),
						array('name' => '����������¼', 'url' => 'admincp.php?action=modslog'),
						array('name' => 'ϵͳ������¼', 'url' => 'admincp.php?action=cplog')));
		showmenu('�������', $pluginsarray);
		showmenu('�˳����', 'admincp.php?action=logout');

?>
</table></td></tr></table></td></tr></table>

</body>
</html>
<?

} else {

	session_set_cookie_params(0, $cookiepath, $cookiedomain);
	session_name('admin_sid');
	session_start();
	session_register('admin_user', 'admin_pw', 'errorlog');

	$HTTP_SESSION_VARS['admin_user'] = isset($HTTP_POST_VARS['adusername']) ? $HTTP_POST_VARS['adusername'] : $HTTP_SESSION_VARS['admin_user'];
	$HTTP_SESSION_VARS['admin_pw'] = isset($HTTP_POST_VARS['adpassword']) ? md5($HTTP_POST_VARS['adpassword']) : $HTTP_SESSION_VARS['admin_pw'];

	if(!$isadmin || $HTTP_SESSION_VARS['errorlog'] >= 2) {
		clearcookies();
		$discuz_user = $discuz_pw = '';
		$status = 'Guest';
		$groupid = 14;
		$styleid = $_DCACHE['settings']['styleid'];

		cpheader();
		cpmsg("ֻ�й���Ա���ܽ���ϵͳ���ã�");
	} elseif($HTTP_SESSION_VARS['admin_user'] != $discuz_user || $HTTP_SESSION_VARS['admin_pw'] != $discuz_pw) {
		if($HTTP_SESSION_VARS['admin_user']) {
			$HTTP_SESSION_VARS['errorlog']++;
		}
		$action = empty($action) ? 'main' : $action;
		cpheader();

?>
<br><br><br><br><br><br>
<form method="post" action="admincp.php?action=<?=$action?>&extr=<?=$extr?>">
<input type="hidden" name="adusername" value="<?=$discuz_user?>">
<table cellspacing="0" cellpadding="0" border="0" width="60%" align="center">
<tr><td bgcolor="<?=BORDERCOLOR?>">
<table border="0" cellspacing="<?=BORDERWIDTH?>" cellpadding="<?=TABLESPACE?>" width="100%">
<tr class="header"><td colspan="2">���������Ĺ���Ա����</td></tr>
<tr><td bgcolor="<?=ALTBG1?>" width="25%">�û���:</td><td bgcolor="<?=ALTBG2?>"><?=$discuz_user?> <a href="logging.php?action=logout&referer=index.php" target="_blank">[�˳���¼]</a></td></tr>
<tr><td bgcolor="<?=ALTBG1?>" width="25%">����:</td><td bgcolor="<?=ALTBG2?>"><input type="password" size="25" name="adpassword"></td></tr>
</td></tr></table></td></tr></table>
<br><center><input type="submit" value="�� &nbsp; ��"></center></form>
<br><br>
<?

		cpfooter();
		discuz_exit();

	}

}

	if ($action == 'main') {

		require $discuz_root.'./include/attachment.php';

		$serverinfo = PHP_OS.' / PHP v'.PHP_VERSION;
		$serverinfo .= @ini_get('safe_mode') ? ' ��ȫģʽ' : NULL;
		$dbversion = $db->result($db->query("SELECT VERSION()"), 0);

		if(@ini_get("file_uploads")) {
			$fileupload = "���� - �ļ� ".ini_get("upload_max_filesize")." - ������".ini_get("post_max_size");
		} else {
			$fileupload = "<font color=\"red\">��ֹ</font>";
		}

		$forumselect = $groupselect = '';
		$query = $db->query("SELECT groupid, grouptitle FROM $table_usergroups ORDER BY status, creditslower");
		while($group = $db->fetch_array($query)) {
			$groupselect .= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
		}
		$query = $db->query("SELECT fid, name FROM $table_forums WHERE type='forum' OR type='sub'");
		while($forum = $db->fetch_array($query)) {
			$forumselect .= "<option value=\"$forum[fid]\">$forum[name]</option>\n";
		}

		$dbsize = 0;
		$query = $db->query("SHOW TABLE STATUS LIKE '$tablepre%'", 1);
		while($table = $db->fetch_array($query)) {
			$dbsize += $table[Data_length] + $table[Index_length];
		}
		$dbsize = $dbsize ? sizecount($dbsize) : "δ֪";

		$attachsize = dirsize("./$attachdir");
		$attachsize = $attachsize ? sizecount($attachsize) : "δ֪";

		cpheader();

?>
<font class="mediumtxt">
<b>��ӭ���� <a href="http://www.Discuz.net" target="_blank">Discuz! <?=$version?></a> ϵͳ�������</b><br>
��Ȩ����&copy; <a href="http://www.comsenz.com" target="_blank">Comsenz Technology Ltd</a>, 2002-2004.

<br><br><br><table cellspacing="0" cellpadding="0" border="0" width="85%" align="center">
<tr><td bgcolor="<?=BORDERCOLOR?>">
<table border="0" cellspacing="<?=BORDERWIDTH?>" cellpadding="0" width="100%">
<tr><td>
<table border="0" cellspacing="0" cellpadding="<?=TABLESPACE?>" width="100%">
<tr class="header"><td colspan="3">�� �� �� ʽ</td></tr>

<form method="post" action="admincp.php?action=forumdetail"><tr bgcolor="<?=ALTBG2?>"><td>�༭��̳</td>
<td><select name="fid"><?=$forumselect?></select></td><td><input type="submit" value="�� ��"></td></tr></form>

<form method="post" action="admincp.php?action=usergroups&type=detail"><tr bgcolor="<?=ALTBG1?>"><td>�༭�û���Ȩ��</td>
<td><select name="id"><?=$groupselect?></td><td><input type="submit" value="�� ��"></td></tr></form>

<form method="post" action="admincp.php?action=members"><tr bgcolor="<?=ALTBG2?>"><td>�༭�û�</td>
<td><input type="text" size="25" name="username"></td><td><input type="submit" name="searchsubmit" value="�� ��"></td></tr></form>

<form method="post" action="admincp.php?action=export&type=mini&saveto=server"><tr bgcolor="<?=ALTBG1?>"><td>��С���ݵ�������</td>
<td><input type="text" size="25" name="filename" value="./forumdata/dz_<?=date("md")."_".random(5)?>.sql"></td><td><input type="submit" name="exportsubmit" value="�� ��"></td></tr></form>

</table></td></tr></table></td></tr></table><br><br>

<table cellspacing="0" cellpadding="0" border="0" width="85%" align="center">
<tr><td bgcolor="<?=BORDERCOLOR?>">
<table border="0" cellspacing="<?=BORDERWIDTH?>" cellpadding="0" width="100%">
<tr><td>
<table border="0" cellspacing="0" cellpadding="<?=TABLESPACE?>" width="100%">
<tr class="header"><td colspan="2">ϵ ͳ �� Ϣ</td></tr>
<tr bgcolor="<?=ALTBG2?>"><td width="50%">����������</td><td><?=$serverinfo?></td></tr>
<tr bgcolor="<?=ALTBG1?>"><td>MySQL �汾</td><td><?=$dbversion?></td></tr>
<tr bgcolor="<?=ALTBG2?>"><td>�����ϴ�����</td><td><?=$fileupload?></td></tr>
<tr bgcolor="<?=ALTBG1?>"><td>���ݿ�ռ��</td><td><?=$dbsize?></td></tr>
<tr bgcolor="<?=ALTBG2?>"><td>�����ļ�ռ��</td><td><?=$attachsize?></td></tr>
</table></td></tr></table></td></tr></table><br><br>

<table cellspacing="0" cellpadding="0" border="0" width="85%" align="center">
<tr><td bgcolor="<?=BORDERCOLOR?>">
<table border="0" cellspacing="<?=BORDERWIDTH?>" cellpadding="0" width="100%">
<tr><td>
<table border="0" cellspacing="0" cellpadding="<?=TABLESPACE?>" width="100%">
<tr class="header"><td colspan="2">�� �� �� ��</td></tr>
<tr bgcolor="<?=ALTBG2?>"><td width="50%">��Ȩ����</td><td><a href="http://www.comsenz.com" target="_blank">������ʢ���ͿƼ����޹�˾</a></td></tr>
<tr bgcolor="<?=ALTBG1?>"><td>��Ŀ����</td><td>Kevin (Crossday) Dell</td></tr>
<tr bgcolor="<?=ALTBG2?>"><td>�����Ŷ�</td><td>Crossday, cnteacher, pk0909, theoldmemory</td></tr>
<tr bgcolor="<?=ALTBG1?>"><td>�������</td><td>theoldmemory, ����, �ϱ��ư�, feixin, cnteacher, pk0909</td></tr>
<tr bgcolor="<?=ALTBG2?>"><td>�������</td><td>�Ϲ� (Discuz! 2.x)</td></tr>
<tr bgcolor="<?=ALTBG1?>"><td>����֧��</td><td>artery, Tyc, ��ʴ, �����Ϳ</td></tr>
<tr bgcolor="<?=ALTBG2?>"><td>�ٷ���̳</td><td><a href="http://www.discuz.net" target="_blank">http://www.Discuz.net</a></td></tr>
</table></td></tr></table></td></tr></table>
<?

	} elseif($action == 'settings') {
		require $discuz_root.'./admin/settings.php';
	} elseif($action == 'forumadd' || $action == 'forumsedit' || $action == 'forumsmerge' || $action == 'forumdetail' || $action == 'forumdelete') {
		require $discuz_root.'./admin/forums.php';
	} elseif($action == 'addmember' || $action == 'members' || $action == 'memberprofile' || $action == 'usergroups' || $action == 'ipban') {
		require $discuz_root.'./admin/members.php';
	} elseif($action == 'announcements') {
		require $discuz_root.'./admin/announcements.php';
	} elseif($action == 'styles') {
		require $discuz_root.'./admin/styles.php';
	} elseif($action == 'templates' || $action == 'tpladd' || $action == 'tpledit') {
		require $discuz_root.'./admin/templates.php';
	} elseif($action == 'forumlinks' || $action == 'censor' || $action == 'smilies' || $action == 'updatecache' || $action == 'logout') {
		require $discuz_root.'./admin/misc.php';
	} elseif($action == 'export' || $action == 'import' || $action == 'runquery' || $action == 'optimize') {
		require $discuz_root.'./admin/database.php';
	} elseif($action == 'attachments') {
		require $discuz_root.'./admin/attachments.php';
	} elseif($action == 'counter') {
		require $discuz_root.'./admin/counter.php';
	} elseif($action == 'prune' || $action == 'pmprune') {
		require $discuz_root.'./admin/prune.php';
	} elseif($action == 'newsletter') {
		require $discuz_root.'./admin/newsletter.php';
	} elseif($action == 'illegallog' || $action == 'karmalog' || $action == 'modslog' || $action == 'cplog') {
		require $discuz_root.'./admin/logs.php';
	}

	if($action != 'menu' && $action != 'header') {
		cpfooter();
	}


discuz_output();

?>