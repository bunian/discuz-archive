<?php

// Message Pack for Discuz! Version 1.0.0
// Translated by Crossday & cknuke

$credittitle = 'credit';
$creditunit = '';

$language = array
(
	'undefined_action' => 'Undefined action.',
	'group_nopermission' => 'Sorry, your usergroup($grouptitle) does not have permission to access this page.',
	'not_loggedin' => 'Sorry, You are not logged in and do not have permission to access this page.',
	'board_closed' => 'Sorry, this bulletin board is temporality closed, please <a href=\"mailto:$adminemail\">contact the administrator</a>.',

	'login_invalid' => 'Invalid username or password, now will forward you to main index as a guest.',
	'login_succeed' => 'Thank you for logging in, $discuz_userss. Now will forward you to where you were.',
	'logout_succeed' => 'You are logged out, now will forward you to where you were.',

	'user_banned' => 'You are BANNED in this forum.',

	'forum_nonexistence' => 'Specified forum does not exist.',
	'forum_passwd_wrong' => 'Invaild password and have no permission to access this forum.',
	'forum_nopermission' => 'Sorry, only specified users have permission to access this forum.',

	'thread_nonexistence' => 'Specified thread does not exist or has been deleted.',
	'thread_nopermission' => 'Sorry, this thread requires your $credittitle at least $thread[creditsrequire] $creditunit.',
	'thread_poll_closed' => 'Specified poll has been closed and you are not able to vote in.',
	'thread_poll_voted' => 'You have already voted on this poll, please return.',
	'thread_poll_invalid' => 'You submitted an invalid vote, please return to correct this problem.',
	'thread_poll_succeed' => 'Your vote on this thread has been added, now will forward you to the thread.',
	'thread_karma_range_invalid' => 'Your vote must be ranged from $minkarmarate to $maxkarmarate, please return.',
	'thread_karma_member_invalid' => 'You can not vote for yourself, please return.',
	'thread_karma_ctrl' => 'Sorry, your could not vote out of $maxrateperday $creditunit in 24 hours, please return.',
	'thread_karma_duplicate' => 'You could not vote for the same post again, please return',
	'thread_karma_succeed' => 'Thanks for your $score $creditunit votes for $username. Now will forward you to the thread.',
	'thread_report_disable' => 'Reporting post has been disabled by the administrator, please return.',
	'thread_report_succeed' => 'Thank you for reporting this post, it will be dealt with as appropriate in due course, now will forward you back to the thread.',

	'attachment_nopermission' => 'Sorry, this attachment requires your $credittitle at least $attach[creditsrequire] $creditunit, please return.',
	'attachment_forum_nopermission' => 'Sorry, only specified users have access to download attachments from this forum, please return.',
	'attachment_nonexistence' => 'Attachment file not found, please contact the administrator.',

	'post_hide_nopermission' => 'Sorry, only moderators have access to posting with [hide], please return to correct this problem.',
	'post_forum_nopermission' => 'Sorry, only specified users have access to post in this forum, please return.',
	'post_thread_closed' => 'Sorry,  the thread is closed and do not accept new posts, please return.',
	'post_subject_toolang' => 'Sorry, your subject is more than 100 bytes, please return to correct this problem.',
	'post_message_toolang' => 'Sorry, your message is more than $maxpostsize bytes, please return to correct this problem.',
	'post_sm_isnull' => 'Sorry, you didn\'t enter the subject or message, please return to correct this problem.',
	'post_flood_ctrl' => 'Sorry, you could only post one message every $floodctrl seconds, please do not flooding!',
	'post_poll_option_toomany' => 'Your poll options are more than 10, please return to correct this problem.',
	'post_edit_nopermission' => 'You do not have permission to edit or delete this post.',
	'post_edit_delete_succeed' => 'The topic has been deleted successfully, now will forward you to the forum.',
	'post_attachment_toobig' => 'The file that you have tried to attach is too big, please return.',
	'post_attachment_ext_notallowed' => 'You have attempted to upload an invalid type of attachment, please return.',
	'post_attachment_save_error' => 'There has been an error with your attempt to upload the file. Please try again, and if the error continues, please contact the administrator',
	'post_edit_succeed' => 'The post has been successfully edited, now will forward you to the thread.',
	'post_reply_succeed' => 'Thank you for your posting, now will forward you to the thread.',
	'post_newthread_succeed' => 'Thank you for your posting, now will forward you to the thread.',

	'register_disable' => 'Sorry, registering is disabled by the administrator, please return.',
	'register_succeed' => 'Thank you for registering, now will forward you to where you were.',

	'profile_username_toolang' => 'Sorry, your username could not be greater than 15 charactors, please return to correct this problem.',
	'profile_passwd_notmatch' => 'The two passwords that you typed do not match, please return to correct this problem.',
	'profile_passwd_wrong' => 'The old pssword is incorrect, you can not modify it!',
	'profile_account_duplicate' => 'Sorry, your username is already in use, please return.',
	'profile_email_duplicate' => 'Sorry, your email is already in use, please return.',
	'profile_username_illegal' => 'Your username is illegal or not allowed to use, please return.',
	'profile_passwd_illegal' => 'Your password is illegal, please return.',
	'profile_email_illegal' => 'Your email is illegal, please return.',
	'profile_sig_toolang' => 'Your signature is more than $maxsigsize bytes, please return.',
	'profile_avatar_toobig' => 'Your specified avatar must be smaller than $maxavatarsize*$maxavatarsize pixels, please return.',
	'profile_avatardir_nonexistence' => 'The avatars\' directory ./images/avatars not found, please contact the administrator.',
	'profile_avatar_succeed' => 'Your avatar has been updated, now will forward you to profile index.',
	'profile_email_identify' => 'Thank you for registering, an email has been dispatched with account information of yours.',
	'profile_succeed' => 'Your profile has been updated, now will forward you to Member\'s CP Home.',

	'buddy_add_invalid' => '$buddy has already been in your buddies list, please return.',
	'buddy_add_nonexistence' => 'User $buddy does not exist, please return to correct this problem.',
	'buddy_add_succeed' => 'Your buddylist has been updated, now will forward you to Member\'s CP Home.',
	'buddy_delete_succeed' => 'Your buddylist has been updated, now will forward you to Member\'s CP Home.',

	'redirect_nextnewset_nonexistence' => 'There are no threads newer than the previous one, please return.',
	'redirect_nextoldset_nonexistence' => 'There are no threads older than the previous one, please return.',

	'favorite_exists' => 'The thread is already in your favorites, please return.',
	'favorite_add_succeed' => 'The favorites have been updated, now will forward you to where you were.',
	'favorite_update_succeed' => 'The favorite has been updated, now will forward you to where you were.',
	'subscription_exists' => 'The thread has already been subscribed, please return.',
	'subscription_add_succeed' => 'The selected topic has been subscibed, now will forward you to where you were.',
	'subscription_update_succeed' => 'The subsciption has been updated, now will forward you to where you were.',

	'search_ctrl' => 'Sorry, you could only search once every $searchctrl seconts, please return.',
	'search_invalid' => 'You did not entered the keyword or username to search on, please return.',
	'search_forum_invalid' => 'You did not specify forums to search in, please return.',

	'member_nonexistence' => 'Invaild member specified, please return.',
	'member_list_disable' => 'Sorry, the members list is disabled by the administrator.',
	'email_friend_invalid' => 'You did not fill all required fields, please return to correct the problem.',
	'email_friend_succeed' => 'An email has been dispatched, now will forward you to the thread.',
	'announcement_nonexistence' => 'There is no announcement available, please return.',
	'mark_read_succeed' => 'All forums have been marked as read, now will forward you to where you were.',

	'getpasswd_account_notmatch' => 'The username and email you entered did not match, please return.',
	'getpasswd_id_illegal' => 'Your ID does not exist or was generated more than 10 days ago.',
	'getpasswd_send_succeed' => 'The link for getting password has been dispatched to your email.',
	'getpasswd_succeed' => 'Your new password is $newpasswd1, please note down.',

	'pm_box_isfull' => 'Your P.M. boxes is full, and you could not read messages until it is cleaned out.',
	'pm_nonexistence' => 'Specified P.M. does not exist or has been deleted.',
	'pm_send_nonexistence' => 'Invalid recipient username, please return.',
	'pm_send_invalid' => 'You did not entered subject or message, please return.',
	'pm_send_toomany' => 'The number of recipients is more than $maxpmsend, please return.',
	'pm_send_ignore' => '$member[username] refused to receive messages from you, please return.',
	'pm_send_succeed' => 'The message has been processed, now will forward you to message list.',
	'pm_delete_succeed' => 'The specified message(s) have been deleted, now will forward you to message list.',
	'pm_ignore_succeed' => 'Your ignore list has been updated, now will forward you to message lsit.',

	'admin_nopermission' => 'Sorry, you do not have permission to administer this forum.',
	'admin_delthread_invalid' => 'You did not specify the threads to delete, please return.',
	'admin_delpost_invalid' => 'You did not specify the posts to delete, please return.',
	'admin_move_invalid' => 'You did not specified the forum to move to, please return to correct the problem.',
	'admin_split_invalid' => 'This specified thread do not contain replies to split, please return.',
	'admin_split_subject_invalid' => 'The subject you entered is invaild, please return to correct the problem.',
	'admin_split_new_invalid' => 'You did not specify the posts to split to new thread, please return to correct the problem.',
	'admin_succeed' => 'Your action has been executed, now will forward you to the forum.'

);

?>