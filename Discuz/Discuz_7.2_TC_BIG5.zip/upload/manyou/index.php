<?php

/*
	[Discuz!] (C)2001-2009 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: index.php 18643 2009-07-08 02:32:07Z monkey $
*/

header('location: ../userapp.php');

?>