<?php

/*
	[DISCUZ!] wap/include/myphone.inc.php - wap info
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005-2-28 10:15
*/

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

$discuz_action = 194;

echo "<p>$lang[myphone]<br />$_SERVER[HTTP_USER_AGENT]<br /><br />";
if(function_exists('getallheaders')) {
	foreach(getallheaders() as $key => $value) {
		echo strtoupper($key).": $value<br/>\n";
	}
} else {
	foreach(array('REMOTE_ADDR', 'REMOTE_PORT', 'REMOTE_USER', 'GATEWAY_INTERFACE', 'SERVER_PROTOCOL', 'HTTP_CONNECTION', 'HTTP_VIA') as $key) {
		if(!empty($_SERVER[$key])) {
			echo "<br />$key: $_SERVER[$key]\n";
		}
	}
}
echo '</p>';

?>