<?php

/*
	[DISCUZ!] wap/index.php - WAP Version of Crossday Discuz! Board
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005-2-28 10:15
*/

define('CURSCRIPT', 'wap');
require_once '../include/common.inc.php';
require_once './include/global.func.php';
require_once DISCUZ_ROOT.'./forumdata/cache/cache_forums.php';

$discuz_action = 191;

if($charset != 'utf-8') {
	require_once './include/chinese.class.php';
}

$action = isset($action) ? $action : 'home';
if($action == 'goto' && !empty($url)) {
	header("Location: $url");
} else {
	wapheader($bbname);
}

include language('wap');

if(!$wapstatus) {
	wapmsg('wap_disabled');
} elseif($bbclosed) {
	wapmsg('board_closed');
}

if($_POST && $charset != 'utf-8') {
	$chs = new Chinese('UTF8', $charset);
	foreach($_POST as $key => $value) {
		$$key = $chs->Convert($value);
	}
	unset($chs);
}

if(in_array($action, array('home', 'login', 'stats', 'myphone', 'goto', 'forum', 'thread', 'post', 'pm'))) {
	require_once './include/'.$action.'.inc.php';
} else {
	wapmsg('undefined_action');
}

wapfooter();

?>
