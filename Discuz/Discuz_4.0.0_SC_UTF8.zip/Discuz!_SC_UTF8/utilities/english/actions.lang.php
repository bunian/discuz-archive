﻿<?php

// Action Pack for Discuz! Version 1.0.0
// Translated by Crossday

$actioncode = array
(
	0 => 'Back to board',

	1 => 'Home',
	2 => 'View Forums',
	3 => 'View Thread',
	5 => 'Register',
	6 => 'Log in',
	7 => 'Member CP',

	11 => 'Post New Thread',
	12 => 'Post Reply',
	13 => 'Edit Post',
	14 => 'Download Attchment',

	21 => 'View Announcements',

	31 => 'View Online List',

	41 => 'View Members List',

	51 => 'View FAQ',

	61 => 'View Member Profile',

	71 => 'Rate',
	72 => 'View Rating Log',

	81 => 'Pay for Thread',
	82 => 'View Payment Log',

	101 => 'Private Messages',

	111 => 'Board Search',

	121 => 'Email to Friend',
	122 => 'Report Post',
	123 => 'Add/Remove Blog',

	131 => 'View Statistics',

	141 => 'Get Password',

	151 => 'Blog',

	191 => 'WAP - Home',
	192 => 'WAP - View Forums',
	193 => 'WAP - View Thread',
	194 => 'WAP - Tools',
	195 => 'WAP - Post New Thread',
	196 => 'WAP - Post Reply',
	197 => 'WAP - Private Messages',

	201 => 'Moderate',

	211 => 'Admin CP',

	254 => 'Access Denied',

	255 => 'Message/Forwarding'
);

?>