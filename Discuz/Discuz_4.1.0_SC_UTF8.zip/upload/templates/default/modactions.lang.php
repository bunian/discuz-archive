﻿<?php

// Moderation Pack for Discuz! Version 1.0.0
// Created by Crossday

$modactioncode = array
(

	'EDT' => '编辑',

	'DEL' => '删除',
	'DLP' => '删除回复',
	'PRN' => '批量删帖',
	'UDL' => '反删除',

	'DIG' => '加入精华',
	'UDG' => '解除精华',
	'EDI' => '限时精华',
	'UED' => '解除限时精华',

	'CLS' => '关闭',
	'OPN' => '打开',
	'ECL' => '限时关闭',
	'UEC' => '解除限时关闭',
	'EOP' => '限时打开',
	'UEO' => '解除限时打开',

	'STK' => '置顶',
	'UST' => '解除置顶',
	'EST' => '限时置顶',
	'UES' => '解除限时置顶',

	'SPL' => '分割',
	'MRG' => '合并',

	'HLT' => '设置高亮',
	'UHL' => '解除高亮',
	'EHL' => '限时高亮',
	'UEH' => '解除限时高亮',

	'BMP' => '提升',

	'MOV' => '移动',
	'TYP' => '分类',

	'RFD' => '强制退款',

	'MOD' => '审核通过',

	'ABL' => '加入 Blog',
	'RBL' => '移除 Blog'

);

?>