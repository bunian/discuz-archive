<?php

/*
	[DISCUZ!] utilities/thumbattach.php
	This is NOT a freeware, use is subject to license terms

	Last Modified: 2006-12-28 15:05
*/

require_once './include/common.inc.php';
require_once DISCUZ_ROOT.'./include/ftp.func.php';

//$db->query("ALTER TABLE cdb_attachments ADD `width` SMALLINT(6) UNSIGNED NOT NULL DEFAULT '0'");

@set_time_limit(0);

$act = isset($_GET['act']) && $_GET['act'] == 'getwidth' ? 'getwidth' : 'ready';

$query = $db->query("SELECT COUNT(*) FROM {$tablepre}attachments WHERE isimage IN ('1', '-1') AND width='0'");
$num = $db->result($query, 0);
if(empty($num)) {
	echo '������ɣ���ɾ���ĳ����ļ�';exit;
}

$total = isset($_GET['total']) ? intval($_GET['total']) : $num;
$start = isset($_GET['start']) ? intval($_GET['start']) : 0;
$repeat = isset($_GET['repeat']) ? intval($_GET['repeat']) : 0;
$limit = 100;

if($act == 'ready') {
	echo $num.'��ͼƬ������Ҫ����<br /><a href="?act=getwidth">�����ʼ</a>';exit;
} else {
	$ftp = unserialize($db->result_first("SELECT value FROM {$tablepre}settings WHERE variable='ftp'"));
	$attachdir = $db->result_first("SELECT value FROM {$tablepre}settings WHERE variable='attachdir'");
	$attachurl = $db->result_first("SELECT value FROM {$tablepre}settings WHERE variable='attachurl'");
	$query = $db->query("SELECT attachment,aid,remote FROM {$tablepre}attachments WHERE isimage IN ('1', '-1') AND width='0' ORDER BY dateline DESC LIMIT $start, $limit");
	$count = 0;
	if($db->num_rows($query)) {
		while($attachments = $db->fetch_array($query)) {
			$img_w = 0;
			if($attachments['remote'] || $ftp['attachurl'] == $attachurl) {
				if($ftp['connid'] || ($ftp['connid'] = dftp_connect($ftp['host'], $ftp['username'], authcode($ftp['password'], 'DECODE', md5($authkey)), $ftp['attachdir'], $ftp['port'], $ftp['ssl']))) {
					$local_file = DISCUZ_ROOT.'./forumdata/tmp_batimgwidth';
					if(dftp_get($ftp['connid'], $local_file, $attachments['attachment'], FTP_BINARY)) {
						$attachinfo	= getimagesize($local_file);
						$img_w		= $attachinfo[0];
						@unlink($local_file);
					} else {
						$target = $ftp['attachurl'].'/'.$attachments['attachment'];
						$attachinfo	= getimagesize($target);
						$img_w		= $attachinfo[0];
					}
				} else {
					$target = $ftp['attachurl'].'/'.$attachments['attachment'];
					$attachinfo	= getimagesize($target);
					$img_w		= $attachinfo[0];
				}
			} else {
				$target		= $attachdir.'/'.$attachments['attachment'];
				$attachinfo	= getimagesize($target);
				$img_w		= $attachinfo[0];
			}
			if($img_w) {
				$db->query("UPDATE {$tablepre}attachments SET width='$img_w' WHERE aid='$attachments[aid]'", 'UNBUFFERED');
				$count++;
			} else {
				writelog('imgwidthlog', implode("\t", $attachments));
			}
		}
	} else {
		$repeat++;
		$yearmonth = gmdate('Ym', $timestamp + $_DCACHE['settings']['timeoffset'] * 3600);
		$logdir = DISCUZ_ROOT.'./forumdata/logs/';
		$logfile = $logdir.$yearmonth.'_imgwidthlog.php';
		if($repeat > 5) {
			echo "������ɣ���ɾ���ĳ����ļ�<br />�����¼��鿴 $logfile �ļ�";exit;
		}
		if(file_exists($logfile)) @unlink($logfile);
		redirect("������ϣ��ٴ����󣬽��ղ���©�Ĵ�����", "batimgwidth.php?act=getwidth&repeat=$repeat");
	}
}
$end = $start + $limit;
redirect("�˴γɹ����� $count ��ͼƬ��ͼƬ�����Ѵ��� $start / $total ...", "batimgwidth.php?act=getwidth&start=$end&total=$total&repeat=$repeat");

function redirect($message, $url_forward) {
echo <<<EOD
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>$message</title>
<script type="text/javascript">
	function redirect(url) {
		window.location=url;
	}	
</script>
</head>
<body>
EOD;
	$message .= "<br /><br /><br /><a href=\"$url_forward\">��������Զ���תҳ�棬�����˹���Ԥ�����ǵ������������ʱ��û���Զ���תʱ����������</a>";
	$message .= "<script>setTimeout(\"redirect('$url_forward');\", 1250);</script></body></html>";
	die($message);
}

?>