||==========================||
||   Discuz! 工具文件说明   ||
||==========================||

+----------------------------------------------------------+
 标准版本升级程序
+----------------------------------------------------------+

upgrade1.php		CDB 3.0RC1 to Discuz! 1.0
upgrade2.php		Discuz! 1.0 到 Discuz! 2.0 升级程序
upgrade3.php		Discuz! 2.0 到 Discuz! 3.0 升级程序
upgrade4.php		Discuz! 3.0 到 Discuz! 3.1 升级程序
upgrade5.php		Discuz! 3.1.2 到 Discuz! 4.0.0 升级程序
upgrade6.php		Discuz! 4.0.0 到 Discuz! 4.1.0 升级程序
upgrade7.php		Discuz! 4.1.0 到 Discuz! 5.0.0 升级程序
upgrade8.php		Discuz! 5.0.0 到 Discuz! 5.5.0 升级程序
upgrade9.php		Discuz! 5.5.0 到 Discuz! 6.0.0 升级程序
upgrade10.php		Discuz! 6.0.0 到 Discuz! 6.1.0 升级程序
upgrade11.php		Discuz! 6.1.0 到 Discuz! 7.0.0 升级程序

+----------------------------------------------------------+
 其他版本升级程序
+----------------------------------------------------------+

d3ftod4.php		Discuz! 3.0F 到 Discuz!4.0 升级程序
rc3torc4.php		Discuz! 4.0RC3 到 Discuz! 4.0RC4 升级程序
rc4torcfinal.php	Discuz! 4.0RC4 到 Discuz! 4.0RCfinal 升级程序
d5rc1torc2.php		Discuz! 5.0RC1 到 Discuz! 5.0RC2 升级程序
d6rc1tofinal.php	Discuz! 6.0RC1 到 Discuz! 6.0.0 升级程序
d60to70.php			Discuz! 6.0.0  到 Discuz! 7.0.0 升级程序

+----------------------------------------------------------+
 相关工具程序
+----------------------------------------------------------+

myconvert.php		Discuz! 4.1.0 -> Discuz! 5.0 “我的”功能转换程序
thumbattach.php		Discuz! 5.0.0 -> Discuz! 5.5.0 旧附件图片缩略图生成程序
tools.php			Discuz!工具箱程序,检查或修复数据库/导入数据库备份/恢复论坛管理员帐号/测试邮件发送方式/数据库冗余数据清理 
checks.php			搜索未知文件