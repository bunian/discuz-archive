<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: forum.inc.php,v $
	$Revision: 1.6 $
	$Date: 2006/06/06 01:46:53 $
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$query = $db->query("SELECT * FROM {$tablepre}forums f
	LEFT JOIN {$tablepre}forumfields ff USING (fid)
	WHERE f.fid='$fid' AND f.status='1' AND f.type<>'group' AND ff.password=''");

$forum = $db->fetch_array($query);

if($forum['redirect']) {
	header("Location: $forum[redirect]");
	exit();
}

$page = empty($page) ? 1 : $page;

$navtitle = ($forum['type'] == 'sub' ? ' - '.strip_tags($_DCACHE['forums'][$forum['fup']]['name']) : '').
	strip_tags($forum['name']).'('.$lang['page'].' '.$page.') - ';

require_once './include/header.inc.php';

?>
<div class="subtable bold altbg1">
<?

if(!$forum || !forumperm($forum['viewperm'])) {

?>
<a href="archiver/"><?=$_DCACHE['settings']['bbname']?></a></div><br>
<div class="simpletable smalltxt" style="width: <?=TABLEWIDTH?>"><div class="subtable altbg2"><br><?=$lang['forum_nonexistence']?><br><br></div></div>
<?

} else {

	$navsub = $forum['type'] == 'sub' ? "<a href=\"archiver/{$qm}fid-$forum[fup].html\">{$_DCACHE[forums][$forum[fup]][name]}</a> <b>&raquo;</b>": ' ';
	$fullversion = array('title' => $forum['name'], 'link' => "forumdisplay.php?fid=$fid");

	$tpp = $_DCACHE['settings']['topicperpage'] * 2;
	$start = ($page - 1) * $tpp;

?>
<a href="archiver/"><?=$_DCACHE['settings']['bbname']?></a> <b>&raquo;</b><?=$navsub?><a href="archiver/<?=$qm?>fid-<?=$fid?>.html"><?=$forum['name']?></a></div><br>
<div class="simpletable" style="width: <?=TABLEWIDTH?>"><div class="subtable altbg2">
<?

	echo "<ul type=\"1\" start=\"".($start + 1)."\">\n";

	$query = $db->query("SELECT * FROM {$tablepre}threads WHERE fid='$fid' AND displayorder>='0' ORDER BY displayorder DESC, lastpost DESC LIMIT $start, $tpp");
	while($thread = $db->fetch_array($query)) {
		echo "<li><a href=\"archiver/{$qm}tid-$thread[tid].html\">$thread[subject]</a> <i>($thread[replies] $lang[replies])</i></li>\n";
	}

	echo "</ul><br></div></div><br>\n";
	echo multi($forum['threads'], $page, $tpp, "{$qm}fid-$fid");

}

?>
