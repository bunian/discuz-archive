<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: ajax.php,v $
	$Revision: 1.20 $
	$Date: 2006/08/10 10:23:30 $
*/

require_once './include/common.inc.php';

if(in_array($action, array('checkseccode', 'checkusername', 'checkemail')) && submitcheck('checksubmit')) {

	if(!$headercharset) {
		@header('Content-Type: text/html; charset='.$charset);
	}

	@include_once language('messages');

	if($action == 'checkseccode') {

		if(intval($seccodeverify) != intval($seccode)) {
			ajaxmessage('checkseccode', $language['submit_seccode_invalid']);
		} else {
			ajaxmessage('checkseccode', 'succeed', 1);
		}

	} elseif($action == 'checkusername') {

		$username = trim($username);

		$guestexp = '\xA1\xA1|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
		$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($censoruser = trim($censoruser)), '/')).')$/i';
		if(preg_match("/^\s*$|^c:\\con\\con$|[%,\*\"\s\t\<\>\&]|$guestexp/is", $username) || ($censoruser && @preg_match($censorexp, $username))) {
			ajaxmessage('checkusername', $language['profile_username_illegal']);
		}

		$query = $db->query("SELECT uid FROM {$tablepre}members WHERE username='$username'");
		$username = dhtmlspecialchars(stripslashes($username));

		if($db->num_rows($query)) {
			eval("\$ajaxmessage = \"".$language['register_check_found']."\";");
			ajaxmessage('checkusername', $ajaxmessage);
		} else {
			ajaxmessage('checkusername', 'succeed', 1);
		}

	} elseif($action == 'checkemail' && !$doublee) {

		$email = trim($email);

		$query = $db->query("SELECT uid FROM {$tablepre}members WHERE email='$email' LIMIT 1");
		if($db->num_rows($query)) {
			ajaxmessage('checkemail', $language['profile_email_duplicate']);
		} else {
			ajaxmessage('checkemail', 'succeed', 1);
		}
	}
}

function ajaxmessage($objname, $message, $succeed = '0') {
	echo "<script language=\"JavaScript\">parent.ajaxresponse('$objname', \"".str_replace('"', '\"', $message)."\", $succeed);</script>";
	exit;
}

?>