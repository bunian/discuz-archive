<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: cleanup_monthly.inc.php,v $
	$Revision: 1.7.2.1 $
	$Date: 2006/09/01 06:15:01 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$myrecordtimes = $_DCACHE['settings']['myrecorddays'] * 86400;
$db->query("DELETE FROM {$tablepre}mythreads WHERE dateline<'$timestamp'-'$myrecordtimes'", 'UNBUFFERED');
$db->query("DELETE FROM {$tablepre}myposts WHERE dateline<'$timestamp'-'$myrecordtimes'", 'UNBUFFERED');
$db->query("DELETE FROM {$tablepre}tradelog WHERE orderid<='".date('Ymd', $timestamp-5*86400)."'", 'UNBUFFERED');

$db->query("TRUNCATE {$tablepre}relatedthreads");

?>