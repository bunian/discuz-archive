<?php

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: cleanup_daily.inc.php,v $
	$Revision: 1.14.6.1 $
	$Date: 2006/09/01 06:15:01 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$db->query("UPDATE {$tablepre}advertisements SET available='0' WHERE endtime>'0' AND endtime<='$timestamp'", 'UNBUFFERED');
$db->query("TRUNCATE {$tablepre}searchindex");
$db->query("DELETE FROM {$tablepre}threadsmod WHERE dateline<'$timestamp'-31536000", 'UNBUFFERED');
$db->query("DELETE FROM {$tablepre}subscriptions WHERE lastpost<'$timestamp'-7776000", 'UNBUFFERED');

if($qihoo_status && $qihoo_relatedthreads) {
	$db->query("DELETE FROM {$tablepre}relatedthreads WHERE expiration<'$timestamp'", 'UNBUFFERED');
}

$db->query("UPDATE {$tablepre}trades SET closed='1' WHERE expiration<>0 AND expiration<'$timestamp'", 'UNBUFFERED');

if($usethreadcaches) {
	$threadcachesdir = DISCUZ_ROOT.'./forumdata/threadcaches/';
	$dir = dir($threadcachesdir);
	while($entry = $dir->read()) {
		if(is_dir($entry) && $entry != '.' && $entry != '..') {
			if($handle = opendir($threadcachesdir.$entry)) {
				while(false !== ($file = readdir($handle))) {
					if($file != "." && $file != ".." && $file != 'index.htm') {
						@unlink($threadcachesdir.$entry.'/'.$file);
					}
				}
				closedir($handle);
			}
		}
	}
}

?>