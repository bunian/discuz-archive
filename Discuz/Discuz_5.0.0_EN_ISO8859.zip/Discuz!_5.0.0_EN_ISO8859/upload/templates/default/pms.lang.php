<?php

// P.M. Pack for Discuz! Version 1.0
// Translated by Crossday

// ATTENTION: Please add slashes(\) before (') and (")

$language = array 
(

  'reason_moderate_subject' => '[Discuz!] Your post has been administered.',
  'reason_moderate_message' => 'This message is sent automatically by the forum.

[b]The following posts were administered by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] with "{$modaction}" action.[/b]

[b]Subject:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]Date:[/b] {$thread[dateline]}
[b]Board:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]Reason:[/b] {$reason}

If you have any objection to this action,please contact me.',
  'reason_merge_subject' => '[Discuz!] Your post has been merged.',
  'reason_merge_message' => 'This message is sent automatically by the forum.

[b]The following posts were administered by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] with "{$modaction}" action.[/b]

[b]Subject:[/b] {$thread[subject]}
[b]Date:[/b] {$thread[dateline]}
[b]Borad:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]Merged Post:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$other[subject]}[/url]

[b]Reason:[/b] {$reason}

If you have any objection to this action,please contact me.',
  'reason_delete_post_subject' => '[Discuz!] Your reply has been deleted.',
  'reason_delete_post_message' => 'This message is sent automatically by the forum.

[b]The following posts were administered by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] with "Delete" action.[/b]
[quote]{$post[message]}[/quote]

[b]Date:[/b] {$post[dateline]}
[b]Board:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]Reason:[/b] {$reason}

If you have any objection to this action,please contact me.',
  'reason_move_subject' => '[Discuz!] Your post has been moved.',
  'reason_move_message' => 'This message is sent automatically by the forum.

[b]The following posts were administered by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] with "Move" action.[/b]

[b]Subject:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]Date:[/b] {$thread[dateline]}
[b]Original Board:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]
[b]Target Board:[/b] [url={$boardurl}forumdisplay.php?fid={$toforum[fid]}]{$toforum[name]}[/url]

[b]Reason:[/b] {$reason}

If you have any objection to this action,please contact me.',
  'rate_reason_subject' => '[Discuz!] Your reply has been rated.',
  'rate_reason_message' => 'This message is sent automatically by the forum.

[b]The following posts were rated by [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url].[/b]
[quote]{$post[message]}[/quote]

[b]Date:[/b] {$post[dateline]}
[b]Board:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]
[b]Thread:[/b] [url={$boardurl}viewthread.php?tid={$tid}&page={$page}#pid{$pid}]{$thread[subject]}[/url]

[b]Score:[/b] {$ratescore}
[b]Reason:[/b] {$reason}',
  'transfer_subject' => '[Discuz!] Credits Transfered.',
  'transfer_message' => 'This message is sent automatically by the forum.

[b]From:[/b] [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url]
[b]Date:[/b] {$transfertime}
[b]Credits:[/b] {$extcredits[$creditstrans][title]} {$amount} {$extcredits[$creditstrans][unit]}
[b]Amount:[/b] {$extcredits[$creditstrans][title]} {$netamount} {$extcredits[$creditstrans][unit]}

[b]Message:[/b] {$transfermessage}

Please view [url={$boardurl}memcp.php?action=credits&operation=creditslog]Here[/url] to check logs.',
  'reportpost_subject' => '[Discuz!] $discuz_user asked you to audit a post',
  'reportpost_message' => '[i]{$discuz_user}[/i] asked you to audit the following post,click following url to view the post:
[url]{$posturl}[/url]

His/Her Reason: {$reason}',
  'addfunds_subject' => '[Discuz!] Recharging Request Successfully Finsished.',
  'addfunds_message' => 'This message is sent automatically by the forum.

[b]Recharging request by you has been approved,credits have benn transfered to you account.[/b]

[b]Order No.:[/b] {$order[orderid]}
[b]Submit Date:[/b] {$submitdate}
[b]Confirm Date:[/b] {$confirmdate}

[b]Outgoing:[/b] ${$order[price]} 
[b]Incoming:[/b] {$extcredits[$creditstrans][title]} {$order[amount]} {$extcredits[$creditstrans][unit]}

Please view [url={$boardurl}memcp.php?action=credits&operation=creditslog]here[/url] to check logs.',
  'trade_seller_send_subject' => '[Discuz!] Goods Selled',
  'trade_seller_send_message' => 'This message is sent automatically by the forum.

"{$user}" has purchased your good "{$itemsubject}".

The buyer has already payed, waitting for your shipment.
Please click [url={$boardurl}trade.php?orderid={$orderid}]Here[/url] to view details.',
  'trade_buyer_confirm_subject' => '[Discuz!] Goods have been shiped.',
  'trade_buyer_confirm_message' => 'This message is sent automatically by the forum.

You have purchased "{$itemsubject}".

The seller "{$user}" has shiped the goods,waitting for your confirmation.
Please click [url={$boardurl}trade.php?orderid={$orderid}]Here[/url] to view details.',
  'trade_fefund_success_subject' => '[Discuz!] Refund Request Successed',
  'trade_fefund_success_message' => 'This message is sent automatically by the forum.

The good "{$itemsubject}" you purchased from {$user}.

Money refunding has been approved.

Please click [url={$boardurl}trade.php?orderid={$orderid}]Here[/url] to view details.',
  'trade_success_subject' => '[Discuz!] Trade Completed',
  'trade_success_message' => 'This message is sent automatically by the forum.

The buyer "{$user}" has confirmed the "{$itemsubject}".

Trade have been finished.
Please click [url={$boardurl}trade.php?orderid={$orderid}]Here[/url] to view details.',
  'activity_apply_subject' => '[Discuz!] Application Approved',
  'activity_apply_message' => 'This message is sent automatically by the forum.

The originator of "[b]{$activity_subject}[/b]" have approved your application.
Please click [url={$boardurl}viewthread.php?tid={$tid}]here[/url] to view details.',
  'reward_question_subject' => '[Discuz!] Your reward have received an "The Best Answer"',
  'reward_question_message' => 'This message is sent automatically by the forum.

[b]"[url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url]" set an "The Best Answer" to your reward thread.[/b]

[b]Reward Thread:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]Date:[/b] {$thread[dateline]}
[b]Board:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forum[name]}[/url]

If you have any objection to this action,please contact the author.',
  'reward_bestanswer_subject' => '[Discuz!] Your reply was choosed as "The Best Answer"',
  'reward_bestanswer_message' => 'This message is sent automatically by the forum.

[b]"[url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url]" choosed your reply as "The Best Answer".[/b]

[b]Reward Thread:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]Date:[/b] {$thread[dateline]}
[b]Board:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forum[name]}[/url]

If you have any objection to this action,please contact the author.',
);

?>
