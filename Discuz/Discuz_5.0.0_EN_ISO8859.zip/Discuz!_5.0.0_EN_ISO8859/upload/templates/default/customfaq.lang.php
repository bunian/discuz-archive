<?php

// Customized FAQ for Discuz! Version 1.0.0
// Translated by Crossday

$customfaq = array();

?>