<?php

// Action Pack for Discuz! Version 1.0.0
// Created by Crossday

$actioncode = array 
(
  0 => 'Back to Forum',
  
  1 => 'View Index',
  2 => 'View Boards',
  3 => 'View Posts',
  5 => 'Register',
  6 => 'Login',
  7 => 'Use CP',
  
  11 => 'New Post',
  12 => 'Reply Post',
  13 => 'Edit Post',
  14 => 'Download Attachment',
  15 => 'Import from Xspace',
  
  21 => 'View Announcements',
  
  31 => 'View Online Members',
  
  41 => 'View Member List',
  
  51 => 'View Help',
  
  61 => 'View Member Information',
  
  71 => 'Rate Post',
  72 => 'View Rating Logs',
  
  81 => 'Purchase Thread',
  82 => 'View Purchasing Logs',
  
  101 => 'P.M.',
  111 => 'Search',
  
  121 => 'Recommend To Friend',
  122 => 'Report',
  123 => 'Add to/Remove from Blog',
  
  131 => 'View Forum Stats.',
  
  141 => 'Retrieve Password',
  
  151 => 'Blog',
  161 => 'Reward',
  
  191 => 'WAP - View Index',
  192 => 'WAP - View Boards',
  193 => 'WAP - View Posts',
  194 => 'WAP - ToolBox',
  195 => 'WAP - New Post',
  196 => 'WAP - Reply Post',
  197 => 'WAP - P.M.',
  
  201 => 'Administration',
  
  211 => 'System Configruation',
  
  254 => 'Invalid Accecss',
  
  255 => 'Notice/Redirect',
);

?>
