﻿document.write("<li><a href=\"license.htm\" target=\"_self\">最终用户授权协议 中文版</a>");
document.write("<li><a href=\"license_english.htm\" target=\"_self\">最终用户授权协议 英文版</a>");