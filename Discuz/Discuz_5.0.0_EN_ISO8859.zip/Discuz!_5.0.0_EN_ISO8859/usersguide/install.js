﻿document.write("<li><a href=\"install.htm\" target=\"_self\">环境要求</a>");
document.write("<li><a href=\"install_steps.htm\" target=\"_self\">安装详细流程</a>");
document.write("<li><a href=\"install_files.htm\" target=\"_self\">文件及目录结构</a>");
document.write("<li><a href=\"install_faq.htm\" target=\"_self\">安装常见问题</a>");
document.write("<li><a href=\"install_xspace.htm\" target=\"_self\">附录：如何在Discuz上安装个人空间SupeSite/X-Space指南</a>");
document.write("<li><a href=\"install_easy_exp.htm\" target=\"_self\">附录：论坛一键安装 Discuz!EXP 及 EasyDiscuz 指南</a>");
document.write("<li><a href=\"install_server_win.htm\" target=\"_self\">附录：Discuz! 本地运行环境构建(Windows)</a>");
