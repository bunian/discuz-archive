<?

/*
	[Discuz!] (C)2001-2006 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$RCSfile: editpost.inc.php,v $
	$Revision: 1.90.2.6 $
	$Date: 2007/02/05 21:31:40 $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$discuz_action = 13;

$query = $db->query("SELECT m.adminid, p.first, p.authorid, p.author, p.dateline, u.allowhtml, p.anonymous, p.invisible FROM {$tablepre}posts p
	LEFT JOIN {$tablepre}members m ON m.uid=p.authorid
	LEFT JOIN {$tablepre}usergroups u USING(groupid)
	WHERE pid='$pid' AND tid='$tid' AND fid='$fid'");

$orig = $db->fetch_array($query);

$isfirstpost = $orig['first'] ? 1 : 0;
$isorigauthor = $discuz_uid && $discuz_uid == $orig['authorid'];
$isanonymous = $isanonymous && $allowanonymous ? 1 : 0;
$alloweditpost = $alloweditpost && !(in_array($orig['adminid'], array(1, 2, 3)) && $adminid > $orig['adminid']) ? 1 : 0;
$audit = $orig['invisible'] == 2 || $thread['displayorder'] == -2 ? $audit : 0;

if((!$forum['ismoderator'] || !$alloweditpost) && !$isorigauthor) {
	showmessage('post_edit_nopermission', NULL, 'HALTED');
} elseif($isorigauthor && !$forum['ismoderator']) {
	if($edittimelimit && $timestamp - $orig['dateline'] > $edittimelimit * 60) {
		showmessage('post_edit_timelimit', NULL, 'HALTED');
	} elseif(($isfirstpost && $modnewthreads) || (!$isfirstpost && $modnewreplies)) {
		showmessage('post_edit_moderate');
	}
}

$thread['pricedisplay'] = $thread['price'] == -1 ? 0 : $thread['price'];

if(!submitcheck('editsubmit')) {

	include_once language('misc');

	$typeselect = typeselect($thread['typeid']);

	$icons = '';
	if(is_array($_DCACHE['icons']) && $isfirstpost) {
		$key = 1;
		foreach($_DCACHE['icons'] as $id => $icon) {
			$icons .= ' <input class="radio" type="radio" name="iconid" value="'.$id.'" '.($thread['iconid'] == $id ? 'checked' : '').'><img src="'.SMDIR.'/'.$icon.'" alt="" />';
			$icons .= !(++$key % 10) ? '<br>' : '';
		}
	}

	$query = $db->query("SELECT * FROM {$tablepre}posts WHERE pid='$pid' AND tid='$tid' AND fid='$fid'");
	$postinfo = $db->fetch_array($query);

	$usesigcheck = $postinfo['usesig'] ? 'checked' : '';
	$urloffcheck = $postinfo['parseurloff'] ? 'checked' : '';
	$smileyoffcheck = $postinfo['smileyoff'] == 1 ? 'checked' : '';
	$codeoffcheck = $postinfo['bbcodeoff'] == 1 ? 'checked' : '';
	$htmloncheck = $postinfo['htmlon'] ? 'checked' : '';

	$poll = $temppoll = '';
	if($isfirstpost) {
		$thread['freecharge'] = $maxchargespan && $timestamp - $thread['dateline'] >= $maxchargespan * 3600 ? 1 : 0;
		if($thread['special'] == 1 && ($alloweditpoll || $thread['authorid'] == $discuz_uid)) {
			$query = $db->query("SELECT polloptionid, displayorder, polloption, multiple, visible, maxchoices, expiration FROM {$tablepre}polloptions AS polloptions LEFT JOIN {$tablepre}polls AS polls ON polloptions.tid=polls.tid WHERE polls.tid ='$tid' ORDER BY displayorder");
			while($temppoll = $db->fetch_array($query)) {
				$poll['multiple'] = $temppoll['multiple'];
				$poll['visible'] = $temppoll['visible'];
				$poll['maxchoices'] = $temppoll['maxchoices'];
				$poll['expiration'] = $temppoll['expiration'];
				$poll['polloptionid'][] = $temppoll['polloptionid'];
				$poll['displayorder'][] = $temppoll['displayorder'];
				$poll['polloption'][] = stripslashes($temppoll['polloption']);
			}
		} elseif($thread['special'] == 2 && ($allowposttrade || $thread['authorid'] == $discuz_uid)) {
			$query = $db->query("SELECT * FROM {$tablepre}trades WHERE tid='$tid'");
			$trade = $db->fetch_array($query);
			$trade['expiration'] = $trade['expiration'] ? date('Y-m-d', $trade['expiration']) : '';
			$expiration_7 = date('Y-m-d', $timestamp + 86400 * 7);
			$expiration_14 = date('Y-m-d', $timestamp + 86400 * 14);
			$expiration_month = date('Y-m-d', mktime(0, 0, 0, date('m')+1, date('d'), date('Y')));
		} elseif($thread['special'] == 3) {
			$rewardprice = abs($thread['price']);
		} elseif($thread['special'] == 4 && ($allowpostactivity || $thread['authorid'] == $discuz_uid)) {
			$query = $db->query("SELECT * FROM {$tablepre}activities WHERE tid='$tid'");
			$activity = $db->fetch_array($query);
			$activity['starttimefrom'] = date("Y-m-d H:i", $activity['starttimefrom'] + $timeoffset * 3600);
			$activity['starttimeto'] = $activity['starttimeto'] ? date("Y-m-d H:i", $activity['starttimeto'] + $timeoffset * 3600) : '';
			$activity['expiration'] = $activity['expiration'] ? date("Y-m-d H:i", $activity['expiration'] + $timeoffset * 3600) : '';
		}
	}

	if($postinfo['attachment']) {
		require_once DISCUZ_ROOT.'./include/attachment.func.php';

		$attachments = array();
		$query = $db->query("SELECT * FROM {$tablepre}attachments WHERE pid='$postinfo[pid]'");
		while($attach = $db->fetch_array($query)) {
			$attach['dateline'] = gmdate("$dateformat $timeformat", $attach['dateline'] + $timeoffset * 3600);
			$attach['filesize'] = sizecount($attach[filesize]);
			$attach['filetype'] = attachtype(fileext($attach['attachment'])."\t".$attach['filetype']);
			$attachments[] = $attach;
		}
	}

	$postinfo['subject'] = str_replace('"', '&quot;', $postinfo['subject']);
	$postinfo['message'] = dhtmlspecialchars($postinfo['message']);
	$postinfo['message'] = preg_replace($language['post_edit_regexp'], '', $postinfo['message']);

	if($editormode == 1 && $bbinsert && !(isopera() && isopera() < 9)) {
		$postinfo['message'] = discuzcode($postinfo['message'], $postinfo['smileyoff'], $postinfo['bbcodeoff'], $postinfo['htmlon'], $forum['allowsmilies'], $forum['allowbbcode'], $forum['allowimgcode'], $forum['allowhtml'], 0, 1);
	}

	include template('post_editpost');

} else {

	if(empty($delete)) {

		if($post_invalid = checkpost()) {
			showmessage($post_invalid);
		}

		if($allowpostattach && is_array($_FILES['attach'])) {
			foreach($_FILES['attach']['name'] as $attachname) {
				if($attachname != '') {
					checklowerlimit($creditspolicy['postattach']);
					break;
				}
			}
		}

		if(!$isorigauthor && !$allowanonymous) {
			if($orig['anonymous'] && !$isanonymous) {
				$isanonymous = 0;
				$authoradd = ', author=\''.addslashes($orig['author']).'\'';
				$anonymousadd = ', anonymous=\'0\'';
			} else {
				$isanonymous = $orig['anonymous'];
				$authoradd = $anonymousadd = '';
			}
		} else {
			$authoradd = ', author=\''.($isanonymous ? '' : addslashes($orig['author'])).'\'';
			$anonymousadd = ", anonymous='$isanonymous'";
		}

		if($isfirstpost) {

			if($subject == '' || $message == '') {
				showmessage('post_sm_isnull');
			}

			$typeid = isset($forum['threadtypes']['types'][$typeid]) ? $typeid : 0;
			$iconid = isset($_DCACHE['icons'][$iconid]) ? $iconid : 0;

			if(!$typeid && $forum['threadtypes']['required']) {
				showmessage('post_type_isnull');
			}

			$readperm = $allowsetreadperm ? $readperm : ($isorigauthor ? 0 : 'readperm');
			$price = intval($price);
			$price = $thread['price'] < 0 && !$thread['special'] ?
				($isorigauthor || !$price ? -1 : $price) :
				($maxprice ? ($price <= $maxprice ? ($price > 0 ? $price : 0) : $maxprice) : ($isorigauthor ? 0 : $thread['price']));

			if($price > 0 && floor($price * (1 - $creditstax)) == 0) {
				showmessage('post_net_price_iszero');
			}

			$polladd = '';
			if(($alloweditpoll || $thread['authorid'] == $discuz_uid) && $thread['special'] == 1 && !empty($polls)) {
				$pollarray = '';
				$pollarray['options'] = $polloption;
				if($pollarray['options']) {
					if(count($pollarray['options']) > $maxpolloptions) {
						showmessage('post_poll_option_toomany');
					}
					foreach($pollarray['options'] as $key => $value) {
						if(!trim($value)) {
							$db->query("DELETE FROM {$tablepre}polloptions WHERE polloptionid='$key' AND tid='$tid'");
							unset($pollarray['options'][$key]);
						}
					}
					$polladd = ', special=\'1\'';
					foreach($displayorder as $key => $value) {
						if(preg_match("/^-?\d*$/", $value)) {
							$pollarray['displayorder'][$key] = $value;
						}
					}
					$pollarray['multiple'] = !empty($multiplepoll);
					$pollarray['visible'] = empty($visibilitypoll);
					$pollarray['expiration'] = $expiration;
					foreach($polloptionid as $key => $value) {
						if(!preg_match("/^\d*$/", $value)) {
							showmessage('submit_invalid');
						}
					}
					$maxchoices = $maxchoices >= count($pollarray['options']) ? count($pollarray['options']) : $maxchoices;
					if(preg_match("/^\d*$/", $maxchoices)) {
						if(!$pollarray['multiple']) {
							$pollarray['maxchoices'] = 1;
						} elseif(empty($maxchoices)) {
							$pollarray['maxchoices'] = 0;
						} else {
							$pollarray['maxchoices'] = $maxchoices;
						}
					}

					if($close) {
						$pollarray['expiration'] = $timestamp;
					} elseif(preg_match("/^\d*$/", $pollarray['expiration'])) {
						if(empty($pollarray['expiration'])) {
							$pollarray['expiration'] = 0;
						} else {
							$pollarray['expiration'] = $timestamp + 86400 * $expiration;
						}
					}
					$optid = '';
					$query = $db->query("SELECT polloptionid FROM {$tablepre}polloptions WHERE tid='$tid'");
					while($tempoptid = $db->fetch_array($query)) {
						$optid[] = $tempoptid['polloptionid'];
					}
					foreach($pollarray['options'] as $key => $value) {
						$value = dhtmlspecialchars(trim($value));
						if(in_array($polloptionid[$key], $optid)) {
							if($alloweditpoll) {
								$db->query("UPDATE {$tablepre}polloptions SET displayorder='".$pollarray['displayorder'][$key]."', polloption='$value' WHERE polloptionid='$polloptionid[$key]' AND tid='$tid'");
							} else {
								$db->query("UPDATE {$tablepre}polloptions SET displayorder='".$pollarray['displayorder'][$key]."' WHERE polloptionid='$polloptionid[$key]' AND tid='$tid'");
							}
						} else {
							$db->query("INSERT INTO {$tablepre}polloptions (tid, displayorder, polloption) VALUES ('$tid', '".$pollarray['displayorder'][$key]."', '$value')");
						}
					}
					$db->query("UPDATE {$tablepre}polls SET multiple='$pollarray[multiple]', visible='$pollarray[visible]', maxchoices='$pollarray[maxchoices]', expiration='$pollarray[expiration]' WHERE tid='$tid'", 'UNBUFFERED');
				} else {
					$polladd = ', special=\'0\'';
					$db->query("DELETE FROM {$tablepre}polls WHERE tid='$tid'");
					$db->query("DELETE FROM {$tablepre}polloptions WHERE tid='$tid'");
				}

			} elseif($thread['special'] == 2 && ($allowposttrade || $thread['authorid'] == $discuz_uid)) {

				$seller = dhtmlspecialchars(trim($seller));
				$item_name = dhtmlspecialchars(trim($item_name));
				$item_price = intval($item_price);
				$item_locus = dhtmlspecialchars(trim($item_locus));
				$item_number = intval($item_number);
				$item_quality = intval($item_quality);
				$item_transport = intval($item_transport);
				$postage_mail = intval($postage_mail);
				$postage_express = intval(trim($postage_express));
				$postage_ems = intval($postage_ems);
				$item_type = intval($item_type);

				if(!$seller) {
					showmessage('trade_alipay_please');
				} elseif(!$item_name) {
					showmessage('trade_please_name');
				} elseif($maxtradeprice && ($mintradeprice > $item_price || $maxtradeprice < $item_price)) {
					showmessage('trade_price_between');
				} elseif(!$maxtradeprice && $mintradeprice > $item_price) {
					showmessage('trade_price_more_than');
				} elseif(!trim($item_locus)) {
					showmessage('trade_please_locus');
				} elseif($item_number < 0) {
					showmessage('tread_please_number');
				}

				$expiration = $item_expiration ? strtotime($item_expiration) : 0;
				$closed = $expiration > 0 && strtotime($item_expiration) < $timestamp ? 1 : $closed;

				switch($transport) {
					case 'seller':$item_transport = 1;break;
					case 'buyer':$item_transport = 2;break;
					case 'virtual':$item_transport = 3;break;
					case 'logistics':$item_transport = 4;break;
				}

				$db->query("UPDATE {$tablepre}trades SET account='$seller', subject='$item_name', price='$item_price', amount='$item_number', quality='$item_quality', locus='$item_locus',
					transport='$item_transport', ordinaryfee='$postage_mail', expressfee='$postage_express', emsfee='$postage_ems', itemtype='$item_type', expiration='$expiration', closed='$closed' WHERE tid='$tid'", 'UNBUFFERED');
			} elseif($thread['special'] == 3 && ($allowpostreward || $thread['authorid'] == $discuz_uid)) {
				if($thread['price'] > 0 && $thread['price'] != $rewardprice) {
					$rewardprice = intval($rewardprice);
					if($rewardprice <= 0){
						showmessage("reward_credits_invalid");
					}
					$addprice = ceil(($rewardprice - $thread['price']) + ($rewardprice - $thread['price']) * $creditstax);
					if(!$forum['ismoderator']) {
						if($rewardprice < $thread['price']) {
							showmessage("reward_credits_fall");
						} elseif($rewardprice < $minrewardprice || ($maxrewardprice > 0 && $rewardprice > $maxrewardprice)) {
							showmessage("reward_credits_between");
						} elseif($addprice > $_DSESSION["extcredits$creditstrans"]) {
							showmessage('reward_credits_shortage');
						}
					}
					$realprice = ceil($thread['price'] + $thread['price'] * $creditstax) + $addprice;

					$db->query("UPDATE {$tablepre}members SET extcredits$creditstrans=extcredits$creditstrans-$addprice WHERE uid='$thread[authorid]'");
					$db->query("UPDATE {$tablepre}rewardlog SET netamount='$realprice' WHERE tid='$tid' AND authorid='$thread[authorid]'");
				}

				if(!$forum['ismoderator'] && $thread['authorid'] == $discuz_uid) {
					if($thread['replies'] > 1) {
						$subject = $thread['subject'];
					}

					if($thread['price'] < 0) {
						$rewardprice = abs($thread['price']);
					}
				}

				$price = $thread['price'] > 0 ? $rewardprice : -$rewardprice;
			} elseif($thread['special'] == 4 && ($allowpostactivity || $thread['authorid'] == $discuz_uid)) {
				if(empty($starttimefrom[$activitytime])) {
					showmessage('activity_fromtime_please');
				} elseif(strtotime($starttimefrom[$activitytime]) === -1 || strtotime($starttimefrom[$activitytime]) === FALSE) {
					showmessage('activity_fromtime_error');
				} elseif(strtotime($starttimefrom[$activitytime]) < $timestamp) {
					showmessage('activity_smaller_current');
				} elseif($activitytime && ((strtotime($starttimefrom) > strtotime($starttimeto) || !$starttimeto))) {
					showmessage('activity_fromtime_error');
				} elseif(!trim($activityclass)) {
					showmessage('activity_sort_please');
				} elseif(!trim($activityplace)) {
					showmessage('activity_address_please');
				} elseif(trim($activityexpiration) && (strtotime($activityexpiration) === -1 || strtotime($activityexpiration) === FALSE)) {
					showmessage('activity_totime_error');
				}

				$activity = array();
				$activity['class'] = dhtmlspecialchars(trim($activityclass));
				$activity['starttimefrom'] = strtotime($starttimefrom[$activitytime]) - $timeoffset * 3600;
				$activity['starttimeto'] = $activitytime ? strtotime($starttimeto) - $timeoffset * 3600 : 0;
				$activity['place'] = dhtmlspecialchars(trim($activityplace));
				$activity['cost'] = intval($cost);
				$activity['gender'] = intval($gender);
				$activity['number'] = intval($activitynumber);
				if($activityexpiration) {
					$activity['expiration'] = strtotime($activityexpiration) - $timeoffset * 3600;
				} else {
					$activity['expiration'] = 0;
				}

				$db->query("UPDATE {$tablepre}activities SET cost='$activity[cost]', starttimefrom='$activity[starttimefrom]', starttimeto='$activity[starttimeto]', place='$activity[place]', class='$activity[class]', gender='$activity[gender]', number='$activity[number]', expiration='$activity[expiration]' WHERE tid='$tid'", 'UNBUFFERED');
			}

			$db->query("UPDATE {$tablepre}threads SET iconid='$iconid', typeid='$typeid', subject='$subject', readperm='$readperm', price='$price' $authoradd $polladd ".($auditstatuson && $audit == 1 ? ",displayorder='0', moderated='1'" : '')." WHERE tid='$tid'", 'UNBUFFERED');

		} else {

			if($subject == '' && $message == '') {
				showmessage('post_sm_isnull');
			}

		}

		if($editedby && ($timestamp - $orig['dateline']) > 60 && $adminid != 1) {
			include_once language('misc');

			$editor = $isanonymous && $isorigauthor ? $language['anonymous'] : $discuz_user;
			$edittime = gmdate($_DCACHE['settings']['dateformat'].' '.$_DCACHE['settings']['timeformat'], $timestamp + $timeoffset * 3600);
			eval("\$message .= \"$language[post_edit]\";");
		}

		$bbcodeoff = checkbbcodes($message, !empty($bbcodeoff));
		$smileyoff = checksmilies($message, !empty($smileyoff));
		$htmlon = $orig['allowhtml'] && !empty($htmlon) ? 1 : 0;

		$tattachment = 0;
		$attachpermadd = '';
		$pattachment = ($allowpostattach && $attachments = attach_upload()) ? 1 : 0;
		$uattachment = ($allowpostattach && $uattachments = attach_upload('attachupdate')) ? 1 : 0;

		$query = $db->query("SELECT aid, readperm, attachment, description FROM {$tablepre}attachments WHERE pid='$pid'");
		while($attach = $db->fetch_array($query)) {
			$attachpermadd = $allowsetattachperm && $attach['readperm'] != $attachpermnew[$attach['aid']] ? ", readperm='{$attachpermnew[$attach['aid']]}'" : '' ;
			$attachdescnew[$attach['aid']] = cutstr(dhtmlspecialchars($attachdescnew[$attach['aid']]), 100);
			$attachdescadd = $attach['description'] != $attachdescnew[$attach['aid']] ? 1 : 0;

			if($uattachment || $attachpermadd || $attachdescadd) {
				$paid = 'paid'.$attach['aid'];
				$attachfileadd = '';
				if($uattachment && isset($uattachments[$paid])) {
					@unlink($attachdir.'/'.$attach['attachment']);
					$attachfileadd = ', dateline=\''.$timestamp.'\',
							filename=\''.$uattachments[$paid]['name'].'\',
							filetype=\''.$uattachments[$paid]['type'].'\',
							filesize=\''.$uattachments[$paid]['size'].'\',
							attachment=\''.$uattachments[$paid]['attachment'].'\'';
					unset($uattachments[$paid]);
				}

				$db->query("UPDATE {$tablepre}attachments SET description='{$attachdescnew[$attach['aid']]}' $attachpermadd $attachfileadd WHERE aid='$attach[aid]'");
			}
		}

		if(!empty($uattachments)) {
			foreach($uattachments as $attach) {
				@unlink($attachdir.'/'.$attach['attachment']);
			}
		}

		if(!empty($deleteaid) || $pattachment) {

			if(!empty($deleteaid) && is_array($deleteaid)) {

				$deleteaids = '\''.implode("','", $deleteaid).'\'';
				$query = $db->query("SELECT aid, attachment FROM {$tablepre}attachments WHERE aid IN ($deleteaids) AND pid='$pid'");

				while($attach = $db->fetch_array($query)) {
					@unlink($attachdir.'/'.$attach['attachment']);
				}

				$db->query("DELETE FROM {$tablepre}attachments WHERE aid IN ($deleteaids)");
				updatecredits($orig['authorid'], $postattachcredits, -($db->affected_rows()));
			}

			if($pattachment) {
				foreach($attachments as $attach) {
					$db->query("INSERT INTO {$tablepre}attachments (tid, pid, dateline, readperm, filename, description, filetype, filesize, attachment, downloads, isimage, uid)
						VALUES ('$tid', '$pid', '$timestamp', '$attach[perm]', '$attach[name]', '$attach[description]', '$attach[type]', '$attach[size]', '$attach[attachment]', '0', '$attach[isimage]', '$attach[uid]')");
				}
				updatecredits($orig['authorid'], $postattachcredits, count($attachments));
			} else {
				$query = $db->query("SELECT aid FROM {$tablepre}attachments WHERE pid='$pid' LIMIT 1");
				$pattachment = $db->result($query, 0) ? 1 : 0;
			}

			if($pattachment) {
				$tattachment = 1;
			} else {
				$query = $db->query("SELECT a.aid FROM {$tablepre}posts p, {$tablepre}attachments a WHERE a.tid='$tid' AND a.pid=p.pid AND p.invisible='0' LIMIT 1");
				$tattachment = $db->result($query, 0) ? 1 : 0;
			}

			$db->query("UPDATE {$tablepre}threads SET attachment='$tattachment' WHERE tid='$tid'");

		}

		if($auditstatuson && $audit == 1) {
			updatepostcredits('+', $orig['authorid'], ($isfirstpost ? $postcredits : $replycredits));
			updatemodworks('MOD', 1);
			updatemodlog($tid, 'MOD');
		}

		$db->query("UPDATE {$tablepre}posts SET message='$message', usesig='$usesig', htmlon='$htmlon', bbcodeoff='$bbcodeoff', parseurloff='$parseurloff',
			smileyoff='$smileyoff', subject='$subject' ".($pattachment ? ", attachment='1'" : '')." $anonymousadd ".($auditstatuson && $audit == 1 ? ",invisible='0'" : '')." WHERE pid='$pid'");
		$forum['lastpost'] = explode("\t", $forum['lastpost']);

		if($orig['dateline'] == $forum['lastpost'][2] && ($orig['author'] == $forum['lastpost'][3] || ($forum['lastpost'][3] == '' && $orig['anonymous']))) {
			$lastpost = "$tid\t".($isfirstpost ? $subject : addslashes($thread['subject']))."\t$orig[dateline]\t".($isanonymous ? '' : addslashes($orig['author']));
			$db->query("UPDATE {$tablepre}forums SET lastpost='$lastpost' WHERE fid='$fid'", 'UNBUFFERED');
		}

		if($thread['lastpost'] == $orig['dateline'] && ((!$orig['anonymous'] && $thread['lastposter'] == $orig['author']) || ($orig['anonymous'] && $thread['lastposter'] == '')) && $orig['anonymous'] != $isanonymous) {
			$db->query("UPDATE {$tablepre}threads SET lastposter='".($isanonymous ? '' : addslashes($orig['author']))."' WHERE tid='$tid'", 'UNBUFFERED');
		}

		if(!$isorigauthor) {
			updatemodworks('EDT', 1);
			require_once DISCUZ_ROOT.'./include/misc.func.php';
			modlog($thread, 'EDT');
		}

	} else {
		if(!$isorigauthor) {

			showmessage('post_edit_nopermission', NULL, 'HALTED');

		} elseif($thread['special'] == 3) {

			if($isfirstpost && $thread['replies'] >= 1) {
				showmessage('post_edit_reward_already_reply', NULL, 'HALTED');
			} elseif($thread['price'] < 0 && ($thread['dateline'] + 1 == $orig['dateline'])) {
				showmessage('post_edit_reward_nopermission', NULL, 'HALTED');
			}

		}

		updatepostcredits('-', $orig['authorid'], ($isfirstpost ? $postcredits : $replycredits));

		if($thread['special'] == 3 && $isfirstpost){
			$db->query("UPDATE {$tablepre}members SET extcredits$creditstrans=extcredits$creditstrans+$thread[price] WHERE uid='$orig[authorid]'", 'UNBUFFERED');
			$db->query("DELETE FROM {$tablepre}rewardlog WHERE tid='$tid'", 'UNBUFFERED');
		}

		$thread_attachment = $post_attachment = 0;
		$query = $db->query("SELECT pid, attachment FROM {$tablepre}attachments WHERE tid='$tid'");
		while($attach = $db->fetch_array($query)) {
			if($attach['pid'] == $pid) {
				$post_attachment = 1;
				@unlink($attachdir.'/'.$attach['attachment']);
				updatecredits($orig['authorid'], $postattachcredits, -($db->affected_rows()));
			} else {
				$thread_attachment = 1;
			}
		}

		if($post_attachment) {
			$db->query("DELETE FROM {$tablepre}attachments WHERE pid='$pid'", 'UNBUFFEREED');
		}

		$db->query("DELETE FROM {$tablepre}posts WHERE pid='$pid'");

		if($isfirstpost) {
			$forumadd = 'threads=threads-1, posts=posts-1';
			$db->query("DELETE FROM {$tablepre}threadsmod WHERE tid='$tid'", 'UNBUFFERED');
			$db->query("DELETE FROM {$tablepre}relatedthreads WHERE tid='$tid'", 'UNBUFFERED');
			$db->query("DELETE FROM {$tablepre}threads WHERE tid='$tid'", 'UNBUFFERED');
			$db->query("DELETE FROM {$tablepre}polloptions WHERE tid='$tid'");
			$db->query("DELETE FROM {$tablepre}polls WHERE tid='$tid'", 'UNBUFFERED');
			if($globalstick && in_array($thread['displayorder'], array(2, 3))) {
				require_once DISCUZ_ROOT.'./include/cache.func.php';
				updatecache('globalstick');
			}
		} else {
			$forumadd = 'posts=posts-1';
			$query = $db->query("SELECT author, dateline FROM {$tablepre}posts WHERE tid='$tid' AND invisible='0' ORDER BY dateline DESC LIMIT 1");
			$lastpost = $db->fetch_array($query);
			$lastpost['author'] = addslashes($lastpost['author']);
			$db->query("UPDATE {$tablepre}threads SET replies=replies-1, attachment='$thread_attachment', lastposter='$lastpost[author]', lastpost='$lastpost[dateline]' WHERE tid='$tid'", 'UNBUFFERED');
		}

		$forum['lastpost'] = explode("\t", $forum['lastpost']);
		if($orig['dateline'] == $forum['lastpost'][2] && ($orig['author'] == $forum['lastpost'][3] || ($forum['lastpost'][3] == '' && $orig['anonymous']))) {
			$query = $db->query("SELECT tid, subject, lastpost, lastposter FROM {$tablepre}threads
				WHERE fid='$fid' AND displayorder>='0' ORDER BY lastpost DESC LIMIT 1");
			$lastthread = daddslashes($db->fetch_array($query), 1);
			$forumadd .= ", lastpost='$lastthread[tid]\t$lastthread[subject]\t$lastthread[lastpost]\t$lastthread[lastposter]'";
		}

		$db->query("UPDATE {$tablepre}forums SET $forumadd WHERE fid='$fid'", 'UNBUFFERED');

	}

	// debug: update thread caches ?
	if($forum['threadcaches']) {
		if($isfirstpost || $page == 1 || $thread['replies'] < $_DCACHE['pospperpage'] || !empty($delete)) {
			deletethreadcaches($tid);
		} else {
			$query = $db->query("SELECT COUNT(*) FROM {$tablepre}posts WHERE tid='$tid' AND pid<'$pid'");
			if($db->result($query, 0) < $_DCACHE['settings']['postperpage']) {
				deletethreadcaches($tid);
			}
		}
	}

	if($auditstatuson) {
		if($audit == 1) {
			showmessage('auditstatuson_succeed', "viewthread.php?tid=$tid&page=$page&extra=$extra#pid$pid");
		} else {
			showmessage('audit_edit_succeed');
		}
	} else {
		if(!empty($delete) && $isfirstpost) {
			showmessage('post_edit_delete_succeed', "forumdisplay.php?fid=$fid");
		} else {
			showmessage('post_edit_succeed', "viewthread.php?tid=$tid&page=$page&extra=$extra#pid$pid");
		}
	}

}

?>