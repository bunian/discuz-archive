<?php

define("IN_CDB", TRUE);
require "./config.php";
error_reporting(7);
@set_time_limit(1000);
$step = $HTTP_GET_VARS[step];
$PHP_SELF = $HTTP_SERVER_VARS[PHP_SELF];
require "./config.php";

mysql_connect($dbhost, $dbuser, $dbpw) or die("config.php û�гɹ�����,���ݿ��޷�����");
mysql_select_db($dbname);

$tables = array('whosonline', 'ranks', 'forumlink', 'attachments', 'announcements', 'banned', 'caches', 'favorites', 'forumlinks', 'forums', 'members', 'memo', 'news', 'posts', 'searchindex', 'sessions', 'settings', 'smilies', 'stats', 'subscriptions', 'templates', 'themes', 'threads', 'u2u', 'usergroups', 'words', 'buddys'); 
foreach($tables as $name) {
	${"table_".$name} = $tablepre.$name;
}

$upgrade[0] = <<<EOT
ALTER TABLE $table_settings ADD onlinerecord varchar(20) NOT NULL default '';
ALTER TABLE $table_threads ADD lastposter varchar(40) NOT NULL default '' AFTER lastpost;
ALTER TABLE $table_threads ADD dateline int(10) UNSIGNED NOT NULL default '0' AFTER lastposter;
UPDATE $table_threads SET lastposter=substring_index(lastpost, '\t', -1) ,dateline=substring_index(lastpost, '\t', 1);
ALTER TABLE $table_threads DROP lastpost;
ALTER TABLE $table_templates DROP INDEX name;
ALTER TABLE $table_themes ADD allowbold tinyint(1) NOT NULL default '0' AFTER fontsize;
ALTER TABLE $table_themes DROP dummy;
EOT;

$upgrade[1] = <<<EOT
ALTER TABLE $table_templates ADD modified tinyint(1) NOT NULL default '0' AFTER name;
ALTER TABLE $table_themes DROP allowbold, ADD nobold tinyint(1) NOT NULL default '0' AFTER fontsize;
ALTER TABLE $table_themes CHANGE name themename varchar(30) NOT NULL default '';
ALTER TABLE $table_themes CHANGE header headercolor varchar(15) NOT NULL default '';
ALTER TABLE $table_threads ADD lastpost int(10) UNSIGNED NOT NULL default '0' AFTER subject;
UPDATE $table_threads SET lastpost=dateline;
ALTER TABLE $table_settings ADD lastmember varchar(25) NOT NULL default '';

CREATE TABLE $table_stats (
	type varchar(20) NOT NULL default '',
	var varchar(20) NOT NULL default '',
	count int(10) UNSIGNED NOT NULL default '0',
	KEY  (type),
	KEY  (var)
);

INSERT INTO $table_stats VALUES ('total', 'hits', '');
INSERT INTO $table_stats VALUES ('total', 'members', '');
INSERT INTO $table_stats VALUES ('total', 'guests', '');
INSERT INTO $table_stats VALUES ('os', 'Windows', '');
INSERT INTO $table_stats VALUES ('os', 'Mac', '');
INSERT INTO $table_stats VALUES ('os', 'Linux', '');
INSERT INTO $table_stats VALUES ('os', 'FreeBSD', '');
INSERT INTO $table_stats VALUES ('os', 'SunOS', '');
INSERT INTO $table_stats VALUES ('os', 'BeOS', '');
INSERT INTO $table_stats VALUES ('os', 'OS/2', '');
INSERT INTO $table_stats VALUES ('os', 'AIX', '');
INSERT INTO $table_stats VALUES ('os', 'Other', '');
INSERT INTO $table_stats VALUES ('browser', 'MSIE', '');
INSERT INTO $table_stats VALUES ('browser', 'Netscape', '');
INSERT INTO $table_stats VALUES ('browser', 'Mozilla', '');
INSERT INTO $table_stats VALUES ('browser', 'Lynx', '');
INSERT INTO $table_stats VALUES ('browser', 'Opera', '');
INSERT INTO $table_stats VALUES ('browser', 'Konqueror', '');
INSERT INTO $table_stats VALUES ('browser', 'Other', '');
INSERT INTO $table_stats VALUES ('week', '0', '');
INSERT INTO $table_stats VALUES ('week', '1', '');
INSERT INTO $table_stats VALUES ('week', '2', '');
INSERT INTO $table_stats VALUES ('week', '3', '');
INSERT INTO $table_stats VALUES ('week', '4', '');
INSERT INTO $table_stats VALUES ('week', '5', '');
INSERT INTO $table_stats VALUES ('week', '6', '');
INSERT INTO $table_stats VALUES ('hour', '00', '');
INSERT INTO $table_stats VALUES ('hour', '01', '');
INSERT INTO $table_stats VALUES ('hour', '02', '');
INSERT INTO $table_stats VALUES ('hour', '03', '');
INSERT INTO $table_stats VALUES ('hour', '04', '');
INSERT INTO $table_stats VALUES ('hour', '05', '');
INSERT INTO $table_stats VALUES ('hour', '06', '');
INSERT INTO $table_stats VALUES ('hour', '07', '');
INSERT INTO $table_stats VALUES ('hour', '08', '');
INSERT INTO $table_stats VALUES ('hour', '09', '');
INSERT INTO $table_stats VALUES ('hour', '10', '');
INSERT INTO $table_stats VALUES ('hour', '11', '');
INSERT INTO $table_stats VALUES ('hour', '12', '');
INSERT INTO $table_stats VALUES ('hour', '13', '');
INSERT INTO $table_stats VALUES ('hour', '14', '');
INSERT INTO $table_stats VALUES ('hour', '15', '');
INSERT INTO $table_stats VALUES ('hour', '16', '');
INSERT INTO $table_stats VALUES ('hour', '17', '');
INSERT INTO $table_stats VALUES ('hour', '18', '');
INSERT INTO $table_stats VALUES ('hour', '19', '');
INSERT INTO $table_stats VALUES ('hour', '20', '');
INSERT INTO $table_stats VALUES ('hour', '21', '');
INSERT INTO $table_stats VALUES ('hour', '22', '');
INSERT INTO $table_stats VALUES ('hour', '23', '');


CREATE TABLE $table_subscriptions (
	username varchar(25) NOT NULL default '',
	email varchar(60) NOT NULL default '',
	tid mediumint(8) UNSIGNED NOT NULL default '0',
	lastnotify int(10) UNSIGNED NOT NULL default '0',
	KEY  (username),
	KEY  (tid)
);

CREATE TABLE $table_usergroups (
  groupid smallint(6) unsigned NOT NULL auto_increment,
  specifiedusers text NOT NULL,
  status varchar(20) NOT NULL default '',
  grouptitle varchar(30) NOT NULL default '',
  creditshigher int(10) NOT NULL default '0',
  creditslower int(10) NOT NULL default '0',
  stars tinyint(3) NOT NULL default '0',
  groupavatar varchar(60) NOT NULL default '',
  allowcstatus tinyint(1) NOT NULL default '0',
  allowavatar tinyint(1) NOT NULL default '0',
  allowvisit tinyint(1) NOT NULL default '0',
  allowview tinyint(1) NOT NULL default '0',
  allowpost tinyint(1) NOT NULL default '0',
  allowpostpoll tinyint(1) NOT NULL default '0',
  allowgetattach tinyint(1) NOT NULL default '0',
  allowpostattach tinyint(1) NOT NULL default '0',
  allowvote tinyint(1) NOT NULL default '0',
  allowsearch tinyint(1) NOT NULL default '0',
  allowkarma tinyint(1) NOT NULL default '0',
  allowsetviewperm tinyint(1) NOT NULL default '0',
  allowsetattachperm tinyint(1) NOT NULL default '0',
  allowsigbbcode tinyint(1) NOT NULL default '0',
  allowsigimgcode tinyint(1) NOT NULL default '0',
  allowviewstats tinyint(1) NOT NULL default '0',
  ismoderator tinyint(1) NOT NULL default '0',
  issupermod tinyint(1) NOT NULL default '0',
  isadmin tinyint(1) NOT NULL default '0',
  maxu2unum smallint(6) unsigned NOT NULL default '0',
  maxmemonum smallint(6) unsigned NOT NULL default '0',
  maxsigsize smallint(6) unsigned NOT NULL default '0',
  maxkarmavote tinyint(3) unsigned NOT NULL default '0',
  maxattachsize mediumint(8) unsigned NOT NULL default '0',
  attachextensions tinytext NOT NULL,
  PRIMARY KEY  (groupid),
  KEY status (status),
  KEY creditshigher (creditshigher),
  KEY creditslower (creditslower)
);

INSERT INTO $table_usergroups VALUES (1, '', '��̳����Ա', '��̳����Ա', 0, 0, 9, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 100, 100, 500, 16, 2048000, '');
INSERT INTO $table_usergroups VALUES (2, '', '��������', '��������', 0, 0, 8, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 90, 60, 300, 12, 2048000, '');
INSERT INTO $table_usergroups VALUES (3, '', '����', '����', 0, 0, 7, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 80, 40, 200, 10, 2048000, '');
INSERT INTO $table_usergroups VALUES (4, '', '��ʽ��Ա', '������ؤ', -9999999, 0, 0, '', 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, '');
INSERT INTO $table_usergroups VALUES (5, '', '��ʽ��Ա', '������·', 0, 10, 1, '', 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 30, 3, 50, 0, 0, '');
INSERT INTO $table_usergroups VALUES (6, '', '��ʽ��Ա', '������Ա', 10, 50, 2, '', 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 40, 5, 50, 0, 128000, 'gif,jpg,png');
INSERT INTO $table_usergroups VALUES (7, '', '��ʽ��Ա', '�߼���Ա', 50, 150, 3, '', 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 50, 10, 100, 2, 256000, 'gif,jpg,png');
INSERT INTO $table_usergroups VALUES (8, '', '��ʽ��Ա', '֧����Ա', 150, 300, 4, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 50, 15, 100, 3, 512000, 'zip,rar,chm,txt,gif,jpg,png');
INSERT INTO $table_usergroups VALUES (9, '', '��ʽ��Ա', '��ͭ����', 300, 600, 5, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 50, 20, 100, 4, 1024000, '');
INSERT INTO $table_usergroups VALUES (10, '', '��ʽ��Ա', '�ƽ���', 600, 1000, 6, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 50, 25, 100, 5, 1024000, '');
INSERT INTO $table_usergroups VALUES (11, '', '��ʽ��Ա', '�׽���', 1000, 3000, 7, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 50, 30, 100, 6, 2048000, '');
INSERT INTO $table_usergroups VALUES (12, '', '��ʽ��Ա', '��վԪ��', 3000, 9999999, 8, '', 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 50, 40, 100, 8, 2048000, '');
INSERT INTO $table_usergroups VALUES (13, '', '�ȴ���֤', '�ȴ���֤��Ա', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 10, 0, 50, 0, 0, '');
INSERT INTO $table_usergroups VALUES (14, '', '�ο�', '�ο�', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO $table_usergroups VALUES (15, '', '��ֹ����', '�û�����ֹ����', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, '');
INSERT INTO $table_usergroups VALUES (16, '', '��ֹIP', '�û�IP����ֹ', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO $table_usergroups VALUES (17, '', '��ֹ����', '�û�����ֹ����', 0, 0, 0, '', 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, '');

CREATE TABLE $table_announcements (
	id smallint(6) UNSIGNED NOT NULL auto_increment,
	author varchar(25) NOT NULL default '',
	subject varchar(250) NOT NULL default '',
	starttime int(10) UNSIGNED NOT NULL default '0',
	endtime int(10) UNSIGNED NOT NULL default '0',
	message text NOT NULL default '',
	PRIMARY KEY  (id)
);

EOT;

$upgrade[2] = <<<EOT
ALTER TABLE $table_attachments CHANGE aid aid mediumint(8) UNSIGNED NOT NULL auto_increment;
ALTER TABLE $table_attachments CHANGE tid tid mediumint(8) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_attachments CHANGE pid pid int(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_attachments CHANGE filesize filesize int(12) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_attachments ADD creditsrequire smallint(6) UNSIGNED NOT NULL DEFAULT '0' AFTER pid;
ALTER TABLE $table_banned CHANGE dateline dateline int(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_banned DROP PRIMARY KEY, DROP id;
ALTER TABLE $table_banned ADD id smallint(6) UNSIGNED NOT NULL auto_increment PRIMARY KEY FIRST;
ALTER TABLE $table_banned CHANGE ip1 ip1 smallint(3) NOT NULL DEFAULT '0';
ALTER TABLE $table_banned CHANGE ip2 ip2 smallint(3) NOT NULL DEFAULT '0';
ALTER TABLE $table_banned CHANGE ip3 ip3 smallint(3) NOT NULL DEFAULT '0';
ALTER TABLE $table_banned CHANGE ip4 ip4 smallint(3) NOT NULL DEFAULT '0';
ALTER TABLE $table_banned CHANGE dateline dateline int(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_banned ADD admin varchar(25) NOT NULL DEFAULT '' AFTER ip4;
ALTER TABLE $table_buddys CHANGE username username varchar(25) NOT NULL DEFAULT '';
ALTER TABLE $table_buddys CHANGE buddyname buddyname varchar(25) NOT NULL DEFAULT '';
ALTER TABLE $table_favorites CHANGE tid tid mediumint(8) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_favorites CHANGE username username varchar(25) NOT NULL DEFAULT '';
ALTER TABLE $table_favorites DROP type;
ALTER TABLE $table_forumlink RENAME $table_forumlinks;
ALTER TABLE $table_forumlinks DROP PRIMARY KEY, DROP id, DROP displayorder;
ALTER TABLE $table_forumlinks ADD id smallint(6) UNSIGNED NOT NULL auto_increment PRIMARY KEY FIRST;
ALTER TABLE $table_forumlinks ADD displayorder tinyint(3) NOT NULL DEFAULT '0' AFTER id;
ALTER TABLE $table_forums CHANGE status status char(3) NOT NULL DEFAULT '';
ALTER TABLE $table_forums DROP private, DROP credits, DROP userlist, DROP postperm, DROP attachstatus, DROP pollstatus, DROP guestposting;
ALTER TABLE $table_forums CHANGE description description text NOT NULL DEFAULT '';
ALTER TABLE $table_forums CHANGE posts posts mediumint(8) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_forums CHANGE threads threads smallint(6) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_forums CHANGE fid fid smallint(6) UNSIGNED NOT NULL auto_increment;
ALTER TABLE $table_forums CHANGE displayorder displayorder tinyint(3) NOT NULL DEFAULT '0';
ALTER TABLE $table_forums DROP theme;

ALTER TABLE $table_forums CHANGE type type1 varchar(10) NOT NULL DEFAULT '';
ALTER TABLE $table_forums ADD type varchar(10) NOT NULL DEFAULT '' AFTER fid;
ALTER TABLE $table_forums CHANGE allowimgcode allowimgcode1 char(3) NOT NULL DEFAULT '';
ALTER TABLE $table_forums ADD allowimgcode char(3) NOT NULL DEFAULT '' AFTER allowbbcode;
ALTER TABLE $table_forums CHANGE fup fup1 smallint(6) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_forums ADD fup smallint(6) UNSIGNED NOT NULL DEFAULT '0' AFTER fid;
ALTER TABLE $table_forums CHANGE icon icon1 varchar(100) NOT NULL DEFAULT '';
ALTER TABLE $table_forums ADD icon varchar(100) NOT NULL DEFAULT '' AFTER type;
UPDATE $table_forums SET allowimgcode=allowimgcode1, type=type1, fup=fup1, icon=icon1;
ALTER TABLE $table_forums DROP allowimgcode1, DROP type1, DROP fup1, DROP icon1;
ALTER TABLE $table_forums ADD postattachperm tinytext NOT NULL DEFAULT '' AFTER threads;
ALTER TABLE $table_forums ADD getattachperm tinytext NOT NULL DEFAULT '' AFTER threads;
ALTER TABLE $table_forums ADD postperm tinytext NOT NULL DEFAULT '' AFTER threads;
ALTER TABLE $table_forums ADD viewperm tinytext NOT NULL DEFAULT '' AFTER threads;
#����: id allowimgcode icon��ǰ type ��
#����: ��postperm���ֶ�
EOT;

$upgrade[3] = <<<EOT
ALTER TABLE $table_members CHANGE uid uid mediumint(8) UNSIGNED NOT NULL auto_increment;
ALTER TABLE $table_members CHANGE regdate regdate int(10) UNSIGNED NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE postnum postnum smallint(6) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_members CHANGE credit credit smallint(6) NOT NULL DEFAULT '0';
ALTER TABLE $table_members CHANGE oicq oicq varchar(12) NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE status status varchar(20) NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE location location varchar(30) NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE bio bio text NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE signature signature text NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE showemail showemail char(3) NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE timeoffset timeoffset char(3) NOT NULL DEFAULT '0';
ALTER TABLE $table_members CHANGE icq icq varchar(12) NOT NULL DEFAULT '';
EOT;

$upgrade[4] = <<<EOT
ALTER TABLE $table_members CHANGE customstatus customstatus varchar(20) NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE avatar avatar varchar(100) NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE tpp tpp tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_members CHANGE ppp ppp tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_members CHANGE regip regip varchar(20) NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE regip regip varchar(20) NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE ignoreu2u ignoreu2u text NOT NULL DEFAULT '';
ALTER TABLE $table_members CHANGE lastvisit lastvisit int(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_members CHANGE pwdrcvtime pwdrcvtime int(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_members CHANGE ppp ppp tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_members CHANGE tpp tpp tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_members ADD gender tinyint(1) NOT NULL DEFAULT '0' AFTER password;
#˳��û����
EOT;

$upgrade[5] = <<<EOT
ALTER TABLE $table_news DROP PRIMARY KEY, DROP id;
ALTER TABLE $table_news ADD id smallint(6) UNSIGNED NOT NULL auto_increment PRIMARY KEY FIRST;
ALTER TABLE $table_posts CHANGE pid pid int(10) UNSIGNED NOT NULL auto_increment;
ALTER TABLE $table_posts CHANGE fid fid smallint(6) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_posts CHANGE tid tid mediumint(8) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_posts DROP INDEX dateline;
UPDATE $table_posts SET author='�ο�' WHERE author='Anonymous';
EOT;

$upgrade[6] = <<<EOT
ALTER TABLE $table_posts CHANGE aid aid mediumint(8) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_posts CHANGE author author varchar(25) NOT NULL DEFAULT '';
ALTER TABLE $table_posts CHANGE dateline dateline int(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_posts CHANGE icon icon varchar(30) NOT NULL DEFAULT '';
EOT;

$upgrade[7] = <<<EOT
ALTER TABLE $table_searchindex CHANGE dateline dateline int(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings DROP maxattachsize, DROP attachextensions, DROP searchstatus, DROP avastatus, DROP adminemail, DROP usercstatus, DROP sightml, DROP sigbbcode, DROP sigimgcode, DROP maxsigsize, DROP u2uquota, DROP regviewonly, DROP catsonly;
ALTER TABLE $table_settings CHANGE hottopic hottopic tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings CHANGE floodctrl floodctrl smallint(4) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings CHANGE credittitle credittitle varchar(20) NOT NULL DEFAULT '';
ALTER TABLE $table_settings CHANGE memberperpage memberperpage tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings CHANGE smcols smcols tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings CHANGE memberperpage memberperpage tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings CHANGE maxpostsize maxpostsize smallint(6) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings CHANGE postperpage postperpage tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings CHANGE topicperpage topicperpage tinyint(3) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_settings CHANGE bboffreason closedreason text NOT NULL DEFAULT '';
ALTER TABLE $table_settings ADD postcredits tinyint(1) NOT NULL DEFAULT '0' AFTER memberperpage;
ALTER TABLE $table_settings ADD statstatus tinyint(1) NOT NULL DEFAULT '0' AFTER memliststatus;
ALTER TABLE $table_settings ADD version varchar(30) NOT NULL DEFAULT '' AFTER attachimgpost;
ALTER TABLE $table_settings ADD timeoffset char(3) NOT NULL DEFAULT '' AFTER attachimgpost;
ALTER TABLE $table_settings ADD debug tinyint(1) NOT NULL DEFAULT '' AFTER maxpostsize;
ALTER TABLE $table_settings ADD bbclosed tinyint(1) NOT NULL DEFAULT '0' AFTER bbname, DROP bbstatus, DROP boardurl;
ALTER TABLE $table_settings ADD welcommsgtxt text NOT NULL DEFAULT '' AFTER bbname;
ALTER TABLE $table_settings ADD welcommsg tinyint(1) NOT NULL DEFAULT '0' AFTER bbname;
UPDATE $table_settings SET version='3.0 RC1', statstatus='0', postcredits='1', debug='1', timeoffset='8', bbclosed='0', memberperpage='25';
#����: settings��û�д���

ALTER TABLE $table_smilies CHANGE type type enum('smiley', 'picon') NOT NULL DEFAULT '';
ALTER TABLE $table_smilies CHANGE code code varchar(10) NOT NULL DEFAULT '';
ALTER TABLE $table_smilies CHANGE url url varchar(30) NOT NULL DEFAULT '';
ALTER TABLE $table_smilies CHANGE type type varchar(10) NOT NULL DEFAULT '';
ALTER TABLE $table_smilies DROP PRIMARY KEY, DROP id;
ALTER TABLE $table_smilies ADD id smallint(6) UNSIGNED NOT NULL auto_increment PRIMARY KEY FIRST;
EOT;

$upgrade[8] = <<<EOT
ALTER TABLE $table_threads CHANGE tid tid mediumint(8) UNSIGNED NOT NULL auto_increment;
ALTER TABLE $table_threads CHANGE icon icon varchar(50) NOT NULL DEFAULT '';
ALTER TABLE $table_threads CHANGE lastposter lastposter varchar(25) NOT NULL DEFAULT '';
EOT;

$upgrade[9] = <<<EOT
ALTER TABLE $table_threads CHANGE replies replies smallint(6) UNSIGNED NOT NULL DEFAULT '0';
UPDATE $table_threads SET author='�ο�' WHERE author='Anonymous';
ALTER TABLE $table_threads CHANGE views views smallint(6) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_threads CHANGE author author varchar(25) NOT NULL DEFAULT '';
ALTER TABLE $table_threads ADD creditsrequire smallint(6) UNSIGNED NOT NULL DEFAULT '0' AFTER fid;
ALTER TABLE $table_threads ADD digist tinyint(1) NOT NULL DEFAULT '0' AFTER replies;
#���� ����creditsrequire
EOT;

$upgrade[10] = <<<EOT
ALTER TABLE $table_u2u CHANGE u2uid u2uid int(10) UNSIGNED NOT NULL auto_increment;
ALTER TABLE $table_u2u CHANGE msgto msgto varchar(25) NOT NULL DEFAULT '';
ALTER TABLE $table_u2u CHANGE msgfrom msgfrom varchar(25) NOT NULL DEFAULT '';
ALTER TABLE $table_u2u CHANGE dateline dateline int(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE $table_u2u CHANGE folder folder varchar(10) NOT NULL DEFAULT '';
EOT;

$upgrade[11] = <<<EOT
ALTER TABLE $table_words DROP PRIMARY KEY, DROP id;
ALTER TABLE $table_words ADD id smallint(6) UNSIGNED NOT NULL auto_increment PRIMARY KEY FIRST;
ALTER TABLE $table_words CHANGE replace1 replacement VARCHAR(60) NOT NULL;
ALTER TABLE $table_favorites ADD KEY(tid);
ALTER TABLE $table_words DROP INDEX find;
UPDATE $table_posts SET dateline=UNIX_TIMESTAMP() WHERE dateline='0';
UPDATE $table_threads SET dateline=UNIX_TIMESTAMP() WHERE dateline='0';

CREATE TABLE $table_sessions (
	sid varchar(32) BINARY NOT NULL default '',
	username varchar(25) NOT NULL default '',
	status varchar(20) NOT NULL default '',
	time int(10) UNSIGNED NOT NULL default '',
	ip varchar(20) NOT NULL default '',
	fid smallint(6) UNSIGNED NOT NULL default '',
	action varchar(60) NOT NULL default '',
	sessionvars text NOT NULL default '',
	KEY  (sid),
	KEY  (fid)
);

CREATE TABLE $table_caches (
	cachename varchar(20) NOT NULL default '',
	cachevars text NOT NULL default '',
	KEY  (cachename)
);
EOT;

if(!$step) {
	echo "�������������� CDB 2.0.0 GOLD �� CDB 3.0 RC1,��ȷ��֮ǰ�Ѿ�˳����װ CDB 2.0.0 GOLD<br><br><br>".
		"<b><font color=\"red\">���б���������֮ǰ,��ȷ���Ѿ��ϴ� 3.0 RC1 ��ȫ���ļ���Ŀ¼,���� config.php,�����óɹ�.</font></b><br><br>".
		"<b><font color=\"red\">������ֻ�ܴ� 2.0.0 GOLD �������� 3.0 RC1 ��,����ʹ�ñ�����������汾����,������ܻ��ƻ������ݿ�����.<br><br>".
		"����������Ҫ�޸�ȫ�����ݽṹ,���� 25 �����Ҳ������.����֮ǰ,<br><br><font size=\"8\">�� !!����!!�������е����ݿ�<br>�ϸ��ճ���Ĳ���˳�����,<br>������;�˳������¿�ʼ</font><br><br>".
		"��ѡ����������е�ʱ���������������������κ���������,���ǽ�������ʹ���.<br><br>�����������,�������ָ�ԭ�еı���,����ԭ������½�������<br><br>".
		"�����֮ǰ��װ�� hack,������ϸ����з��޸� CDB ���������ݽṹ,ȷ���������ܼ�������.<br><br>".
		"�������򽫰�������������ģ��,������������,��������֮���޷���¼��̳.����������ģ�����Ҫ,��������֮ǰ���Ʊ���</font></b><br><br>".
		"��ȷ����������Ϊ:<br>1. �ϴ� 3.0 RC1 ���ȫ���ļ���Ŀ¼,���Ƿ������ϵ� 2.0.0 GOLD ��;<br>2. ���ú���Ӧ�� config.php,���������ݱ�ǰ׺<br>3. �ϴ�������($PHP_SELF)�� CDB Ŀ¼��;<br>4. ���б�����,ֱ������������ɵ���ʾ;<br>5. �ָ�Ĭ��ģ��,�������.<br><br>".
		"<a href=\"$PHP_SELF?step=1\">�������ȷ���������Ĳ���,�����������</a>";
}  else {

	echo "���ڽ��������� $step ��, �� 25 �� ...<br><br>";

	if($step <= 12 && $step >= 1) {
		if($step == 1) {
			mysql_query("DROP TABLE $table_usergroups;");
			mysql_query("DROP TABLE $table_sessions;");
			mysql_query("DROP TABLE $table_forumlinks;");
			mysql_query("DROP TABLE $table_subscriptions;");
			mysql_query("DROP TABLE $table_whosonline;");
			mysql_query("DROP TABLE $table_caches;");
			mysql_query("DROP TABLE $table_ranks;");
			mysql_query("DROP TABLE $table_stats;");
			mysql_query("DROP TABLE $table_memo;");
			mysql_query("DROP TABLE $table_announcements;");
		}
		runquery($upgrade[$step - 1]);
	} elseif($step == 13) {
		colmove($table_posts, "usesig", "char(3)", "AFTER useip");
		colmove($table_forums, "description", "text", "AFTER name");
		colmove($table_forums, "displayorder", "tinyint(3)", "AFTER status");
		colmove($table_forums, "posts", "mediumint(8) UNSIGNED", "AFTER displayorder");
		colmove($table_forums, "threads", "smallint(6) UNSIGNED", "AFTER displayorder");
		colmove($table_forums, "moderator", "tinytext", "AFTER displayorder");
		colmove($table_forums, "allowhtml", "tinyint(1)", "AFTER allowsmilies");
		colmove($table_forums, "password", "varchar(12)", "AFTER allowimgcode");
	} elseif($step == 14) {
		colmove($table_members, "status", "varchar(20)", "AFTER gender");
		colmove($table_members, "lastvisit", "int(10) UNSIGNED", "AFTER regdate");
		colmove($table_members, "customstatus", "varchar(20)", "AFTER signature");
		colmove($table_members, "avatar", "varchar(100)", "AFTER bio");
		colmove($table_members, "newsletter", "char(3)", "AFTER showemail");
		colmove($table_members, "bday", "date", "AFTER location");
	} elseif($step == 15) {
		colmove($table_members, "tpp", "tinyint(3) UNSIGNED", "AFTER customstatus");
		colmove($table_members, "ppp", "tinyint(3) UNSIGNED", "AFTER tpp");
		colmove($table_members, "regip", "varchar(20)", "AFTER status");
		colmove($table_members, "timeformat", "varchar(5)", "AFTER ppp");
		colmove($table_members, "dateformat", "varchar(10)", "AFTER ppp");
		colmove($table_members, "theme", "varchar(30)", "AFTER ppp");
		colmove($table_members, "msn", "varchar(40)", "AFTER site");
		colmove($table_members, "yahoo", "varchar(40)", "AFTER site");
		colmove($table_members, "oicq", "varchar(12)", "AFTER site");
		colmove($table_members, "icq", "varchar(12)", "AFTER site");
	} elseif($step == 16) {
		colmove($table_threads, "icon", "varchar(30)", "AFTER creditsrequire");
		colmove($table_threads, "author", "varchar(25)", "AFTER icon");
		colmove($table_threads, "topped", "tinyint(1)", "AFTER replies");
		colmove($table_threads, "dateline", "int(10) UNSIGNED", "AFTER subject");
	} elseif($step == 17) {
		colmove($table_u2u, "new", "char(3)", "AFTER msgfrom");
		colmove($table_u2u, "folder", "varchar(10)", "AFTER msgfrom");
		colmove($table_u2u, "subject", "varchar(75)", "AFTER new");
		colmove($table_settings, "postperpage", "tinyint(3) UNSIGNED", "AFTER creditunit");
		colmove($table_settings, "topicperpage", "tinyint(3) UNSIGNED", "AFTER creditunit");
		colmove($table_settings, "regstatus", "char(3)", "AFTER bbname");
		colmove($table_settings, "closedreason", "text", "AFTER bbclosed");
		colmove($table_settings, "doublee", "char(3)", "AFTER regstatus");
		colmove($table_settings, "sitename", "varchar(50)", "AFTER closedreason");
		colmove($table_settings, "siteurl", "varchar(60)", "AFTER sitename");
		colmove($table_settings, "hottopic", "tinyint(3) UNSIGNED", "AFTER creditunit");
		colmove($table_settings, "floodctrl", "smallint(6) UNSIGNED", "AFTER creditunit");
		colmove($table_settings, "whosonlinestatus", "char(3)", "AFTER memberperpage");
		colmove($table_settings, "vtonlinestatus", "char(3)", "AFTER whosonlinestatus");
		colmove($table_settings, "chcode", "char(3)", "AFTER vtonlinestatus");
		colmove($table_settings, "maxpostsize", "smallint(6) UNSIGNED", "AFTER memberperpage");
		colmove($table_settings, "smcols", "tinyint(3) UNSIGNED", "AFTER maxpostsize");
		colmove($table_settings, "dateformat", "varchar(10)", "AFTER attachimgpost");
		colmove($table_settings, "timeformat", "varchar(5)", "AFTER attachimgpost");
		colmove($table_settings, "maxavatarsize", "tinyint(3) UNSIGNED", "AFTER maxpostsize");
		colmove($table_settings, "gzipcompress", "char(3)", "AFTER chcode");
		colmove($table_settings, "bbrules", "char(3)", "AFTER doublee");
		colmove($table_settings, "bbrulestxt", "text", "AFTER bbrules");
		colmove($table_settings, "moddisplay", "varchar(10)", "AFTER creditunit");
		colmove($table_settings, "emailcheck", "tinyint(1)", "AFTER doublee");
	} elseif($step == 18) {
		boolean($table_settings, "regstatus,doublee,bbrules,whosonlinestatus,vtonlinestatus,chcode,gzipcompress,hideprivate,emailcheck,fastpost,memliststatus,reportpost,bbinsert,smileyinsert,editedby,dotfolders,attachimgpost");
		boolean($table_forums, "status,allowhtml,allowsmilies,allowbbcode,allowimgcode");
		boolean($table_members, "showemail,newsletter");
	} elseif($step == 19) {
		boolean($table_posts, "usesig,bbcodeoff,smileyoff,parseurloff");
	} elseif($step == 20) {
		boolean($table_u2u, "new");
		mysql_query("UPDATE $table_settings SET dateformat='Y-n-j', timeformat='h:i A'");
		mysql_query("UPDATE $table_members SET dateformat='Y-n-j', timeformat='h:i A'");
		mysql_query("ALTER TABLE $table_settings ADD censoruser text NOT NULL default '' AFTER regstatus");
		$query = mysql_query("SELECT lastpost, lastposter, subject, fid FROM $table_threads GROUP BY tid ORDER BY tid");
		while($tinfo = mysql_fetch_array($query)) {
			mysql_query("UPDATE $table_forums SET lastpost='$tinfo[subject]\t$tinfo[lastpost]\t$tinfo[lastposter]' WHERE fid='$tinfo[fid]'");
		}
	} elseif($step == 21) {
		colmove($table_posts, "message", "text", "AFTER dateline");
		colmove($table_posts, "icon", "varchar(30)", "AFTER aid");
		$query = mysql_query("SELECT tid, dateline FROM $table_posts GROUP BY tid ORDER BY pid ASC");
		while($tinfo = mysql_fetch_array($query)) {
			mysql_query("UPDATE $table_threads SET dateline=$tinfo[dateline] WHERE tid='$tinfo[tid]'");
		}
	} elseif($step == 22) {
		$query = mysql_query("SELECT tid, filetype FROM $table_attachments GROUP by tid ORDER BY pid");
		while($attach = mysql_fetch_array($query)) {
			mysql_query("UPDATE $table_threads SET attachment='".substr(strrchr($attach[attachment], "."), 1)."\t$attach[filetype]' WHERE tid='$attach[tid]'");
		}
		$lastmember = mysql_result(mysql_query("SELECT username FROM $table_members ORDER BY uid DESC LIMIT 0, 1"), 0);
		mysql_query("UPDATE $table_settings SET lastmember='$lastmember'");
	} elseif($step == 23) {
		mysql_query("ALTER TABLE $table_settings CHANGE moddisplay moddisplay ENUM('flat', 'selectbox') NOT NULL");
		mysql_query("ALTER TABLE $table_smilies CHANGE type type ENUM('smiley', 'picon') NOT NULL");
		createcache("settings");
		createcache("usergroups");
		createcache("announcements");
		createcache("forums");
		createcache("forumlinks");
		createcache("smilies");
		createcache("picons");
		createcache("censor");
		createcache("news");
	} elseif($step == 24) {
		mysql_query("ALTER TABLE $table_settings ADD digistcredits tinyint(2) NOT NULL default '-1' AFTER postcredits");
		mysql_query("UPDATE $table_settings SET digistcredits='10'");
		mysql_query("ALTER TABLE $table_forums ADD postcredits TINYINT(1) NOT NULL AFTER password"); 
		mysql_query("
			CREATE TABLE $table_memo (
				id int(10) UNSIGNED NOT NULL auto_increment,
				username varchar(25) NOT NULL default '',
				type enum('address', 'notebook', 'collections') NOT NULL,
				dateline int(10) UNSIGNED NOT NULL default '0',
				var1 varchar(50) NOT NULL default '',
				var2 varchar(100) NOT NULL default '',
				var3 tinytext NOT NULL default '',
				KEY (username),
				KEY (type),
				PRIMARY KEY (id)
			)");
		mysql_query("ALTER TABLE $table_threads DROP INDEX tid, DROP INDEX fid, ADD INDEX lastpost (topped, lastpost, fid)");
		mysql_query("ALTER TABLE $table_threads ADD hide TINYINT(1) DEFAULT '0' NOT NULL AFTER replies");
		mysql_query("ALTER TABLE $table_forums CHANGE type type ENUM('group', 'forum', 'sub') DEFAULT 'forum' NOT NULL");
		mysql_query("ALTER TABLE $table_members ADD newu2u TINYINT(1) NOT NULL AFTER ignoreu2u");
		mysql_query("ALTER TABLE $table_themes DROP PRIMARY KEY");
		mysql_query("ALTER TABLE $table_themes ADD INDEX (themename)");
		mysql_query("ALTER TABLE $table_themes ADD id SMALLINT(6) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST");
		mysql_query("ALTER TABLE $table_forums MODIFY postcredits tinyint(1) NOT NULL default '-1'");
		mysql_query("ALTER TABLE $table_themes CHANGE id themeid SMALLINT(6) UNSIGNED NOT NULL AUTO_INCREMENT");
		mysql_query("DELETE FROM {$tablepre}templates");
		$filesize=filesize('./templates.cdb');
		$fp=fopen('./templates.cdb','r');
		$templatesfile=fread($fp,$filesize);
		fclose($fp);
		$templates = explode("|#*CDB TEMPLATE FILE*#|", $templatesfile);
		while (list($key,$val) = each($templates)) {
			$template = explode("|#*CDB TEMPLATE*#|", $val);
			$template[1] = trim(addslashes(addslashes($template[1])));
			mysql_query("INSERT INTO ".$tablepre."templates (name, template)
				VALUES ('".addslashes($template[0])."', '".$template[1]."')");
		}
		mysql_query("DELETE FROM ".$tablepre."templates WHERE name=''");
		mysql_query("UPDATE $table_members SET charset='$charset'");

	} else {
		echo "��ϲ��!���ݽṹ�������! ������Ҫ�����¼��������������:<br>".
			"1. ��ΪȨ�޵���,ȫ����̳Ȩ�޶�����Ϊ��,�������޸�.<br>".
			"2. �� config.php �� \"\$sysemail\" ��Ϊ \"\$adminemail\"<br>".
			"������ɾ��������cp.php,cp2.php�Է�ֹ�����ƻ�";
		@unlink("upgrade3.php");
		@unlink("cp.php");
		@unlink("cp2.php");
	}

	if($step <= 24) {
		if($step % 2) {
			$color = "blue";
			$br = "<br><br>";
		} else {
			$color = "red";
			$br = "";
		}
		echo "<font color=\"$color\">���������ɹ�.<br><br>";
		echo "$br<a href=\"$PHP_SELF?step=".($step + 1)."\">������������һ�� >>></a>";
		echo "<br><br>[ע��] ���������������й�ע�����������,ǧ��Ҫ�ظ����,����,�˳���ر������</font>";
	}

}
function createcache($cachename) {
	global $db, $table_caches;
	$cols = "*";
	$conditions = "";
	$type = "array";
	switch($cachename) {
		case settings:
			$table = $GLOBALS[table_settings];
			$cols = "bbname, regstatus, bbclosed, closedreason, sitename, siteurl, theme, credittitle, creditunit, moddisplay, floodctrl, hottopic, topicperpage, postperpage, memberperpage, maxpostsize, maxavatarsize, smcols, whosonlinestatus, vtonlinestatus, chcode, gzipcompress, postcredits, hideprivate, emailcheck, fastpost, memliststatus, statstatus, debug, reportpost, bbinsert, smileyinsert, editedby, dotfolders, attachimgpost, timeformat, dateformat, timeoffset, version, onlinerecord, lastmember";
			break;
		case usergroups:
			$table = $GLOBALS[table_usergroups];
			$cols = "specifiedusers, status, grouptitle, creditshigher, creditslower, stars, groupavatar, allowavatar, allowsigbbcode, allowsigimgcode";
			$conditions = "ORDER BY creditslower ASC";
			break;
		case announcements:
			$table = $GLOBALS[table_announcements];
			$cols = " id, subject, starttime, endtime";
			$conditions = "ORDER BY starttime";
			break;
		case forums:
			$table = $GLOBALS[table_forums];
			$cols = "fid, type, name, fup";
			$conditions = "WHERE status='1' ORDER BY displayorder";
			break;
		case forumlinks:
			$table = $GLOBALS[table_forumlinks];
			$conditions = "ORDER BY displayorder";
			break;
		case smilies:
			$table = $GLOBALS[table_smilies];
			$conditions = "WHERE type='smiley'";
			break;
		case picons:
			$table = $GLOBALS[table_smilies];
			$conditions = "WHERE type='picon'";
			break;
		case news:
			$table = $GLOBALS[table_news];
			$conditions = "ORDER BY id";
			break;
		case censor:
			$table = $GLOBALS[table_words];
			break;
	}

	$data = array();
	$query = mysql_query("SELECT $cols FROM $table $conditions");
	if($cachename == "settings") {
		$data = mysql_fetch_array($query);
	} elseif($cachename == "censor") {
		$data[find] = $data[replace] = array();
		while($censor = mysql_fetch_array($query)) {
			$data[find][] = "/([^[:alpha:]]|^)$censor[find]([^[:alpha:]]|$)/is";
			$data[replace][] = "\\1$censor[replacement]\\2";
		}	
	} else {
		while($datarow = mysql_fetch_array($query)) {
			$data[] = $datarow;
		}
	}
	$cachevars = addslashes(serialize($data));
	mysql_query("INSERT INTO $table_caches (cachename, cachevars) VALUES ('$cachename', '$cachevars')");
}

function runquery($query) {
	$expquery = explode(";", $query);
	foreach($expquery as $sql) {
		$sql = trim($sql);
		if($sql != "" && $sql[0] != "#") {
			//echo "$sql<br>\n";
			mysql_query($sql) or die(mysql_error());
		}
	}
}

function colmove($table, $name, $type, $position) {
	$query .= "ALTER TABLE $table CHANGE $name {$name}1 $type NOT NULL DEFAULT '';\n";
	$query .= "ALTER TABLE $table ADD $name $type NOT NULL DEFAULT '' $position;\n";
	$query .= "UPDATE $table SET $name={$name}1;\n";
	$query .= "ALTER TABLE $table DROP {$name}1;";
	runquery($query);
}

function boolean($table, $cols) {
	$cols = explode(",", str_replace(" ", "", $cols));
	foreach($cols as $col) {
		$coldata .= "$comma$col=REPLACE(REPLACE(REPLACE(REPLACE($col, 'off', '0'), 'no', '0'), 'on', '1'), 'yes', '1')";
		$comma = ",";
		$query1 .= "ALTER TABLE $table CHANGE $col $col tinyint(1) NOT NULL DEFAULT '0';\n";
	}
	$query .= "UPDATE $table SET $coldata;\n";
	$query .= "$query1\n";
	runquery($query);
}

?>