<?php
//-----------------------------------------------------------------------------
//    Discuz! Board 1.0 Standard - Discuz! ������̳ (PHP & MySQL) 1.0 ��׼��
//-----------------------------------------------------------------------------
//    Copyright(C) Dai Zhikang, Crossday Studio, 2002. All rights reserved
//
//    Crossday ������ www.crossday.com    *Discuz! ����֧�� www.Discuz.net
//-----------------------------------------------------------------------------
//  ����ϸ�Ķ� Discuz! ��ȨЭ��,�鿴��ʹ�� Discuz! ���κβ�����ζ����ȫͬ��
//  Э���е�ȫ������,�����֮��֧�ֹ���������ҵ,�Ͻ�һ��Υ��Э�����Ȩ��Ϊ.
//-----------------------------------------------------------------------------
// Discuz! רע���ṩ��Чǿ�����̳�������,��������ҵ��;,�����빺��ʹ����Ȩ!
//-----------------------------------------------------------------------------


require "./header.php";

$tplnames = "css,header,footer,forumdisplay_whosonline,forumdisplay_thread_lastpost,forumdisplay_thread,forumdisplay,u2uprompt";
$tplnames .= $fastpost ? ",forumdisplay_fastpost" : NULL;
$ismoderator = modcheck($cdbuser);
$useraction = "�����̳��$forum[name]��";

if(!$forum[fid] || $forum[type] == "group") {
	showmessage("ָ������̳�����ڣ��뷵�ء�");
}

if($forum[type] == "forum") {
	$navigation .= "&raquo; $forum[name]";
	$navtitle .= " - $forum[name]";
} else {
	$forumup = $CDB_CACHE_VARS[forums][$forum[fup]][name];
	$navigation .= "&raquo; <a href=\"forumdisplay.php?fid=$forum[fup]\">$forumup</a> &raquo; $forum[name]";
	$navtitle .= " - $forumup - $forum[name]";
}

if($forum[password] && $action == "pwverify") {
	if($pw != $forum[password]) {
		showmessage("����������벻��ȷ�����ܷ��������̳��");
	} else {
		setcookie("fidpw$fid", $pw, "0", $cookiepath, $cookiedomain);
		$CDB_SESSION_VARS["fidpw$fid"] = $pw;
		header("Location: {$boardurl}forumdisplay.php?fid=$fid&sid=$sid");
	}
}

if($forum[viewperm] && !strstr($forum[viewperm], "\t$groupid\t")) {
	showmessage("�Բ��𣬱���ֻ̳���ض��û����Է��ʣ��뷵�ء�");
}

if($forum[password] != $HTTP_COOKIE_VARS["fidpw$fid"] && $forum[password] != $CDB_SESSION_VARS["fidpw$fid"] && $forum[password]) {
	$url = "forumdisplay.php?fid=$fid&action=pwverify";
	eval("\$pwforum = \"".template("forumdisplay_password")."\";");
	showmessage($pwforum, "", 1);
}

$moderatedby = moddisplay($forum[moderator], "forumdisplay");
$moderatedby = !$moderatedby ? "*��ȱ��*" : $moderatedby;

$subexists = 0;
$forumlist = "";
foreach($CDB_CACHE_VARS[forums] as $sub) {
	if($sub[type] == "sub" && $sub[fup] == $fid && (!$sub[viewperm] || ($sub[viewperm] && strstr($sub[viewperm], "\t$groupid\t")))) {
		$subexists = 1;
		break;
	}
}

preloader($subexists ? "index_forum_lastpost,forumdisplay_subforum,forumdisplay_subforums" : NULL);

$subthreads = 0;
if($subexists) {
	$querys = $db->query("SELECT * FROM $table_forums WHERE status='1' AND type='sub' AND fup='$fid' ORDER BY displayorder");
	while($sub = $db->fetch_array($querys)) {
		$subthreads += $sub[threads];
		$forumlist .= forum($sub, "forumdisplay_subforum");
	}
	eval("\$subforums = \"".template("forumdisplay_subforums")."\";");
}

$newpolllink = $allowpostpoll ? "&nbsp;<a href=\"post.php?action=newthread&fid=$fid&poll=yes\"><img src=\"$imgdir/poll.gif\" border=\"0\"></a>" : NULL;

if($page) {
	$start_limit = ($page - 1) * $tpp;
} else {
	$start_limit = 0;
	$page = 1;
}

$forumdisplayadd = $filteradd = "";
if($filter && $filter != "digist") {
	$forumdisplayadd .= "&filter=$filter";
	$filteradd = "AND lastpost>='".($timestamp - $filter)."'";
} elseif($filter == "digist") {
	$forumdisplayadd .= "&filter=digist";
	$filteradd = "AND digist<>'0'";
}

!$ascdesc ? $ascdesc = "DESC" : $forumdisplayadd .= "&ascdesc=$ascdesc";
$dotadd1 = $dotadd2 = "";
if($dotfolders && $cdbuser) {
	$dotadd1 = "DISTINCT p.author AS dotauthor, ";
	$dotadd2 = "LEFT JOIN $table_posts p ON (t.tid=p.tid AND p.author='$cdbuser')";
}

if($whosonlinestatus) {
	$onlinenum = 0;
	$memtally = $table = "";
	$online = array("username" => $cdbuserss, "time" => $timestamp, "action" => "�����̳��".strip_tags($forum[name])."��", "status" => $status);
	$query = $db->query("SELECT username, status, time, fid, action, username='' AS guests FROM $table_sessions WHERE fid='$fid' AND !(username='$cdbuser' AND ip='$onlineip') ORDER BY guests");
	do {
		$onlinenum++;
		$online[time] = gmdate("$timeformat", $online[time] + ($timeoffset * 3600));
		$onlinedetail = "ʱ�䣺$online[time]\n��̳��".strip_tags($forum[name])."\n������$online[action]";

		if($online[status] == "��̳����Ա") {
			$memtally .= "$table<img src=\"$imgdir/online_admin.gif\" align=\"absmiddle\" alt=\"$onlinedetail\"> <a href=\"member.php?action=viewpro&username=".rawurlencode($online[username])."\" title=\"$onlinedetail\"><b><i>$online[username]</i></b></a>";
		} elseif($online[status] == "��������" || $online[status] == "����") {
			$memtally .= "$table<img src=\"$imgdir/online_moderator.gif\" align=\"absmiddle\" alt=\"$onlinedetail\"> <a href=\"member.php?action=viewpro&username=".rawurlencode($online[username])."\" title=\"$onlinedetail\"><b>$online[username]</b></a>";
		} elseif($online[status] == "��ʽ��Ա") {
			$memtally .= "$table<img src=\"$imgdir/online_member.gif\" align=\"absmiddle\" alt=\"$onlinedetail\"> <a href=\"member.php?action=viewpro&username=".rawurlencode($online[username])."\" title=\"$onlinedetail\">$online[username]</a>";
		} else {
			$memtally .= "$table<img src=\"$imgdir/online_guest.gif\" align=\"absmiddle\" alt=\"$onlinedetail\"> <span title=\"$onlinedetail\">�ο�</span>";
		}
		$table = $onlinenum % 7 == 0 ? "</td></tr><tr><td nowrap>" : "</td><td nowrap>";
	} while($online = $db->fetch_array($query));
	$memberlist = "<tr><td nowrap>$memtally</td></tr>";
	eval("\$forumwhosonline = \"".template("forumdisplay_whosonline")."\";");
} else {
	$forumwhosonline = "";
}

if($cdbuser && $newu2u) {
	include "./u2uprompt.php";
}

if($filteradd) {
	$query = $db->query("SELECT COUNT(*) FROM $table_threads WHERE fid='$fid' $filteradd");
	$topicsnum = $db->result($query, 0);
} else {
	$topicsnum = $forum[threads] - $subthreads;
}

$multipage = multi($topicsnum, $tpp, $page, "forumdisplay.php?fid=$fid$forumdisplayadd");
$delthread = $ismoderator && $topicsnum ? " &nbsp; &nbsp; <img src=\"$imgdir/delthread.gif\" border=\"0\" align=\"absmiddle\"> <a href=\"###\" onclick=\"this.document.delthread.submit();\">ɾ��ѡ������</a>" : NULL;
$showthread = $filter == "digist" ? "<a href=\"forumdisplay.php?fid=$fid\">�鿴ȫ������</a>" : "<a href=\"forumdisplay.php?fid=$fid&filter=digist\">�鿴���澫��</a>";

$query = $db->query("SELECT $dotadd1 t.* FROM $table_threads t $dotadd2 WHERE t.fid='$fid' $filteradd ORDER BY t.topped DESC, t.lastpost $ascdesc LIMIT $start_limit, $tpp");
while($thread = $db->fetch_array($query)) {
	if($thread[lastposter] != "�ο�") {
		$lastposter = "<a href=\"member.php?action=viewpro&username=".rawurlencode($thread[lastposter])."\">$thread[lastposter]</a>";
	}
	$lastreplytime = gmdate("$dateformat $timeformat", $thread[lastpost] + ($timeoffset * 3600));
	$lastpost = "$lastreplytime<br>by $lastposter";
	eval("\$lastpostrow = \"".template("forumdisplay_thread_lastpost")."\";");
	if($thread[icon]) {
		$thread[icon] = "<img src=\"$smdir/$thread[icon]\" align=\"absmiddle\">";
	} else {
		$thread[icon] = "&nbsp;";
	}

	if($thread[closed]) {
		if(substr($thread[closed], 0, 5) == "moved") {
			$prefix = "�ƶ���";
			$thread[tid] = substr($thread[closed], 6);
			$thread[replies] = "-";
			$thread[views] = "-";
		}
		$folder = "lock_folder.gif";
	} else {
		$folder = "folder.gif";
		$folder = $lastvisit < $thread[lastpost] && !strstr($HTTP_COOKIE_VARS[oldtopics], "\t$thread[tid]\t") ? "red_$folder" : $folder;
		$folder = $thread[replies] >= $hottopic ? "hot_$folder" : $folder;
		$folder = $dotfolders && $thread[dotauthor] == $cdbuser && $cdbuser ? "dot_$folder" : $folder;
	}
	$folder = "<a href=\"viewthread.php?tid=$thread[tid]\" target=\"_blank\"><img src=\"$imgdir/$folder\" border=\"0\"></a>";

	$thread[subject] = censor($thread[subject]);
	$thread[subject] .= $thread[creditsrequire] ? " - [$credittitle<span class=\"bold\">$thread[creditsrequire]</span>$creditunit]" : NULL;
	$authorinfo = $thread[author] != "�ο�" ? "<a href=\"member.php?action=viewpro&username=".rawurlencode($thread[author])."\">$thread[author]</a>" :$thread[author];
	$authorinfo .= "<br>".gmdate($dateformat, $thread[dateline] + ($timeoffset * 3600));

	$postsnum = $thread[replies] + 1;
	if($postsnum  > $ppp) {
		$posts = $postsnum;
		$topicpages = ceil($posts / $ppp);
		for ($i = 1; $i <= $topicpages; $i++) {
			$pagelinks .= "<a href=\"viewthread.php?tid=$thread[tid]&page=$i\">$i</a> ";
			if($i == 6) {
				$i = $topicpages + 1;
			}
		}
		if($topicpages > 6) {
			$pagelinks .= " .. <a href=\"viewthread.php?tid=$thread[tid]&page=$topicpages\">$topicpages</a> ";
		}
		$multipage2 = "&nbsp;&nbsp;&nbsp;( <img src=\"$imgdir/multipage.gif\" align=\"absmiddle\" boader=0> $pagelinks)";
		$pagelinks = "";
	} else {
		$multipage2 = "";
	}

	if($thread[digist]) {
		switch($thread[digist]) {
			case 1: $level = "��"; break;
			case 2: $level = "��"; break;
			case 3: $level = "��"; break;
		}
		$prefix = "<img src=\"$imgdir/digist.gif\" align=\"absmiddle\">&nbsp;����{$level}��";
	} elseif($thread[topped]) {
		switch($thread[topped]) {
			case 1: $level = "��"; break;
			case 2: $level = "��"; break;
			case 3: $level = "��"; break;
		}
		$prefix = "<img src=\"$imgdir/pin.gif\" align=\"absmiddle\">&nbsp;�ö�{$level}��";
	} elseif($thread[pollopts]) {
		$prefix = "<img src=\"$imgdir/pollsmall.gif\" align=\"absmiddle\">&nbsp;ͶƱ��";
	}
	if($thread[attachment]) {
		$prefix .= attachicon($thread[attachment])." ";
	}
	if($ismoderator) {
		$prefix = "<input type=\"checkbox\" name=\"delete[]\" value=\"$thread[tid]\"> $prefix";
	}

	eval("\$threadlist .= \"".template("forumdisplay_thread")."\";");
	$topicsnum++;
	$prefix = "";
}

if(!$topicsnum) {
	eval("\$threadlist = \"".template("forumdisplay_nothreads")."\";");
}

$check[$filter] = "selected=\"selected\"";
$ascdesc == "ASC" ? $check[asc] = "selected=\"selected\"" : $check[desc] = "selected=\"selected\"";

$forumselect = forumselect();
if($fastpost && ((!$forum[postperm] && $allowpost) || ($forum[postperm] && strstr($forum[postperm], "\t$groupid\t")))) {
	if($signature) {
		$usesigcheck = "checked";
	}
	if((!$forum[postattachperm] && $allowpostattach) || ($forum[postattachperm] && strstr($forum[postattachperm], "\t$groupid\t"))) {
		$enctype = "enctype=\"multipart/form-data\"";
	} else {
		$enctype = "";
	}
	eval("\$fastpost_newthread = \"".template("forumdisplay_fastpost")."\";");
}

eval("\$forumdisplay = \"".template("forumdisplay")."\";");
echo $forumdisplay;

gettotaltime();
eval("\$footer = \"".template("footer")."\";");
echo $footer;

cdb_output();

?>
