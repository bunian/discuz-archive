<?php
//-----------------------------------------------------------------------------
//    Discuz! Board 1.0 Standard - Discuz! ������̳ (PHP & MySQL) 1.0 ��׼��
//-----------------------------------------------------------------------------
//    Copyright(C) Dai Zhikang, Crossday Studio, 2002. All rights reserved
//
//    Crossday ������ www.crossday.com    *Discuz! ����֧�� www.Discuz.net
//-----------------------------------------------------------------------------
//  ����ϸ�Ķ� Discuz! ��ȨЭ��,�鿴��ʹ�� Discuz! ���κβ�����ζ����ȫͬ��
//  Э���е�ȫ������,�����֮��֧�ֹ���������ҵ,�Ͻ�һ��Υ��Э�����Ȩ��Ϊ.
//-----------------------------------------------------------------------------
// Discuz! רע���ṩ��Чǿ�����̳�������,��������ҵ��;,�����빺��ʹ����Ȩ!
//-----------------------------------------------------------------------------


require "./header.php";

if(file_exists("install.php")) {
	@unlink("install.php");
	if(file_exists("install.php")) {
		die("���İ�װ���� install.php �Դ����ڷ������ϣ���ͨ�� FTP ɾ������ܽ���ϵͳ���á�<br>Please delete install.php via FTP!");
	}
}

@set_time_limit(1000);

$useraction = "�޸���̳ϵͳ����";

if($action && $action != "main" && $action != "header" && $action != "menu" && !strpos($action, "log")) {
	$extra = $semicolon = "";
	if(is_array($HTTP_GET_VARS)) {
		foreach($HTTP_GET_VARS as $key => $val) {
			if($key != "action" && $key != "sid") {
				$extra .= "$semicolon$key=$val";
				$semicolon = "; ";
			}
		}
	}

	@$fp = fopen("./datatemp/cplog.php", "a");
	@flock($fp, 3);
	@fwrite($fp, "$cdbuser\t$onlineip\t$timestamp\t$action\t$extra\n");
	@fclose($fp);
}

function cpmsg($message, $url_forward = "", $msgtype = "message") {
	if($GLOBALS[showmsgtype]) {
		showmessage($message, $url_forward);
	} else {
		extract($GLOBALS, EXTR_OVERWRITE);
		if($msgtype == "form") {
			$message = "<form method=\"post\" action=\"$url_forward\"><br><br><br>$message<br><br><br><br>\n".
	        		"<input type=\"submit\" name=\"confirmed\" value=\"ȷ ��\"> &nbsp; \n".
        			"<input type=\"button\" value=\"�� ��\" onClick=\"history.go(-1);\"></form><br>";
		} else {
			if($url_forward) {
				$message .= "<br><br><br><a href=\"$url_forward\">������������û���Զ���ת����������</a>";
				$url_forward = url_rewriter($url_forward);
				$message .= "<script>setTimeout(\"redirect('$url_forward');\", 1250);</script>";
			} elseif(strpos($message, "����")) {
				$message .= "<br><br><br><a href=\"javascript:history.go(-1);\" class=\"mediumtxt\">[ �����ﷵ����һҳ ]</a>";
			}
			$message = "<br><br><br>$message<br><br>";
        	}
        }

?>
<br><br><br><br><br><br><table cellspacing="0" cellpadding="0" border="0" width="60%" align="center">
<tr><td bgcolor="<?=$bordercolor?>"><table border="0" cellspacing="<?=$borderwidth?>" cellpadding="<?=$tablespace?>" width="100%">
<tr class="header"><td>Discuz! ��ʾ</td></tr><tr><td bgcolor="<?=$altbg2?>" align="center">
<table border="0" width="90%" cellspacing="0" cellpadding="0"><tr><td width="100%" align="center">
<?=$message?><br><br>
</td></tr></table></td></tr></table></td></tr></table><br><br><br>
<?

	cpfooter();
	cdbexit();
}

function showforum($forum, $id, $type = "") {
	$dot = array(1 => "<li>", 2 => "<li type=\"circle\">", 3 => "<li type=\"square\">");
	$url = $type == "group" ? "./index.php?gid=$forum[fid]" : "./forumdisplay.php?fid=$forum[fid]";
	$editforum = "<a href=\"admincp.php?action=forumdetail&fid=$forum[fid]\">[�༭]</a> ";
	$hide = !$forum[status] ? " (����)" : NULL;
	echo $dot[$id]."<a href=\"$url\" target=\"_blank\"><b>$forum[name]</b>$hide</a> - ˳��<input type=\"text\" name=\"order[{$forum[fid]}]\" value=\"$forum[displayorder]\" size=\"1\">".
		"&nbsp; ������<input type=\"text\" name=\"moderator[{$forum[fid]}]\" value=\"$forum[moderator]\" size=\"15\"> - ".
		"$editforum<a href=\"admincp.php?action=forumdelete&fid=$forum[fid]\">".
		"[ɾ��]</a><br></li>\n";
}

function showtype($name, $type = "") {
	global $bordercolor, $borderwidth, $tablespace;
	if($type != "bottom") {
		if(!$type) {
			echo "</table></td></tr></table><br><br>\n";
		}
		if(!$type || $type == "top") {

?>
<a name="#<?=$name?>"></a>
<table cellspacing="0" cellpadding="0" border="0" width="90%" align="center">
<tr><td bgcolor="<?=$bordercolor?>">
<table border="0" cellspacing="<?=$borderwidth?>" cellpadding="<?=$tablespace?>" width="100%">
<tr class="header">
<td colspan="2"><?=$name?></td>
</tr>
<?

		}
	} else {
		echo "</table></td></tr></table>\n";
	}
}

function showsetting($setname, $varname, $value, $type = "radio", $comment = "", $width = "60%") {
	global $altbg1, $altbg2;
	$setname = "<b>$setname</b>";
	if($comment) {
		$setname .= "<br>$comment";
	}
	$aligntop = $type == "textarea" || $width != "60%" ?  "valign=\"top\"" : NULL;
	echo "<tr><td width=\"$width\" bgcolor=\"$altbg1\" $aligntop>$setname</td>\n".
		"<td bgcolor=\"$altbg2\">\n";

	if($type == "radio") {
		$value ? $checktrue = "checked" : $checkfalse = "checked";
		echo "<input type=\"radio\" name=\"$varname\" value=\"1\" $checktrue> �� &nbsp; \n".
			"<input type=\"radio\" name=\"$varname\" value=\"0\" $checkfalse> ��\n";
	} elseif($type == "text") {
		echo "<input type=\"text\" size=\"30\" value=\"$value\" name=\"$varname\">\n";
	} elseif($type == "textarea") {
		echo "<textarea rows=\"5\" name=\"$varname\" cols=\"30\">".htmlspecialchars($value)."</textarea>";
	} else {
		echo $type;
	}
	echo "</td></tr>\n";
}

function showmenu($title, $menus = array()) {
	global $borderwidth, $bordercolor, $tablespace, $headertext, $altbg1, $altbg2, $menucount, $expand;

?>
<tr><td bgcolor="<?=$altbg1?>"><a name="#<?=$menucount?>"></a>
<table cellspacing="0" cellpadding="0" border="0" width="100%" align="center"> 
<tr><td bgcolor="<?=$bordercolor?>"> 
<table border="0" cellspacing="<?=$borderwidth?>" cellpadding="<?=$tablespace?>" width="100%"> 
<?

	if(is_array($menus)) {
		$menucount++;
		$expanded = preg_match("/(^|_)$menucount($|_)/is", $expand);
		echo "<tr><td width=\"100%\" class=\"header\"><img src=\"images/common/".($expanded ? "minus" : "plus").".gif\"><a href=\"admincp.php?action=menu&expand=$expand&change=$menucount#$menucount\" style=\"color: $headertext\">$title</td></tr>\n";
		if($expanded) {
			foreach($menus as $menu) {
				echo "<tr><td bgcolor=\"$altbg2\" onMouseOver=\"this.style.backgroundColor='$altbg1'\" onMouseOut=\"this.style.backgroundColor='$altbg2'\"><img src=\"images/common/spacer.gif\"><a href=\"".url_rewriter($menu[url])."\" target=\"main\">$menu[name]</a></td></tr>";
			}
		}
	} else {
		echo "<tr><td width=\"100%\" class=\"header\"><img src=\"images/common/plus.gif\"><a href=\"".url_rewriter($menus)."\" target=\"main\" style=\"color: $headertext\">$title</a></td></tr>\n";
	}
	echo "</table></td></tr></table></td></tr>";
}

function sqldumptable($table, $startfrom = 0, $currsize = 0) {
	global $db, $multivol, $sizelimit, $startrow;

	$offset = 64;
	if(!$startfrom) {
		$tabledump = "DROP TABLE IF EXISTS $table;\n";
		$tabledump .= "CREATE TABLE $table (\n";

		$firstfield = 1;

		$fields = $db->query("SHOW FIELDS FROM $table");
		while ($field = $db->fetch_array($fields)) {
			if (!$firstfield) {
				$tabledump .= ",\n";
			} else {
				$firstfield = 0;
			}
			$tabledump .= "\t$field[Field] $field[Type]";

			if ($field[Null] != "YES") {
				$tabledump .= " NOT NULL";
			}

			if (!empty($field["Default"])) {
				$tabledump .= " default '$field[Default]'";
			}
			if ($field[Extra] != "") {
				$tabledump .= " $field[Extra]";
			}
		}

		$db->free_result($fields);

		$keys = $db->query("SHOW KEYS FROM $table");
		while ($key = $db->fetch_array($keys)) {
			$kname = $key['Key_name'];
			if ($kname != "PRIMARY" and $key['Non_unique'] == 0) {
				$kname="UNIQUE|$kname";
			}
			if(!is_array($index[$kname])) {
				$index[$kname] = array();
			}
			$index[$kname][] = $key['Column_name'];
		}

		$db->free_result($keys);

		while(list($kname, $columns) = @each($index)){
			$tabledump .= ",\n";
			$colnames = implode($columns, ",");

			if($kname == "PRIMARY"){
				$tabledump .= "\tPRIMARY KEY ($colnames)";
			} else {
				if (substr($kname,0,6) == "UNIQUE") {
					$kname = substr($kname,7);
				}

				$tabledump .= "\tKEY $kname ($colnames)";

			}
		}

		$tabledump .= "\n);\n\n";
	}

	$tabledumped = 0;
	$numrows = $offset;
	while(($multivol && $currsize + strlen($tabledump) < $sizelimit * 1000 && $numrows == $offset) || (!$multivol && !$tabledumped)) {
		$tabledumped = 1;
		if($multivol) {
			$limitadd = "LIMIT $startfrom, $offset";
			$startfrom += $offset;
		}

		$rows = $db->query("SELECT * FROM $table $limitadd");
		$numfields = $db->num_fields($rows);
		$numrows = $db->num_rows($rows);
		while ($row = $db->fetch_row($rows)) {
			$comma = "";
			$tabledump .= "INSERT INTO $table VALUES(";
			for($i = 0; $i < $numfields; $i++) {
				$tabledump .= $comma."'".mysql_escape_string($row[$i])."'";
				$comma = ",";
			}
			$tabledump .= ");\n";
		}
	}

	$startrow = $startfrom;
	$tabledump .= "\n";
	return $tabledump;
}

function splitsql($sql){
	$sql = str_replace("\r", "\n", $sql);
	$ret = array();
	$num = 0;
	$queriesarray = explode(";\n", trim($sql));
	unset($sql);
	foreach($queriesarray as $query) {
		$queries = explode("\n", trim($query));
		foreach($queries as $query) {
			$ret[$num] .= $query[0] == "#" ? NULL : $query;
		}
		$num++;
	}			
	return($ret);
}

function cpheader() {
	if($GLOBALS[showmsgtype] == "cdb_with_header") {
		loadtemplates("css,header,footer,showmessage");
		extract($GLOBALS, EXTR_OVERWRITE);
		eval("\$css = \"".template("css")."\";");
		eval("\$header = \"".template("header")."\";");
		echo $header;
	} elseif(!$GLOBALS[showmsgtype]) {
		global $css, $bgcode, $text, $charset;

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$charset?>">
<?=$css?>

<script language="JavaScript">
function checkall(form) {
	for(var i = 0;i < form.elements.length; i++) {
		var e = form.elements[i];
		if (e.name != 'chkall' && e.disabled != true) {
			e.checked = form.chkall.checked;
		}
	}
}
function Popup(url, window_name, window_width, window_height) {
	var settings = "toolbar=no,location=no,directories=no,"+"status=no,menubar=no,scrollbars=yes,"+"resizable=yes,width="+window_width+",height="+window_height;
	NewWindow = window.open(url, window_name, settings);
}

function redirect(url) {
	window.location.replace(url);
}

function redirect(url) {
	window.location.replace(url);
}
</script>
</head>

<body <?=$bgcode?> text="<?=$text?>" leftmargin="10" topmargin="10">
<br>
<?
	}

}

function cpfooter() {
	if($GLOBALS[showmsgtype] == "cdb_with_header") {
		extract($GLOBALS, EXTR_OVERWRITE);
		gettotaltime();
		$debuginfo = $GLOBALS["debuginfo"];
		eval("\$footer = \"".template("footer")."\";");
		echo $footer;
		cdb_output();
	} elseif(!$GLOBALS[showmsgtype]) {
		global $bordercolor, $text, $version;

?>
<br><br><br><br><hr size="0" noshade color="<?=$bordercolor?>" width="80%"><center><font style="font-size: 11px; font-family: Tahoma, Verdana, Arial">
Powered by <a href="http://forum.crossday.com" style="color: <?=$text?>"><b>Discuz!</b> <?=$version?></a> &nbsp;&copy; 2002, <b>
<a href="http://www.crossday.com" target="_blank" style="color: <?=$text?>">Crossday Studio</a></b></font>

</body>
</html>
<?
	}
}

function dirsize($dir) { 
	@$dh = opendir($dir);
	$size = 0;
	while ($file = @readdir($dh)) {
		if ($file != "." and $file != "..") {
			$path = $dir."/".$file;
			if (is_dir($path)) {
				$size += dirsize($path);
			} elseif (is_file($path)) {
				$size += filesize($path);
			}
		}
	}
	@closedir($dh);
	return $size;
}

	
?>