<?php
//-----------------------------------------------------------------------------
//    Discuz! Board 1.0 Standard - Discuz! ������̳ (PHP & MySQL) 1.0 ��׼��
//-----------------------------------------------------------------------------
//    Copyright(C) Dai Zhikang, Crossday Studio, 2002. All rights reserved
//
//    Crossday ������ www.crossday.com    *Discuz! ����֧�� www.Discuz.net
//-----------------------------------------------------------------------------
//  ����ϸ�Ķ� Discuz! ��ȨЭ��,�鿴��ʹ�� Discuz! ���κβ�����ζ����ȫͬ��
//  Э���е�ȫ������,�����֮��֧�ֹ���������ҵ,�Ͻ�һ��Υ��Э�����Ȩ��Ϊ.
//-----------------------------------------------------------------------------
// Discuz! רע���ṩ��Чǿ�����̳�������,��������ҵ��;,�����빺��ʹ����Ȩ!
//-----------------------------------------------------------------------------


if(!defined("IN_CDB")) {
        die("Access Denied");
}

cpheader();

$logs = array();
$logdir = "./datatemp";
$maxlogrows = 500;
$lpp = 30;

$filename = "$logdir/$action.php";
@$logfile = file($filename);
@$fp = fopen($filename, "w");
@flock($fp, 3);
@fwrite($fp, "<?PHP exit(\"Access Denied\"); ?>\n");

for($i = count($logfile) - $maxlogrows; $i < count($logfile); $i++) {
	if(strpos($logfile[$i], "\t")) {
		$logfile[$i] = trim($logfile[$i]);
		$logs[] = $logfile[$i];
		@fwrite($fp, "$logfile[$i]\n");
	}
}
@fclose($fp);

if(!$page) {
	$page = 1;
}
$start = ($page - 1) * $lpp;
$logs = array_reverse($logs);
$num = count($logs);
$multipage = multi($num, $lpp, $page, "admincp.php?action=$action");

for($i = 0; $i < $start; $i++) {
	unset($logs[$i]);
}
for($i = $start + $lpp; $i < $num; $i++) {
	unset($logs[$i]);
}

?>
<table cellspacing="0" cellpadding="0" border="0" width="95%" align="center">
<tr class="multi"><td><?=$multipage?></td></tr>
<tr><td bgcolor="<?=$bordercolor?>">
<table border="0" cellspacing="<?=$borderwidth?>" cellpadding="<?=$tablespace?>" width="100%">
<?

if($action == "illegallog") {

	echo "<tr class=\"header\"><td colspan=\"4\">��������¼</td></tr>\n".
		"<tr class=\"header\" align=\"center\"><td>�����û���</td><td>��������</td><td>IP ��ַ</td><td>ʱ��</td></tr>\n";

	foreach($logs as $logrow) {
		$log = explode("\t", $logrow);
		if(strtolower($log[0]) == strtolower($cdbuserss)) {
			$log[0] = "<b>$log[0]</b>";
		}
		//$log[0] = addslashes($log[0]);
		$log[3] = gmdate("y-n-j H:i", $log[3] + $timeoffset * 3600);

		echo "<tr align=\"center\"><td bgcolor=\"$altbg1\" width=\"25%\">$log[0]</td>\n".
			"<td bgcolor=\"$altbg2\" width=\"25%\">$log[1]</td><td bgcolor=\"$altbg1\" width=\"25%\">$log[2]</td>\n".
			"<td bgcolor=\"$altbg2\" width=\"25%\">$log[3]</td></tr>\n";
	}

} elseif($action == "karmalog") {

	echo "<tr class=\"header\"><td colspan=\"7\">�û����ּ�¼</td></tr>\n".
		"<tr class=\"header\" align=\"center\"><td>�û���</td><td>ͷ��</td><td>ʱ��</td><td>�������û�</td><td>����</td><td>����</td></tr>\n";

	foreach($logs as $logrow) {
		$log = explode("\t", $logrow);
		$log[0] = "<a href=\"member.php?action=viewpro&username=".rawurlencode($log[0])."\" target=\"_blank\">$log[0]";
		$log[3] = "<a href=\"member.php?action=viewpro&username=".rawurlencode($log[3])."\" target=\"_blank\">$log[3]</a>";
		//$log[0] = addslashes($log[0]);
		if($log[4] == $cdbuserss) {
			$log[4] = "<b>$log[4]</b>";
		}
		$log[2] = gmdate("y-n-j H:i", $log[2] + $timeoffset * 3600);
		$log[4] = $log[4] > 0 ? "+$log[4]" : "<b>$log[4]</b>";
		$log[6] = "<a href=\"./viewthread.php?tid=$log[5]\" target=\"_blank\">".wordscut($log[6], 20)."</a>";

		echo "<tr align=\"center\"><td bgcolor=\"$altbg1\" width=\"15%\">$log[0]</a></td><td bgcolor=\"$altbg2\" width=\"12%\">$log[1]</td>\n".
			"<td bgcolor=\"$altbg1\" width=\"18%\">$log[2]</td><td bgcolor=\"$altbg2\" width=\"15%\">$log[3]</td>\n".
			"<td bgcolor=\"$altbg1\" width=\"8%\">$log[4]</td><td bgcolor=\"$altbg2\" width=\"28%\">$log[6]</td></tr>\n";
	}

} elseif($action == "modslog") {

	echo "<tr class=\"header\"><td colspan=\"7\">����������¼</td></tr>\n".
		"<tr class=\"header\" align=\"center\"><td width=\"10%\">�û���</td><td width=\"15%\">ͷ��</td><td width=\"10%\">IP ��ַ</td><td width=\"18%\">ʱ��</td><td width=\"15%\">��̳</td><td width=\"19%\">����</td><td width=\"13%\">����</td></tr>\n";

	foreach($logs as $logrow) {
		$log = explode("\t", $logrow);
		//$log[0] = addslashes($log[0]);
		if($log[0] != $cdbuser) {
			$log[0] = "<b>$log[0]</b>";
		}
		$log[3] = gmdate("y-n-j H:i", $log[3] + $timeoffset * 3600);
		$log[5] = "<a href=\"./forumdisplay.php?fid=$log[4]\" target=\"_blank\">$log[5]</a>";
		$log[7] = "<a href=\"./viewthread.php?tid=$log[6]\" target=\"_blank\">".wordscut($log[7], 15)."</a>";

		echo "<tr align=\"center\"><td bgcolor=\"$altbg1\">$log[0]</td>\n".
			"<td bgcolor=\"$altbg2\">$log[1]</td><td bgcolor=\"$altbg1\">$log[2]</td>\n".
			"<td bgcolor=\"$altbg2\">$log[3]</td><td bgcolor=\"$altbg1\">$log[5]</td>\n".
			"<td bgcolor=\"$altbg2\">$log[7]</td><td bgcolor=\"$altbg1\">$log[8]</td></tr>\n";
	}

} elseif($action == "cplog") {

	echo "<tr class=\"header\"><td colspan=\"5\">ϵͳ������¼</td></tr>\n".
		"<tr class=\"header\" align=\"center\"><td width=\"15%\">����Ա</td><td width=\"15%\">IP ��ַ</td><td width=\"18%\">ʱ��</td><td width=\"15%\">����</td><td width=\"37%\">����</td></tr>\n";

	foreach($logs as $logrow) {
		$log = explode("\t", $logrow);
		//$log[0] = addslashes($log[0]);
		if($log[0] != $cdbuser) {
			$log[0] = "<b>$log[0]</b>";
		}
		$log[2] = gmdate("y-n-j H:i", $log[2] + $timeoffset * 3600);

		echo "<tr align=\"center\"><td bgcolor=\"$altbg1\">$log[0]</td>\n".
			"<td bgcolor=\"$altbg2\">$log[1]</td><td bgcolor=\"$altbg1\">$log[2]</td>\n".
			"<td bgcolor=\"$altbg2\">$log[3]</td><td bgcolor=\"$altbg1\">$log[4]</td></tr>\n";
	}

}

?>
</table></td></tr><tr class="multi"><td><?=$multipage?></td></tr>
</table>