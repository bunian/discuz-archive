<?php

$xmllang = "
<okbtn>確定</okbtn>
<ctnbtn>繼續</ctnbtn>
<fileName>文件名</fileName>
<size>文件大小</size>
<stat>上傳進度</stat>
<browser>瀏覽</browser>
<delete>刪除</delete>
<return>返回</return>
<upload>上傳</upload>
<okTitle>上傳完成</okTitle>
<okMsg>文件上傳成功</okMsg>
<uploadTitle>正在上傳</uploadTitle>
<uploadMsg1>總共有</uploadMsg1>
<uploadMsg2>個文件等待上傳,正在上傳第</uploadMsg2>
<uploadMsg3>個文件</uploadMsg3>
<bigFile>文件過大</bigFile>
<uploaderror>上傳失敗</uploaderror>
";

?>