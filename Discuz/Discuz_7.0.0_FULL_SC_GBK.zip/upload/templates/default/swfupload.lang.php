<?php

$xmllang = "
<okbtn>确定</okbtn>
<ctnbtn>继续</ctnbtn>
<fileName>文件名</fileName>
<size>文件大小</size>
<stat>上传进度</stat>
<browser>浏览</browser>
<delete>删除</delete>
<return>返回</return>
<upload>上传</upload>
<okTitle>上传完成</okTitle>
<okMsg>文件上传成功</okMsg>
<uploadTitle>正在上传</uploadTitle>
<uploadMsg1>总共有</uploadMsg1>
<uploadMsg2>个文件等待上传,正在上传第</uploadMsg2>
<uploadMsg3>个文件</uploadMsg3>
<bigFile>文件过大</bigFile>
<uploaderror>上传失败</uploaderror>
";

?>