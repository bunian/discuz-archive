﻿document.write("<li><a href=\"install.htm\" target=\"_self\">環境要求</a>");
document.write("<li><a href=\"install_steps.htm\" target=\"_self\">安裝詳細流程</a>");
document.write("<li><a href=\"install_files.htm\" target=\"_self\">文件及目錄結構</a>");
document.write("<li><a href=\"install_faq.htm\" target=\"_self\">安裝常見問題</a>");
document.write("<li><a href=\"install_server_win.htm\" target=\"_self\">附錄：Discuz! 本地運行環境構建(Windows)</a>");