﻿document.write("<li><a href=\"using.htm\" target=\"_self\">使用常見問題首頁</a>");
document.write("<li><a href=\"using_config.htm\" target=\"_self\">config.inc.php 配置問題</a>");
document.write("<li><a href=\"using_general.htm\" target=\"_self\">日常使用</a>");
document.write("<li><a href=\"using_styles.htm\" target=\"_self\">風格與模板</a>");
document.write("<li><a href=\"using_permissions.htm\" target=\"_self\">用戶權限設定</a>");
document.write("<li><a href=\"using_server.htm\" target=\"_self\">服務器相關</a>");
document.write("<li><a href=\"using_tips.htm\" target=\"_self\">經驗技巧</a>");