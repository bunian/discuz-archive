﻿document.write("<li><a href=\"upgrade.htm\" target=\"_self\">升級指南首頁</a>");
document.write("<li><a href=\"upgrade_changelog.htm\" target=\"_self\">版本更新記錄</a>");