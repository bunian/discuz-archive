﻿document.write("<li><a href=\"intro.htm\" target=\"_self\">Discuz! 產品概況首頁</a>");
document.write("<li><a href=\"intro_features.htm\" target=\"_self\">Discuz! 產品特色</a>");
document.write("<li><a href=\"intro_tech.htm\" target=\"_self\">Discuz! 新技術概述</a>");
document.write("<li><a href=\"intro_history.htm\" target=\"_self\">Discuz! 產品發展歷程</a>");
document.write("<li><a href=\"intro_corp.htm\" target=\"_self\">康盛科技簡介</a>");