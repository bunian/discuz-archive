﻿<?php

// Misc Language Pack for Discuz! Version 1.0.0
// Translated by Crossday

$language = array
(
	'post_hidden' => '**** The message has been hidden by the author *****',
	'post_hide_credits' => 'Below message is for members whose credits are greater than $creditsrequire',
	'post_hide_credits_hidden' => '**** Hidden to credits lower than $creditsrequire ****',
	'post_hide_reply' => 'Below message is for replyers of this thread',
	'post_hide_reply_hidden' => '**** Hidden to non-reply visitors *****',
	'post_reply_quote' => 'Originally posted by $thaquote[author] at $time',
	'post_edit' => '\n\n[[i] Last edited by $discuz_user at $edittime [/i]]',
	'post_edit_regexp' => '/\n{2}\[\[i\] Last edited by .+? at .+? \[\/i\]\]$/s',

	'attach' => 'Attachment',
	'attach_credits_policy' => 'View credits policy',
	'attach_img' => 'Image Attachment',
	'attach_readperm' => 'Reading Access',
	'attach_img_zoom' => 'Click here to open new windows\\nCTRL+Mouse wheel to zoom in/out',
	'attach_download_count' => 'Download count'
);

?>