﻿<?php

// Email Pack for Discuz! Version 1.0.1
// Translated by Crossday

// ATTENTION: Please add slashes(\) before single & double quotes( ' & " )

$language = array
(

	'get_passwd_subject' =>		'[Discuz!] Getting Back Your Password',
	'get_passwd_message' =>		'
$member[username],
This email has been sent from $bbname.

You have received this email because a user account password recovery was instigated
by you on our forums.

----------------------------------------------------------------------
IMPORTANT!
----------------------------------------------------------------------

If you did not request this password change, please IGNORE and DELETE this email
immediately. Only continue if you wish your password to be reset!

----------------------------------------------------------------------
Password Resetting Instructions
----------------------------------------------------------------------

Simply click on the following link in 3 days after your requisition to resetting your
password:

{$boardurl}member.php?action=getpasswd&uid=$member[uid]&id=$idstring

(AOL Email users may need to cut and paste the link into your web browser).

We will ask you for a new password, after submitted, you will be able to login using
your new password. You can change this password at any time from your Member\'s CP.

IP address of sender: $onlineip



Regards,

The $bbname team.
$boardurl',


	'email_verify_subject' =>	'[Discuz!] Email Validate',
	'email_verify_message' =>	'
$discuz_user,
This email has been sent from $bbname.

You have received this email because this address was used during registration or an
email change of member\'s profile in our forums. If you have not been to our forums,
please disregard this email. You do not need to unsubscribe or take any further action.

----------------------------------------------------------------------
Activation Instructions
----------------------------------------------------------------------

You are a new member or have just modified your email address, we require that you
\"validate\" your email address which was used in our forums. This protects against
unwanted spam and malicious abuse.

To activate your account, simply click on the following link:

{$boardurl}member.php?action=activate&uid=$discuz_uid&id=$idstring

(AOL Email users may need to cut and paste the link into your web browser).

Thank you for visiting and enjoy your stay!



Regards,

The $bbname team.
$boardurl',


	'email_notify_subject' =>	'[Discuz!] $thread[subject] had new reply(s)',
	'email_notify_message' =>	'
Hi,
This email has been sent from $bbname.

You have received this email because $discuz_user has just posted a reply to a topic
that you have subscribed to. If you have not been to our forums, please disregard this
email. You do not need to unsubscribe or take any further action..

----------------------------------------------------------------------
$thread[subject]
----------------------------------------------------------------------

The topic can be found here:
{$boardurl}viewthread.php?tid=$tid


There may be more replies to this topic, but we will not send this notification again
in 24 hours. This is to limit the amount of mail that is sent to your inbox.



Regards,

The $bbname team.
$boardurl',


	'add_member_subject' =>		'[Discuz!] You have been added to be a member of our forum',
	'add_member_message' => 	'
$newusername,
This email has been sent from $bbname.

I am $discuz_user, the administrator of $bbname, you have received this email
because you were add to be a member of our forums. 

----------------------------------------------------------------------
IMPORTANT!
----------------------------------------------------------------------

If you are not interested in our forums, you can ignore this email.

----------------------------------------------------------------------
About the Account
----------------------------------------------------------------------

Board Name: $bbname
Board URL: $boardurl

Username: $newusername
Password: $newpassword

You are able to login to our forums with your account. Wish you enjoy your stay.



Regards,

The $bbname team.
$boardurl',


	'email_to_friend_subject' => 'Recommending to you: $thread[subject]',
	'email_to_friend_message' => '
$sendtoname,
This email has been sent from $discuz_userss from the $bbname.

You have received this email because one of our members has recommended a thread to you
via "Email to Friend" provided by our board. If you are not interested to such a topic,
please disregard this email. You do not need to unsubscribe or take any further action.

----------------------------------------------------------------------
Beginning of the Original Message
----------------------------------------------------------------------

$message

----------------------------------------------------------------------
End of the Original Message
----------------------------------------------------------------------

This is NOT a official mail from $bbname, we will takes no responsibility for
such kind of messages sent through our system.',


	'moderate_member_subject' =>	'[Discuz!] Notice of your Registration',
	'moderate_member_message' =>	'
$member[username],
This email has been sent from $bbname.

You have received this email because this address was used during registration in our
forums, and the administrator has chosen to moderate all new members manually. Your
request of registration has been received, this email is going to inform you the result
of your request.

----------------------------------------------------------------------
Information & Result
----------------------------------------------------------------------

Username: $member[username]
Reg. Date: $member[regdate]
Submit Date: $member[submitdate]
Submit Times: $member[submittimes]
Reg. Reason: $member[message]

Mod. Result: $member[operation]
Mod. Date: $member[moddate]
Admin.: $discuz_userss
Message: $member[remark]

----------------------------------------------------------------------
About the Result
----------------------------------------------------------------------

Validated:
	Your request has been approved and you are now the regular member of our forums.

Invalidated:
	You have not complete the required information or fallen short of our qualification of
	new members. You can revise your message, complete the required fields and try again.

Deleted:
	We are sorry to inform you that your register information was not fit for our forums,
	or the amount of members has been over our expectancy. Your registration was finally
	invalidated.



Regards,

The $bbname team.
$boardurl',
);

?>