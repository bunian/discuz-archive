﻿<?php

// Moderation Pack for Discuz! Version 1.0.0
// Created by Crossday

$modactioncode = array
(

	'EDT' => 'edited',

	'DEL' => 'deleted',
	'DLP' => 'reply-deleted',
	'PRN' => 'pruned',
	'UDL' => 'undeleted',

	'DIG' => 'added to digest',
	'UDG' => 'removed from digest',

	'CLS' => 'closed',
	'OPN' => 'opened',

	'STK' => 'sticked',
	'UST' => 'un-sticked',

	'SPL' => 'splited',
	'MRG' => 'merged',

	'HLT' => 'highlighted',
	'UHL' => 'un-highlighted',

	'BMP' => 'bumped',

	'MOV' => 'moved',
	'TYP' => 're-typed',

	'RFD' => 'refunded',

	'MOD' => 'moderated',

	'ABL' => 'added to blog',
	'RBL' => 'removed from blog'

);

?>