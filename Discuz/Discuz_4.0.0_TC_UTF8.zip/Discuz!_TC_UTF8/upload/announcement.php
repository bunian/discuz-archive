<?php

/*
	[DISCUZ!] announcement.php - show board announcements
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005-10-20 07:35
*/

require_once './include/common.inc.php';
require_once DISCUZ_ROOT.'./include/discuzcode.func.php';

$discuz_action = 21;

$total = 0;
$query = $db->query("SELECT id, starttime, endtime FROM {$tablepre}announcements ORDER BY displayorder, starttime DESC, id DESC");
while($announce = $db->fetch_array($query)) {
	if($timestamp >= $announce['starttime'] && ($timestamp <= $announce['endtime'] || !$announce['endtime'])) {
		$total++;
		if(isset($id) && $announce['id'] == $id) {
			$page = ceil($total / $ppp);
		}
	}
}

if($total != $db->num_rows($query)) {
	$db->query("DELETE FROM {$tablepre}announcements WHERE endtime<>'0' AND endtime<'$timestamp'");
	require_once DISCUZ_ROOT.'./include/cache.func.php';
	updatecache('announcements');
	updatecache('announcements_forum');
}

if(!$total) {
	showmessage('announcement_nonexistence');
}

$page = (empty($page) || !ispage($page)) && empty($id) ? 1 : max(1, $page);
$start_limit = ($page - 1) * $ppp;

$multipage = multi($total, $ppp, $page, 'announcement.php');

$announcelist = array();
$query = $db->query("SELECT * FROM {$tablepre}announcements WHERE endtime='0' OR endtime>'$timestamp' ORDER BY displayorder, starttime DESC, id DESC LIMIT $start_limit, $ppp");

if((!empty($id) && !$page) || !$db->num_rows($query)) {
	showmessage('undefined_action');
}

while($announce = $db->fetch_array($query)) {
	$announce['authorenc'] = rawurlencode($announce['author']);
	$announce['starttime'] = gmdate($dateformat, $announce['starttime'] + $timeoffset * 3600);
	$announce['endtime'] = $announce['endtime'] ? gmdate($dateformat, $announce['endtime'] + $timeoffset * 3600) : NULL;
	$announce['message'] = nl2br(discuzcode($announce['message'], 0, 0, 1, 1, 1, 1, 1));

	$announcelist[] = $announce;
}

include template('announcement');

?>