<?php

/*
	[DISCUZ!] include/threadpay.inc.php - pay for thread
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005-3-7 17:16
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!isset($extcredits[$creditstrans])) {
	showmessage('credits_transaction_disabled');
}

if($thread['rate']) {
	$query = $db->query("SELECT pid FROM {$tablepre}posts WHERE tid='$tid' AND invisible='0' AND first='1'");
	$pid = $db->result($query, 0);
}

$query = $db->query("SELECT COUNT(*) AS payers, SUM(netamount) AS income FROM {$tablepre}paymentlog WHERE tid='$tid'");
$payment = $db->fetch_array($query);

$thread['payers'] = $payment['payers'];
$thread['netprice'] = !$maxincperthread || ($maxincperthread && $payment['income'] < $maxincperthread) ? floor($thread['price'] * (1 - $creditstax)) : 0;
$thread['creditstax'] = sprintf('%1.2f', $creditstax * 100).'%';
$thread['endtime'] = $maxchargespan ? gmdate("$dateformat $timeformat", $timestamp + $maxchargespan * 3600 + $timeoffset * 3600) : 0;

if($thread['replies'] >= 1) {
	include_once language('misc');

	$postlist = array();
	$query = $db->query("SELECT * FROM {$tablepre}posts WHERE tid='$tid' AND invisible='0' AND first='0' ORDER BY dateline DESC LIMIT 10");
	while($post = $db->fetch_array($query)) {
		$post['thisbg'] = $thisbg = isset($thisbg) && $thisbg == 'altbg1' ? 'altbg2' : 'altbg1';
		$post['dateline'] = gmdate("$dateformat $timeformat", $post['dateline'] + $timeoffset * 3600);;
		$post['message'] = preg_replace("/\[hide=?\d*\](.+?)\[\/hide\]/is", "[b]$language[post_hidden][/b]", $post['message']);
		$post['message'] = discuzcode($post['message'], $post['smileyoff'], $post['bbcodeoff'], $post['htmlon'], $forum['allowsmilies'], $forum['allowbbcode'], $forum['allowimgcode'], $forum['allowhtml'], $forum['jammer']);

		$postlist[] = $post;
	}
}

if($postlist) {
	$postlist = array_reverse($postlist);
}

include template('viewthread_pay');
dexit();

?>