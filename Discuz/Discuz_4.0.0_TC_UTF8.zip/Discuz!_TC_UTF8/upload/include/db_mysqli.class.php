<?php

/*
	[DISCUZ!] include/db_mysql.class.php - MySQL 3.23,4.x class
	This is NOT a freeware, use is subject to license terms

	Version: 4.0.0
	Web: http://www.comsenz.com
	Copyright: 2001-2005 Comsenz Technology Ltd.
	Last Modified: 2005-3-8 14:53
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class dbstuff {
	var $conn;
	var $querynum = 0;

	function connect($dbhost, $dbuser, $dbpw, $dbname = '', $pconnect = 0) {
		if($pconnect) {
			if(!@$this->conn = mysqli_pconnect($dbhost, $dbuser, $dbpw)) {
				$this->halt('Can not connect to MySQL server');
			}
		} else {
			if(!@$this->conn = mysqli_connect($dbhost, $dbuser, $dbpw)) {
				$this->halt('Can not connect to MySQL server');
			}
		}

		if($dbname) {
			mysqli_select_db($this->conn, $dbname);
		}

		//mysqli_query($this->conn, "SET NAMES 'gbk'");
	}

	function select_db($dbname) {
		return mysqli_select_db($this->conn, $dbname);
	}

	function fetch_array($query, $result_type = MYSQLI_ASSOC) {
		return mysqli_fetch_array($query, $result_type);
	}

	function query($sql, $type = '') {
		$func = $type == 'UNBUFFERED' && @function_exists('mysqli_unbuffered_query') ?
			'mysqli_unbuffered_query' : 'mysqli_query';
		if(!($query = $func($this->conn, $sql)) && $type != 'SILENT') {
			$this->halt('MySQL Query Error', $sql);
		}
		$this->querynum++;
		return $query;
	}

	function affected_rows() {
		return mysqli_affected_rows($this->conn);
	}

	function error() {
		return mysqli_error($this->conn);
	}

	function errno() {
		return intval(mysqli_errno($this->conn));
	}

	function result($query, $row) {
		$query = mysqli_result($query, $row);
		return $query;
	}

	function num_rows($query) {
		$query = mysqli_num_rows($query);
		return $query;
	}

	function num_fields($query) {
		return mysqli_num_fields($query);
	}

	function free_result($query) {
		return mysqli_free_result($query);
	}

	function insert_id() {
		$id = mysqli_insert_id();
		return $id;
	}

	function fetch_row($query) {
		$query = mysqli_fetch_row($query);
		return $query;
	}

	function version() {
		return mysqli_get_server_info();
	}

	function close() {
		return mysqli_close();
	}

	function halt($message = '', $sql = '') {
		require_once DISCUZ_ROOT.'./include/db_mysql_error.inc.php';
	}
}

?>