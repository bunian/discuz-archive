﻿<?php

// P.M. Pack for Discuz! Version 1.0
// Translated by Crossday

// ATTENTION: Please add slashes(\) before (') and (")

$language = array
(

	'reason_moderate_subject' => '[Discuz!] 您發表的主題被執行管理操作',
	'reason_moderate_message' => '這是由論壇系統自動發送的通知短消息。

[b]以下您所發表的主題被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 執行 {$modaction} 操作。[/b]

[b]主題:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]發表時間:[/b] {$thread[dateline]}
[b]所在論壇:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]操作理由:[/b] {$reason}

如果您對本管理操作有異議，請與我取得聯繫。',

	'reason_delete_post_subject' => '[Discuz!] 您發表的回復被執行管理操作',
	'reason_delete_post_message' => '這是由論壇系統自動發送的通知短消息。

[b]以下您所發表的回復被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 執行 刪除 操作。[/b]
[quote]{$post[message]}[/quote]

[b]發表時間:[/b] {$post[dateline]}
[b]所在論壇:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]

[b]操作理由:[/b] {$reason}

如果您對本管理操作有異議，請與我取得聯繫。',

	'reason_move_subject' => '[Discuz!] 您發表的主題被執行管理操作',
	'reason_move_message' => '這是由論壇系統自動發送的通知短消息。

[b]以下您所發表的主題被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 執行 移動 操作。[/b]

[b]主題:[/b] [url={$boardurl}viewthread.php?tid={$thread[tid]}]{$thread[subject]}[/url]
[b]發表時間:[/b] {$thread[dateline]}
[b]原論壇:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]
[b]目標論壇:[/b] [url={$boardurl}forumdisplay.php?fid={$toforum[fid]}]{$toforum[name]}[/url]

[b]操作理由:[/b] {$reason}

如果您對本管理操作有異議，請與我取得聯繫。',

	'rate_reason_subject' => '[Discuz!] 您發表的帖子被評分',
	'rate_reason_message' => '這是由論壇系統自動發送的通知短消息。

[b]以下您所發表的帖子被 [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url] 評分。[/b]
[quote]{$post[message]}[/quote]

[b]發表時間:[/b] {$post[dateline]}
[b]所在論壇:[/b] [url={$boardurl}forumdisplay.php?fid={$fid}]{$forumname}[/url]
[b]所在主題:[/b] [url={$boardurl}viewthread.php?tid={$tid}&page={$page}#pid{$pid}]{$thread[subject]}[/url]

[b]評分分數:[/b] {$ratescore}
[b]操作理由:[/b] {$reason}',

	'transfer_subject' => '[Discuz!] 您收到一筆積分轉賬',
	'transfer_message' => '這是由論壇系統自動發送的通知短消息。

[b]您收到一筆來自他人的積分轉賬。[/b]

[b]來自:[/b] [url={$boardurl}viewpro.php?uid={$discuz_uid}][i]{$discuz_user}[/i][/url]
[b]時間:[/b] {$transfertime}
[b]積分:[/b] {$extcredits[$creditstrans][title]} {$amount} {$extcredits[$creditstrans][unit]}
[b]淨收入:[/b] {$extcredits[$creditstrans][title]} {$netamount} {$extcredits[$creditstrans][unit]}

[b]附言:[/b] {$transfermessage}

詳情請[url={$boardurl}memcp.php?action=credits&operation=creditslog]點擊這裡[/url]訪問您的積分轉賬與兌換記錄。',

	'reportpost_subject'	=> '[Discuz!] $discuz_user 向您報告一篇帖子',
	'reportpost_message'	=> '[i]{$discuz_user}[/i] 向您報告以下的帖子，詳細內容請訪問:
[url]{$posturl}[/url]

他/她的報告理由是: {$reason}',

	'addfunds_subject' => '[Discuz!] 積分充值成功完成',
	'addfunds_message' => '這是由論壇系統自動發送的通知短消息。

[b]您提交的積分充值請求已成功完成，相應數額的積分已經存入您的積分賬戶。[/b]

[b]訂單號:[/b] {$order[orderid]}
[b]提交時間:[/b] {$submitdate}
[b]確認時間:[/b] {$confirmdate}

[b]支出:[/b] 人民幣 {$order[price]} 元
[b]收入:[/b] {$extcredits[$creditstrans][title]} {$order[amount]} {$extcredits[$creditstrans][unit]}

詳情請[url={$boardurl}memcp.php?action=credits&operation=creditslog]點擊這裡[/url]訪問您的積分轉賬與兌換記錄。'

);

?>