﻿<?php

// Message Pack for Discuz! WAP Version 1.0.0
// Created by Crossday

$lang = array
(

	'username' => '用戶名/UID',
	'password' => '密碼',
	'submit' => '提交',
	'page' => '頁號',
	'reply' => '回復',
	'delete' => '刪除',
	'forum' => '論壇',
	'thread' => '主題',
	'type' => '分類',
	'subject' => '標題',
	'message' => '內容',
	'next_page' => '下頁',
	'next_thread' => '下一主題',
	'end' => '結束',
	'unread' => '未讀',
	'sub_forums' => '子論壇',

	'not_loggedin' => '請登錄後使用本功能',
	'wap_disabled' => 'WAP 功能未啟用',
	'board_closed' => '論壇目前臨時關閉',
	'undefined_action' => '未定義操作',

	'home' => '首頁',
	'home_online' => '在線',
	'home_members' => '會員',
	'home_newpm' => '條新短消息',
	'home_forums' => '=論壇分類=',
	'home_tools' => '==工具箱==',

	'login' => '登錄',
	'login_succeed' => '{$discuz_user}成功登錄',
	'login_strike' => '累計5次密碼錯誤,15分鐘內不能登錄',
	'login_invalid' => '用戶名或密碼有誤,您共有5次嘗試機會.如果尚未註冊,請通過PC訪問{$boardurl}register.php,註冊後再登錄',
	'logout' => '退出',
	'logout_succeed' => '成功退出登錄',

	'forum_thread_sticky' => '置頂&gt;',
	'forum_thread_digest' => '精華&gt;',
	'forum_nopermission' => '無權訪問本論壇',
	'forum_nonexistence' => '指定論壇不存在',

	'thread_nopermission' => '無權查看本主題',
	'thread_nonexistence' => '指定主題不存在',

	'post_reply' => '回復本帖',
	'post_new' => '發新話題',
	'post_sm_isnull' => '未填寫標題或內容',
	'post_subject_toolang' => '標題超過80字節',
	'post_message_toolang' => '內容超過{$minpostsize}字節限制',
	'post_message_tooshort' => '內容少於{$maxpostsize}字節限制',
	'post_type_isnull' => '未選擇主題分類',
	'post_flood_ctrl' => '兩次發表少於{$floodctrl}秒',
	'post_mod_succeed' => '成功提交人工審核',
	'post_mod_forward' => '回到當前論壇',
	'post_thread_closed' => '本主題已關閉',
	'post_thread_closed_by_dateline' => '本主題發佈於$forum[autoclose]天前<br />已被自動關閉',
	'post_thread_closed_by_lastpost' => '本主題最後回復於$forum[autoclose]天前<br />已被自動關閉',
	'post_newbie_span' => '註冊{$newbiespan}小時後才可發帖',
	'post_hide_nopermission' => '無權使用[hide]代碼',
	'post_newthread_nopermission' => '無權在本論壇發新話題',
	'post_newthread_succeed' => '主題發表成功<br /><a href=\"index.php?action=forum&amp;fid=$fid\">返回論壇</a>',
	'post_newthread_forward' => '查看主題',
	'post_newreply_nopermission' => '無權在本論壇發表回復',
	'post_newreply_succeed' => '主題回復成功<br /><a href=\"index.php?action=forum&amp;fid=$fid\">返回論壇</a>',
	'post_newreply_forward' => '查看回復',

	'pm' => '短消息',
	'pm_home' => '短消息首頁',
	'pm_unread' => '未讀消息',
	'pm_all' => '全部消息',
	'pm_send' => '發送短消息',
	'pm_to' => '收信人',
	'pm_flood_ctrl' => '兩次發表少於{$floodctrl}秒',

	'pm_sm_isnull' => '未填寫標題或內容',
	'pm_nonexistence' => '短消息不存在',
	'pm_send_nonexistence' => '收信人不存在',
	'pm_send_ignore' => '收件人拒收短消息',
	'pm_send_succeed' => '短消息成功發送',
	'pm_delete_succeed' => '短消息成功刪除',

	'stats' => '論壇統計',
	'stats_threads' => '主題數',
	'stats_posts' => '帖子數',
	'stats_members' => '會員數',

	'myphone' => '我的手機',
	'goto' => 'WAP跳轉',


);

?>