<?
header('Content-Type: text/html; charset=gbk');

$msg = '';

if($_POST['action'] == 'save') {

	if(is_writeable('mail_config.inc.php')) {

		$_POST['sendmail_silent_new'] = intval($_POST['sendmail_silent_new']);
		$_POST['mailsend_new'] = intval($_POST['mailsend_new']);
		$_POST['maildelimiter_new'] = intval($_POST['maildelimiter_new']);
		$_POST['mailusername_new'] = intval($_POST['mailusername_new']);
		$_POST['mailcfg_new']['server'] = addslashes($_POST['mailcfg_new']['server']);
		$_POST['mailcfg_new']['port'] = intval($_POST['mailcfg_new']['port']);
		$_POST['mailcfg_new']['auth'] = intval($_POST['mailcfg_new']['auth']);
		$_POST['mailcfg_new']['from'] = addslashes($_POST['mailcfg_new']['from']);
		$_POST['mailcfg_new']['auth_username'] = addslashes($_POST['mailcfg_new']['auth_username']);
		$_POST['mailcfg_new']['auth_password'] = addslashes($_POST['mailcfg_new']['auth_password']);

$savedata = <<<EOF
<?php

\$sendmail_silent = $_POST[sendmail_silent_new];
\$maildelimiter = $_POST[maildelimiter_new];
\$mailusername = $_POST[mailusername_new];
\$mailsend = $_POST[mailsend_new];

EOF;

		if($_POST['mailsend_new'] == 2) {

$savedata .= <<<EOF

\$mailcfg['server'] = '{$_POST[mailcfg_new][server]}';
\$mailcfg['port'] = {$_POST[mailcfg_new][port]};
\$mailcfg['auth'] = {$_POST[mailcfg_new][auth]};
\$mailcfg['from'] = '{$_POST[mailcfg_new][from]}';
\$mailcfg['auth_username'] = '{$_POST[mailcfg_new][auth_username]}';
\$mailcfg['auth_password'] = '{$_POST[mailcfg_new][auth_password]}';

EOF;

		} elseif($_POST['mailsend_new'] == 3) {

$savedata .= <<<EOF

\$mailcfg['server'] = '{$_POST[mailcfg_new][server]}';
\$mailcfg['port'] = '{$_POST[mailcfg_new][port]}';

EOF;

		}

		setcookie('mail_cfg', base64_encode(serialize($_POST['mailcfg_new'])), time() + 86400);

$savedata .= <<<EOF

?>
EOF;

		$fp = fopen('mail_config.inc.php', 'w');
		fwrite($fp, $savedata);
		fclose($fp);

		$msg = '�]�m�O�s�����I';

		if($_POST['sendtest']) {

			define('IN_DISCUZ', true);

			define('DISCUZ_ROOT', './');
			define('TPLDIR', './templates/default');
			require './include/global.func.php';

			$test_tos = explode(',', $_POST['mailcfg_new']['test_to']);
			$date = date('Y-m-d H:i:s');

			switch($_POST['mailsend_new']) {
				case 1:
					$title = '�зǤ覡�o�e Email';
					$message = "�q�L PHP ��Ƥ� UNIX sendmail �o�e\n\n�Ӧ� {$_POST['mailcfg_new']['test_from']}\n\n�o�e�ɶ� ".$date;
					break;
				case 2:
					$title = '�q�L SMTP �A�Ⱦ�(SOCKET)�o�e Email';
					$message = "�q�L SOCKET �s�� SMTP �A�Ⱦ��o�e\n\n�Ӧ� {$_POST['mailcfg_new']['test_from']}\n\n�o�e�ɶ� ".$date;
					break;
				case 3:
					$title = '�q�L PHP ��� SMTP �o�e Email';
					$message = "�q�L PHP ��� SMTP �o�e Email\n\n�Ӧ� {$_POST['mailcfg_new']['test_from']}\n\n�o�e�ɶ� ".$date;
					break;
			}

			$bbname = '�l���o����';
			sendmail($test_tos[0], $title.' @ '.$date, "$bbname\n\n\n$message", $_POST['mailcfg_new']['test_from']);
			$bbname = '�l��s�o����';
			sendmail($_POST['mailcfg_new']['test_to'], $title.' @ '.$date, "$bbname\n\n\n$message", $_POST['mailcfg_new']['test_from']);

			$msg = '�]�m�O�s�����I<br>���D���u'.$title.' @ '.$date.'�v�����նl��w�g�o�X�I';

		}

	} else {

		$msg = '�L�k�g�J�l��t�m��� mail_config.inc.php�A�n�ϥΥ��u��г]�m����󪺥i�g�J�v���C';

	}

}

include './mail_config.inc.php';

?>
<html>
<head>
<title>Discuz! Board Mail Config and Test Tools</title>
<style>
body,table,td	{COLOR: #3A4273; FONT-FAMILY: Tahoma, Verdana, Arial; FONT-SIZE: 12px; LINE-HEIGHT: 20px; scrollbar-base-color: #E3E3EA; scrollbar-arrow-color: #5C5C8D}
tr		{background-color: #E3E3EA}
th		{background-color: #3A4273; color: #FFFFFF}
input		{border: 1px solid #CCCCCC}
.button 	{background-color: #3A4273; color: #FFFFFF}
.text		{width: 100%}
.checkbox,.radio{border: 0px}
</style>
<script>
function $(id) {
	return document.getElementById(id);
}
</script>
</head>

<body>
<?

if($msg) {
	echo '<center><font color="#FF0000">'.$msg.'</font></center>';
}

?>
<table width="60%" cellspacing="1" bgcolor="#000000" border="0" align="center">
<form method="post">
<input type="hidden" name="action" value="save"><input type="hidden" name="sendtest" value="0">
<tr><th colspan="2">�l��t�m/���դu��</th></tr>
<?

$saved_mailcfg = empty($_COOKIE['mail_cfg']) ? array(
	'server' => 'smtp.21cn.com',
	'port' => '25',
	'auth' => 1,
	'from' => 'Discuz <username@21cn.com>',
	'auth_username' => 'username@21cn.com',
	'auth_password' => 'password',
	'test_from' => 'user <my@mydomain.com>',
	'test_to' => 'user1 <test1@test1.com>, user2 <test2@test2.net>'
) : unserialize(base64_decode($_COOKIE['mail_cfg']));

echo '<tr><td width="40%">�̽��l��o�e�����������~����</td><td>';
echo ' <input class="checkbox" type="checkbox" name="sendmail_silent_new" value="1"'.($sendmail_silent ? ' checked' : '').'><br>';
echo '</tr>';
echo '<tr><td>�l���Y�����j��</td><td>';
echo ' <input class="radio" type="radio" name="maildelimiter_new" value="1"'.($maildelimiter ? ' checked' : '').'> �ϥ� CRLF �@�����j��<br>';
echo ' <input class="radio" type="radio" name="maildelimiter_new" value="0"'.(!$maildelimiter ? ' checked' : '').'> �ϥ� LF �@�����j��<br>';
echo '</tr>';
echo '<tr><td>����H���]�t�Τ�W</td><td>';
echo ' <input class="checkbox" type="checkbox" name="mailusername_new" value="1"'.($mailusername ? ' checked' : '').'><br>';
echo '</tr>';

echo '<tr><td>�l��o�e�覡</td><td>';
echo ' <input class="radio" type="radio" name="mailsend_new" value="1"'.($mailsend == 1 ? ' checked' : '').' onclick="$(\'hidden1\').style.display=\'none\';$(\'hidden2\').style.display=\'none\'"> �q�L PHP ��Ƥ� UNIX sendmail �o�e(���˦��覡)<br>';
echo ' <input class="radio" type="radio" name="mailsend_new" value="2"'.($mailsend == 2 ? ' checked' : '').' onclick="$(\'hidden1\').style.display=\'\';$(\'hidden2\').style.display=\'\'"> �q�L SOCKET �s�� SMTP �A�Ⱦ��o�e(��� ESMTP ����)<br>';
echo ' <input class="radio" type="radio" name="mailsend_new" value="3"'.($mailsend == 3 ? ' checked' : '').' onclick="$(\'hidden1\').style.display=\'\';$(\'hidden2\').style.display=\'none\'"> �q�L PHP ��� SMTP �o�e Email(�� win32 �U����, ����� ESMTP)<br>';
echo '</tr>';

$mailcfg['server'] = $mailcfg['server'] == '' ? $saved_mailcfg['server'] : $mailcfg['server'];
$mailcfg['port'] = $mailcfg['port'] == '' ? $saved_mailcfg['port'] : $mailcfg['port'];
$mailcfg['auth'] = $mailcfg['auth'] == '' ? $saved_mailcfg['auth'] : $mailcfg['auth'];
$mailcfg['from'] = $mailcfg['from'] == '' ? $saved_mailcfg['from'] : $mailcfg['from'];
$mailcfg['auth_username'] = $mailcfg['auth_username'] == '' ? $saved_mailcfg['auth_username'] : $mailcfg['auth_username'];
$mailcfg['auth_password'] = $mailcfg['auth_password'] == '' ? $saved_mailcfg['auth_password'] : $mailcfg['auth_password'];

echo '<tbody id="hidden1" style="display:'.($mailsend == 1 ? ' none' : '').'">';
echo '<tr><td>SMTP �A�Ⱦ�</td><td>';
echo ' <input class="text" type="text" name="mailcfg_new[server]" value="'.$mailcfg['server'].'"><br>';
echo '</tr>';
echo '<tr><td>SMTP �ݤf, �q�{���ݭק�</td><td>';
echo ' <input class="text" type="text" name="mailcfg_new[port]" value="'.$mailcfg['port'].'"><br>';
echo '</tr>';
echo '</tbody>';
echo '<tbody id="hidden2" style="display:'.($mailsend != 2 ? ' none' : '').'">';
echo '<tr><td>�O�_�ݭn AUTH LOGIN ����</td><td>';
echo ' <input class="checkbox" type="checkbox" name="mailcfg_new[auth]" value="1"'.($mailcfg['auth'] ? ' checked' : '').'><br>';
echo '</tr>';
echo '<tr><td>�o�H�H�a�} (�p�G�ݭn����,���������A�Ⱦ��a�})</td><td>';
echo ' <input class="text" type="text" name="mailcfg_new[from]" value="'.$mailcfg['from'].'"><br>';
echo '</tr>';
echo '<tr><td>���ҥΤ�W</td><td>';
echo ' <input class="text" type="text" name="mailcfg_new[auth_username]" value="'.$mailcfg['auth_username'].'"><br>';
echo '</tr>';
echo '<tr><td>���ұK�X</td><td>';
echo ' <input class="text" type="text" name="mailcfg_new[auth_password]" value="'.$mailcfg['auth_password'].'"><br>';
echo '</tr>';
echo '</tbody>';

?>
<tr><td colspan="2" align="center">
<input class="button" type="submit" name="submit" value="�O�s�]�m">
</td></tr>
<?

echo '<tr><td>���յo��H</td><td>';
echo ' <input class="text" type="text" name="mailcfg_new[test_from]" value="'.$saved_mailcfg['test_from'].'"><br>';
echo '</tr>';
echo '<tr><td>���զ���H</td><td>';
echo ' <input class="text" type="text" name="mailcfg_new[test_to]" value="'.$saved_mailcfg['test_to'].'"><br>';
echo '</tr>';

?>
<tr><td colspan="2" align="center">
<input class="button" type="submit" name="submit" onclick="this.form.sendtest.value = 1" value="�O�s�]�m�ô��յo�e">
</td></tr>
</form>
</table>

</body>